import { browser, protractor, WebElement, element, by, ExpectedConditions, WebElementPromise } from 'protractor';
import { isArrowFunction } from 'typescript';
var Excel = require('exceljs');
let sheet,workbook;

export class excelWrapper{

    
    constructor() {        
       workbook = new Excel.Workbook();
    }

    async getExcelCellRowForSpecificColumn(filePath,sheetName,sColumnName,sColumnValue)
    {     
     
       return await workbook.xlsx.readFile(filePath).then(function(){ 
            sheet = workbook.getWorksheet(sheetName);
            let iCol = 0;
            let iRow = 0;
                for (let i = 1; i <= sheet.getRow(1).actualCellCount; i++) { 
                    if(sColumnName==sheet.getRow(1).getCell(i).value)
                    {
                            iCol = i;
                            break;
                    }                          
                }
           
                if(iCol>0)  
                {  
                    for (let i = 1; i <= sheet.rowCount; i++) {                     
                      if(sColumnValue=="" || sColumnValue==null )
                      {
                        return iRow;
                      }
                      else if(sColumnValue==sheet.getRow(i).getCell(iCol).value)
                      {
                        iRow=i;
                        break;
                      }
                     }   
                }
                console.log("Row No for for specific data "+iRow);
            return iRow;
        });
       
    }

async verifyExcelCellValuesofSingleRowForSpecifiedColumn(filePath,sheetName,sColumnNames,sColumnValues)
    { 
    
        let columnList = sColumnNames.split("~");
        let valueList = sColumnValues.split("~");
        let bReturnFlag;
        var file = filePath.split("/");
  

       let rowNo = await this.getExcelCellRowForSpecificColumn(filePath,sheetName,columnList[0],valueList[0]);
       console.log("row "+rowNo);

       if(rowNo==0)
        {
                console.log("No row found for Specified data "+rowNo); 
                return false;
        }  
       return await workbook.xlsx.readFile(filePath).then(function(){ 
            sheet = workbook.getWorksheet(sheetName);
            let iCol = 0;
        
            for (let k = 0; k < columnList.length; k++) {
                let bFlag = false;
                
                for (let i = 1; i <= sheet.getRow(1).actualCellCount; i++) { 
                    if(columnList[k]==sheet.getRow(1).getCell(i).value)
                    {
                            iCol = i;
                            break;
                    }                          
                }
               
                if(iCol>0)  
                {                      
                      if(valueList[k]=="" || valueList[k]==null )
                      {
                        if(sheet.getRow(rowNo).getCell(iCol)=="")
                        {
                            bFlag = true;
                           
                        }
                      }
                        else if(valueList[k]==sheet.getRow(rowNo).getCell(iCol).value)
                        {
                            bFlag = true;
                           
                        }
                        
                }
                if(bFlag)
                {
                       console.log("verfied cell value - "+valueList[k]+" under column - "+columnList[k]+" in excel -"+file[file.length-1]);
                      
                }
                else if(iCol==0)
                {
                        console.log(columnList[k]+" column not found in excel -"+file[file.length-1]);
                   
                }
                else   
                {
                        console.log(valueList[k]+" cell value not found under column - "+columnList[k]+" in excel -"+file[file.length-1])
                    
                }
                bReturnFlag = bFlag;
            }
            return bReturnFlag;
        });
       
}

async readExcelHeader(fileName,sheetName)
{ 
    let header ="";

   await workbook.xlsx.readFile(fileName).then(function(){ 
        sheet = workbook.getWorksheet(sheetName);
        for (let i = 1; i <= sheet.getRow(1).actualCellCount;i++) { 
            if(i==1)
                header=sheet.getRow(1).getCell(i).value;   
            else
                header+="~"+sheet.getRow(1).getCell(i).value;             

        }
        console.log(header)
    });
    return header;
}

       } 

