import { Console } from 'console';
import { key } from 'nconf';
import { browser, protractor, WebElement, element, by, ExpectedConditions, WebElementPromise } from 'protractor';

export class wrapper
{
    iDefaultTimeout : number;
    iMaxTimeout : number;
    iMinTimeout : number;
    
    constructor()
    {
        this.iDefaultTimeout = 5000;
        this.iMaxTimeout = 10000;//350000;
        this.iMinTimeout = 1000;
    }

    async getWebElements(objLocator)
    {
        return await element.all(objLocator);
    }

    async waitForElementPresence(objLocator, iTimeout)
    {
            var EC = protractor.ExpectedConditions;    
            await browser.wait(EC.presenceOf(element(objLocator)), iTimeout).catch(error => { console.log('Error : ', error.message); return false; });  
            return true; 
    }

    async getElementText(objLocator, iTimeout)
    {
        try
        {
            this.waitForElementPresence(objLocator, iTimeout);
            let objElement = await element(objLocator);
            console.log(await objElement.getText());
            return await objElement.getText();
        }
        catch(exception)
        {
            console.log("Error while getting text of element '"+objLocator+"'" + exception);
            return null;
        }       
    }

    async clickOnElement(objLocator, iTimeout)
    {
        try
        {
            await this.waitForElementToBeClickable(objLocator, iTimeout);
            let objElement = element(objLocator);
            browser.executeScript("arguments[0].scrollIntoView();", objElement);
            await objElement.click();
            return true;
        }
        catch(exception)
        {
            console.log("Error while clicking on element '"+objLocator+"'"+exception);
            return false;
        }
        
        
    }

    async doubleClickOnElement(objLocator, iTimeout)
    {
        // var ele;
        // if (arguments.length === 0) {
        //     ele = objElement;
        // }
        // else if (arguments.length === 1) {
        //     iTimeout = 20000;
        // }
        try
        {
            this.waitForElementToBeClickable(objLocator, iTimeout);
            let objElement = await element(objLocator);
            //console.log(objElement)
            await browser.executeScript("arguments[0].scrollIntoView();", objElement);
            return await browser.actions().doubleClick(objElement).perform();
            //return true;
        }
        catch(exception)
        {
            console.log("Error while double clicking on element '"+objLocator+"'"+exception);
            return false;
        }
        
        
    }

    async setInputValue(objLocator, sVal: string, iTimeout)
    {
        try
        {
            let bResult;
            await this.waitForElementPresence(objLocator, iTimeout);
            let objElement = await element(objLocator);
            await objElement.clear();
            await objElement.sendKeys(sVal);
            return true;
            // return await objElement.getAttribute('textContent').then(function(sText){
            //     console.log(sText)
            //     if(sText == sVal)
            //         return true;
            //     else
            //         return false;
            // });
        }
        catch(exception)
        {
            console.log("Error while setting input value '"+sVal+"' in object '"+objLocator+"'"+exception);
            return false;
        }
        
    }

    async setInputValueWithoutClear(objLocator, sVal: string, iTimeout)
    {
        try
        {
            let bResult;
            this.waitForElementPresence(objLocator, iTimeout);
            let objElement = await element(objLocator);
            //objElement.clear();
            return await objElement.sendKeys(sVal);            
        }
        catch(exception)
        {
            console.log("Error while setting input value '"+sVal+"' in object '"+objLocator+"'"+exception);
            return false;
        }
        
    }

    async waitForElementToBeClickable(objlocator, iTimeout)
    {
        var EC = protractor.ExpectedConditions;
        // Waits for the element with id 'abc' to be clickable.
        await browser.wait(EC.elementToBeClickable(element(objlocator)), iTimeout).catch(error => { console.log('Error : ', error.message); return false; });
        return true;
    }

    async getWebelement(objLocator, iTimeout)
    {
        this.waitForElementPresence(objLocator, iTimeout);
        let objWE = await element(objLocator);
        return objWE;
    }

    async getTableColumnCount(objTableHeader, iTimeout):Promise<number>
    {
        this.waitForElementPresence(objTableHeader, iTimeout);
        var iTotalCount:number;
        await element.all(objTableHeader).count().then(function(iColCount:number){iTotalCount = iColCount;});
        return iTotalCount;
    }

    async scrollTableTillLastVisibleColumn(objTableHeader, iTimeout)
    {
        await this.waitForElementPresence(objTableHeader, iTimeout);
        let objLastVisibleCol = await element.all(objTableHeader).last();
        await this.getElementAttribute(objLastVisibleCol, "col-id", iTimeout).then(function(sAttrb){console.log("Last Col:"+sAttrb)});
        await this.scrollTillElement(objLastVisibleCol);
    }

    async getTableColumnNumber(objTableHeader, sColumnName, iTimeout):Promise<number>
    {
        let iColCount, iColNum = -1;
        await this.getTableColumnCount(objTableHeader, iTimeout).then(function(iCnt){iColCount = iCnt});
        console.log(iColCount);
        var sColHeader;
        for(var iCount = 0; iCount<iColCount; iCount++)
        {
            await element.all(objTableHeader).then(function(objElements){
                //console.log(sText);
                sColHeader = objElements[iCount];
            });
            await sColHeader.getText().then(function(sTxt){
                console.log(sTxt);
                if(sTxt == sColumnName)
                {
                    iColNum = iCount;
                    iCount = iColCount; 
                }
            });
        }
        return iColNum;
    }

    async getTableRowCount(objTable, objTblLastRow, iTimeout):Promise<number>
    {
        await this.waitForElementPresence(objTable, iTimeout);
        var iTotalCount:number, iPrevCount = 0;
        // let objLastRow = await element.all(objTable).last();
        // browser.executeScript("arguments[0].scrollIntoView();", objLastRow);
        await element.all(objTable).count().then(function(iRowCount:number){iTotalCount = iRowCount;});
        do
        { 
            let objLastRow = element.all(objTable).last();
            browser.executeScript("arguments[0].scrollIntoView();", objLastRow);
            iPrevCount = iTotalCount;
            await element.all(objTable).count().then(function(iRowCount:number){iTotalCount = iRowCount;});
        }while(iPrevCount < iTotalCount);
        await this.getElementAttribute(objTblLastRow, "row-index", iTimeout).then(function(sVal){iTotalCount = parseInt(sVal);});

        return iTotalCount;
    }

    async getElementAttribute(objLocator, sAttribute, iTimeout):Promise<string>
    {
        if(await this.waitForElementPresence(objLocator, iTimeout))
        {
            var sAttrb:string;
            let objWebelement = element(objLocator);
            await browser.executeScript("arguments[0].scrollIntoView();", objWebelement);
            await objWebelement.getAttribute(sAttribute).then(function(sAttr){sAttrb = sAttr;console.log(sAttrb)});
            return sAttrb;
        }
        else
            return null;			
    }

    async isElementPresent(objLocator, iTimeout)
    {
        try
        {
            let bResult;
            await this.waitForElementPresence(objLocator, iTimeout).then(function(bRes){
													   
																	
                bResult = bRes;
            });
            if(bResult)
            {
                let objElement = await element(objLocator);
                return await objElement.isPresent().then(function(bRes){
                    return bRes;
                }).catch(error => { console.log('Error : ', error.message); return false; });
            }
            else
                return false;
               
        }
        catch(exception)
        {
            console.log("Element '"+objLocator+"' is not displayed "+exception);
            return false;
        }

    }

    async isElementPresentWithoutWait(objLocator)
    {
        try
        {
            let bResult;
            //this.waitForElementPresence(objLocator, iTimeout);
            let objElement = await element(objLocator);
            return await objElement.isPresent().then(function(bRes){
                return bRes;
            });
               
        }
        catch(exception)
        {
            console.log("Element '"+objLocator+"' is not displayed "+exception);
            return false;
        }

    }

    async scrollTillElement(objLocator)
    {
        let objElement = element(objLocator);
        await browser.executeScript("arguments[0].scrollIntoView();", objElement).catch(error => { console.log('Error : ', error.message); return false; });
        return true;
    }

    convertToCamelCase(sString)
    {
        return sString.replace(/(?:^\w|[A-Z]|\b\w)/g, function(word, index) 
        { 
            return index == 0 ? word.toLowerCase() : word.toUpperCase(); 
        }).replace(/\s+/g, ''); 
    }

    async isElementEnabled(objLocator, iTimeout)
    {
        this.waitForElementPresence(objLocator, iTimeout);
        let objElement = element(objLocator);
        return await objElement.isEnabled();
    }

    async javascriptClickOnElement(objLocator, iTimeout)
    {
        let bRresult = true;
        console.log("inside javascriptClickOnElement")
        this.waitForElementPresence(objLocator, iTimeout);
		await this.scrollTillElement(objLocator);										 
        let objElement = element(objLocator);
        await browser.executeScript("arguments[0].click();", objElement).catch(error => { console.log('Error : ', error.message); bRresult = false; });
        return bRresult;
    }

    async getWebelementCount(objLocator)
    {
        return await element.all(objLocator).count();
    }

    async setAttributeUsingJavaScript(objLocator, iTimeout, sAttributeName, sAttributeVal)
    {
        this.waitForElementPresence(objLocator, iTimeout);
        let objElement = element(objLocator);
        //await this.scrollTillElement(objElement);
        return browser.executeScript("arguments[0].setAttribute('"+sAttributeName+"', '"+sAttributeVal+"');", objElement);
    }

    async sendKeysInActiveElmnt(sKey)
    {
        switch(sKey)
        {
            case "Enter":
                await browser.actions().sendKeys(protractor.Key.ENTER).perform();
                break;
            case "Prev":
                await browser.actions().sendKeys(protractor.Key.HOME).perform();
                break;
            case "Next":
                await browser.actions().sendKeys(protractor.Key.END).perform();
                break;
            case "Alt":
                await browser.actions().sendKeys(protractor.Key.ALT).perform();
                break;
			case "Backspace":
                await browser.actions().sendKeys(protractor.Key.BACK_SPACE).perform();
                break;			 
            default :
                await browser.actions().sendKeys(sKey).perform();
        }
    }

    async isElementDisplayed(objLocator, iTimeout)
    {
        try
        {
            let bResult;
            this.waitForElementPresence(objLocator, iTimeout);
            let objElement = await element(objLocator);
            return await objElement.isDisplayed().then(function(bRes){
                return bRes;
            });
               
        }
        catch(exception)
        {
            console.log("Element '"+objLocator+"' is not displayed "+exception);
            return false;
        }

    }

    async waitTillInvisibilityOfElement(objLocator, iTimeout)
    {
        try
        {
            var EC = protractor.ExpectedConditions;    
            browser.wait(EC.invisibilityOf(element(objLocator)), iTimeout);   
        }
        catch(exception)
        {
            console.log("Error while waiting for invisibility of element '"+objLocator+"'" + exception);
        }
    }

    async clickOnElementWithoutWait(objLocator)
    {
        console.log("clickOnElementWithoutWait")
        try
        {
            //this.waitForElementToBeClickable(objLocator, iTimeout);
            let objElement = element(objLocator);
            browser.executeScript("arguments[0].scrollIntoView();", objElement);
            await objElement.click();
            return true;
        }
        catch(exception)
        {
            console.log("Error while clicking on element '"+objLocator+"'"+exception);
            return false;
        }
        
        
    }

    async javascriptClickOnElementWithoutWait(objLocator)
    {
        console.log("inside javascriptClickOnElementWithoutWait")
        //this.waitForElementPresence(objLocator, iTimeout);
        let objElement = element(objLocator);
        return browser.executeScript("arguments[0].click();", objElement);
    }

    // async jQueryGetVal(objcssSelector)
    // {
    //     console.log("$('"+objcssSelector+"')")
    //     // let optSel: string = ($('option:selected', this).val() as string);
    //     let sVal:string = ($('"+objcssSelector+"', this).val() as string);
    //     console.log(sVal);
    //     return sVal;
    // }

    async waitTillInvisibilityOfLoadingIcon(objLocator)
    {
        let iCounter = 0;
        //let objLoadIcon = by.xpath("//div[@class='spinner-border text-info']|//div[@class='spinner-border']");
        do
        {
            browser.sleep(this.iMinTimeout);
            iCounter = iCounter + 1;
        }while(await this.isElementPresentWithoutWait(objLocator) || iCounter < 20);
    }

    //Richa_29012021 - is checkbox selected
    async isCheckboxSelected(objCheckbox, iTimeout)
    {
        this.waitForElementPresence(objCheckbox, iTimeout);
        let objElement = await element(objCheckbox);
        return await objElement.isSelected();
    }

    //Richa_11022021 - get elements text
    async getElementsText(objLocator, sConsoleMessage)
    {
        return await element.all(objLocator).then(async function(objEle){
            let sElementText;
            for(let iCount = 0; iCount < objEle.length; iCount++)
            {
                let sEtext = await objEle[iCount].getText().then(function(sText){
                    console.log(sText);
                    return sText;
                });
                if(sElementText)
                    sElementText = sElementText + "~" + sEtext.trim();
                else
                    sElementText = sEtext.trim();   
            }
            console.info(sConsoleMessage + " " + sElementText);
            return sElementText;
        });
    }

     //Richa_22022021 - dragDrop
     async elementDragDrop(objSourceLocator, objTargetLocator, iTimeout)
     {
        let objSourceElem = await this.getWebelement(objSourceLocator, iTimeout);
        let objTargetElem = await this.getWebelement(objTargetLocator, iTimeout);
        await browser.actions().dragAndDrop(objSourceElem, objTargetElem).perform();
     }
     //Nidhi-04/03/2021 -Clear Text
     async clearText(objLocator, iTimeout)
    {
        try
        {
            this.waitForElementPresence(objLocator, iTimeout);
            let objElement = await element(objLocator);
            await objElement.clear();
            return true;
        }
        catch(exception)
        {
            console.log("Error while Clearing input value in object '"+objLocator+"'"+exception);
            return false;
        }
        
    }
    async clearTextUsingKeys(objLocator, iTimeout){
        this.waitForElementPresence(objLocator, iTimeout);
        let objElement = await element(objLocator);
        return await objElement.sendKeys(protractor.Key.chord(protractor.Key.CONTROL,"a")).then(()=>{
        objElement.sendKeys(protractor.Key.DELETE);
        return true;
    });
}
    //Nidhi-12/03/2021 click on the element without scrolling the page
async clickOnElementWithOutScroll(objLocator, iTimeout)
{
    try
    {
        await this.waitForElementToBeClickable(objLocator, iTimeout);
        let objElement = element(objLocator);
        await objElement.click();
        return true;
    }
    catch(exception)
    {
        console.log("Error while clicking on element '"+objLocator+"'"+exception);
        return false;
    }
    
    
}


     //Richa_17032021 - set input char by char
    async setInputCharByChar(objLocator, sVal: string, iTimeout)
    {
        try
        {
            let bResult;
            await this.waitForElementPresence(objLocator, iTimeout);
            let objElement = await element(objLocator);
            await objElement.clear();
            for(let iCount = 0; iCount < sVal.length; iCount++)
            {
                console.log(sVal[iCount]);
                
                await objElement.sendKeys(sVal[iCount]);
                //await browser.driver.sleep(this.iMinTimeout);
                await browser.driver.sleep(iTimeout);
            }
            
            return true;
            // return await objElement.getAttribute('textContent').then(function(sText){
            //     console.log(sText)
            //     if(sText == sVal)
            //         return true;
            //     else
            //         return false;
            // });
        }
        catch(exception)
        {
            console.log("Error while setting input value '"+sVal+"' in object '"+objLocator+"'"+exception);
            return false;
        }
        
    }

    async scrollWindowToTopLeft()
    {
        await browser.executeScript("window.scrollTo(0,0);").catch(error => { console.log('Error : ', error.message); return false; });
        return true;
    }
    async getBackgroundColourofElement(objLocator, iTimeout):Promise<string>
    {
        await this.waitForElementPresence(objLocator, iTimeout);
        var sBckgColor:string;
        let objWebelement = element(objLocator);console.log("inside")
        await browser.executeScript("arguments[0].scrollIntoView();", objWebelement);                                                                                    
        await objWebelement.getCssValue("background-color").then(function(sBgColor){
            switch(sBgColor)
            {
                case "rgba(115, 179, 87, 1)":
                    sBckgColor = "green";
                    break;
 
                case "rgba(0, 187, 212, 1)":
                    sBckgColor = "blue";
                    break;
                case "rgb(0,187, 212)":
                    sBckgColor = "blueColor";
                    break;
                case "rgba(230, 50, 61, 1)":
                    sBckgColor = "red";
                    break;
 
                default :
                    sBckgColor = sBgColor;
                    break;
            }
            console.log(sBckgColor)});
        return sBckgColor;
    }
 
    async getBackgroundColour(objLocator, iTimeout):Promise<string>
    {
        await this.waitForElementPresence(objLocator, iTimeout);
        var sBckgColor:string;
        let objWebelement = element(objLocator);console.log("inside")
        await browser.executeScript("arguments[0].scrollIntoView();", objWebelement);
        await objWebelement.getCssValue("background").then(function(sBgColor){
            switch(sBgColor)
            {
                case "rgba(115, 179, 87, 1)":
                    sBckgColor = "green";
                    break;
 
                case "rgba(0, 187, 212, 1)":
                    sBckgColor = "blue";
                    break;
                case "rgb(0,187, 212)":
                    sBckgColor = "blueColor";
                    break;
                case "rgba(230, 50, 61,1)":
                    sBckgColor = "red";
                    break;
 
                default :
                    sBckgColor = sBgColor;
                    break;
            }
            console.log(sBckgColor)});
        return sBckgColor;
    }

	async clickOnElementUsingActionClass(objLocator, iTimeout)
    {
        // var ele;
        // if (arguments.length === 0) {
        //     ele = objElement;
        // }
        // else if (arguments.length === 1) {
        //     iTimeout = 20000;
        // }
        try
        {
            this.waitForElementToBeClickable(objLocator, iTimeout);
            let objElement = await element(objLocator);
            //console.log(objElement)
            await browser.executeScript("arguments[0].scrollIntoView();", objElement);
            return await browser.actions().click(objElement).perform();
            //return true;
        }
        catch(exception)
        {
            console.log("Error while double clicking on element '"+objLocator+"'"+exception);
            return false;
        }
        
        
    }

    //Nidhi-28/04/2021 Will give the count of the elements
    async getElementsCount(objLocator)
    {
        return await element.all(objLocator).then(async function(objEle){
        let objEleCount = objEle.length;
        console.log(objEleCount);
        return objEleCount;
        });
    }
//Nidhi-28/04/2021 - Set Input using Javascript
    async javascriptSetInput(objLocator,sVal: string, iTimeout)
    {
        let bRresult = true;
        console.log("inside javascriptClickOnElement")
        this.waitForElementPresence(objLocator, iTimeout);								 
        let objElement = element(objLocator);
        await browser.executeScript("arguments[0].value='"+sVal+"';", objElement).catch(error => { console.log('Error : ', error.message); bRresult = false; });
        return bRresult;
    }

    async getValueAttributeUsingJavascript(objLocator, iTimeout)
 {
    this.waitForElementPresence(objLocator, iTimeout);
    let objElement = element(objLocator); 
    return browser.executeScript("return arguments[0].value;", objElement);
 }
}    
