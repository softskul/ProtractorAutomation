// Because this file imports from `protractor` npm package, 
// you'll need to have it as a project dependency. 
//
// `baseUrl` property is passed in as a param
import { Config, browser } from 'protractor';
import { SpecReporter } from 'jasmine-spec-reporter';

var HtmlReporter = require('protractor-beautiful-reporter');
var screenshots = require('protractor-take-screenshots-on-demand');

export let config: Config = {
  allScriptsTimeout: 110000,
  framework: 'jasmine',
  //directConnect:true,
  capabilities: {
    browserName: 'chrome',
    'shardTestFiles': true,
    'maxInstances': 10,
    chromeOptions: { w3c: false }
  },
  jasmineNodeOpts: {
    showColors: true,
    defaultTimeoutInterval: 1000000,
    isVerbose: true,
    print: function() {}
  },

  // Keep max browsers running to 1 because
  // multiple browsers running at once was pausing/failing for no reason
  
  // You could set no globals to true to avoid jQuery '$' and protractor '$'
  // collisions on the global namespace.
  //noGlobals: true,

  onPrepare: async () => {
    // Use `jasmine-spec-reporter` as the spec result reporter
    await browser.waitForAngularEnabled(false);
    jasmine.getEnv().addReporter(new SpecReporter({ spec: { displayStacktrace: true } }));
    jasmine.getEnv().addReporter(new HtmlReporter({
      preserveDirectory: false,
            takeScreenShotsOnlyForFailedSpecs: true,
            screenshotsSubfolder: 'images',
            jsonsSubfolder: 'jsons',
            baseDirectory: 'reports',
      //baseDirectory: 'tmp/screenshots'
   }).getJasmine2Reporter());


    // Set browser window width to 1200 and height to 900px
    browser.driver.manage().window().maximize();
    return browser.takeScreenshot();
  },
  params: {
      // baseUrl: 'https://spwebappdev.amat.com/DemoRequest_Dev/#/'
      baseUrl: 'https://spwebappdev.amat.com/DemoRequest_Dev/#/login-view'
  },

  suites: {
    CreateNewDemo: 'specs/**/createNewDemoRequest_TCs.js',
    myDraft: 'specs/**/myDraftRequest_TCs.js',
    myDemo:  'specs/**/myDemoRequest_TCs.js',
    allView: 'specs/**/allView_TCs.js',
    manageView: 'specs/**/manageView_TCs.js',
    grantDemoAccess: 'specs/**/grantDemoAccess_TCs.js',
    adminAccessView: 'specs/**/adminAccessView_TCs.js',
    homePage: 'specs/**/homePage_TCs.js',
    myDemoTask:  'specs/**/myDemoTasks_TCs.js',
    importantLink: 'specs/**/importantLinks_TCs.js'
  },


  seleniumAddress: 'http://localhost:4444/wd/hub'
};
