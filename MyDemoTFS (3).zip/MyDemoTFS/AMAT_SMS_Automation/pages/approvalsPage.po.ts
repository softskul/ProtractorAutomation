import { wrapper } from '../utils/wrapper.util';
import { element, by, browser } from 'protractor';
import { BrowserUtil } from '../utils/browser.util';
let sConsole;

let objWrapper:wrapper;
export class approvalsPage{
    constructor()
    {
        objWrapper = new wrapper();
    }

    

    async clickOnDemoRequestRow(sDemoName)
    {
        let objDemoRequestRow = by.xpath("//div[@col-id='demoName' and contains(text(), '"+sDemoName+"')]");
        return await objWrapper.javascriptClickOnElement(objDemoRequestRow, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
	
                sConsole = "Pass : Clicked on demo request row with demo name as '"+sDemoName+"'.";
	   
	
            else
	
                sConsole = "Fail : Fail to click on demo request row with demo name as '"+sDemoName+"'.";
            console.info(sConsole);
            return sConsole;
	
        });
    }

    async clickOnDemoApprovalDD()
    {
        let cmbDemoApproval = by.xpath("//label[contains(text(), 'Demo Approval')]/following-sibling::div/select");
        //await objWrapper.javascriptClickOnElement(cmbDemoApproval, objWrapper.iDefaultTimeout);
        return await objWrapper.javascriptClickOnElement(cmbDemoApproval, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
	
                sConsole = "Pass : Clicked on Demo Approval drop down.";
		  
	
            else
			 
                sConsole = "Fail : Fail to click on Demo Approval drop down.";
            console.info(sConsole);
            return sConsole;    
			 
        });
    }

    async selectDemoApprovalOption(sOption)
    {
        let objOption = by.xpath("//label[contains(text(), 'Demo Approval')]/following-sibling::div/select/option[text()='"+sOption+"']");
        return await objWrapper.clickOnElement(objOption, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
			 
                sConsole = "Pass : Selected demo approval option as '"+sOption+"'.";
							
			 
            else
			 
                sConsole = "Fail : Fail to select demo approval option as '"+sOption+"'.";
            console.info(sConsole);
            return sConsole;
			 
        });
    }
    async selectDemoApproval(sDemoApproval)
    {
        //expect(await this.clickOnDemoApprovalDD()).toBeTruthy();
        expect(await this.clickOnDemoApprovalDD()).toContain("Pass");
        return await this.selectDemoApprovalOption(sDemoApproval);
    }

    async clickOnPriorityDD()
    {
        let cmbPriority = by.xpath("//label[contains(text(), 'Priority')]/following-sibling::div/select");
        return await objWrapper.javascriptClickOnElement(cmbPriority, objWrapper.iDefaultTimeout).then(function(bRes){
        // return await objWrapper.clickOnElement(cmbPriority, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
				
                sConsole = "Pass : Clicked on Priority drop down.";
            else
				
				   
				
                sConsole = "Fail : Fail to click on Priority drop down.";
            console.info(sConsole);
            return sConsole;
				
        });
    }

    async selectPriorityOption(sOption)
    {
        let objOption = by.xpath("//label[contains(text(), 'Priority')]/following-sibling::div/select/option[text()='"+sOption+"']");
        return await objWrapper.clickOnElement(objOption, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
			 
                sConsole = "Pass : Selected Priority option as '"+sOption+"'.";
							
			 
            else
			 
                sConsole = "Fail : Fail to select Priority option as '"+sOption+"'.";
            console.info(sConsole);
            return sConsole;
			 
        });
    }

    async selectPriority(sDemoApproval)
    {
        //expect(await this.clickOnPriorityDD()).toBeTruthy();
        expect(await this.clickOnPriorityDD()).toContain("Pass");
        return await this.selectPriorityOption(sDemoApproval);
    }

    async setDemoOwnerVal(sDemoOwner)
    {
        let txtDemoOwner = by.xpath("//label[text()='Demo Owner']/following-sibling::app-people-picker//input[@name='name']")
        await objWrapper.setInputValue(txtDemoOwner, sDemoOwner, objWrapper.iDefaultTimeout);
        return await objWrapper.getElementAttribute(txtDemoOwner, 'ng-reflect-model', objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sDemoOwner)
			 
                sConsole = "Pass : Set demo owner as '"+sDemoOwner+"'.";
							
			 
            else
			 
                sConsole = "Fail : Fail to set demo owner as '"+sDemoOwner+"'.";
            console.info(sConsole);
            return sConsole;
			 
        });
    }

    async selectDemoOwner(sDemoOwner)
    {
        let lstDemoOwner = by.xpath("//ul[@class='list-group']//a[contains(text(),'"+sDemoOwner+"')]/parent::li");
        await objWrapper.javascriptClickOnElement(lstDemoOwner, objWrapper.iDefaultTimeout);
        browser.sleep(5000);
        let objSelectedOwner = by.xpath("//label[text()='Demo Owner']/following-sibling::app-people-picker//input[@name='name_hide']");
        return await objWrapper.getElementAttribute(objSelectedOwner, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
            if(sText.match(sDemoOwner))
			 
                sConsole = "Pass : Clicked on Demo owner list option '"+sDemoOwner+"'.";
							
			 
            else
			 
                sConsole = "Fail : Fail to click on Demo owner list option '"+sDemoOwner+"'.";
            console.info(sConsole);
            return sConsole;
			 
        });
    }

    async setDemoOwner(sDemoOwner)
    {
        expect(await this.setDemoOwnerVal(sDemoOwner)).toBeTruthy();
        browser.sleep(5000);
        return await this.selectDemoOwner(sDemoOwner);
    }

    async setCATRATMngrVal(sCATRATMngr)
    {
        let txtCATRATMngr = by.xpath("//label[text()='CAT/RAT Manager']/following-sibling::app-people-picker//input[@name='name']")
        await objWrapper.setInputValue(txtCATRATMngr, sCATRATMngr, objWrapper.iDefaultTimeout);
        return await objWrapper.getElementAttribute(txtCATRATMngr, 'ng-reflect-model', objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sCATRATMngr)
            {
                console.info("Set CAT/RAT Manager as '"+sCATRATMngr+"'.");
                return true;
            }
            else
            {
                console.error("Fail to set CAT/RAT manager as '"+sCATRATMngr+"'.");
                return false;
            }
        });
    }

    async selectCATRATMngr(sCATRATMngr)
    {
        let lstCATRATMngr = by.xpath("//ul[@class='list-group']//a[contains(text(),'"+sCATRATMngr+"')]/parent::li");
        await objWrapper.javascriptClickOnElement(lstCATRATMngr, objWrapper.iDefaultTimeout);
        let objSelectedOwner = by.xpath("//label[text()='CAT/RAT Manager']/following-sibling::app-people-picker//input[@name='name_hide']");
        return await objWrapper.getElementAttribute(objSelectedOwner, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
            if(sText.match(sCATRATMngr))
            {
                console.info("Clicked on CAT/RAT Manager list option '"+sCATRATMngr+"'.");
                return true;
            }
            else
            {
                console.error("Fail to click on CAT/RAT Manager list option '"+sCATRATMngr+"'.");
                return false;
            }
        });
    }

    async setCATRATManager(sCATRATMngr)
    {
        expect(await this.setCATRATMngrVal(sCATRATMngr)).toBeTruthy();
        browser.sleep(5000);
        return await this.selectCATRATMngr(sCATRATMngr);
    }

    async clickOnExecutionRiskDD()
    {
        let cmbExecRisk = by.xpath("//label[contains(text(), 'Execution Risk')]/following-sibling::div/select");
        return await objWrapper.clickOnElement(cmbExecRisk, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
			 
                sConsole = "Pass : Clicked on Execution Risk drop down.";
							
			 
            else
			 
                sConsole = "Fail : Fail to click on Execution Risk drop down.";
            console.info(sConsole);
            return sConsole;
			 
        });
    }

    async selectExecutionRiskOption(sOption)
    {
        let objOption = by.xpath("//label[contains(text(), 'Execution Risk')]/following-sibling::div/select/option[text()='"+sOption+"']");
        return await objWrapper.clickOnElement(objOption, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
			 
                sConsole = "Pass : Selected Execution Risk option as '"+sOption+"'.";
							
			 
            else
			 
                sConsole = "Fail : Fail to select Execution Risk option as '"+sOption+"'.";
            console.info(sConsole);
            return sConsole;
			 
        });
    }

    async selectExecutionRisk(sExecRisk)
    {
        expect(await this.clickOnExecutionRiskDD()).toContain("Pass");
        expect(await this.selectExecutionRiskOption(sExecRisk)).toContain("Pass");
        return await this.clickOnExecutionRiskDD();
    }

    async verifyDemoApprovalStatus(sDemoName, sDemoApprovalStatus)
    {
        let tblDemoApproval = by.xpath("//div[@col-id='demoName' and contains(text(), '"+sDemoName+"')]/parent::div");
        let iRow = await objWrapper.getElementAttribute(tblDemoApproval, 'row-index', objWrapper.iDefaultTimeout).then(function(iRNo){
            return iRNo;
        });
        let tblDemoApproved = by.xpath("//div[@row-index='"+iRow+"']//div[@col-id='stageStatus' and contains(text(), '"+sDemoApprovalStatus+"')]");
        console.log("//div[@row-index='"+iRow+"']//div[@col-id='stageStatus' and contains(text(), '"+sDemoApprovalStatus+"')]");
        return await objWrapper.isElementPresent(tblDemoApproved, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Demo request with demo name'"+sDemoName+"' is having demo approval status as '"+sDemoApprovalStatus+"'.";
            else
                sConsole ="Fail : Fail to find demo request with demo name'"+sDemoName+"' is having demo approval status '"+sDemoApprovalStatus+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    async clickOnSaveApprovalView()
    {
        let btnSave = by.xpath("//h5[text()='Approval View']/parent::div/following-sibling::div[@class='modal-footer']//em[@class='fa fa-save']/parent::button");
        return await objWrapper.clickOnElement(btnSave, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on Save on Approval View.";
            else
                sConsole = "Fail : Fail to click on Save on Approval View.";
            console.info(sConsole);
            return sConsole;
        });
    }

    async clickOnStatusDDOnAllRequest()
    {
        let cmbStatus = by.css("select[name='status']");
        return await objWrapper.clickOnElement(cmbStatus, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
            {
                console.info("Clicked on Status drop down on All Request page.");
                return true;
            }
            else
            {
                console.error("Fail to click on Status drop down on All Request page.");
                return false;
            }
        });
    }

    async selectStatusOption(sOption)
    {
        let objOption = by.xpath("//select[@name='status']/option[contains(text(), '"+sOption+"')]");
        return await objWrapper.clickOnElement(objOption, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
            {
                console.info("Selected Status option as '"+sOption+"'.");
                return true;
            }
            else
            {
                console.error("Fail to select Status option as '"+sOption+"'.");
                return false;
            }
        });
    }

    async selectRequestStatus(sReqStatus)
    {
        expect(await this.clickOnStatusDDOnAllRequest()).toBeTruthy();
        return await this.selectStatusOption(sReqStatus);
        //return await this.clickOnExecutionRiskDD();
    } 
    
    async verifyDemoNumberPresentInTable(sDemoName) 
    {
        let objTblDemoName = by.xpath("//div[@col-id='demoName' and contains(text(), '"+sDemoName+"')]");
        return await objWrapper.isElementPresent(objTblDemoName, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
            {
                console.info("Demo request with demo name'"+sDemoName+"' present.");
                return true;
            }
            else
            {
                console.error("Fail to find demo request with demo name'"+sDemoName+"'.");
                return false;
            }
        });
    }

    async setJustificationInApprovalViewPopUp(sJustification)
    {
        let txtJustification = by.xpath("//label[text()='Justification']/following-sibling::div/textarea");
        await objWrapper.setInputValue(txtJustification, sJustification, objWrapper.iDefaultTimeout);
        return objWrapper.getElementAttribute(txtJustification, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sJustification)
            {
                console.info("Set justification value as '"+sJustification+"' on Approval View pop up.");
                return true;
            }
            else
            {
                console.error("Fail to set justification value as '"+sJustification+"' on approval view pop up.");
                return false;
            }
        });
    }
	
	async verifyApprovedByUserName(sDemoName, sApprovedByUserName)
    {
        let tblDemoXpath = by.xpath("//div[@col-id='demoName' and contains(text(), '"+sDemoName+"')]/parent::div");
          
      
        let iRow = await objWrapper.getElementAttribute(tblDemoXpath, 'row-index', objWrapper.iDefaultTimeout).then(function(iRNo){
            return iRNo;
        });
        let tblApprovedBy = by.xpath("//div[@row-index='"+iRow+"']//div[@col-id='approvedBy' and contains(text(), '"+sApprovedByUserName+"')]");
      
        return await objWrapper.isElementPresent(tblApprovedBy, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
            {
                console.info("Demo request with demo name'"+sDemoName+"' is approved by user '"+sApprovedByUserName+"'.");
                return true;
            }
            else
            {
                console.error("Fail to find demo request with demo name'"+sDemoName+"' approved by user '"+sApprovedByUserName+"'.");
                return false;
            }
        });
    }
}