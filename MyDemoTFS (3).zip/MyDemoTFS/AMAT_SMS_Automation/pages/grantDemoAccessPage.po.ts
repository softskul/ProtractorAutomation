import { wrapper } from '../utils/wrapper.util';
import { element, by, browser } from 'protractor';

let objWrapper:wrapper;
let sConsole;
export class grantDemoAccessPage{
    constructor()
    {
        objWrapper = new wrapper();
    }
//Nidhi-19/03/2021- selet the owner name from the dropdown on the all view pop up page
async setOwnerName(sLabelName, sOwnerName)
    {
      
    let txtLabel = by.xpath("//label[contains(text(),'"+sLabelName+"')]//parent::div//input[@name='name']")
    await objWrapper.setInputCharByChar(txtLabel,sOwnerName, objWrapper.iDefaultTimeout);
    return await objWrapper.getElementAttribute(txtLabel, 'ng-reflect-model', objWrapper.iDefaultTimeout).then(function(sText){
        if(sText == sOwnerName)
            sConsole = "Pass : Set "+sLabelName+" as '"+sOwnerName+"'.";
        else
            sConsole = "Not able to set "+sLabelName+" as '"+sOwnerName+"'.";
        console.info(sConsole);
        return sConsole;
    });
}
//Nidhi-Select the Team Member
async selectOwnerName(sLabelName,sOwnerName)
{
    let lstTeamMember = by.xpath("//ul[@class='list-group']//a[contains(text(),'"+sOwnerName+"')]/parent::li");
    await objWrapper.javascriptClickOnElement(lstTeamMember, objWrapper.iDefaultTimeout);
    let objSelectedOwner = by.xpath("//label[text()='"+sLabelName+"']/following-sibling::app-people-picker//input[@name='name_hide']");
    return await objWrapper.getElementAttribute(objSelectedOwner, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
        console.log(sText);
        if(sText==sOwnerName)
        sConsole= "Pass : Clicked on "+sLabelName+" list option '"+sOwnerName+"'.";
        else
        sConsole= "Not able to click on "+sLabelName+".";
        console.info(sConsole);
        return sConsole;
        
    });
}
// Nidhi- 25/03/2021 Select the CAT RAT Manager
async selectOwnerFromDD(sLabelName,sOwnerName)
{
    expect(await this.setOwnerName(sLabelName,sOwnerName)).toContain("Pass");
    await browser.sleep(15000);
    return await this.selectOwnerName(sLabelName,sOwnerName);
} 
//Nidhi-21/04/2021 remove Username
async removeOwnerName(sLabelName)
{  
    let objOwner = by.xpath("//label[contains(text(),'"+sLabelName+"')]//parent::div//a[text()='x']")
    return await objWrapper.clickOnElement(objOwner,objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
            sConsole = "Pass : Removed Ower Name of Label"+sLabelName+".";
        else
            sConsole = "Not able to Remove Owner Name.";
        console.info(sConsole);
        return sConsole;
    });
}
    
}