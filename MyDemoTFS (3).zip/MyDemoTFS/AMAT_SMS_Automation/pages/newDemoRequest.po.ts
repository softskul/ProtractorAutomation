import { exec } from 'child_process';
import { browser, by, element, Key } from 'protractor';
import { protractor } from 'protractor/built/ptor';
import { resolveTypeReferenceDirective } from 'typescript';
import { BrowserUtil } from '../utils/browser.util';
import { wrapper } from '../utils/wrapper.util';
import { SpecReporter } from 'jasmine-spec-reporter';
import { commonPage } from './commonPage.po';

let objWrapper:wrapper;
let objCommonPage: commonPage;
let sConsole;
export class newDemoRequest
{
    constructor()
    {
        objWrapper = new wrapper();
        objCommonPage = new commonPage();
    }

    //Richa_Jan2021 - verify opportunity info section displayed
    async verifyOpportunityInfoSectionDisplayed()
    {
        let objOppInfoSection = by.css("div.opportunity-info-card");
        return await objWrapper.isElementPresent(objOppInfoSection, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Opportunity info section displayed successfully.";
            else
                sConsole = "Fail : Fail to display opportunity info section.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_Jan2021 - verify button is disabled
    async verifyBtnIsDisabled(sBtnName)
    {
        let btnButton = by.xpath("//button[contains(text(),'"+sBtnName+"')]");
        return await objWrapper.isElementEnabled(btnButton, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Button '"+sBtnName+"' is enabled.";
            else
                sConsole = "Pass : Button  '"+sBtnName+"' is disabled.";
            console.info(sConsole);
            return sConsole;
        });
    }
	
    //Chakradhar 05 may 2021 -verify alert button is disabled	
	async verifyAlertBtnIsDisabled(sBtnName)
	{
		let btnButton = by.xpath("//div[@class='modal-content']//div[@class='modal-footer']//button[contains(text(),'"+sBtnName+"')]");
		return await objWrapper.isElementEnabled(btnButton, objWrapper.iDefaultTimeout).then(function(bRes){
			if(bRes)
				sConsole = "Button '"+sBtnName+"' is enabled.";
			else
				sConsole = "Pass : Button  '"+sBtnName+"' is disabled.";
			console.info(sConsole);
			return sConsole;
		});
	}

    //Richa_Jan2021 - Enter demo name
    async enterDemoName(sDemoName)
    {
        let txtDemoName = by.xpath("//label[contains(text(), 'Demo Name')]/following-sibling::div/input");
        await objWrapper.setInputValue(txtDemoName, sDemoName, objWrapper.iDefaultTimeout);
        return await objWrapper.getElementAttribute(txtDemoName, 'ng-reflect-model', objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sDemoName)
                sConsole = "Pass : Set demo name as '"+sDemoName+"'.";
            else
                sConsole = "Fail : Fail to set demo name as '"+sDemoName+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_01032021 - setTextInField
    async setTextInField(sFieldName, sFieldVal)
    {
        let txtField = by.xpath("//label[contains(text(), '"+sFieldName+"')]/following-sibling::div/input|//label[contains(text(), '"+sFieldName+"')]/following-sibling::div/textarea");
        await objWrapper.setInputValue(txtField, sFieldVal, objWrapper.iDefaultTimeout);
        return await objWrapper.getElementAttribute(txtField, 'ng-reflect-model', objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sFieldVal)
                sConsole = "Pass : Set '"+sFieldName+"' value as '"+sFieldVal+"'.";
            else
                sConsole = "Fail : Fail to set '"+sFieldName+"' value as '"+sFieldVal+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    async clickOnDropDown(sDDLabel)
    {
        //let cmbDD = by.xpath("//label[text()='"+sDDLabel+"']/following-sibling::div//span[@class='ng-arrow']");
        let cmbDD = by.xpath("//label[text()='"+sDDLabel+"']/following-sibling::div//input|//label[text()='"+sDDLabel+"']/following-sibling::ng-select//input|//label[text()='"+sDDLabel+"']/following-sibling::ng-multiselect-dropdown");
        return await objWrapper.javascriptClickOnElement(cmbDD, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
			 
                sConsole = "Pass : Clicked on DD with label " + sDDLabel;
							
			 
            else
			 
                sConsole = "Fail : Fail to click on DD with label " + sDDLabel;
            console.info(sConsole);
            return sConsole;
			 
        });
    }

    //Richa_Jan2021 - Click on DD option
    // async clickOnDropDownOption(sDDLabel, sOption)
    // {
    //     let cmbDD = by.xpath("//label[text()='"+sDDLabel+"']/following-sibling::div//input");
    //     await objWrapper.setInputValue(cmbDD, sOption, objWrapper.iDefaultTimeout);
    //     let objOption = by.xpath("//div[contains(@class, 'ng-dropdown-panel-items')]//span[text() ='"+sOption+"']");
    //     return await objWrapper.clickOnElement(objOption, objWrapper.iDefaultTimeout).then(function(bRes){
    //         if(bRes)
    //             sConsole = "Pass : Clicked on drop down option '"+sOption+"' in dd '"+sDDLabel+"'";
    //         else
    //             sConsole = "Fail : Fail to click on drop down option '"+sOption+"' in dd '"+sDDLabel+"'";
    //         console.info(sConsole);
    //         return sConsole;
    //     });
    // }
    async clickOnDropDownOption(sDDLabel, sOption)
    {
        let cmbDD = by.xpath("//label[text()='"+sDDLabel+"']/following-sibling::div//input|//label[text()='"+sDDLabel+"']/following-sibling::ng-select//input");
        await objWrapper.setInputValue(cmbDD, sOption, objWrapper.iDefaultTimeout);
        await browser.sleep(2000);
        let objOption = by.xpath("//div[contains(@class, 'ng-dropdown-panel-items')]//span[text() ='"+sOption+"']");
        let objOptSelected = by.css("ng-select[ng-reflect-model*='"+sOption+"']");
        return await objWrapper.javascriptClickOnElement(objOption, objWrapper.iDefaultTimeout).then(function(bRes){
        // return  await objWrapper.getElementAttribute(objOptSelected, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
            if(bRes)
                sConsole = "Pass : Clicked on drop down option '"+sOption+"' in dd '"+sDDLabel+"'";
            else
                sConsole = "Fail : Fail to click on drop down option '"+sOption+"' in dd '"+sDDLabel+"'";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_Jan2021 - Select account
    async selectAccount(sAccount)
    {
        //await this.clickOnDropDown("Account");
        return await this.clickOnDropDownOption("Account", sAccount);
    }

    async verifyAccountListItemExists(sAccount)
    {
        let cmbDD = by.xpath("//label[text()='Account']/following-sibling::div//input");
        await objWrapper.setInputValue(cmbDD, sAccount, objWrapper.iDefaultTimeout);
        let objAccountOption = by.xpath("//div[@class='ng-dropdown-panel-items scroll-host']//div/span[text()='"+sAccount+"']");
        return await objWrapper.isElementPresent(objAccountOption, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
            {
                console.info("Account option '"+sAccount+"' is present.");
                return true;
            }
            else
            {
                console.error("Fail to find on Account option '"+sAccount+"'.");
                return false;
            }
        });
    }

    async selectPrimaryBU(sPrimaryBU)
    {
        //await this.clickOnDropDown("Primary BU");
        return await this.clickOnDropDownOption("Primary BU", sPrimaryBU);
    }

    async clickOnSaveAsDraft()
    {
        let btnSaveAsDraft = by.xpath("//button[contains(text(),'Save As Draft')]");
        return await objWrapper.clickOnElement(btnSaveAsDraft, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
          sConsole = "Pass : licked on Save As Draft button.";
        else
          sConsole = "Fail to click on button Save As Draft.";
          console.info(sConsole);
          return sConsole;

        });
    }

    async verifyPrimaryBUDDIsEnabled()
    {
        let cmbPrimaryBU = by.xpath("//label[text()='Primary BU']/following-sibling::div/ng-select");
        return await objWrapper.getElementAttribute(cmbPrimaryBU, "ng-reflect-is-disabled", objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
            sConsole = "Pass : Primary BU DD is disabled.";
        else
            sConsole = "Primary BU DD is enabled.";
        console.info(sConsole);
        return sConsole;
        });
    }

    //Richa_Jan2021 - Verify toggle button present for field
    async verifyToggleForFieldIsPresent(sFieldLabel)
    {
        let objTambaToggle = by.xpath("//label[text()='"+sFieldLabel+"']/following-sibling::div[@class='switchToggle']");
        return await objWrapper.isElementPresent(objTambaToggle, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Toggle button for '"+sFieldLabel+"' is present.";
            else
                sConsole = "Fail : Fail to find toggle button for '"+sFieldLabel+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Pass bState as true if user wants to set TAMBA value as Yes else false
    async toggleField(sFieldLabel, bState)
    {
        let sFieldLabel1, sFieldName;
        let objTAMBAState;
        switch(sFieldLabel)
        {
            case "Resource Estimation to Execute Demo (Optional)" :
                sFieldName = "estimation";
                objTAMBAState = by.xpath("//h3[contains(text(),'"+sFieldLabel+"')]/following-sibling::div[contains(@class, 'switchToggle')]/input");
                break;
            case "BM Approved" :
                sFieldName = "isBmApproved";
                objTAMBAState = by.xpath("//label[text()='"+sFieldLabel+"']/following-sibling::div[@class='switchToggle']/input");
                break;
			case "CAT/RAT Project" :
                sFieldName = "ratProject";
                objTAMBAState = by.xpath("//label[text()='"+sFieldLabel+"']/following-sibling::div[@class='switchToggle']/input");
                break;  
            default :
                sFieldLabel1 = sFieldLabel.toLowerCase();
                sFieldName = objWrapper.convertToCamelCase(sFieldLabel1);
                objTAMBAState = by.xpath("//label[text()='"+sFieldLabel+"']/following-sibling::div[@class='switchToggle']/input");
        }
        
        let objTAMBAToggle = by.css("div.switchToggle>input[name='"+sFieldName+"']+label");
         
        var bActState = false;
        await objWrapper.getElementAttribute(objTAMBAState, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
            console.log("sText : "+sText);
            if(sText == "true")          
                bActState = true;   
        });
       
        if(bActState != bState)
        {
            await objWrapper.javascriptClickOnElement(objTAMBAToggle, objWrapper.iDefaultTimeout);

            await objWrapper.getElementAttribute(objTAMBAState, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
                if(sText == "true")
                    bActState = true;
                else
                    bActState = false;
            });
        }
        if(bActState == bState)
            sConsole = "Pass : '"+sFieldLabel+"' button selected as " + bState;
        else
            sConsole = "Fail : Fail to select '"+sFieldLabel+"' button as " + bState;
        console.info(sConsole);
        return sConsole;
    }

    //Richa_Jan2021 - Click on TAMBA search icon
    async clickOnTAMBASearch()
    {
        let btnTAMBASearch = by.xpath("//label[contains(text(), 'TAMBA Name')]/following-sibling::div/button");
        let objTAMBAPopUp = by.xpath("//div[@id='tambaSearch']//div[@class='modal-header']/h5[text()='Tamba']");
        await objWrapper.javascriptClickOnElement(btnTAMBASearch, objWrapper.iDefaultTimeout)
        return await objWrapper.isElementPresent(objTAMBAPopUp, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on TAMBA search icon.";
            else
                sConsole = "Fail : Fail to click on TAMBA search icon.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_Jan2021 - Click on From account DD on TAMBA search Pop up
    async clickOnFromAccountOnTambaSearchPopUp()
    {
        let cmbFromAcc = by.xpath("//div[@id='tambaSearch']//label[text()='From Account']/following-sibling::ng-select");
        return await objWrapper.clickOnElement(cmbFromAcc, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on From Account DD on Tamba Search pop up.";
            else
                sConsole = "Fail : Fail to click on From Account DD on Tamba Search pop up.";
            console.info(sConsole);
            return sConsole;
        }); 
    }

    //Richa_Jan2021 - Click on From account DD on TAMBA search Pop up
    async clickOptionOnFromAccountList(sOption)
    {
        let objOption = by.xpath("//div[@id='tambaSearch']//div[@class='ng-option']/span[text()='"+sOption+"']");
        return await objWrapper.clickOnElement(objOption, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass: Clicked on From Account DD option '"+sOption+"' on Tamba Search pop up.";
            else
                sConsole = "Fail : Fail to click on From Account DD option '"+sOption+"' on Tamba Search pop up.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_Jan2021 - Select From Account on TAMBA search Pop up
    async selectFromAccountOnTambaSearchPopUp(sAccount)
    {
        expect(await this.clickOnFromAccountOnTambaSearchPopUp()).toContain("Pass");
        return this.clickOptionOnFromAccountList(sAccount);
    }

    async clickOnGoOnTambaSearchPopUp()
    {
        let btnGo = by.xpath("//div[@id='tambaSearch']//button[text()='Go']");
        return await objWrapper.clickOnElement(btnGo, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on Go button on Tamba Search pop up.";
            else
                sConsole = "Fail : Fail to click on Go button on Tamba Search pop up.";
            console.info(sConsole);
            return sConsole;
            // {
            //     console.info("Clicked on Go button on Tamba Search pop up.");
            //     browser.sleep(10000);
            //     return true;
            // }
            // else
            // {

            //     console.error("Fail to click on Go button on Tamba Search pop up.");
            //     return false;
            // }
        });
    }

    async getTambaTblRowCountOnTambaSearchPopUp()
    {
        let tblTambaRows = by.xpath("//div[@id='tambaSearch']//div[@class='tambaTable']//tbody/tr");
        return await objWrapper.getWebelementCount(tblTambaRows);
    }

    async selectTambaRowOnTambaSearchPopUp()
    {
        var iRNum;   
        let bRowRes =  await this.getTambaTblRowCountOnTambaSearchPopUp().then(async function(iCount){
            if(iCount > 0)
            {
                console.log(iCount);
                iRNum = Math.floor(Math.random()*(iCount - 1)) + 1;
                console.log(iRNum);
                return true;
            }                   
        });
        if(bRowRes)
        {
            var sTambaNum;
            let objRowSelection = by.xpath("//div[@id='tambaSearch']//div[@class='tambaTable']//tbody/tr["+iRNum+"]/td[1]/label");
            await this.saveSelectedTambaValues(iRNum);
            let objRowTambaNumber = by.xpath("//div[@id='tambaSearch']//div[@class='tambaTable']//tbody/tr["+iRNum+"]/td[2]");
            await objWrapper.getElementText(objRowTambaNumber, objWrapper.iDefaultTimeout).then(function(sNum){
                console.log(sNum);
                sTambaNum = sNum;
            });
            return await objWrapper.clickOnElement(objRowSelection, objWrapper.iDefaultTimeout).then(function(bRes){    
                if(bRes)
                    sConsole = "Pass : Selected tamba number " + sTambaNum;
                else
                    sConsole = "Fail : Fail to select tamba number " + sTambaNum;
                console.info(sConsole);
                return sConsole;
            });
        }
        else
        {
            sConsole = "Fail : Fail to find rows in Tamba table on Tamba search pop up.";
            console.info(sConsole);
            return sConsole;
        }
        
        
    }

    async saveSelectedTambaValues(iRow)
    {
        let tblRow = by.xpath("//div[@id='tambaSearch']//div[@class='tambaTable']//tbody/tr["+iRow+"]/td[2]");
        await objWrapper.getElementText(tblRow, objWrapper.iDefaultTimeout).then(function(sTambaName){
            console.log(sTambaName);
            browser.executeScript("window.localStorage.setItem('sTambaName', '"+sTambaName+"');");
        });
        tblRow = by.xpath("//div[@id='tambaSearch']//div[@class='tambaTable']//tbody/tr["+iRow+"]/td[3]");
        await objWrapper.getElementText(tblRow, objWrapper.iDefaultTimeout).then(function(sAccount){
            console.log(sAccount);
            browser.executeScript("window.localStorage.setItem('sAccount', '"+sAccount+"');");
        });
        tblRow = by.xpath("//div[@id='tambaSearch']//div[@class='tambaTable']//tbody/tr["+iRow+"]/td[4]");
        await objWrapper.getElementText(tblRow, objWrapper.iDefaultTimeout).then(function(sMngdAcc){
            console.log(sMngdAcc);
            browser.executeScript("window.localStorage.setItem('sMngdAcc', '"+sMngdAcc+"');");
        });
        tblRow = by.xpath("//div[@id='tambaSearch']//div[@class='tambaTable']//tbody/tr["+iRow+"]/td[5]");
        await objWrapper.getElementText(tblRow, objWrapper.iDefaultTimeout).then(function(sBU){
            console.log(sBU);
            browser.executeScript("window.localStorage.setItem('sBU', '"+sBU+"');");
        });
        tblRow = by.xpath("//div[@id='tambaSearch']//div[@class='tambaTable']//tbody/tr["+iRow+"]/td[6]");
        await objWrapper.getElementText(tblRow, objWrapper.iDefaultTimeout).then(function(sAppSegment){
            console.log(sAppSegment);
            browser.executeScript("window.localStorage.setItem('sAppSegment', '"+sAppSegment+"');");
        });
        tblRow = by.xpath("//div[@id='tambaSearch']//div[@class='tambaTable']//tbody/tr["+iRow+"]/td[7]");
        await objWrapper.getElementText(tblRow, objWrapper.iDefaultTimeout).then(function(sApp){
            console.log(sApp);
            browser.executeScript("window.localStorage.setItem('sApp', '"+sApp+"');");
        });
        tblRow = by.xpath("//div[@id='tambaSearch']//div[@class='tambaTable']//tbody/tr["+iRow+"]/td[8]");
        await objWrapper.getElementText(tblRow, objWrapper.iDefaultTimeout).then(function(sDeviceType){
            console.log(sDeviceType);
            browser.executeScript("window.localStorage.setItem('sDeviceType', '"+sDeviceType+"');");
        });
        tblRow = by.xpath("//div[@id='tambaSearch']//div[@class='tambaTable']//tbody/tr["+iRow+"]/td[9]");
        await objWrapper.getElementText(tblRow, objWrapper.iDefaultTimeout).then(function(sCustNode){
            console.log(sCustNode);
            browser.executeScript("window.localStorage.setItem('sCustNode', '"+sCustNode+"');");
        });
        tblRow = by.xpath("//div[@id='tambaSearch']//div[@class='tambaTable']//tbody/tr["+iRow+"]/td[10]");
        await objWrapper.getElementText(tblRow, objWrapper.iDefaultTimeout).then(function(sAMATNode){
            console.log(sAMATNode);
            browser.executeScript("window.localStorage.setItem('sAMATNode', '"+sAMATNode+"');");
        });
        tblRow = by.xpath("//div[@id='tambaSearch']//div[@class='tambaTable']//tbody/tr["+iRow+"]/td[11]");
        await objWrapper.getElementText(tblRow, objWrapper.iDefaultTimeout).then(function(sAMATProd){
            console.log(sAMATProd);
            browser.executeScript("window.localStorage.setItem('sAMATProd', '"+sAMATProd+"');");
        });
    }

    async clickOnSubmit()
    {
        let btnSubmit = by.xpath("//div[@id='tambaSearch']//button[contains(text(), 'Submit')]");
        return await objWrapper.clickOnElement(btnSubmit, objWrapper.iDefaultTimeout).then(function(bRes){    
            if(bRes)
                sConsole = "Pass : Clicked on Submit button on TAMBA search pop up.";
            else
                sConsole = "Fail : Fail to click on Submit button on TAMBA search pop up.";
            console.info(sConsole);
            return sConsole;
        });
    }

    async verifyValInField(sFieldLabel, sFieldVal)
    {
        let objField = by.xpath("//label[contains(text(),'"+sFieldLabel+"')]/following-sibling::div/ng-select[@ng-reflect-model='"+sFieldVal+"']|//label[contains(text(),'"+sFieldLabel+"')]/following-sibling::div/input[@ng-reflect-model='"+sFieldVal+"']|//label[contains(text(),'"+sFieldLabel+"')]/following-sibling::ng-select[@ng-reflect-model='"+sFieldVal+"']|//label[contains(text(),'"+sFieldLabel+"')]/following-sibling::app-people-picker//input[@name='name' and @ng-reflect-model='"+sFieldVal+"']");
        return await objWrapper.isElementPresent(objField, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Verified field '"+sFieldLabel+"' is having value " + sFieldVal;
            else
                sConsole = "Fail : Fail to verify field '"+sFieldLabel+"' is having value " + sFieldVal;
            console.info(sConsole);
            return sConsole;
        });
    }

    async verifyTambaDtlsOnNewDemoForm()
    {
        let sTambaName, sAccount, sBU, sAppSegment, sApp, sDeviceType, sAMATProd, sAMATNode, sCustNode, sMngdAcc;
        let sTambaName1, sAccount1, sBU1, sAppSegment1, sApp1, sDeviceType1, sAMATProd1, sAMATNode1, sCustNode1, sMngdAcc1;
        sTambaName = browser.executeScript("return window.localStorage.getItem('sTambaName');");
        await sTambaName.then(function(sText){sTambaName1 = sText;});
        sAccount = browser.executeScript("return window.localStorage.getItem('sAccount');");
        await sAccount.then(function(sText){sAccount1 = sText;});
        sMngdAcc = browser.executeScript("return window.localStorage.getItem('sMngdAcc');");
        await sMngdAcc.then(function(sText){sMngdAcc1 = sText});
        sBU = browser.executeScript("return window.localStorage.getItem('sBU');");
        await sBU.then(function(sText){sBU1 = sText;});
        sAppSegment = browser.executeScript("return window.localStorage.getItem('sAppSegment');");
        await sAppSegment.then(function(sText){sAppSegment1 = sText;});
        sApp = browser.executeScript("return window.localStorage.getItem('sApp');");
        await sApp.then(function(sText){sApp1 =  sText;});
        sDeviceType = browser.executeScript("return window.localStorage.getItem('sDeviceType');");
        await sDeviceType.then(function(sText){sDeviceType1 = sText;});
        sAMATProd = browser.executeScript("return window.localStorage.getItem('sAMATProd');");
        await sAMATProd.then(function(sText){sAMATProd1 = sText;});
        sAMATNode = browser.executeScript("return window.localStorage.getItem('sAMATNode');");
        await sAMATNode.then(function(sText){sAMATNode1 = sText;});
        sCustNode = browser.executeScript("return window.localStorage.getItem('sCustNode');");
        await sCustNode.then(function(sText){console.log("Cust Node : "+sText); sCustNode1 = sText;});
        expect(await this.verifyValInField("TAMBA Name", sTambaName1)).toContain("Pass");
        expect(await this.verifyValInField("Account", sAccount1)).toContain("Pass");
        expect(await this.verifyValInField("Managed Account", sMngdAcc1)).toContain("Pass");
        expect(await this.verifyValInField("Primary BU", sBU1)).toContain("Pass");
        expect(await this.verifyValInField("Application Segment", sAppSegment1)).toContain("Pass");
        expect(await this.verifyValInField("Application", sApp1)).toContain("Pass");
        expect(await this.verifyValInField("Device Type", sDeviceType1)).toContain("Pass");
        if(sAMATProd1 == null)
            sAMATProd1 = "";
        expect(await this.verifyValInField("AMAT Product", sAMATProd1)).toContain("Pass");
        expect(await this.verifyValInField("AMAT Node", sAMATNode1)).toContain("Pass");
        expect(await this.verifyValInField("Customer Node", sCustNode1)).toContain("Pass");
    }

    async verifyPrimaryBUIsMandatoryWhenInternalDemo()
    {
        let objField = by.xpath("//h3[contains(text(), 'Opportunity Information')]/parent::div[@id='headingOne']/following-sibling::div//span[text()='*']/preceding-sibling::label");
        return await objWrapper.getElementText(objField, objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == "Primary BU")
                sConsole = "Pass : Only Primary BU field is mandatory when internal demo is Yes.";
            else
                sConsole = "Fail : Primary BU field is not the only mandatory field when internal demo is yes.";
            console.info(sConsole);
            return sConsole;
        });
    }

    async enterHVP(sHVP)
    {
        let txtHVP = by.xpath("//label[contains(text(), 'HVP')]/following-sibling::div/textarea");
        await objWrapper.setInputValue(txtHVP, sHVP, objWrapper.iDefaultTimeout);
        return await objWrapper.getElementAttribute(txtHVP, 'ng-reflect-model', objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sHVP)
            {
                console.info("Set HVP value as " + sHVP);
                return true;
            }
            else
            {
                console.error("Fail to set HVP value as " + sHVP);
                return false;
            }
        });
    }

    async setSuccessCriteria(sSuccessCriteria)
    {
        let txtSuccessCriteria = by.xpath("//label[contains(text(), 'Success Criteria')]/following-sibling::div/input");
        await objWrapper.setInputValue(txtSuccessCriteria, sSuccessCriteria, objWrapper.iDefaultTimeout);
        return await objWrapper.getElementAttribute(txtSuccessCriteria, 'ng-reflect-model', objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sSuccessCriteria)
                sConsole = "Pass : Set Success Criteria as " + sSuccessCriteria;
            else
                sConsole = "Fail : Fail to set Success Criteria as " + sSuccessCriteria;
            console.info(sConsole);
            return sConsole;
        });
    }

    async clickOnRequestedCompletionDate()
    {
        let objReqCompDt = by.xpath("//label[contains(text(), 'Requested Completion Date')]/following-sibling::div//span[@class ='fa fa-calendar']");
        return await objWrapper.clickOnElement(objReqCompDt, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Requested Completion Date selected as today's date.";
            else
                sConsole = "Fail : Fail to select today's date as Requested Completion Date.";
            console.info(sConsole);
            return sConsole;
            // {
            //     //browser.actions().sendKeys(protractor.Key.ENTER).perform();
            //     // objWrapper.sendKeysInActiveElmnt("Enter");
            //     console.info("Requested Completion Date selected as today's date.");
            //     return true;
            // }
            // else
            // {
            //     console.error("Fail to select today's date as Requested Completion Date.");
            //     return false;
            // }
        });
    }

    async setRequestedCompletionDate(sDate)
    {
        let objReqCompDt = by.xpath("//label[contains(text(), 'Requested Completion Date')]/following-sibling::div/input");
        await objWrapper.setAttributeUsingJavaScript(objReqCompDt, objWrapper.iDefaultTimeout, "ng-reflect-model", sDate);
    }

    async clickOnDemoTypeDD()
    {
        let cmbDemoType = by.xpath("//label[contains(text(), 'Demo Type')]/following-sibling::div//span[@class='dropdown-down']");
        return await objWrapper.clickOnElement(cmbDemoType, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on Demo Type DD.";
            else
                sConsole = "Fail : Fail to click on Demo Type DD.";
            console.info(sConsole);
            return sConsole;
        });
    }

    async selectDemoTypeFromList(sDemoType)
    {
        let objDemoTypeOption = by.xpath("//div[@class='dropdown-list']//li/div[text()='"+sDemoType+"']");
        return await objWrapper.clickOnElement(objDemoTypeOption, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on Demo type option '"+sDemoType+"'.";
            else
                sConsole = "Fail : Fail to click on Demo Type option '"+sDemoType+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    async verifyDemoTypeListItemExists(sDemoType)
    {
        let objDemoTypeOption = by.xpath("//div[@class='dropdown-list']//li/div[text()='"+sDemoType+"']");
        return await objWrapper.isElementPresent(objDemoTypeOption, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
            {
                console.info("Demo type option '"+sDemoType+"' is present.");
                return true;
            }
            else
            {
                console.error("Fail to find on Demo Type option '"+sDemoType+"'.");
                return false;
            }
        });
    }

    async clickBtnOnNewRequestForm(sBtnName)
    {
        let btnButton = by.xpath("//button[contains(text(),'"+sBtnName+"')]");
        return await objWrapper.clickOnElement(btnButton, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on button '"+sBtnName+"'.";
            else
                sConsole = "Fail : Fail to click on button '"+sBtnName+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    async selectDemoType(sDemoType)
    {
        expect(await this.clickOnDemoTypeDD()).toContain("Pass");
        return await this.selectDemoTypeFromList(sDemoType);
    }

    async verifyCustomerSpecSectionDisplayed()
    {
        let objCustomerSpecSection = by.xpath("//div[@class='opportunity-info-card']//h5[contains(text(), 'Customer Spec')]");
        return await objWrapper.isElementPresent(objCustomerSpecSection, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Customer Spec section displayed.";
            else
                sConsole = "Fail : Fail to find customer spec section.";
            console.info(sConsole);
            return sConsole;
        });
    }

    async verifySubstrateTypeDDExists()
    {
        let cmbSubstrateType = by.xpath("//label[text()='Substrate Type']/following-sibling::div/select");
        return await objWrapper.isElementPresent(cmbSubstrateType, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
            {
                console.info("Substrate type drop down is present.");
                return true;
            }
            else
            {
                console.error("Fail to find substrate type drop down.");
                return false;
            }
        });
    }

    async clickOnSubstrateTypeDD()
    {
        let cmbSubstrateType = by.xpath("//label[text()='Substrate Type']/following-sibling::div/select");
        return await objWrapper.clickOnElement(cmbSubstrateType, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on Substrate Type DD.";
            else
                sConsole = "Fail : Fail to click on Substrate Type DD.";
            console.info(sConsole);
            return sConsole;
        });
    }

    async selectOptionFromSubstrateTypeDD(sOption)
    {
        let objOption = by.xpath("//label[text()='Substrate Type']/following-sibling::div/select/option[contains(text(), '"+sOption+"')]");
        return await objWrapper.clickOnElement(objOption, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Selected Substrate Type Option '"+sOption+"'.";
            else
                sConsole = "Fail : Fail to select Substrate Type option '"+sOption+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    async selectSubstrateType(sOption)
    {
        expect(await this.clickOnSubstrateTypeDD()).toContain("Pass");
        return await this.selectOptionFromSubstrateTypeDD(sOption);
    }

    async clickCustomerSpecOption(sOption)
    {
        let chkCustomerSpec = by.xpath("//label[contains(text(),'Customer Spec')]/following-sibling::div//label[@for='"+sOption+"']");
        return await objWrapper.clickOnElement(chkCustomerSpec, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on customer spec option '"+sOption+"'.";
            else
                sConsole = "Fail : Fail to click on customer spec option '"+sOption+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    async clickBrowseToChooseCustSpecFile()
    {
        let objCustFile = by.css("div.custom-file");
        let txtCustFile = by.css("input#inputGroupFile04");
        let lblCustFile = by.css("label[class*=custom-file-label]");
        await objWrapper.javascriptClickOnElement(lblCustFile, objWrapper.iDefaultTimeout);
        /* return await objWrapper.clickOnElement(lblCustFile, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
            {
                console.info("Clicked on browse to choose customer spec file.");
                return true;
            }
            else
            {
                console.error("Fail to click on browse to choose customer spec file.");
                return false;
            }
        }); */
    }

    async setCustSpecFileName(sCustSpecFileWithExtn)
    {
        
        let lblCustFile = by.css("label[class*=custom-file-label]");
        //await objWrapper.setAttributeUsingJavaScript(lblCustFile, objWrapper.iDefaultTimeout, "text", sCustSpecFileWithExtn);
        await objWrapper.sendKeysInActiveElmnt(sCustSpecFileWithExtn);
        await objWrapper.sendKeysInActiveElmnt("Enter");
        //await objWrapper.setInputValueWithoutClear(lblCustFile, sCustSpecFileWithExtn, objWrapper.iDefaultTimeout);
        return objWrapper.getElementText(lblCustFile, objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sCustSpecFileWithExtn)
            {
                console.info("Set customer specification file name as '"+sCustSpecFileWithExtn+"'.");
                
                return true;
            }
            else
            {
                console.error("Fail to set customer specification file name as '"+sCustSpecFileWithExtn+"'.");
                return false;
            }
        });
    }

    async clickOnUploadCustSpec()
    {
        let btnUpload = by.xpath("//button[text()='Upload']");
        return await objWrapper.clickOnElement(btnUpload, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
            {
                console.info("Clicked on Upload button for customer Spec file.");
                return true;
            }
            else
            {
                console.error("Fail to click on Upload button for customer spec file.");
                return false;
            }
        })
    }

    async uploadCustSpec(sCustSpecFileWithExtn)
    {
        await this.clickBrowseToChooseCustSpecFile()
        expect(await this.setCustSpecFileName(sCustSpecFileWithExtn)).toBeTruthy();
        return await this.clickOnUploadCustSpec();
    }

    async setAccountOwnerVal(sAccOwner)
    {
        let txtAccOwner = by.xpath("//label[text()='Account Owner']/following-sibling::app-people-picker//input[@name='name']")
        await objWrapper.setInputValue(txtAccOwner, sAccOwner, objWrapper.iDefaultTimeout);
        return await objWrapper.getElementAttribute(txtAccOwner, 'ng-reflect-model', objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sAccOwner)
                sConsole = "Pass : Set account owner as '"+sAccOwner+"'.";
            else
                sConsole = "Fail : Fail to set account owner as '"+sAccOwner+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    async selectAccountOwner(sAccOwner)
    {
        let lstAccOwner = by.xpath("//ul[@class='list-group']//a[contains(text(),'"+sAccOwner+"')]/parent::li");
        await objWrapper.javascriptClickOnElement(lstAccOwner, objWrapper.iDefaultTimeout);
        let objSelectedOwner = by.xpath("//label[text()='Account Owner']/following-sibling::app-people-picker//input[@name='name_hide']");
        return await objWrapper.getElementAttribute(objSelectedOwner, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
            if(sText.match(sAccOwner))
                sConsole = "Pass : Clicked on Account owner list option '"+sAccOwner+"'.";
            else
                sConsole = "Fail : Fail to click on Account owner list option '"+sAccOwner+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    async setAccountOwner(sAccOwner)
    {
        expect(await this.setAccountOwnerVal(sAccOwner)).toContain("Pass");
        browser.sleep(5000);
        return await this.selectAccountOwner(sAccOwner);
    }

    //Richa_02032021 - set value in people picker
    async setValInPeoplePicker(sFieldName, sValue)
    {
        let txtPplPicker = by.xpath("//label[contains(text(),'"+sFieldName+"')]/following-sibling::app-people-picker//input[@name='name']");
        await objWrapper.setInputValue(txtPplPicker, sValue, objWrapper.iDefaultTimeout);
        return await objWrapper.getElementAttribute(txtPplPicker, 'ng-reflect-model', objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sValue)
                sConsole = "Pass : Set '"+sFieldName+"' as '"+sValue+"'.";
            else
                sConsole = "Fail : Fail to set '"+sFieldName+"' as '"+sValue+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_02032021 - select value from people picker
    async selectPeoplePickerVal(sFieldName, sValue)
    {
        expect(await this.setValInPeoplePicker(sFieldName, sValue)).toContain("Pass");
        await browser.sleep(5000);
        let lstPplPicker = by.xpath("//ul[@class='list-group']//a[contains(text(),'"+sValue+"')]/parent::li");
        await objWrapper.javascriptClickOnElement(lstPplPicker, objWrapper.iDefaultTimeout);
        let objSelectedPplPicker = by.xpath("//label[contains(text(), '"+sFieldName+"')]/following-sibling::app-people-picker//input[@name='name_hide']");
        return await objWrapper.getElementAttribute(objSelectedPplPicker, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
            if(sText.match(sValue))
                sConsole = "Pass : Clicked on '"+sFieldName+"' list option '"+sValue+"'.";
            else
                sConsole = "Fail : Fail to click on '"+sFieldName+"' list option '"+sValue+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    async setAttributeCategory(sAttrbCategory)
    {
        let tblRow = by.xpath("//table[@class='table table-striped top_priority mb-3 mt-1']/tbody/tr");
        let iRowCount;
        await objWrapper.getWebelementCount(tblRow).then(function(iCnt){iRowCount = iCnt});
        let txtAttrbCat = by.xpath("//table[@class='table table-striped top_priority mb-3 mt-1']/tbody/tr["+iRowCount+"]/td[2]//input");
        await objWrapper.setInputValue(txtAttrbCat, sAttrbCategory, objWrapper.iDefaultTimeout);
        return await objWrapper.getElementAttribute(txtAttrbCat, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sAttrbCategory)
                sConsole = "Pass : Set attribute category value as '"+sAttrbCategory+"'";
            else
                sConsole = "Fail : Fail to set attribute category value as '"+sAttrbCategory+"'";
            console.info(sConsole);
            return sConsole;
        });
    }

    async setAttribute(sAttribute)
    {
        let tblRow = by.xpath("//table[@class='table table-striped top_priority mb-3 mt-1']/tbody/tr");
        let iRowCount;
        await objWrapper.getWebelementCount(tblRow).then(function(iCnt){iRowCount = iCnt});
        let txtAttrbCat = by.xpath("//table[@class='table table-striped top_priority mb-3 mt-1']/tbody/tr["+iRowCount+"]/td[3]//input");
        await objWrapper.setInputValue(txtAttrbCat, sAttribute, objWrapper.iDefaultTimeout);
        return await objWrapper.getElementAttribute(txtAttrbCat, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sAttribute)
                sConsole = "Pass : Set attribute value as '"+sAttribute+"'";
            else
                sConsole = "Fail : Fail to set attribute value as '"+sAttribute+"'";
            console.info(sConsole);
            return sConsole;
        });
    }

    async setMarketSegmentReq(sMarketSegReq)
    {
        let tblRow = by.xpath("//table[@class='table table-striped top_priority mb-3 mt-1']/tbody/tr");
        let iRowCount;
        await objWrapper.getWebelementCount(tblRow).then(function(iCnt){iRowCount = iCnt});
        let txtAttrbCat = by.xpath("//table[@class='table table-striped top_priority mb-3 mt-1']/tbody/tr["+iRowCount+"]/td[4]//input");
        await objWrapper.setInputValue(txtAttrbCat, sMarketSegReq, objWrapper.iDefaultTimeout);
        return await objWrapper.getElementAttribute(txtAttrbCat, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sMarketSegReq)
                sConsole = "Pass : Set market segment requirement value as '"+sMarketSegReq+"'";
            else
                sConsole = "Fail : Fail to set market segment requirement value as '"+sMarketSegReq+"'";
            console.info(sConsole);
            return sConsole;
        });
    }

    async clickOnWeightPriorityDD()
    {
        let tblRow = by.xpath("//table[@class='table table-striped top_priority mb-3 mt-1']/tbody/tr");
        let iRowCount;
        await objWrapper.getWebelementCount(tblRow).then(function(iCnt){iRowCount = iCnt});
        let cmbWtPriority = by.xpath("//table[@class='table table-striped top_priority mb-3 mt-1']/tbody/tr["+iRowCount+"]/td[5]//input"); 
        return await objWrapper.clickOnElement(cmbWtPriority, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on Weight/Priority DD.";
            else
                sConsole = "Fail : Fail to click on Weight/Priority DD.";
            console.info(sConsole);
            return sConsole;
        });
    }

    async selectWeightPriorityOption(sOption)
    {
        let objOption = by.xpath("//span[@class='ng-option-label' and text()='"+sOption+"']");
        return await objWrapper.clickOnElement(objOption, objWrapper.iDefaultTimeout).then(function(bRes)
        {
            if(bRes)
                sConsole = "Pass : Clicked on Weight/Priority option '"+sOption+"'.";
            else
                sConsole = "Fail : Fail to click on Weight/Priority '"+sOption+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    async selectWeighPriority(sOption)
    {
        expect(await this.clickOnWeightPriorityDD()).toContain("Pass");
        return await this.selectWeightPriorityOption(sOption);
    }

    async clickOnAttributeSave()
    {
        let btnSave = by.css("a[data-original-title='Save']");
        return await objWrapper.clickOnElement(btnSave, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on Save button."
            else
                sConsole = "Fail : Fail to click on Save button.";
            console.info(sConsole);
            return sConsole;
        });
    }

    async clickOnFromBUOnSearchTAMBAPopUp()
    {
        let cmbFromBU = by.xpath("//label[text()='From BU']/following-sibling::select[@name='buniseeUnitList']");
        return await objWrapper.clickOnElement(cmbFromBU, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
            {
                console.info("Clicked on From BU DD on Tamba Search Pop Up.");
                return true;
            }
            else
            {
                console.error("Fail to click on From BU DD on Tamba search pop up.");
                return false;
            }
        });
    }

    async selectFromBUOptionOnTAMBASearchPopUp(sOption)
    {
        let objOption = by.xpath("//label[text()='From BU']/following-sibling::select[@name='buniseeUnitList']/option[text()='"+sOption+"']");
        return await objWrapper.clickOnElement(objOption, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
            {
                console.info("Click on BU option '"+sOption+"' on TAMBA search pop up.");
                return true;
            }
            else
            {
                console.error("Fail to click on BU option '"+sOption+"' on TAMBA search pop up.");
                return false;
            }
        })
    }

    async selectFromBUONTAMBASearchPopUp(sOption)
    {
        expect(await this.clickOnFromBUOnSearchTAMBAPopUp()).toBe(true);
        return await this.selectFromBUOptionOnTAMBASearchPopUp(sOption);
    }

    async clickOnAccountDD()
    {
        let cmbAccount = by.xpath("//div[@class='opportunity-info-card']//label[text()='Account']/following-sibling::div/ng-select//span[@class='ng-arrow-wrapper']");
        await objWrapper.javascriptClickOnElement(cmbAccount, objWrapper.iDefaultTimeout);
        // let lstAccount
        // return await objWrapper.clickOnElement(cmbAccount, objWrapper.iMaxTimeout).then(function(bRes){
        //     if(bRes)
        //     {
        //         console.info("Clicked on Account drop down.");
        //         return true;
        //     }
        //     else
        //     {
        //         console.error("Fail to click on Account drop down.");
        //         return false;
        //     }
        // });
    }

    async verifySubstrateMaterialDDExists()
    {
        let cmbSubstrateMaterial = by.xpath("//label[text()='Substrate Material']/following-sibling::select");
        return await objWrapper.isElementPresent(cmbSubstrateMaterial, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
			 
                sConsole = "Pass : Substrate Material drop down is present.";
							
			 
            else
			 
                sConsole = "Fail to find Substrate Material drop down.";
            console.info(sConsole);
            return sConsole;
			 
        });
    }

    async verifyDefValInSubstrateMaterialDD(sDefVal)
    {
        let cmbSubstrateMaterial = by.xpath("//label[text()='Substrate Material']/following-sibling::select");
        return await objWrapper.getElementAttribute(cmbSubstrateMaterial, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sDefVal)
			 
                sConsole = "Pass : Default selected value in Substrate Material drop down is '"+sDefVal+"'.";
							
			 
            else
			 
                sConsole = "Fail : Fail to find default selected value in Substrate Material drop down as '"+sDefVal+"'.";
            console.info(sConsole);
            return sConsole;
			 
        });
    }

    async verifySubstrateMaterialDDIsNotMandatory()
    {
        let cmbSubstrateMaterial = by.xpath("//label[text()='Substrate Material']/following-sibling::span[text()='*']");
        return await objWrapper.isElementPresent(cmbSubstrateMaterial, objWrapper.iDefaultTimeout).then(function(bRes){
            if(!bRes)
			 
                sConsole = "Pass : Substrate Material drop down is non mandatory.";
							
			 
            else
			 
                sConsole = "Fail : Substrate Material drop down is mandatory.";
            console.info(sConsole);
            return sConsole;
			 
        });
    }

    async verifyTextFieldDisplayedForOtherSubstrateMaterial()
    {
        let txtOtherSubstrate = by.xpath("//label[text()='Substrate Material']/following-sibling::div/input[@name='otherSubstrate']");
        return await objWrapper.isElementPresent(txtOtherSubstrate, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
			 
                sConsole = "Pass : Text field is displayed when Substrate Material is selected as Other.";
							
			 
            else
			 
                sConsole = "Fail : Fail to find text field when Substrate Material is selected as Other.";
            console.info(sConsole);
            return sConsole;
			 
        });
    }

    async clickOnSubstrateMaterialDD()
    {
        let cmbSubstrateMaterial = by.xpath("//label[text()='Substrate Material']/following-sibling::select");
        return await objWrapper.clickOnElement(cmbSubstrateMaterial, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
			 
                sConsole = "Pass : Clicked on Substrate Material DD.";
							
			 
            else
			 
                sConsole = "Fail : Fail to click on Substrate Material DD.";
            console.info(sConsole);
            return sConsole;
			 
        });
    }

    async clickOnSubstrateMaterialDDOption(sOption)
    {
        let cmbSubstrateMaterialOption = by.xpath("//label[text()='Substrate Material']/following-sibling::select/option[@value='"+sOption+"']");
        return await objWrapper.clickOnElement(cmbSubstrateMaterialOption, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
			 
                sConsole = "Pass : Clicked on Substrate Material DD option '"+sOption+"'.";
							
			 
            else
			 
                sConsole = "Fail : Fail to click on Substrate Material DD option '"+sOption+"'.";
            console.info(sConsole);
            return sConsole;
			 
        });
    }

    async selectSubstrateMaterial(sOption)
    {
        expect(await this.clickOnSubstrateMaterialDD()).toContain("Pass");
        return await this.clickOnSubstrateMaterialDDOption(sOption);
    }

    async verifyWaferThicknessIsMandatory()
    {
        let txtWaferThickness = by.xpath("//label[text()='Wafer Thickness']/following-sibling::span[text()='*']/following-sibling::div/input");
        return await objWrapper.isElementPresent(txtWaferThickness, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
			 
                sConsole = "Pass : Wafer thickness text field is mandatory.";
							
			 
            else
			 
                sConsole = "Fail : Wafer thickness text field is non mandatory.";
            console.info(sConsole);
            return sConsole;
			 
        });
    }

    async setWaferThickness(sWaferThickness)
    {
        let txtWaferThickness = by.xpath("//label[text()='Wafer Thickness']/following-sibling::div/input");
        await objWrapper.setInputValue(txtWaferThickness, sWaferThickness, objWrapper.iDefaultTimeout);
        return await objWrapper.getElementAttribute(txtWaferThickness, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sWaferThickness)
			 
                sConsole = "Pass : Set wafer thickness as '"+sWaferThickness+"'.";
							
			 
            else
			 
                sConsole = "Fail : Fail to set wafer thickness as '"+sWaferThickness+"'.";
            console.info(sConsole);
            return sConsole;
			 
        });
    }

    async verifyFrontsideProtectionOrCarrierTypeDDIsMandatory()
    {
        let cmbFrontsideProtectionOrCarrierType = by.xpath("//label[text()='Frontside protection or Carrier type']/following-sibling::span[text()='*']/following-sibling::div/select");
        return await objWrapper.isElementPresent(cmbFrontsideProtectionOrCarrierType, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
			 
                sConsole = "Pass : Frontside protection or carrier type drop down is mandatory.";
							
			 
            else
			 
                sConsole = "Fail : Frontside protection or carrier type drop down is non mandatory.";
            console.info(sConsole);
            return sConsole;
			 
        });
    }

    async setDimensions(sDimensions)
    {
        let txtDimensions = by.xpath("//label[text()='Dimensions']/following-sibling::div/input");
        await objWrapper.setInputValue(txtDimensions, sDimensions, objWrapper.iDefaultTimeout);
        return await objWrapper.getElementAttribute(txtDimensions, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sDimensions)
			 
                sConsole = "Pass : Set dimensions as '"+sDimensions+"'";
							
			 
            else
			 
                sConsole = "Fail : Fail to set dimension as '"+sDimensions+"'";
            console.info(sConsole);
            return sConsole;
			 
        });
    }

    async setInternalAccount(sInternalAccount)
    {
        let txtInternalAcc = by.xpath("//label[text()='Internal Account']/following-sibling::div/input");
        await objWrapper.setInputValue(txtInternalAcc, sInternalAccount, objWrapper.iDefaultTimeout);
        return await objWrapper.getElementAttribute(txtInternalAcc, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sInternalAccount)
                sConsole = "Pass : Set Internal Account as '"+sInternalAccount+"'.";
            else
                sConsole = "Fail : Fail to set Internal Account as '"+sInternalAccount+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    async setInternalAccountOwnerVal(sInternalAccOwner)
    {
        let txtInternalAccOwner = by.xpath("//label[text()='Internal Account Owner']/following-sibling::app-people-picker//input[@name='name']")
        await objWrapper.setInputValue(txtInternalAccOwner, sInternalAccOwner, objWrapper.iDefaultTimeout);
        return await objWrapper.getElementAttribute(txtInternalAccOwner, 'ng-reflect-model', objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sInternalAccOwner)
                sConsole = "Pass : Set Internal account owner as '"+sInternalAccOwner+"'.";
            else
                sConsole = "Fail : Fail to set Internal account owner as '"+sInternalAccOwner+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    async selectInternalAccountOwner(sInternalAccOwner)
    {
        let lstAccOwner = by.xpath("//ul[@class='list-group']//a[contains(text(),'"+sInternalAccOwner+"')]/parent::li");
        await objWrapper.javascriptClickOnElement(lstAccOwner, objWrapper.iDefaultTimeout);
        let objSelectedOwner = by.xpath("//label[text()='Internal Account Owner']/following-sibling::app-people-picker//input[@name='name_hide']");
        return await objWrapper.getElementAttribute(objSelectedOwner, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
            if(sText.match(sInternalAccOwner))
                sConsole = "Pass : Clicked on Internal Account owner list option '"+sInternalAccOwner+"'.";
            else
                sConsole = "Fail : Fail to click on Internal Account owner list option '"+sInternalAccOwner+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    async setInternalAccountOwner(sInternalAccOwner)
    {
        expect(await this.setInternalAccountOwnerVal(sInternalAccOwner)).toBeTruthy();
        browser.sleep(5000);
        return await this.selectInternalAccountOwner(sInternalAccOwner);
    }

    async clickOnAdditionalDocumentBrowseButton()
    {
        //let btnBrowse = by.xpath("//label[text()='Additional Document']/following-sibling::div//label[contains(@class,'custom-file-label')]");
        let btnBrowse = by.xpath("//label[text()='Additional Document']/following-sibling::div/div[@class='custom-file']");//
        // await objWrapper.javascriptClickOnElement(btnBrowse, objWrapper.iDefaultTimeout);
        // await objWrapper.javascriptClickOnElement(btnBrowse, objWrapper.iDefaultTimeout);
        return await objWrapper.clickOnElement(btnBrowse, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on Additional Document browse button.";
            else
                sConsole = "Fail : Fail to click on Additional Document browse button.";
            console.info(sConsole);
            return sConsole;
        });
    }

    async verifyAdditionalDocumentBrowsed(sFileName)
    {
        let lblFileUploaded = by.xpath("//label[text()='Additional Document']/following-sibling::div//label[contains(@class,'custom-file-label')]");
        return await objWrapper.getElementText(lblFileUploaded, objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sFileName)
                sConsole = "Pass : Additional document '"+sFileName+"' browsed successfully.";
            else
                sConsole = "Fail : Fail to browse Additional Document '"+sFileName+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    async clickOnAdditionalDocumentUploadButton()
    {
        let btnUpload = by.xpath("//label[text()='Additional Document']/following-sibling::div/div/button[text()='Upload']");
        //await objWrapper.javascriptClickOnElement(btnBrowse, objWrapper.iDefaultTimeout);
        return await objWrapper.clickOnElement(btnUpload, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on Additional Document Upload button.";
            else
                sConsole = "Fail : Fail to click on Additional Document Upload button.";
            console.info(sConsole);
            return sConsole;
        });
    }

    async verifyAdditionalDocumentUploaded(sFileName)
    {
        let tblCell = by.xpath("//label[text()='Uploaded File Details ']/parent::div/following-sibling::table//td/a[text()='"+sFileName+"']");
        return await objWrapper.isElementPresent(tblCell, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Additional document '"+sFileName+"' uploaded successfully.";
            else
                sConsole = "Fail : Fail to upload Additional Document '"+sFileName+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_02032021 - click on From BU on TAMBA search pop up
    async clickOnFromBUDDOnTAMBAsearchPopUp()
    {
        let cmbFromBU = by.xpath("//div[@id='tambaSearch']//label[text()='From BU']/following-sibling::select");
        return await objWrapper.clickOnElement(cmbFromBU, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on From BU DD on TAMBA search pop up.";
            else
                sConsole = "Fail : Fail to click on From BU DD on TAMBA search pop up.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_02032021 - select From BU on TAMBA search pop up
    async selectFromBUOnTAMBAsearchPopUp(sFromBU)
    {
        expect(await this.clickOnFromBUDDOnTAMBAsearchPopUp()).toContain("Pass");
        let cmbFromBUOpt = by.xpath("//div[@id='tambaSearch']//label[text()='From BU']/following-sibling::select/option[text()='"+sFromBU+"']");
        return await objWrapper.clickOnElement(cmbFromBUOpt, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Selected option '"+sFromBU+"' in From BU DD on TAMBA search pop up.";
            else
                sConsole = "Fail : Fail to select option '"+sFromBU+"' in From BU DD on TAMBA search pop up.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_02032021 - verify BM owner field displayed
    async verifyBMOwnerIsDisplayedAndMandatory()
    {
        let objBMOwner = by.xpath("//label[text()='BM Owner']/following-sibling::span[@class='text-danger validation']/following-sibling::app-people-picker//input[@name='name']");
        return await objWrapper.isElementPresent(objBMOwner, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : BM Owner field is displayed and is mandatory";
            else
                sConsole = "Fail : Fail to verify that BM Owner field is displayed and is mandatory";
            console.info(sConsole);
            return sConsole;
        })
    }

    //Richa_02032021 - Verify consumables Details section is present
    async verifyConsumablesDtlSectionPresent()
    {
        let objConsumableDtls = by.xpath("//h3[contains(text(),'Consumables Details')]/parent::div[@id='headingFive']");
        return await objWrapper.isElementPresent(objConsumableDtls, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Consumables Details section is present on opportunity info screen.";
            else
                sConsole = "Fail : Fail to verify that consumables Details section is present on Opportunity info screen.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_02032021 - Verify tooltip is present for Estimator Name field
    async verifyEstimatorNameTooltip(sToolTip)
    {
        let objToolTip = by.xpath("//label[contains(text(),'Estimator Name')]/i[@ngbtooltip='"+sToolTip+"']");
        return await objWrapper.isElementPresent(objToolTip, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Estimator Name field is having tooltip '"+sToolTip+"'.";
            else
                sConsole = "Fail : Fail to find tooltip '"+sToolTip+"' for field Estimator Name.";
            console.info(sConsole);
            return sConsole;
        })
    }

    //Richa_03032021 - Set other AMAT product value
    async setOtherAMATProdVal(sOtherAMATProd)
    {
        let txtAMATOtherProd = by.css("input[name='otherProductLine']");
        await objWrapper.setInputValue(txtAMATOtherProd, sOtherAMATProd, objWrapper.iDefaultTimeout);
        return await objWrapper.getElementAttribute(txtAMATOtherProd, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sOtherAMATProd)
                sConsole = "Pass : Set value '"+sOtherAMATProd+"' in AMAT Other Product textbox.";
            else
                sConsole = "Fail : Fail to set value '"+sOtherAMATProd+"' in AMAT Other Product textbox.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_03032021 - verify tooltip displayed against submit button
    async getSubmitBtnTooltip()
    {
        let objTooltip = by.xpath("//button[contains(text(), 'Submit')]/following-sibling::span/i");
        return await objWrapper.getElementAttribute(objTooltip, "ngbtooltip", objWrapper.iDefaultTimeout).then(function(sText){
            console.info("Tooltip against submit button is displayed as '"+sText+"'.");
            return sText;
        });
    }

    //Richa_04032021 - click on wafer stack option
    async clickWaferStackOption(sOption)
    {
        let chkWaferStack = by.xpath("//label[contains(text(),'Wafer Stack')]/following-sibling::div//label[@for='w"+sOption+"']");
        return await objWrapper.clickOnElement(chkWaferStack, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on wafer stack option '"+sOption+"'.";
            else
                sConsole = "Fail : Fail to click on wafer stack option '"+sOption+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_04032021 - click on browse button against field name
    async clickOnBrowseButtonAgainstField(sFieldName)
    {
        let btnBrowse = by.xpath("//label[contains(text(),'"+sFieldName+"')]/ancestor::div[contains(@class,'form-row')]/following-sibling::div[1]//label[contains(@class,'custom-file-label')]");
        return await objWrapper.clickOnElementUsingActionClass(btnBrowse, objWrapper.iDefaultTimeout).then(function(bRes){
        // return await objWrapper.clickOnElement(btnBrowse, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on '"+sFieldName+"' browse button.";
            else
                sConsole = "Fail : Fail to click on '"+sFieldName+"' browse button.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_04032021 - verify document browsed against field
    async verifyDocBrowsedAgainstField(sFieldName, sFileName)
    {
        let lblFileUploaded = by.xpath("//label[contains(text(),'"+sFieldName+"')]/ancestor::div[contains(@class,'form-row')]/following-sibling::div[1]//label[contains(@class,'custom-file-label')]");
        return await objWrapper.getElementText(lblFileUploaded, objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sFileName)
                sConsole = "Pass : For '"+sFieldName+"' '"+sFileName+"' browsed successfully.";
            else
                sConsole = "Fail : Fail to browse file '"+sFileName+"' against field '"+sFieldName+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_04032021 - click on upload button against field
    async clickOnUploadButtonAgainstField(sFieldName)
    {
        let btnUpload = by.xpath("//label[contains(text(),'"+sFieldName+"')]/ancestor::div[contains(@class,'form-row')]/following-sibling::div[1]//button[text()='Upload']");
        //await objWrapper.javascriptClickOnElement(btnBrowse, objWrapper.iDefaultTimeout);
        return await objWrapper.clickOnElement(btnUpload, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on Upload button against field '"+sFieldName+"'.";
            else
                sConsole = "Fail : Fail to click on Upload button against field '"+sFieldName+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_04032021 - verify document uploaded against field 
    async verifyDocumentUploadedAgainstField(sFieldName, sFileName)
    {
        let tblCell = by.xpath("//label[contains(text(),'"+sFieldName+"')]/ancestor::div[contains(@class,'form-row')]/following-sibling::table//td/a[text()='"+sFileName+"']");
        return await objWrapper.isElementPresent(tblCell, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Document '"+sFileName+"' uploaded against field '"+sFieldName+"'.";
            else
                sConsole = "Document '"+sFileName+"' against field '"+sFieldName+"' not found.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_04032021 - verify checkbox status against field
    async verifyChkboxStatusAgainstField(sFieldName, sChkboxName, sExpStatus)
    {
        let chkField = by.xpath("//label[contains(text(),'"+sFieldName+"')]/following-sibling::div//label[@for='"+sChkboxName+"']/preceding-sibling::input|//label[contains(text(),'"+sFieldName+"')]/following-sibling::div//label[@for='w"+sChkboxName+"']/preceding-sibling::input")
        return await objWrapper.getElementAttribute(chkField, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sExpStatus)
                sConsole = "Pass : '"+sChkboxName+"' Checkbox status against field name '"+sFieldName+"' is '"+sExpStatus+"'.";
            else
                sConsole = "Fail : Fail to verify staus of checkbox '"+sChkboxName+"' against field name '"+sFieldName+"' is '"+sExpStatus+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_05032021 - get drop down values
    async getDDValues(sDDName)
    {
        let cmbDD = by.xpath("//label[text()='"+sDDName+"']/following-sibling::select/option|//label[text()='"+sDDName+"']/following-sibling::div/ng-select//span[@class='ng-option-label']");
        if(sDDName == "Demo Type")
            cmbDD = by.css("ng-multiselect-dropdown[name='demotype1'] li>div");
        else if(sDDName == "Secondary BU")
            cmbDD = by.css("ng-dropdown-panel.ng-dropdown-panel span");
        console.log(cmbDD);
        return await objWrapper.getElementsText(cmbDD, "Values in DD '"+sDDName+"' are : ");
    }

    //Richa_05032021 - verify customer spec field is mandatory
    async verifyCustSpecFieldIsMandatory()
    {
        let objCustSpec = by.xpath("/label[contains(text(), 'Customer Spec')]/span[@class='star']");
        return await objWrapper.isElementPresent(objCustSpec, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Customer Spec field is mandatory.";
            else
                sConsole = "Customer Spec field is non mandatory.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_120032021 - verify field is mandatory
    async verifyFieldIsMandatory(sFieldName)
    {
        let objField = by.xpath("//label[text()='"+sFieldName+"']/following-sibling::span[text()='*']");
        return await objWrapper.isElementPresent(objField, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Field '"+sFieldName+"' is mandatory.";
            else
                sConsole = "Field '"+sFieldName+"' is non mandatory.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_12032021 - open dd list
    async openDDList(sDDLabel)
    {
        let cmbDD = by.xpath("//label[text()='"+sDDLabel+"']/following-sibling::div//input|//label[text()='"+sDDLabel+"']/following-sibling::ng-select//input");
        let cmbWEDD
        await objWrapper.getWebelement(cmbDD, objWrapper.iDefaultTimeout).then(function(objWE){
            cmbWEDD = objWE;
        });
        cmbWEDD.sendKeys(Key.ARROW_DOWN);
        let objDDList = by.css("ng-dropdown-panel.ng-dropdown-panel");
        return await objWrapper.isElementPresent(objDDList, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Open '"+sDDLabel+"' DD list.";
            else
                sConsole = "Fail : Fail to open '"+sDDLabel+"' DD list.";
            console.info(sConsole);
            return sConsole;
        })
    }

    //Richa_15032021 - Add BU
    async clickOnAddSecondaryBU()
    {
        let btnAdd = by.css("a[title='Add New']");
        return await objWrapper.clickOnElement(btnAdd, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on Add butoon when Multi BU demo type is selected.";
            else
                sConsole = "Not able to click on Add butoon when Multi BU demo type is selected.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_16032021 - Open BU DD list in secondary BU table
    async openBUDDListInSecondaryBUTable()
    {
        let cmbTableBU = by.xpath("//table[@class='table table-striped top_priority mb-3 mt-1']//tr[1]//td[2]//input");
        let cmbWEDD
        await objWrapper.getWebelement(cmbTableBU, objWrapper.iDefaultTimeout).then(function(objWE){
            cmbWEDD = objWE;
        });
        cmbWEDD.sendKeys(Key.ARROW_DOWN);
        let objDDList = by.css("ng-dropdown-panel.ng-dropdown-panel");
        return await objWrapper.isElementPresent(objDDList, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Opened BU DD list.";
            else
                sConsole = "Not able to open BU DD list.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_16032021 - select customer wafer destination drop down value
    async selectCustWaferDestDDVal(sCustWaferDest)
    {
        let sCustWaferDestValue;
        let cmbCustWaferDest = by.xpath("//label[text()='Customer Wafer Destination']/following-sibling::select");
        // await objWrapper.clickOnElement(cmbCustWaferDest, objWrapper.iDefaultTimeout).then(function(bRes){
        //     if(bRes)
        //         sConsole = "Pass : Click on Customer Wafer Destination drop down.";
        //     else
        //         sConsole = "Fail : Fail to click on Customer Wafer Destination drop down.";
        //     console.info(sConsole);
        // });
        
        let cmbCustWaferDestOpt = by.xpath("//label[text()='Customer Wafer Destination']/following-sibling::select/option[text()='"+sCustWaferDest+"']");
        return await objWrapper.clickOnElement(cmbCustWaferDestOpt, objWrapper.iDefaultTimeout).then(async function(bRes){
            if(bRes)
            {
                sConsole = "Pass : Selected Customer Wafer Destination option '"+sCustWaferDest+"'.";
                await objWrapper.getElementAttribute(cmbCustWaferDestOpt, "ng-reflect-value", objWrapper.iDefaultTimeout).then(function(sText){sCustWaferDestValue = sText});
                browser.executeScript("window.localStorage.setItem('sCustWaferDestVal', '"+sCustWaferDestValue+"');");
            }
            else
                sConsole = "Fail : Fail to select Customer Wafer Destination Option '"+sCustWaferDest+"'.";
            console.info(sConsole);
            return sConsole;
        })
    }

    //Richa_16032021 - verify value selected in drop down
    async verifyValSelectedInCustWaferDestDD(sSelectedVal)
    {
        let cmbCustWaferDest = by.xpath("//label[text()='Customer Wafer Destination']/following-sibling::select");
        let sCustWaferDestVal = browser.executeScript("return window.localStorage.getItem('sCustWaferDestVal');");
        let sCustWaferDestVal1 = await sCustWaferDestVal.then(function(sText){console.log(sText); return sText;});
        return await objWrapper.getElementAttribute(cmbCustWaferDest, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sCustWaferDestVal1)
                sConsole = "Pass : Verified that value selected in Customer Wafer Destination DD is '"+sSelectedVal+"'.";
            else
                sConsole = "Fail : Fail to verify that value selected in Customer Wafer Destination DD is '"+sSelectedVal+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_16032021 - verify Demo Info section displayed
    async verifyDemoInfoSectionDisplayed()
    {
        let objDemoInfoSection = by.xpath("//h3[contains(text(), 'Demo Info')]/ancestor::div[@class='card accordion__item']");
        return await objWrapper.isElementPresent(objDemoInfoSection, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Demo info section displayed successfully.";
            else
                sConsole = "Fail : Fail to display Demo Info section.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_17032021 - select secondary BU
    async selectSecondaryBUInTable(sBU)
    {
        let objTblRows = by.xpath("//table[@class='table table-striped top_priority mb-3 mt-1']/tbody//tr");
        let iRowCount = await objWrapper.getWebelementCount(objTblRows).then(function(sText){console.log(sText); return sText;});
        let cmbTblBU = by.xpath("//table[@class='table table-striped top_priority mb-3 mt-1']//tr["+iRowCount+"]//td[2]//input");
        await objWrapper.setInputValue(cmbTblBU, sBU, objWrapper.iDefaultTimeout);
        let lstTblBuOption = by.xpath("//div[contains(@class, 'ng-dropdown-panel-items')]//span[text()='"+sBU+"']");
        return await objWrapper.clickOnElement(lstTblBuOption, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Selected secondary BU as '"+sBU+"'.";
            else
                sConsole = "Fail : Fail to select secondary BU as '"+sBU+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_17032021 - Select requestor in secondary BU table
    async selectRequestorInSecBUTbl(sRequestor)
    {
        let objTblRows = by.xpath("//table[@class='table table-striped top_priority mb-3 mt-1']/tbody//tr");
        let iRowCount = await objWrapper.getWebelementCount(objTblRows).then(function(sText){console.log(sText); return sText;});
        let txtTblRequestor = by.xpath("//table[@class='table table-striped top_priority mb-3 mt-1']//tr["+iRowCount+"]//td[3]//input");
        await objWrapper.setInputCharByChar(txtTblRequestor, sRequestor, objWrapper.iDefaultTimeout);
        await browser.sleep(objWrapper.iMaxTimeout);
        let lstRequestorOpt = by.xpath("//div[@class='completer-dropdown']//span[@class='completer-list-item' and text()='"+sRequestor+"']");
        return await objWrapper.clickOnElement(lstRequestorOpt, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Selected Requestor as '"+sRequestor+"' in table.";
            else
                sConsole = "Fail : Fai to select Requestor as '"+sRequestor+"' in table.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_17032021 - Save secondary BU details
    async clickOnSaveSecondaryBU()
    {
        let btnSave = by.css("a[data-original-title='Save']");
        return await objWrapper.clickOnElement(btnSave, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on Save button in order to save Secondary BU details.";
            else
                sConsole = "Fail : Fail to click on Save button in order to save Secondary BU details.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_22032021 - click on TAMBA status dd
    async clickTAMBAStatusDD()
    {
        let cmbTAMBASTatus = by.xpath("//label[text()='TAMBA Status']/following-sibling::select");
        return await objWrapper.javascriptClickOnElement(cmbTAMBASTatus, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on TAMBA status drop down.";
            else
                sConsole = "Fail : Fail to click on TAMBA status drop down.";
            console.info(sConsole);
            return sConsole;
        })
    }

    //Richa_23032021 - Verify field is editable
    async verifyFieldIsNonEditable(sFieldLabel, sFieldVal, sFieldType)
    {
        let objField = by.xpath("//label[contains(text(),'"+sFieldLabel+"')]/following-sibling::div/ng-select[@ng-reflect-model='"+sFieldVal+"']|//label[contains(text(),'"+sFieldLabel+"')]/following-sibling::div/input[@ng-reflect-model='"+sFieldVal+"']|//label[contains(text(),'"+sFieldLabel+"')]/following-sibling::ng-select[@ng-reflect-model='"+sFieldVal+"']|//label[contains(text(),'"+sFieldLabel+"')]/following-sibling::app-people-picker//input[@name='name' and @ng-reflect-model='"+sFieldVal+"']");
        let sFieldAttribute
        if(sFieldType == "input")
            sFieldAttribute = await objWrapper.getElementAttribute(objField, "readonly", objWrapper.iDefaultTimeout).then(function(sText){console.info("sInputAttribute : " + sText); return sText;});
        else
            sFieldAttribute = await objWrapper.getElementAttribute(objField, "ng-reflect-is-disabled", objWrapper.iDefaultTimeout).then(function(sText){console.info("sDDAttribute : " + sText); return sText;});
        if(sFieldAttribute != "false")
            sConsole = "Pass : Verified field '"+sFieldLabel+"' is non editable";
        else
            sConsole = "Field '"+sFieldLabel+"' is editable";
        console.info(sConsole);
        return sConsole;
        
    }

    //Richa_23032021 - Click on toggle button
    async clickOnToggleField(sFieldLabel)
    {
        let sFieldLabel1, sFieldName;
        let objTAMBAState;
        switch(sFieldLabel)
        {
            case "Resource Estimation to Execute Demo (Optional)" :
                sFieldName = "estimation";
                objTAMBAState = by.xpath("//h3[contains(text(),'"+sFieldLabel+"')]/following-sibling::div[contains(@class, 'switchToggle')]/input");
                break;
            case "BM Approved" :
                sFieldName = "isBmApproved";
                objTAMBAState = by.xpath("//label[text()='"+sFieldLabel+"']/following-sibling::div[@class='switchToggle']/input");
                break;
            default :
                sFieldLabel1 = sFieldLabel.toLowerCase();
                sFieldName = objWrapper.convertToCamelCase(sFieldLabel1);
                objTAMBAState = by.xpath("//label[text()='"+sFieldLabel+"']/following-sibling::div[@class='switchToggle']/input");
        }
        
        let objTAMBAToggle = by.css("div.switchToggle>input[name='"+sFieldName+"']+label");
         
        return await objWrapper.javascriptClickOnElement(objTAMBAToggle, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on '"+sFieldLabel+"' toggle button.";
            else
                sConsole = "Fail : Fail to click on '"+sFieldLabel+"' toggle button.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_23032021 - verify toggle button state
    async verifyToggleFieldState(sFieldLabel, bState)
    {
        let sFieldLabel1, sFieldName;
        let objTAMBAState;
        switch(sFieldLabel)
        {
            case "Resource Estimation to Execute Demo (Optional)" :
                sFieldName = "estimation";
                objTAMBAState = by.xpath("//h3[contains(text(),'"+sFieldLabel+"')]/following-sibling::div[contains(@class, 'switchToggle')]/input");
                break;
            case "BM Approved" :
                sFieldName = "isBmApproved";
                objTAMBAState = by.xpath("//label[text()='"+sFieldLabel+"']/following-sibling::div[@class='switchToggle']/input");
                break;
            default :
                sFieldLabel1 = sFieldLabel.toLowerCase();
                sFieldName = objWrapper.convertToCamelCase(sFieldLabel1);
                objTAMBAState = by.xpath("//label[text()='"+sFieldLabel+"']/following-sibling::div[@class='switchToggle']/input");
        }
        
        var bActState = false;
        await objWrapper.getElementAttribute(objTAMBAState, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
            console.log("sText : "+sText);
            if(sText == "true")          
                bActState = true;   
        });
       
        if(bActState == bState)
            sConsole = "Pass : Field '"+sFieldLabel+"' is having toggle state as '"+bState+"'.";
        else
            sConsole = "Fail : Fail to verify field '"+sFieldLabel+"' is having toggle state as '"+bState+"'.";
        console.info(sConsole);
        return sConsole;
    }

    //Richa_23032021 - Verify radio button present
    async verifyRadioBtnPresent(sRadioBtnName)
    {
        await objWrapper.scrollWindowToTopLeft();
        let rButton = by.xpath("//label[contains(text(),'"+sRadioBtnName+"')]/preceding-sibling::input");
        return await objWrapper.isElementPresent(rButton, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Radio button '"+sRadioBtnName+"' is present.";
            else
                sConsole = "Fail : Radio button '"+sRadioBtnName+"' is not present.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_23032021 - Verify radio button present
    async clickOnRadioBtn(sRadioBtnName)
    {
        let rButton = by.xpath("//label[contains(text(),'"+sRadioBtnName+"')]/preceding-sibling::input");
        return await objWrapper.javascriptClickOnElement(rButton, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on radio button '"+sRadioBtnName+"'.";
            else
                sConsole = "Fail : Fail to click on radio button '"+sRadioBtnName+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_23032021 - Verify Special Group to Be informed drop down is present
    async verifySpecialGrpToBeInformedDDPresent()
    {
        let rButton = by.xpath("//label[text()='Special Group to be Informed']/following-sibling::ng-multiselect-dropdown");
        return await objWrapper.isElementPresent(rButton, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Special Group To Be Informed drop down is present.";
            else
                sConsole = "Fail : Special Group To Be Informed drop down is not present.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_24032021 - select option from mutlti select list
    async selectOptionFromMultiSelectList(sDDName, sListOption)
    {
        let objDDOption = by.xpath("//div[@class='dropdown-list']//li/div[text()='"+sListOption+"']");
        return await objWrapper.javascriptClickOnElement(objDDOption, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on '"+sDDName+"' option '"+sListOption+"'.";
            else
                sConsole = "Fail : Fail to click on '"+sDDName+"' option '"+sListOption+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_24032021 - select option from mutlti select list
    async deselectOptionFromMultiSelectList(sDDName, sListOption)
    {
        await objWrapper.scrollWindowToTopLeft();
        let objDDOption = by.xpath("//div[@class='dropdown-list']//li/div[text()='"+sListOption+"']");
        await objWrapper.javascriptClickOnElement(objDDOption, objWrapper.iDefaultTimeout)
        return await objWrapper.isCheckboxSelected(objDDOption, objWrapper.iDefaultTimeout).then(function(bRes){
            if(!bRes)
                sConsole = "Pass : Deselected '"+sDDName+"' option '"+sListOption+"'.";
            else
                sConsole = "Fail : Fail to deselect '"+sDDName+"' option '"+sListOption+"'.";
            console.info(sConsole);
            
            return sConsole;
        });
    }

    //Richa_24032021 - Verify Special Group drop down is present
    async verifyFieldIsPresent(sFieldLabel)
    {
        let objField = by.xpath("//label[contains(text(),'"+sFieldLabel+"')]/following-sibling::div//input");
        return await objWrapper.isElementPresent(objField, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : '"+sFieldLabel+"' is present on create new demo request page.";
            else
                sConsole = "Fail : Fail to find presence of '"+sFieldLabel+"' on create new demo request page.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_24032021 - Select wafer size from DD
    async selectWaferSize(sWaferSize)
    {
        let cmbWaferSize = by.xpath("//label[text()='Wafer Size']/following-sibling::div/select/option[contains(text(),'"+sWaferSize+"')]");
        return await objWrapper.clickOnElement(cmbWaferSize, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on wafer size '"+sWaferSize+"'.";
            else
                sConsole = "Fail : Fail to click on wafer size '"+sWaferSize+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }
    //Nidhi-23/03/2021- Verify the date in the uploaded details section for specific field
    async verifyDateTimeAgainstField(sFieldName)
    {   
        let tblCell = by.xpath("//label[contains(text(),'"+sFieldName+"')]/ancestor::div[contains(@class,'form-row')]/following-sibling::table//td[2]");
        return await objWrapper.getElementText(tblCell,objWrapper.iDefaultTimeout).then(function(sText){
            console.info("Pass : Field '"+sFieldName+"' is having Date/Time as Today's Date as "+sText+".")
            return sText;								
		});
	}
    //Richa_29032021 - Click delete against uploaded document
    async clickDeleteAgainstUploadedDoc(sFieldName, sDocNameWithExt)
    {
        let btnDelete = by.xpath("//label[contains(text(),'"+sFieldName+"')]/ancestor::div[contains(@class,'form-row')]/following-sibling::table//a[text()='"+sDocNameWithExt+"']/parent::td/following-sibling::td/a[contains(@class,'btn-danger')]");
        return await objWrapper.clickOnElement(btnDelete, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on delete against document '"+sDocNameWithExt+"' against field '"+sFieldName+"'.";
            else
                sConsole = "Fail : Fail to click on delete against document '"+sDocNameWithExt+"' against field '"+sFieldName+"'.";
            console.info(sConsole);
            return sConsole;
        });

    }

    //Richa_29032021 - Click on add to add manual customer spec details
    async clickAddManualCustSpecDtls()
    {
        let btnAdd = by.xpath("//label[contains(text(),'Customer Spec')]/ancestor::div[contains(@class,'form-row')]/following-sibling::app-basic//a[@title='Add New']");
        return await objWrapper.clickOnElement(btnAdd, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on Add New button in order to add new manual customer spec details.";
            else
                sConsole = "Fail : Fail to click on Add New button in order to add new manual customer spec details.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_29032021 - select customer spec attribute for editing
    async selectCustSpecAttrbForEdit(sAttribute)
    {
        let tblRow = by.xpath("//label[contains(text(),'Customer Spec')]/ancestor::div[contains(@class,'form-row')]/following-sibling::app-basic//table[@class='table table-striped top_priority mb-3 mt-1']/tbody/tr");
        let iRowCount, iRow = 0;
        await objWrapper.getWebelementCount(tblRow).then(function(iCnt){iRowCount = iCnt});
        for(let iCount = 1; iCount <= iRowCount; iCount++)
        {
            let txtAttrbCat = by.xpath("//label[contains(text(),'Customer Spec')]/ancestor::div[contains(@class,'form-row')]/following-sibling::app-basic//table[@class='table table-striped top_priority mb-3 mt-1']/tbody/tr["+iCount+"]/td[2]//input");
            await objWrapper.getValueAttributeUsingJavascript(txtAttrbCat, objWrapper.iDefaultTimeout).then(async function(sText){
                console.log(sText);
                if(sText == sAttribute)
                {
                    let chkTableSelect = by.xpath("//label[contains(text(),'Customer Spec')]/ancestor::div[contains(@class,'form-row')]/following-sibling::app-basic//table[@class='table table-striped top_priority mb-3 mt-1']/tbody/tr["+iCount+"]/td[1]/div");
                    return await objWrapper.clickOnElement(chkTableSelect, objWrapper.iDefaultTimeout).then(function(bRes){
                        if(bRes)
                            sConsole = "Pass : Clicked in customer spec table checkbox with attribute '"+sAttribute+"'.";
                        else
                            sConsole = "Fail : Fail to click in customer spec table checkbox with attribute '"+sAttribute+"'.";
                        
                    });
                }
                    
                //     sConsole = "Pass : Set attribute category value as '"+sAttrbCategory+"'";
                // else
                //     sConsole = "Fail : Fail to set attribute category value as '"+sAttrbCategory+"'";
                // console.info(sConsole);
                // return sConsole;
            });
        }
        console.info(sConsole);
        return sConsole;
        
    }

    //Richa_30032021 - Click on edit to edit manual customer spec details
    async clickEditManualCustSpecDtls()
    {
        let btnEdit = by.xpath("//label[contains(text(),'Customer Spec')]/ancestor::div[contains(@class,'form-row')]/following-sibling::app-basic//a[@title='Edit']");
        return await objWrapper.clickOnElement(btnEdit, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on Edit button in order to edit manual customer spec details.";
            else
                sConsole = "Fail : Fail to click on Edit button in order to edit manual customer spec details.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_30032021 - Click on delete to delete manual customer spec details
    async clickDeleteManualCustSpecDtls()
    {
        let btnEdit = by.xpath("//label[contains(text(),'Customer Spec')]/ancestor::div[contains(@class,'form-row')]/following-sibling::app-basic//a[@title='Delete']");
        return await objWrapper.clickOnElement(btnEdit, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on Delete button in order to delete manual customer spec details.";
            else
                sConsole = "Fail : Fail to click on Delete button in order to delete manual customer spec details.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_30032021 - Set manual wafer stack comment
    async setManualWaferStackComment(sWaferStackComment)
    {
        let txtWaferStackComment = by.xpath("//label[contains(text(),'Wafer Stack')]/ancestor::div[contains(@class,'form-row')]/following-sibling::div//textarea[@name='manualWaferStackComment']");
        await objWrapper.setInputValue(txtWaferStackComment, sWaferStackComment, objWrapper.iDefaultTimeout);
        return await objWrapper.getElementAttribute(txtWaferStackComment, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sWaferStackComment)
                sConsole = "Pass : Set manual wafer stack comment as '"+sWaferStackComment+"'.";
            else
                sConsole = "Fail : Fail to set manual wafer stack comment as '"+sWaferStackComment+"'.";
            
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_01042021 - verify delete button present against uploaded document
    async verifyDeleteBtnPresentAgainstUploadedDoc(sFieldName, sDocNameWithExt)
    {
        let btnDelete = by.xpath("//label[contains(text(),'"+sFieldName+"')]/ancestor::div[contains(@class,'form-row')]/following-sibling::table//a[text()='"+sDocNameWithExt+"']/parent::td/following-sibling::td/a[contains(@class,'btn-danger')]");
        return await objWrapper.isElementPresent(btnDelete, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Delete button present against document '"+sDocNameWithExt+"' against field '"+sFieldName+"'.";
            else
                sConsole = "Delete button not present against document '"+sDocNameWithExt+"' against field '"+sFieldName+"'.";
            console.info(sConsole);
            return sConsole;
        });

    }

    //Richa_05042021- get date in the uploaded details section for specific field against specified document
    async getDateTimeAgainstDocInField(sFieldName, sDocNameWithExtn)
    {   
        let tblCell = by.xpath("//label[contains(text(),'"+sFieldName+"')]/ancestor::div[contains(@class,'form-row')]/following-sibling::table//a[text()='"+sDocNameWithExtn+"']/parent::td/following-sibling::td[1]");
        return await objWrapper.getElementText(tblCell,objWrapper.iDefaultTimeout).then(function(sText){
            console.info("Date time value against document '"+sDocNameWithExtn+"' in field '"+sFieldName+"' is "+ sText);
            return sText;
        });
        
    }

    //Richa_06042021 - set value in CAT RAT project id
    async setCATRATProjectID(sCATRATId)
    {
        let txtCATRATId = by.css("input#ratNo");
        await objWrapper.setInputCharByChar(txtCATRATId, sCATRATId, objWrapper.iDefaultTimeout);
        return await objWrapper.getElementAttribute(txtCATRATId, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sCATRATId)
                sConsole = "Pass : Set CAT/RAT project id as '"+sCATRATId+"'.";
            else
                sConsole = "Fail : Fail to set CAT/RAT project id as '"+sCATRATId+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_06042021 - set CAT/RAT Project ID from list
    async selectCATRATPrjIDFromList(sCATRATId)
    {
        let txtCATRATId = by.css("input#ratNo");
        await objWrapper.setInputCharByChar(txtCATRATId, sCATRATId, objWrapper.iDefaultTimeout);
        // await objWrapper.sendKeysInActiveElmnt("Backspace");
        // await objWrapper.setAttributeUsingJavaScript(txtCATRATId, objWrapper.iDefaultTimeout, "ng-reflect-model", sCATRATId);
        await browser.sleep(10000);
        let lstCATRATId = by.xpath("//div[@class='completer-item-text']//span[text()='"+sCATRATId+"']");
        return await objWrapper.clickOnElement(lstCATRATId, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on CAT/RAT Project# list item '"+sCATRATId+"'.";
            else
                sConsole = "Fail : Fail to click on CAT/RAT Project# list item '"+sCATRATId+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_07042021 - Set number of AMAT customer wafers for wafer type
    async setNoOfWafersForWaferType(sAMATCust, sWaferType, sWaferCnt)
    {
        let sName = "noOf" + sWaferType + sAMATCust + "Waffer";
        let txtNoOfWafers = by.css("input[name='"+sName+"']");
        await objWrapper.setInputValue(txtNoOfWafers, sWaferCnt, objWrapper.iDefaultTimeout);
        return await objWrapper.getElementAttribute(txtNoOfWafers, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sWaferCnt)
                sConsole = "Pass : Set number of '"+sAMATCust+"' wafers for wafer type '"+sWaferType+"' as '"+sWaferCnt+"'";
            else
                sConsole = "Fail : Fail to set number of '"+sAMATCust+"' wafers for wafer type '"+sWaferType+"' as '"+sWaferCnt+"'";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_08042021 - Click on Additional TAMBA search button
    async clickOnAdditionalTAMBASearchBtn()
    {
        let btnAdditionalTAMBASearch = by.xpath("//label[contains(text(), 'Additional TAMBA')]/following-sibling::div/button");
        return await objWrapper.javascriptClickOnElement(btnAdditionalTAMBASearch, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on Additional TAMBA search button";
            else
                sConsole = "Fail : Fail to click on Additional TAMBA search button.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_08042021 - Click on From BU option on Additiona BU tamba search pop up
    async selectFromBUOnAdditionalBUTambaSearchPopUp(sBu)
    {
        let cmbFromBu = by.xpath("//h5[text()='Tamba']/parent::div[@class='modal-header']/following-sibling::div//label[text()='From BU']/following-sibling::select[@ng-reflect-name='additionalBu']/option[text()='"+sBu+"']");
        return await objWrapper.clickOnElement(cmbFromBu, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Selected From BU value as '"+sBu+"' on additiona BU tamba search pop up.";
            else    
                sConsole = "Fail : Fail to select From BU value as '"+sBu+"' on additiona BU tamba search pop up.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_08042021 - Click on Go button on Additiona BU tamba search pop up
    async clickGoOnAdditionalBUTambaSearchPopUp()
    {
        let btnGo = by.css("div#specialGrouptambaSearch button.btn.btn-info.btnSearch");
        return await objWrapper.clickOnElement(btnGo, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Click on Go button on additiona BU tamba search pop up.";
            else    
                sConsole = "Fail : Fail to clickOnGo button on additiona BU tamba search pop up.";
            console.info(sConsole);
            return sConsole;
        });
    }

    async getTambaTblRowCountOnAdditionalTambaSearchPopUp()
    {
        let tblTambaRows = by.xpath("//div[@id='specialGrouptambaSearch']//div[@class='tambaTable']//tbody/tr");
        return await objWrapper.getWebelementCount(tblTambaRows);
    }

    async selectTambaRowOnAdditionalTambaSearchPopUp()
    {
        var iRNum;   
        let bRowRes =  await this.getTambaTblRowCountOnTambaSearchPopUp().then(async function(iCount){
            if(iCount > 0)
            {
                console.log(iCount);
                iRNum = Math.floor(Math.random()*(iCount - 1)) + 1;
                console.log(iRNum);
                return true;
            }                   
        });
        if(bRowRes)
        {
            var sTambaNum;
            let objRowSelection = by.xpath("//div[@id='specialGrouptambaSearch']//div[@class='tambaTable']//tbody/tr["+iRNum+"]/td[1]/label");
            // await this.saveSelectedTambaValues(iRNum);
            let objRowTambaNumber = by.xpath("//div[@id='specialGrouptambaSearch']//div[@class='tambaTable']//tbody/tr["+iRNum+"]/td[2]");
            await objWrapper.getElementText(objRowTambaNumber, objWrapper.iDefaultTimeout).then(function(sNum){
                console.log(sNum);
                sTambaNum = sNum;
            });
            return await objWrapper.clickOnElement(objRowSelection, objWrapper.iDefaultTimeout).then(function(bRes){    
                if(bRes)
                    sConsole = "Pass : Selected tamba number " + sTambaNum;
                else
                    sConsole = "Fail : Fail to select tamba number " + sTambaNum;
                console.info(sConsole);
                return sConsole;
            });
        }
        else
        {
            sConsole = "Fail : Fail to find rows in Tamba table on Additional Tamba search pop up.";
            console.info(sConsole);
            return sConsole;
        } 
    }

    async clickOnSubmitOnAdditionalTambaSearchPopUp()
    {
        let btnSubmit = by.xpath("//div[@id='specialGrouptambaSearch']//button[contains(text(), 'Submit')]");
        return await objWrapper.clickOnElement(btnSubmit, objWrapper.iDefaultTimeout).then(function(bRes){    
            if(bRes)
                sConsole = "Pass : Clicked on Submit button on additional TAMBA search pop up.";
            else
                sConsole = "Fail : Fail to click on Submit button on additional TAMBA search pop up.";
            console.info(sConsole);
            return sConsole;
        });
    }	 
	//Richa_20042021 - verify Submit button is enabled
    async verifySubmitBtnIsEnabled()
    {
        let btnSubmit = by.xpath("//button[contains(text(), 'Submit')]");
        return await objWrapper.isElementEnabled(btnSubmit, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Submit button is enabled.";
            else
                sConsole = "Submit button is disabled.";
            console.info(sConsole);
            return sConsole;
        });
    }												  
   //Richa_23042021 - set repeat demo id
    async setRepeatDemoID(sDemoId)
    {
        let txtRepeatDemoId = by.xpath("//label[text()='Repeat Demo#']/following-sibling::div//input");
        await objWrapper.setInputCharByChar(txtRepeatDemoId, sDemoId, objWrapper.iMinTimeout);
        let lstDemo = by.css("div.completer-dropdown completer-List-Item[ng-reflect-text='"+sDemoId+"']");
        return await objWrapper.clickOnElement(lstDemo, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Set value in repeat demo ID as '"+sDemoId+"'.";
            else
                sConsole = "Fail : Fail to set value in repeat demo ID as '"+sDemoId+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_26042021 - Verify fied not present
    async verifyFieldNotPresent(sFieldLabel)
    {
        let objField = by.xpath("//label[text() = '"+sFieldLabel+"']/following-sibling::div//input[@type='text]");
        return await objWrapper.isElementPresent(objField, objWrapper.iDefaultTimeout).then(function(bRes){
            if(!bRes)
                sConsole = "Pass : '"+sFieldLabel+"' is not present on create new demo request page.";
            else
                sConsole = "Fail : '"+sFieldLabel+"' is present on create new demo request page.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_26042021 - get table headers on TAMBA search pop up
    async getTblHrdsOnTAMBASearchPopUp()
    {
        let tblHeaders = by.css("div#tambaSearch table th");
        return await objWrapper.getElementsText(tblHeaders, "Table column headers on TAMBA search pop up are ");
    }

    //Richa_26042021 - verify TAMBA search pop up displayed
    async verifyTAMBASearchPopUpDisplayed()
    {
        let objTAMBAPopUp = by.xpath("//div[@id='tambaSearch']//div[@class='modal-header']/h5[contains(text(),'Tamba')]|//div[@class='modal-header']/h4[contains(text(),'Tamba')]");
        return await objWrapper.isElementPresent(objTAMBAPopUp, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : TAMBA search pop up displayed.";
            else
                sConsole = "Fail : Fail to find TAMBA search pop up.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_26042021 - click cancel on TAMBA search pop up
    async clickCancelOnTAMBASearchPopUp()
    {
        let btnCancel = by.xpath("//div[@id='tambaSearch']//div[@class='modal-footer']/button[contains(text(),'Cancel')]");
        return await objWrapper.clickOnElement(btnCancel, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked Cancel on TAMBA search pop up.";
            else
                sConsole = "Fail : Fail to click on Cancel button on TAMBA search pop up.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_23032021 - Verify requested completion date value is non editable
    async verifyReqCompDateIsNonEditable(sFieldVal)
    {
        let objField = by.css("input[name='reqCompletionDate']");
        let sFieldAttribute
        // if(sFieldType == "input")
        sFieldAttribute = await objWrapper.getElementAttribute(objField, "value", objWrapper.iDefaultTimeout).then(function(sText){console.info("sInputAttribute : " + sText); return sText;});
        // else
        //     sFieldAttribute = await objWrapper.getElementAttribute(objField, "ng-reflect-is-disabled", objWrapper.iDefaultTimeout).then(function(sText){console.info("sDDAttribute : " + sText); return sText;});
        if(sFieldAttribute != "false" && sFieldAttribute != null)
            sConsole = "Pass : Verified that Requested Completion Date field is having value '"+sFieldVal+"' and is non editable.";
        else
            sConsole = "Fail to Verify that Requested Completion Date field is having value '"+sFieldVal+"' and is non editable.";
        console.info(sConsole);
        return sConsole;
        
    }

    //Richa_02032021 - select requestor
    async selectRequestor(sValue)
    {
        let txtPplPicker = by.xpath("//label[contains(text(),'Requestor')]/following-sibling::app-people-picker//input[@name='name']");
        await objWrapper.setInputCharByChar(txtPplPicker, sValue, objWrapper.iDefaultTimeout);
        await browser.sleep(5000);
        let lstPplPicker = by.xpath("//ul[@class='list-group']//a[contains(text(),'"+sValue+"')]/parent::li");
        await objWrapper.javascriptClickOnElement(lstPplPicker, objWrapper.iDefaultTimeout);
        let objSelectedPplPicker = by.xpath("//label[contains(text(), 'Requestor')]/following-sibling::app-people-picker//input[@name='name_hide']");
        return await objWrapper.getElementAttribute(objSelectedPplPicker, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
            if(sText.match(sValue))
                sConsole = "Pass : Clicked on Requestor list option '"+sValue+"'.";
            else
                sConsole = "Fail : Fail to click on Requestor list option '"+sValue+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }
    //Nidhi-30/04/2021 set Number in teh range field
    async setNumberInRangeField(sFieldName, sFieldVal)
    {
        let txtField = by.xpath("//label[contains(text(), '"+sFieldName+"')]//following-sibling::input");
        await objWrapper.setInputValue(txtField, sFieldVal, objWrapper.iDefaultTimeout);
        return await objWrapper.getElementAttribute(txtField, 'ng-reflect-model', objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sFieldVal)
                sConsole = "Pass : Set '"+sFieldName+"' value as '"+sFieldVal+"'.";
            else
                sConsole = "Fail : Fail to set '"+sFieldName+"' value as '"+sFieldVal+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }
}