import { wrapper } from '../utils/wrapper.util';
import { element, by, browser } from 'protractor';
import { BrowserUtil } from '../utils/browser.util';
import { SpecReporter } from 'jasmine-spec-reporter';
import { connected } from 'process';

let objWrapper:wrapper;
let sConsole;
export class myDemoTasksPage{
    constructor()
    {
        objWrapper = new wrapper();
    }

    //Namrata-12/04/2021- verify the status of Demo in table
    async verifyDemoStatusInTableGrid(sDemoName, sDemoApprovalStatus)
    {console.log("innn");
        let objDemoStatus = by.xpath("//div[@col-id='demoName'][contains(text(),'"+sDemoName+"')]/parent::div//div[contains(text(),'"+sDemoApprovalStatus+"')]");
        return await objWrapper.isElementPresent(objDemoStatus, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
               sConsole = "Pass : Demo request with demo name'"+sDemoName+"' is having demo status as '"+sDemoApprovalStatus+"'.";   
            else
              sConsole = "Verified that demo name'"+sDemoName+"' is not having demo approval status as '"+sDemoApprovalStatus+"'.";  
              console.info(sConsole);
              return sConsole; 
    });
    }

    //Namrata-14/04/2021- Verify Assignments and Estimations page is displayed.
    async verifyAssementsAndEstimationsPageIsDisplayed()
    {
        let objDemoDetails = by.xpath("//h5[contains(text(), 'Assessment & Estimation ')]");
        return await objWrapper.isElementDisplayed(objDemoDetails, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)			 
                sConsole = "Pass : Assessment & Estimation page displayed successfully";	 
            else			 
                sConsole = "Fail : Fail to display Assessment & Estimation page.";
            console.info(sConsole);
            return sConsole;			 
        })
    }

//Namrata-14/04/2021- Verify specified demo is displayed.
    async verifyDemoisDisplayed(sDemoName)
    {
        let tblDemoNumber = by.xpath("//div[@col-id='demoName' and contains(text(), '"+sDemoName+"')]");
       
        return await objWrapper.isElementDisplayed(tblDemoNumber, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)			 
                sConsole = "Pass : "+sDemoName+" Demo request is displayed on My Demo Tasks page";	 
            else			 
                sConsole = "Fail :  "+sDemoName+" Demo request is not displayed on My Demo Tasks page";
            return sConsole;
        });
    }

    async verifyFieldIsDisplayed(sFieldLabel)
    {
        let objField = by.xpath("//label[contains(text(),'"+sFieldLabel+"')]/following-sibling::div//input | //label[contains(text(),'"+sFieldLabel+"')]/following-sibling::select | //label[contains(text(),'"+sFieldLabel+"')]/following-sibling::input");
        return await objWrapper.isElementPresent(objField, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : '"+sFieldLabel+"' is displayed";
            else
                sConsole = "Fail : Fail to find presence of "+sFieldLabel;
            console.info(sConsole);
            return sConsole;
        });
    }
}