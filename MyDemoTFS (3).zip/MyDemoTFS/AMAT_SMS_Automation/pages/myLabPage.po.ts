import { wrapper } from '../utils/wrapper.util';
import { element, by, browser } from 'protractor';
import { BrowserUtil } from '../utils/browser.util';
import { SpecReporter } from 'jasmine-spec-reporter';
import { demoDetailsPage } from '../pages/demoDetailsPage.po';
let objWrapper:wrapper;
let objDemoDetailsPage:demoDetailsPage;
let sConsole;
export class myLabPage{
    constructor()
    {
        objWrapper = new wrapper();
        objDemoDetailsPage = new demoDetailsPage();
    }

    
    async clickOnCalendarIcon(sFieldName)
    {            
        let calXpath = by.xpath("//label[text()='"+sFieldName+"']/parent::div//div//button[@aria-label='Select date']");
        return await objWrapper.clickOnElement(calXpath, objWrapper.iDefaultTimeout).then(function(bRes){     
         if(bRes)            
                sConsole = "Pass : Clicked on calendar icon on "+sFieldName+" popup";
        else
            sConsole = "Not able to click on calendar icon on "+sFieldName+"popup";
        console.info(sConsole);
        return sConsole;
        });
    }

}