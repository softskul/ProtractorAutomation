import { wrapper } from '../utils/wrapper.util';
import { element, by, browser } from 'protractor';
import { BrowserUtil } from '../utils/browser.util';
import { SpecReporter } from 'jasmine-spec-reporter';
import { commonPage } from './commonPage.po';
let objWrapper:wrapper;
let objCommonPage:commonPage;
let sConsole;
export class homePage{
    constructor()
    {
        objWrapper = new wrapper();
        objCommonPage = new commonPage();
    }

    async openApplication(sUrl: string) {
        console.log(browser.params.baseUrl + sUrl);
        await browser.get(browser.params.baseUrl + sUrl);
        expect(browser.getCurrentUrl()).toContain(browser.params.baseUrl);
    }
    
    //Richa_26042021 - open webmail
	async openWebmail(sUrl: string) {
        // console.log(browser.params.baseUrl + sUrl);
        await browser.get(sUrl);
        //expect(browser.getCurrentUrl()).toContain(sUrl);
    }

    async refreshAppPage()
    {
        await browser.refresh();
    }

async verifyMyDemoLogo()
    {
        let objLogo = by.xpath("//img[@class='app-logo' and @src='./assets/Images/mydemologo.svg']/span[text()='Dev']");
        return await objWrapper.isElementPresent(objLogo, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
            {
                console.info("MyDemo logo is present.");
                return true;
            }   
            else
            {
                console.error("Fail to find MyDemo logo.");
                return false;
            }
        });
}

async verifyMenuItemPresent(sMenuItem)
    {
        let objMenuItem = by.xpath("//ul[@class='menu ml-auto header']//a[text() = \""+sMenuItem+"\"]");
        return await objWrapper.isElementPresent(objMenuItem, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
            {
                console.info("Menu item '"+sMenuItem+"' is present.");
                return true;
            }   
            else
            {
                console.error("Fail to find menu item " + sMenuItem);
                return false;
            }
        });
}

async clickOnBUDD()
    {
        let cmbBU = by.css("select#bu");
        return await objWrapper.clickOnElement(cmbBU, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
            sConsole ="Pass : Clicked on BU DD ";
            else
            sConsole ="Not able to Click DD";
            console.log(sConsole);
            return sConsole;
        });
        
}

async selectBUOption(sOption)
    {
        let objOption = by.xpath("//select[@id='bu']/option[text()='"+sOption+"']");
        return await objWrapper.clickOnElement(objOption, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
            sConsole ="Pass: Selected on BU option '"+sOption+"'.";
            else
            sConsole ="Not able to select  on BU option '"+sOption+"'.";
            console.log(sConsole);
            return sConsole;
        }); 
}

async selectBU(sOption)
    {
        expect(await this.clickOnBUDD()).toContain("Pass");
        return await this.selectBUOption(sOption);
    }

async verifyRowCountAfterBUSelection(sBU, iTotCount)
    {
        let objTableRow = by.xpath("//div[@col-id='demoNumber' and @role='gridcell' and contains(text(),'"+sBU+"')]/parent::div[contains(@class,'ag-row-last')]");
        return await objWrapper.getElementAttribute(objTableRow, "row-index", objWrapper.iDefaultTimeout).then(function(iLastRowNum){
            if(Number.parseInt(iLastRowNum) == (iTotCount - 1))
            {
                console.info("Row count after BU selection is " + iTotCount);
                return true;
            }
            else
            {
                console.error("Row count after BU selection is expected as '"+iTotCount+"' but in actual it is '"+Number.parseInt(iLastRowNum) + 1+"'")
                return false;
            }
        });
}

async verifyAccountTAMValInDescOrder()
    {
        let objTAMVal = by.css("div[col-id='tam'][role='gridcell']");
        let objTAMHdr = by.css("div[col-id='roiPurpose'][class*='ag-header-cell']");
        await objWrapper.scrollTillElement(objTAMHdr);
        objTAMHdr =  by.css("div[col-id='tam'][class*='ag-header-cell']");
        await objWrapper.scrollTillElement(objTAMHdr);
        let sVal = "", iTotCount, iCount = 1;
        await element.all(objTAMVal).count().then(function(iTot){
            console.log(iTot);
            iTotCount = iTot;
        });
        await element.all(objTAMVal).each(function(objElmnt)
        {
            objElmnt.getText().then(function(sText){
                console.log(sText);
                if(sVal != "")
                {
                    console.log(sVal);
                    if(Number.parseFloat(sVal) >= Number.parseFloat(sText))
                        iCount = iCount + 1;
                }
                else
                    sVal = sText;
            });
        });
        console.log(iTotCount);
        console.log(iCount);
        if(iTotCount == iCount)
            sConsole = "Pass : TAM values in table are in descending order.";
        else
        sConsole= "TAM values in table are not in descending order.";
        console.info(sConsole);
        return sConsole;
           
        
}

    //Click on menu options
async clickOnMenuOption(sMenu)
    {
        let objMenuItem = by.xpath("//ul[@class='menu ml-auto header']//a[text() = \""+sMenu+"\"]");
        return await objWrapper.clickOnElement(objMenuItem, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole="Pass : Clicked on menu option "+sMenu+".";
            else
                sConsole="Fail : Fail to click on menu option "+sMenu+".";
            console.info(sConsole);
            return sConsole;
        });
}
 
    //Click on submenu option
async clickOnSubMenuOption(sSubMenu)
    {
        let objSubMenuOption = by.xpath("//div[contains(@class, 'dropdown-menu')]/a[contains(text(), '"+sSubMenu+"')]");
        return await objWrapper.clickOnElement(objSubMenuOption, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole="Pass : Clicked on Sub menu option "+sSubMenu+".";
            else
                sConsole="Fail : Fail to click on Sub menu option "+sSubMenu+".";
            console.info(sConsole);
            return sConsole;
        });
}

    //select menu option
async selectMenuOption(sMenu, sSubMenu)
    {
        expect(await this.clickOnMenuOption(sMenu)).toContain("Pass");
        return await this.clickOnSubMenuOption(sSubMenu);
}

clickOnNewProjectButton()
    {
        try
        {
            //let btnNewProject = element(by.xpath("//button[contains(text(), 'New Project')]"));
            let btnNewProject = by.xpath("//button[contains(text(), 'New Project')]");
            //BrowserUtil.waitUntilReady(element(btnNewProject));
            if(objWrapper.clickOnElement(btnNewProject, objWrapper.iDefaultTimeout))
            {
                console.info("Successfully clicked on New Project button.");
                return true;
            }
            else
            {
                console.error("Fail to click on New project button.")
                return false;
            }
            //btnNewProject.click();
            //return true;
        }
        catch(exception)
        {
            return false;
        }
}

async clickOnPrioritizationLink()
    {
        //app-header>nav.navbar.navbar-expand-xl.navbar-custom>div#ratp3Nav a[href='#/prioritization']
        let lnkPrioritization = by.css("nav nav a[href='#/prioritization']");
        return await objWrapper.clickOnElement(lnkPrioritization, objWrapper.iDefaultTimeout);
}

async getLoggedInUser()
    {
        let objUser = by.css("span.user-name");
        return await objWrapper.getElementText(objUser, objWrapper.iDefaultTimeout).then(function(sText){console.log(sText); return sText;});
}

async getTodaysDate(sFormat)
    {
        var sFinalDate, sNewdd;
        var sToday = new Date();
        var sdd = sToday.getDate();
        var smm = sToday.getMonth() + 1;
        var sYear = sToday.getFullYear();
        switch(sFormat)
        {
            case "mm/dd/yyyy":
                if(sdd < 10)
                {
                    sNewdd = "0" + sdd;
                }
                else
                {
                    sNewdd = sdd;
                }
                sFinalDate = smm + "/" + sNewdd + "/" + sYear;
                return sFinalDate; 
            case "mm/d/yyyy":
                sFinalDate = smm + "/" + sdd + "/" + sYear;
                return sFinalDate;
        }
}

async verifyHomePageDisplayed()
    {
        let objWelcomeMsg = by.xpath("//span[text()='Welcome to My Demo']");
        return await objWrapper.isElementDisplayed(objWelcomeMsg, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Display My Demo Banner On Home Page.";   
            else
                sConsole = "Fail : Does Not Display My Demo Banner On Home Page."; 
                console.info(sConsole);
                return sConsole;
        });  
}
async getCurrentUrl(sUserUrl) {  
       return await browser.getCurrentUrl().then(function(sURL){
        if(sURL.includes(sUserUrl))
            sConsole = "Pass : User is on the "+sUserUrl+" correct page as the URL is "+sURL+".";   
        else
            sConsole = "User is not on the correct Page on as current URL is the "+sURL+"."; 
            console.info(sConsole);
            return sConsole;
    });
}
//Nidhi-8/04/2021 will give the list of the all submenu contains by menu
async getSubMenuList(sMenu)								 
    {
        let objSubMenuHdr = by.xpath("//a[contains(text(),'"+sMenu+"')]//parent::li//a[@class='dropdown-item']");
        return await objWrapper.getElementsText(objSubMenuHdr, 'List of Submenu');
};
//Nidhi-8/04/2021 will give the list of the all menu 
async getMenuList()								 
{
    let objMenuHdr = by.xpath("//ul[@id='customNavigationHeader']//li/a/img/parent::a");
    return await objWrapper.getElementsText(objMenuHdr, 'List of Menu');
};

async getBannerTextPart1()
{
    let objWelcomeMsg = by.xpath("//div[@class='welcom-txt p-3']//span");
    return await objWrapper.getElementText(objWelcomeMsg, objWrapper.iDefaultTimeout).then(function(sText){
    return sText;
    });
}
async getBannerTextPart2()
{
    let objWelcomeMsg = by.xpath("//div[@class='welcom-txt p-3']//div");
    return await objWrapper.getElementText(objWelcomeMsg, objWrapper.iDefaultTimeout).then(function(sText){
    return sText;
    });
}
//Nidhi-28/04/2021 getting the count of entry in the table.
async getDemoEntriesInTable(sColName)
{   
    let sColId= await objCommonPage.getColId(sColName)
    let objSearchList = by.xpath("//div[@col-id='"+sColId+"'][@role='gridcell']");
    return await objWrapper.getElementsCount(objSearchList).then(function(sCount){
    let sDataEntryCount = sCount;
    if(sDataEntryCount>10)
    sConsole = "Data Entries in Top 10 Demos Table is more then 10";   
    else
    sConsole = "Pass : Data Entries in Top 10 Demos Table is 10 Only"; 
    console.info(sConsole);
    return sConsole;
    });
  
}
//Nidhi-28/04/2021-Verify BU DD Is present or not
async verifyBuDDIsPresent()
    {
        let cmbBU = by.xpath("//select[@id='bu']");
        return await objWrapper.isElementPresent(cmbBU, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
        sConsole = "Pass : BU Dropdown is Present";   
        else
        sConsole = "BU Dropdown is not present"; 
        console.info(sConsole);
        return sConsole;
        });
        
}
//Nidhi-28/04/2021-Verify BU DD Is present or not
async verifyLegendPresent(sLegendName)
    {
        let objLegends = by.xpath("//h6[text()='"+sLegendName+"']//parent::div//following-sibling::div[1]//span[2]");
        return await objWrapper.getElementsText(objLegends, 'List of Legends are').then(function(sTextList){
        return sTextList; 
        });
        
}
//Nidhi-28/04/2021- Set Coment on the add comment pop up
async setCommentOnPopUp(sComment)
    {
        let txtComment = by.css("[name='comment']");
        await objWrapper.setInputValue(txtComment, sComment, objWrapper.iDefaultTimeout);
        return await objWrapper.getElementAttribute(txtComment, 'ng-reflect-model', objWrapper.iDefaultTimeout).then(function(sText){
        if(sText)
        sConsole="Pass : Set Comment as '"+sText+"."
        else
        sConsole="Not able to set comment."
        console.info(sConsole);
        return sConsole;
    });
    
}
//Nidhi-28/04/2021 click on the button on add comment section pop up
async clickOnBtnOnPopUpIcon(sBtnName)
{  
    let objOkBtn = by.xpath("//button[contains(text(),'"+sBtnName+"')]");
    return await objWrapper.clickOnElement(objOkBtn, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
        sConsole = "Pass : Clicked on "+sBtnName+" button.";   
    else
        sConsole = "Not able to click on "+sBtnName+" button."; 
        console.info(sConsole);
        return sConsole;
    });
}
//Nidhi-29/04/2021- Click on the the passed icon names
async clickOnTheIcon(sIconName,sDemoName)
{
    let objDemoAddActionIcon = by.xpath("//div[@col-id='demoName'][text()='"+sDemoName+"']/parent::div//span[@title='"+sIconName+"']");
    return await objWrapper.clickOnElement(objDemoAddActionIcon, objWrapper.iDefaultTimeout).then(function(bRes){
    if(bRes)
    sConsole = "Pass : Clicked on the "+sIconName+" Icon of demo number "+sDemoName+".";    
    else
    sConsole = "Not Clickedon the "+sIconName+" Icon of demo number "+sDemoName+".";   
    console.info(sConsole);
    return sConsole;  
    });
}
//Nidhi-29/04/2021- verify Delete btn is disabled on pop up or not.
async verifyBtnIsDisabledOnPopUp(sBtnName)
    {
        let objBtn = by.xpath("//div[@class='modal-content']//div[@class='modal-footer']//button[contains(text(),'"+sBtnName+"')][@disabled]");
        return await objWrapper.isElementPresentWithoutWait(objBtn).then(function(bRes){    
            if(bRes)
                sConsole = "Pass : "+sBtnName+" Btn is Disabled please enter mandate details";
            else
                sConsole = ""+sBtnName+" Button is not disabled.";
            console.info(sConsole);
            return sConsole;
        });
    }
//Nidhi-29/04/2021 get Table headers on the add action pop up
    async getTableHeadersOnPopUp()								 
    {
        let objColHdrList = by.xpath("//ag-grid-angular[@id='actionGrid']//div[@class='ag-header-cell-label']/span[1]");
        return await objWrapper.getElementsText(objColHdrList, 'List of all the col header is');
    };

    getColIdOnPopUp(sColName)									  										   
    {
        let sColId;
        console.log(sColName)
        switch(sColName)
        {	
            case "Created Date":
                sColId = "actionCreatedDate";
                break;
            case "Status":
                sColId = "actionStatus";
                break;
            case "Action Item":
                sColId = "actionDescription";
                break;
            case "ECD":
                sColId = "ecd";
                break;  
            case "Owner":
                sColId = "owner";
                break;
            case "Comments":
                sColId = "actionComment";
                break;
            case "Checkbox":
                sColId = "0";
                break;
            default :
                sColId = sColName.replace("/", "");
                sColId = sColId.toLowerCase();
                sColId = objWrapper.convertToCamelCase(sColId);
        }
        return sColId;
    }	

async getTableCellValue(sColName)
{ 
    let  objTableCell,sColId;
    sColId = this.getColIdOnPopUp(sColName);
    objTableCell= by.xpath("//ag-grid-angular[@id='actionGrid']//div[@row-id='0']//div[@col-id='"+sColId+"']//span");
    return await objWrapper.getElementText(objTableCell, objWrapper.iDefaultTimeout).then(function(sText){
        console.info("Cell text in column '"+sColName+"' is '"+sText+"'.");
        return sText;
    });
}

//Nidhi-29/04/2021- verify View Button Is present or not.
async verifyViewButtonIsPresentOnPopUp()
    {
        let objBtn = by.xpath("//ag-grid-angular[@id='actionGrid']//div[@row-id='0']//button[text()='View']");
        return await objWrapper.isElementPresentWithoutWait(objBtn).then(function(bRes){    
            if(bRes)
                sConsole = "Pass : View Btn is Present";
            else
                sConsole = "View Button is not Present.";
            console.info(sConsole);
            return sConsole;
        });
    }
//Nidhi-29/04/2021- Click in the Table cell on the pop up
    async clickInTheTableCellOnPopUp(sColName)
    {
        let  objTableCell, sColId;
        sColId = this.getColIdOnPopUp(sColName);
        objTableCell = by.xpath("//ag-grid-angular[@id='actionGrid']//div[@row-id='0']//div[@col-id='"+sColId+"']");
        return await objWrapper.clickOnElement(objTableCell, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
			sConsole = "Pass : Clicked in the col'"+sColName+"'.";  
        else
			sConsole = "Not able to click in the col '"+sColName+"'."; 
		console.info(sConsole);
		return sConsole;
	});

}
//Nidhi-29/04/2021- Set text on the table cell value on pop up.
async setOwnerName(sColName, sValue)
    {
        let  sColId;
        sColId = this.getColIdOnPopUp(sColName);
        let txtComment = by.xpath("//ag-grid-angular[@id='actionGrid']//div[@row-id='0']//div[@col-id='"+sColId+"']//input");
        return await objWrapper.setInputCharByChar(txtComment, sValue, objWrapper.iDefaultTimeout).then(function(sValue){
        sConsole="Pass : Set text as '"+sValue+" in col name "+sColName+"."
        console.info(sConsole);
        return sConsole;
    });
    
}
//Nidhi-29/04/2021- selet the owner name from the dropdown on the all view pop up page
async selectOwnerName(sOwnerName)
    {
        
        let lstAccOwner = by.xpath("//div[contains(@class,'autocomplete ag-cell-editor')]//strong[text()='"+sOwnerName+"']");
        await objWrapper.javascriptClickOnElement(lstAccOwner, objWrapper.iDefaultTimeout);
        let objSelectedOwner = by.xpath("//ag-grid-angular[@id='actionGrid']//div[@row-id='0']//div[@col-id='owner']//span");
        return await objWrapper.getElementText(objSelectedOwner, objWrapper.iDefaultTimeout).then(function(sText){
            if(sText.includes(sOwnerName))
                sConsole = "Pass : Clicked on  owner list option '"+sOwnerName+"'.";
            else
                sConsole = "Not able to click on  owner list option '"+sOwnerName+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

// Nidhi- 29/04/2021 enter and select owner name from the list
async selectOwnerOnActionPopUp(sColName,OwnerName)
{
    expect(await this.setOwnerName(sColName,OwnerName)).toContain("Pass");
    await browser.sleep(15000);
    return await this.selectOwnerName(OwnerName);
}


//Nidhi-29/04/2021- Set text on the table cell value on pop up.
async setTextAreaInTableCellOnPopUp(sColName, sValue)
{
        let txtComment = by.xpath("//textarea[@ref='eInput']");
        return await objWrapper.setInputValue(txtComment, sValue, objWrapper.iDefaultTimeout).then(function(bRes){
        sConsole="Pass : Set text as '"+sValue+" in col name "+sColName+"."
        console.info(sConsole);
        return sConsole;
    });
    

}

//Nidhi-29/04/2021 - select calendar month
 async selectCalendarMonth(sMonth)
 {
     let objMonthDD = by.css("select[data-handler='selectMonth']");
     await objWrapper.clickOnElement(objMonthDD, objWrapper.iDefaultTimeout).then(function(bRes){
         if(bRes)
             sConsole = "Pass : Clicked on Calendar Month DD.";
         else
             sConsole = "Fail to click on Calendar Month DD.";
         console.info(sConsole);
     });
     let objMonth = by.xpath("//select[@data-handler='selectMonth']//option[text()='"+sMonth+"']");
     return await objWrapper.clickOnElement(objMonth, objWrapper.iDefaultTimeout).then(function(bRes){
         if(bRes)
             sConsole = "Pass : Selected calendar month '"+sMonth+"'.";
         else
             sConsole = "Fail to select calendar month '"+sMonth+"'.";
         console.info(sConsole);
         return sConsole;
     });
 }

 //Nidhi-29/04/2021 - select calendar year
 async selectCalendarYear(sYear)
 {
     let objYearDD = by.css("select[data-handler='selectYear']");
     await objWrapper.clickOnElement(objYearDD, objWrapper.iDefaultTimeout).then(function(bRes){
         if(bRes)
             sConsole = "Pass : Clicked on Calendar Year DD.";
         else
             sConsole = "Fail to click on Calendar Year DD.";
         console.info(sConsole);
     });
     let objYear = by.xpath("//select[@data-handler='selectYear']//option[text()='"+sYear+"']");
     return await objWrapper.clickOnElement(objYear, objWrapper.iDefaultTimeout).then(function(bRes){
         if(bRes)
             sConsole = "Pass : Selected calendar year '"+sYear+"'.";
         else
             sConsole = "Fail : Fail to select calendar year '"+sYear+"'.";
         console.info(sConsole);
         return sConsole;
     });
 }
 

 //Nidhi-29/04/2021 - select calendar date
 async selectDateFromdd(sDay, sMonth, sYear)
 {
     expect(await this.selectCalendarMonth(sMonth)).toContain("Pass");
     expect(await this.selectCalendarYear(sYear)).toContain("Pass");
     let objDay = by.xpath("//td[@data-handler='selectDay']//a[text()='"+sDay+"']");
     return await objWrapper.clickOnElement(objDay, objWrapper.iDefaultTimeout).then(function(bRes){
         if(bRes)
             sConsole = "Pass : Selected Requested date '"+sDay+"'.";
         else
             sConsole = "Fail : Fail to select Requested date '"+sDay+"'";
         console.info(sConsole);
         return sConsole;
     });
 }

 //Nidhi-29/04/2021- Click in the Table cell on the pop up
 async clickInTheTableCellOnPopUpJavascript(sColName)
 {
     let  objTableCell, sColId;
     sColId = this.getColIdOnPopUp(sColName);
     objTableCell = by.xpath("//ag-grid-angular[@id='actionGrid']//div[@row-id='0']//div[@col-id='"+sColId+"']");
     return await objWrapper.javascriptClickOnElement(objTableCell, objWrapper.iDefaultTimeout).then(function(bRes){
     if(bRes)
         sConsole = "Pass : Clicked in the col'"+sColName+"'.";  
     else
         sConsole = "Not able to click in the col '"+sColName+"'."; 
     console.info(sConsole);
     return sConsole;
 });

}

//Nidhi-30/04/2021- give the count present on the icons.
 async getTheCountOnTheIcon(sDemoName,sIconName)
 {
     let objCount = by.xpath("//div[@col-id='demoName'][text()='"+sDemoName+"']/parent::div//span[@title='"+sIconName+"']//mark");
     return await objWrapper.getElementText(objCount, objWrapper.iDefaultTimeout).then(function(sText){
     sConsole = "count on icon "+sIconName+" is "+sText+".";  
     console.info(sConsole);
     return sText;
 });

}

//Nidhi-29/04/2021 click on the Cancel button on Icons pop up
async clickOnCancelBtnOnPopUpIcon()
{  
    let objCancelBtn = by.xpath("//app-custom-modal/div[@class='modal-footer']//button[contains(text(),'Cancel')]");
    return await objWrapper.clickOnElement(objCancelBtn, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
        sConsole = "Pass : Clicked on Cancel button.";   
    else
        sConsole = "Not able to click on Cancel button."; 
        console.info(sConsole);
        return sConsole;
    });
}

async getRowNoForApplicationName(sActionItem)
    {
        let sColId = this.getColIdOnPopUp("Action Item");
        let objTableCell = by.xpath("//div[@col-id='actionDescription']//span[contains(text(),'"+sActionItem+"')]/ancestor::div[@role='row' and contains(@class,'ag-row')]");
        return await objWrapper.getElementAttribute(objTableCell, "row-index", objWrapper.iDefaultTimeout); 
    }
//Click In The checkbox as per the passed action item name
async clickInTheCheckbox(sColName,sActionItem)
{
    let  objTableCell, iRowNo, sColId;
    await this.getRowNoForApplicationName(sActionItem).then(function(iRow){iRowNo = iRow;});
    sColId = this.getColIdOnPopUp(sColName);
    objTableCell = by.xpath("//div[@row-index='"+iRowNo+"']//div[@role='presentation' and  @col-id='"+sColId+"']//div[@class='ag-selection-checkbox']");
    return await objWrapper.clickOnElement(objTableCell, objWrapper.iDefaultTimeout).then(function(bRes){
    if(bRes)
        sConsole = "Pass : Clicked in the col'"+sColName+"'cell contains '"+sActionItem+"'.";   
    else
        sConsole = "Fail : Fail to click in the col '"+sColName+"'cell contains '"+sActionItem+"'."; 
        console.info(sConsole);
        return sConsole;
    });  
}


//Nidhi-30/04/2021- Click on the external link label
async clickOnExternalLinkLabelOnPopUp()
{
    let objLabel = by.xpath("//div[@id='headingExternalLink']");
    return await objWrapper.clickOnElement(objLabel, objWrapper.iDefaultTimeout).then(function(bRes){
    if(bRes)
    sConsole = "Pass : Clicked on External Link Label.";    
    else
    sConsole = "Not Able to click on External Link Label";   
    console.info(sConsole);
    return sConsole;  
    });
}

//Nidhi-28/04/2021- Set External Link on the on Attachment pop up.
async setExternalLinkPopUp(sLink)
    {
        let objLink = by.css("[name='shippingInfo']");
        await objWrapper.setInputValue(objLink, sLink, objWrapper.iDefaultTimeout);
        return await objWrapper.getElementAttribute(objLink, 'ng-reflect-model', objWrapper.iDefaultTimeout).then(function(sText){
        if(sText)
        sConsole="Pass : Set External Link as '"+sText+"."
        else
        sConsole="Not able to set External Link."
        console.info(sConsole);
        return sConsole;
    });
}

}