import { wrapper } from '../utils/wrapper.util';
import { element, by, browser } from 'protractor';

let objWrapper:wrapper;
let sConsole;
export class adminAccessViewPage{
    constructor()
    {
        objWrapper = new wrapper();
    }
    getColIdAdmin(sColName)																			   
    {
        let sColId;
        console.log(sColName)
        switch(sColName)
        {	
            case "Display Name":
                sColId = "userName";
                break;
            case "Account":
                sColId = "account";
                break;
            case "Access Level":
                sColId = "roleName";
                break;
            case "BU":
                sColId = "businessUnit";
                break;
            case "Checkbox":
                sColId = "0";
                break;
            case "Created By":
                sColId = "createdBy";
                break;
            default :
                sColId = objWrapper.convertToCamelCase(sColName);
        }
        return sColId;
    }
    async getRowNoForDisplayName(sUserName)
    {
        let sColId = this.getColIdAdmin("Display Name");
        let objTableCell = by.xpath("//div[@role='gridcell' and @col-id='"+sColId+"'][contains(text(),'"+sUserName+"')]/ancestor::div[@role='row' and contains(@class,'ag-row')]");
        return await objWrapper.getElementAttribute(objTableCell, "row-index", objWrapper.iDefaultTimeout); 
    }
    async getTableCellValue(sColName,sUserName)
    {
        try{
        let  objTableCell, iRowNo, sColId;
        await this.getRowNoForDisplayName(sUserName).then(function(iRow){iRowNo = iRow;});
        sColId = this.getColIdAdmin(sColName); 
        if(sColName == 'Account'||sColName == 'Display Name'||sColName == 'BU')
        {
            objTableCell = by.xpath("//div[@row-index='"+iRowNo+"']//div[@col-id='"+sColId+"']");
        }
        else
        {
            objTableCell = by.xpath("//div[@row-index='"+iRowNo+"']//div[@role='gridcell' and @col-id='"+sColId+"']//span");
        }
        return objWrapper.getElementText(objTableCell, objWrapper.iDefaultTimeout).then(function(sText){
        console.info("Cell text in column '"+sColName+"' against application name '"+sUserName+"' is '"+sText+"'.");
        return sText;
        });
    }
    catch(exception){
        console.log("Error while getting text of coloumn '"+sColName+"'" + exception);
            return null;
    }
    }
    // click in the table cell value at 0th row on admin access view page
async clickInTheTableCellWhileAddingUser(sColName)
    {
        let sColId = this.getColIdAdmin(sColName);
        let  objTableCell = by.xpath("//div[@row-index='0']//div[@col-id='"+sColId+"']");																																													
        return await objWrapper.clickOnElement(objTableCell, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
			sConsole = "Pass : Clicked in the col'"+sColName+"'.";  
        else
			sConsole = "Not able to click in the col '"+sColName+"'."; 
		console.info(sConsole);
		return sConsole;
	});
}
// double click in the table cell value at 0th row on admin access view page
async doubleclickInTheTableCell(sColName)
{
    let sColId = this.getColIdAdmin(sColName);
    let  objTableCell = by.xpath("//div[@row-index='0']//div[@col-id='"+sColId+"']");																																													
    return await objWrapper.doubleClickOnElement(objTableCell, objWrapper.iDefaultTimeout).then(function(bRes){
    if(bRes)
        sConsole = "Pass : Clicked in the col'"+sColName+"'.";  
    else
        sConsole = "Not able to click in the col '"+sColName+"'."; 
    console.info(sConsole);
    return sConsole;
});
}

   //Nidhi-22/04/2021 Set The text in the Table cell
    async setTextInTableCell(sColName, sValue)
    {
    
        let sColId = this.getColIdAdmin(sColName)
        let objTableCell = by.xpath("//div[@row-index='0']//div[@col-id='"+sColId+"']//ancestor::div[@ref='eRootWrapper']//div[contains(@class,'ag-theme-balham')]//input");	
        await objWrapper.setInputValue(objTableCell, sValue, objWrapper.iDefaultTimeout);
        return await objWrapper.getElementAttribute(objTableCell, 'ng-reflect-model', objWrapper.iDefaultTimeout).then(function(sText){
        if(sText)
        sConsole="Pass : Entered Text for '"+sText+"' for column name '"+sColName+"."
        else
        sConsole="Fail to Enter Text for '"+sText+"' for column name '"+sColName+"."
        console.info(sConsole);
        return sConsole;
    });
    
}
//Nidhi-22/04/2021- selet the owner name from the dropdown on table cell value
async selectOwnerName(sColName, sOwnerName)
    {
        let sColId = this.getColIdAdmin(sColName)
        let lstAccOwner = by.xpath("//ul[@class='list-group']//a[contains(text(),'"+sOwnerName+"')]/parent::li");
        await objWrapper.javascriptClickOnElement(lstAccOwner, objWrapper.iDefaultTimeout);
        let objSelectedOwner = by.xpath("//div[@row-index='0']//div[@col-id='"+sColId+"']");
        return await objWrapper.getElementText(objSelectedOwner, objWrapper.iDefaultTimeout).then(function(sText){
        if(sText==sOwnerName)
                sConsole = "Pass : Clicked on Account owner list option '"+sOwnerName+"'.";
        else
                sConsole = "Not able to click on Account owner list option '"+sOwnerName+"'.";
        console.info(sConsole);
        return sConsole;
        });
    }
// Nidhi- 22/04/2021 enter and select owner name from the list
async selectOwnerOnPopUp(sColName,sOwnerName)
{
    expect(await this.setTextInTableCell(sColName, sOwnerName)).toContain("Pass");
    await browser.sleep(15000);
    return await this.selectOwnerName(sColName,sOwnerName);
}
    //Nidhi-22/04/2021 Click On Add User Button
    async clickOnAddUserButton()
    {  
        let objOkBtn = by.xpath("//button[contains(text(),'Add User')]");
        return await objWrapper.clickOnElement(objOkBtn, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
            sConsole = "Pass : Clicked on Add User button.";   
        else
            sConsole = "Not able to click on Add User button."; 
            console.info(sConsole);
            return sConsole;
        });
    }
    //Nidhi-22/04/2021 Click On Remove User Button
    async clickOnRemoveUserButton()
    {  
        let objOkBtn = by.xpath("//button[contains(text(),'Remove User')]");
        return await objWrapper.clickOnElement(objOkBtn, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
            sConsole = "Pass : Clicked on Remove User button.";   
        else
            sConsole = "Not able to click on Remove User button."; 
            console.info(sConsole);
            return sConsole;
        });
    }

    //Nidhi-22/04/2021 Click On Add User Button
    async clickOnMultiSelectDD()
    {  
        let objOkBtn = by.xpath("//div[@class='multiselect-dropdown']");
        return await objWrapper.clickOnElement(objOkBtn, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
            sConsole = "Pass : Clicked on Multiselect DD.";   
        else
            sConsole = "Not able to click on Multiselect DD."; 
            console.info(sConsole);
            return sConsole;
        });
    }
    //Nidhi-22/04/2021 Select the Utem from Table Header Multi Icon.
    async selectItemFromMutiSelectDDInTableCell(sItemName)
    {
       
        let objItem = by.xpath("//div[@class='dropdown-list']//div[text()='"+sItemName+"']");
        return await objWrapper.clickOnElement(objItem, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
            sConsole = "Pass : Selected Item "+sItemName+" from Multi DD";   
        else
            sConsole = "Not able to select item from Multi DD"; 
            console.info(sConsole);
            return sConsole;
        });
    }
    // click in the table cell as per passec Display User name
    async clickInTheTableCell(sColName,sUserName)
    {
        let iRowNo, sColId;
        await this.getRowNoForDisplayName(sUserName).then(function(iRow){iRowNo = iRow;});
        sColId = this.getColIdAdmin(sColName); 
        let objTableCell = by.xpath("//div[@row-index='"+iRowNo+"']//div[@col-id='"+sColId+"']");
        return await objWrapper.clickOnElement(objTableCell, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
			sConsole = "Pass : Clicked in the col'"+sColName+"'cell contains Display Name '"+sUserName+"'.";  
        else
			sConsole = "Not able to click in the col '"+sColName+"'cell contains Display Name'"+sUserName+"'."; 
		console.info(sConsole);
		return sConsole;
	});
}
 //Nidhi-23/04/2021 set search in filter search
 async setSearchInFilter(sItemName)
 {
    
     let objItem = by.xpath("//input[@placeholder='Search...']");
     return await objWrapper.setInputValue(objItem,sItemName, objWrapper.iDefaultTimeout).then(function(bRes){
     if(bRes)
         sConsole = "Pass : set search as Item "+sItemName+" from Multi DD";   
     else
         sConsole = "Not able to set search "+sItemName+"  for Multi DD"; 
         console.info(sConsole);
         return sConsole;
     });
 }
 //Nidhi-11-03-2021 will give the list of data contains by particluar col
async geColDataListOnAdminView(sColName)								 
{
let sColId= this.getColIdAdmin(sColName)
let objSearchList = by.xpath("//div[@col-id='"+sColId+"']");
return await objWrapper.getElementsText(objSearchList, 'List of Data Conatins by Col is').then(function(sTextList){
     return sTextList; 
    });
};
    
}