import { wrapper } from '../utils/wrapper.util';
import { element, by, browser } from 'protractor';
import { BrowserUtil } from '../utils/browser.util';
import { SpecReporter } from 'jasmine-spec-reporter';

let objWrapper:wrapper;
let sConsole;
export class demoDetailsPage{
    constructor()
    {
        objWrapper = new wrapper();
    }

    async verifyDemoDetailsPageIsDisplayed()
    {
        let objDemoDetails = by.xpath("//li[@id='planLink']//a[contains(text(), 'Demo Details')]");
        return await objWrapper.isElementDisplayed(objDemoDetails, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
			 
                sConsole = "Pass : Demo details page displayed successfully";
							
			 
            else
			 
                sConsole = "Fail : Fail to display Demo Details page.";
            console.info(sConsole);
            return sConsole;
			 
        })
    }
    getFieldName(sFieldName)																			   
    {
        let sFieldId;
        console.log(sFieldName)
        switch(sFieldName)
        {	
            case "Wafer location":
                sFieldId = "waferLocation";
                break;
            case "Execution Risk":
                sFieldId = "risk";
                break;
            case "Milestone Status":
                sFieldId = "startMilestoneList";
                break;
        
            default :
                sFieldId = objWrapper.convertToCamelCase(sFieldName);
        }
        return sFieldId;
    }
    //Richa_31032021 - Click on attachments button
    async clickOnAttachmentsBtn()
    {
        let btnAttachments = by.xpath("//label[text()='Attachments']/following-sibling::button");
        return await objWrapper.javascriptClickOnElement(btnAttachments, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on button Attachments.";
            else
                sConsole = "Fail : Fail to click on button Attachments.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_31032021 - verify attachments pop up displayed
    async verifyAttachmentsPopUpDisplayed()
    {
        let objAttachments = by.xpath("//div[@class='modal-content']//div[@class='modal-header']/h5[contains(text(),'Attachments')]");
        return await objWrapper.isElementPresent(objAttachments, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Attachments pop up displayed.";
            else
                sConsole = "Fail : Fail to find presence of Attachments pop up.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_31032021 - click on browse button on attachments scree
    async clickBrowseOnAttachmentsPopUp()
    {
        let btnBrowse = by.xpath("//div[@class='modal-header']/h5[contains(text(),'Attachments')]/ancestor::div[@class='modal-content']//label[contains(@class,'custom-file-label')]");
        return await objWrapper.clickOnElementUsingActionClass(btnBrowse, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on Browse button on Attachments pop up.";
            else
                sConsole = "Fail : Fail to click on Browse button on Attachments pop up.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_31032021 - verify attachments pop up displayed
    async verifyFileBrowsedOnAttachmentsPopUp(sFileNameWithExtn)
    {
        let objFileBrowsed = by.xpath("//div[@class='modal-header']/h5[contains(text(),'Attachments')]/ancestor::div[@class='modal-content']//label[contains(@class,'custom-file-label')]");
        return await objWrapper.isElementPresent(objFileBrowsed, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : File '"+sFileNameWithExtn+"' browsed on Attachments pop up.";
            else
                sConsole = "Fail : Fail to browse file '"+sFileNameWithExtn+"' on Attachments pop up.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_31032021 - select Security DD value on attachments pop up
    async selectDDValOnAttachmentsPopUp(sDDName, sDDVal)
    {
        let cmbDD = by.xpath("//h5[contains(text(),'Attachments')]/ancestor::div[@class='modal-content']//label[text()='"+sDDName+"']/following-sibling::div/select/option[@ng-reflect-value = '"+sDDVal+"']");
        return await objWrapper.clickOnElement(cmbDD, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on '"+sDDName+"' DD option '"+sDDVal+"' on Attachments pop up.";
            else
                sConsole = "Fail : Fail to click on '"+sDDName+"' DD option '"+sDDVal+"' on Attachments pop up.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_31032021 - Click on Upload button
    async clickUploadBtnOnAttachmentsPopUp()
    {
        let btnUpload = by.xpath("//h5[contains(text(),'Attachments')]/ancestor::div[@class='modal-content']//button[text()='Upload']");
        return await objWrapper.clickOnElement(btnUpload, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on Upload button on Attachments pop up.";
            else
                sConsole = "Fail : Fail to click on Upload button on Attachments pop up.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_31032021 - verify document uploaded on attachment pop up
    async verifyDocUploadedOnAttachmentsPopUp(sFileNameWithExtn)
    {
        let tblAttachments = by.xpath("//h5[contains(text(),'Attachments')]/ancestor::div[@class='modal-content']//table//td/a[text()='"+sFileNameWithExtn+"']");
        return await objWrapper.isElementPresent(tblAttachments, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : File '"+sFileNameWithExtn+"' uploaded on Attachments pop up.";
            else
                sConsole = "Fail : Fail to upload file '"+sFileNameWithExtn+"' on Attachments pop up.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_05042021 - Click delete against uploaded document in attachment pop up
    async deleteUploadedDocOnAttachmentsPopUp(sFileNameWithExtn)
    {
        let btnDelete = by.xpath("//h5[contains(text(),'Attachments')]/ancestor::div[@class='modal-content']//table//a[text()='"+sFileNameWithExtn+"']/parent::td/following-sibling::td/a[@title='Delete']");
        return await objWrapper.clickOnElement(btnDelete, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on Delete button against attachment '"+sFileNameWithExtn+"' in attachment po up";
            else
                sConsole = "Fail : Fail to click on Delete button against attachment '"+sFileNameWithExtn+"' in attachment po up";
            console.info(sConsole);
            return sConsole;
        });
	}
	//Richa_12042021 - set value in field on demo details page
    async setFieldValInDemoDtlsPage(sFieldName, sVal)
    {
        let txtField = by.xpath("//label[contains(text(),'"+sFieldName+"')]//parent::div//input|//label[contains(text(),'"+sFieldName+"')]//parent::div//textarea");
        await objWrapper.setInputValue(txtField, sVal, objWrapper.iDefaultTimeout);
        return await objWrapper.getElementAttribute(txtField, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sVal)
                sConsole = "Pass : Set value '"+sVal+"' in field '"+sFieldName+"'.";
            else
                sConsole = "Fail : Fail to set value '"+sVal+"' in field '"+sFieldName+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

	//Chakradhar_06052021  -set link on demo details page
    async setlenghtyFieldValInDemoDtlsPage(sFieldName, sVal)
    {
        let txtField = by.xpath("//label[contains(text(),'"+sFieldName+"')]//parent::div//input|//label[contains(text(),'"+sFieldName+"')]//parent::div//textarea");
        return await objWrapper.setInputValue(txtField, sVal, objWrapper.iDefaultTimeout).then(function(bRes){            
            if(bRes)
                sConsole = "Pass : Set value '"+sVal+"' in field '"+sFieldName+"'.";
            else
                sConsole = "Fail : Fail to set value '"+sVal+"' in field '"+sFieldName+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }
	
    //Richa_12042021 - Select DD option on demo details page
    async selectDDOptionOnDemoDtlsPage(sDDName, sDDVal)
    {
        // let cmbField = by.xpath("//label[contains(text(),'"+sDDName+"')]//parent::div//select");
        let cmbFieldOpt = by.xpath("//label[contains(text(),'"+sDDName+"')]//parent::div//select/option[contains(text(), '"+sDDVal+"')]");
        // await objWrapper.clickOnElement(cmbField, objWrapper.iDefaultTimeout);
        return await objWrapper.clickOnElement(cmbFieldOpt, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Selected DD option '"+sDDVal+"' from '"+sDDName+"' drop down.";
            else
                sConsole = "Fail : Fail to select  DD option '"+sDDVal+"' from '"+sDDName+"' drop down.";
            console.info(sConsole);
            return sConsole;
        });
    }
    //Nidhi-12/03/2021- click on the field on the demo details page.
    async clickFieldOnDemoDetails(sFieldName)
    {
        let objFieldType = by.xpath("//label[contains(text(),'"+sFieldName+"')]//parent::div/div|//label[contains(text(),'"+sFieldName+"')]//parent::div/select");
        return await objWrapper.clickOnElement(objFieldType, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on Field Name '"+sFieldName+"'.";
            else
                sConsole = "Not able to click Field Name '"+sFieldName+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }
    //Nidhi-12/03/2021- click on the field on the demo details page without Scroll.
    async clickFieldOnDemoDetailsWithoutScroll(sFieldName)
    {
        let objFieldType = by.xpath("//label[contains(text(),'"+sFieldName+"')]//parent::div//div");
        return await objWrapper.clickOnElementWithOutScroll(objFieldType, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on Field Name '"+sFieldName+"'.";
            else
                sConsole = "Not able to click Field Name '"+sFieldName+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }
    //Nidhi-12/03/2021- select the option from the demo details Field Dropdown.
    async selectOptionFromFieldOnDemoDetails(sFieldName,sOption)
    {
        let objOption = by.xpath("//label[contains(text(),'"+sFieldName+"')]//parent::div//option[contains(text(),'"+sOption+"')]");
        return await objWrapper.clickOnElement(objOption, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Selected From Field Name '"+sFieldName+"' Option '"+sOption+"'.";
            else
                sConsole = "Not able to select option '"+sOption+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }
    //Nidhi-12/03/2021- will click on the submit button of demo details page.
async clickOnSubmitDemoDetails()
{
    let btnSubmit = by.xpath("//button[contains(text(), 'Submit')]");
    return await objWrapper.clickOnElement(btnSubmit, objWrapper.iDefaultTimeout).then(function(bRes){    
        if(bRes)
            sConsole = "Pass : Clicked on Submit button";
        else
            sConsole = "Not able to click on Submit button.";
        console.info(sConsole);
        return sConsole;
    });
}
async verifyFieldIsDisabledOnDemoDetailsPage(sLabelName)
{
   
    let sLabelId = this.getLabelId(sLabelName);
    let objField = by.xpath("//input[@name='"+sLabelId+"'][@readonly]|//select[@name='"+sLabelId+"'][@disabled]|//div[@ng-reflect-name='"+sLabelId+"']//input[@disabled]|//input[@name='"+sLabelId+"'][@disabled]|//label[@name='"+sLabelId+"'][@readonly]");
   
    return await objWrapper.isElementPresent(objField,objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
            sConsole = "Pass : Field "+sLabelName+" is disabled.";
        else
            sConsole = "Field "+sLabelName+" is not disabled.";
        console.info(sConsole);
        return sConsole;
    });
}

getLabelId(sColName)																			   
{
    let sColId;
    console.log(sColName)
    switch(sColName)
    {	
        case "Demo Approval":
            sColId = "demoStatus";
            break;
        case "Demo Owner":
            sColId = "demoOwner";
            break;
        case "Demo Number":
            sColId = "demoNumber";
            break;
        case "Demo Name":
            sColId = "demoName";
            break;
        case "Wafer Status":
            sColId = "waferLocation";
            break;
        case "Priority":
            sColId = "priority";
            break;
        case "Co-Owner":
            sColId = "coOwner";
            break;
        case "CAT/RAT Manager":
            sColId = "catratManager";
            break;
        case "IO/Cost Center":
            sColId = "costCenter";
            break;
        case "Execution Risk":
            sColId = "risk";
            break;
        case "Account":
            sColId = "managedAccount";
            break;
        case "Demo Start":
            sColId = "scheduleStartDate";
            break;
        case "Demo Completion":
            sColId = "scheduleCompletionDate";
            break;
        case "Lab Ready":
            sColId = "configChangeDate";
            break;	  
        default :
            sColId = objWrapper.convertToCamelCase(sColName);
            break;
    }
    return sColId;
}  

async clickOnBtn(sButtonName)
    {
        let btnSubmit = by.xpath("//button[contains(text(), '"+sButtonName+"')]");
        return await objWrapper.clickOnElement(btnSubmit, objWrapper.iDefaultTimeout).then(function(bRes){    
            if(bRes)
                sConsole = "Pass : Clicked on "+sButtonName+" button";
            else
                sConsole = "Not able to click on "+sButtonName+" button.";
            console.info(sConsole);
            return sConsole;
        });
    }

    async clickOnFieldDropDown(sFieldName)
    {
        let cmbDDXpath = by.xpath("//form//label[contains(text(),'"+sFieldName+"')]/parent::div//div[@class='ng-select-container']");
    
        await objWrapper.waitForElementToBeClickable(cmbDDXpath, objWrapper.iDefaultTimeout);
        return await objWrapper.clickOnElementWithOutScroll(cmbDDXpath, objWrapper.iDefaultTimeout).then(function(bRes){    
            if(bRes)
                sConsole = "Pass : Clicked on "+sFieldName+" button";
            else
                sConsole = "Not able to click on "+sFieldName+" button.";
            console.info(sConsole);
            return sConsole;
        });
    }

    async selectOptionFromDDList(sFieldName, sOption)
    {
        let cmbDDXpath = by.xpath("//label[contains(text(),'"+sFieldName+"')]/parent::div//div/span[text()='"+sOption+"']");
    
        await objWrapper.waitForElementToBeClickable(cmbDDXpath, objWrapper.iDefaultTimeout);
        return await objWrapper.clickOnElementWithOutScroll(cmbDDXpath, objWrapper.iDefaultTimeout).then(function(bRes){    
            if(bRes)
                sConsole = "Pass : Selected "+sOption+" option form "+sFieldName+" DD";
            else
                sConsole = "Not able to select "+sOption+" from "+sFieldName+" DD.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Namrata-09/04/2021- select multiple options from dropdown on the demo details page.
    async selectMultipleOptionFromDDList(sFieldName,sOption)
    {
 
																									  
							
																							 
																							 

        let cmbDDOption = by.xpath("//label[contains(text(),'"+sFieldName+"')]/parent::div//div[@class='dropdown-list']/ul/li//div[text()='"+sOption+"']");
        return await objWrapper.clickOnElement(cmbDDOption, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)            
               sConsole = "Pass : Selected option on "+sOption+" from "+sFieldName+" dropdown";
            else
               sConsole = "Not able to select on "+sOption+" from "+sFieldName+" dropdown";
            return sConsole;
        });  
    }

    async clickOnMultipleSelectFieldDropDown(sFieldName)
    {
        let cmbDDXpath = by.xpath("//form//label[contains(text(),'"+sFieldName+"')]/parent::div/div");
        browser.sleep(5000);
        await objWrapper.waitForElementToBeClickable(cmbDDXpath, objWrapper.iDefaultTimeout);
 
        return await objWrapper.clickOnElementWithOutScroll(cmbDDXpath, objWrapper.iDefaultTimeout).then(function(bRes){   
            if(bRes)
                sConsole = "Pass : Clicked on "+sFieldName+" button";
            else
                sConsole = "Not able to click on "+sFieldName+" button.";
            console.info(sConsole);
            return sConsole;
        });
    } 

    //Namrata-12/04/2021- click on schedule icon of date field on the demo details page.
    async clickonScheduleIcon(sFieldName)
    {
        let iconXpath = by.xpath("//label[text()='"+sFieldName+"']/parent::div//div//button");
        return await objWrapper.clickOnElement(iconXpath, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)            
                sConsole = "Pass : Clicked on "+sFieldName+" date icon";
            else
                sConsole = "Not able to click on "+sFieldName+" date icon";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Namrata-12/04/2021- click on the calendar icon on the demo details page.
    async clickOnCalendarIcon(sFieldName)
    {            
        let calXpath = by.xpath("//label[text()='"+sFieldName+"']/parent::div//div//button | //label[text()='New "+sFieldName+"']/parent::div//div//button");
        return await objWrapper.clickOnElement(calXpath, objWrapper.iDefaultTimeout).then(function(bRes){     
         if(bRes)            
                sConsole = "Pass : Clicked on calendar icon on "+sFieldName+" popup";
        else
            sConsole = "Not able to click on calendar icon on "+sFieldName+"popup";
        console.info(sConsole);
        return sConsole;
        });
    }

//Namrata-12/04/2021- verify background color of field on the demo details page.
    async verifyBackgroudColour(sFieldName, sBckgColor)
    {
        let sColId = this.getLabelId(sFieldName);
        let xpath = by.xpath("//input[@name='"+sColId+"']");
        return await objWrapper.getBackgroundColourofElement(xpath, objWrapper.iDefaultTimeout).then(function(sColor){
             if(sColor==sBckgColor)            
                sConsole = "Pass : Verfied background color as "+sBckgColor;
             else
                sConsole = "Failed to verify background color as "+sBckgColor;
            console.info(sConsole);
            return sConsole;
        });
    }

    //Namrata-12/04/2021- verify dropdown options from the field on the demo details page.
    async verifyOptionFromFieldDDOnDemoDetails(sFieldName,sOption)
    {
        let sFieldId = await this.getFieldName(sFieldName);
        let objOption = by.xpath("//select[@name='"+sFieldId+"']//option[contains(text(),'"+sOption+"')]");
        return await objWrapper.isElementPresent(objOption, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass :'"+sOption+"' Option is present under '"+sFieldName+"' dropdown";
            else
                sConsole = sOption+" is not present under "+sFieldName+" dropdown";
            console.info(sConsole);
            return sConsole;
        });
    } 

    //Namrata-12/04/2021- set text value in the field on the demo details page.
    async setValInField(sFieldName, sValue)
    {
        let txtPplPicker = by.xpath("//label[contains(text(),'"+sFieldName+"')]/parent::div//div/textarea");
        await objWrapper.setInputValue(txtPplPicker, sValue, objWrapper.iDefaultTimeout);
        return await objWrapper.getElementAttribute(txtPplPicker, 'ng-reflect-model', objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sValue)
                sConsole = "Pass : Set '"+sFieldName+"' as '"+sValue+"'.";
            else
                sConsole = "Fail : Fail to set '"+sFieldName+"' as '"+sValue+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }
    //Namrata-14/04/2021- get text value from the field on the demo details page.
    async getFieldValue(sFieldName)
    {
        let txtPplPicker = by.xpath("//label[contains(text(),'"+sFieldName+"')]//parent::div//input | //label[contains(text(),'"+sFieldName+"')]//parent::div//select");      
        return await objWrapper.getElementAttribute(txtPplPicker, 'ng-reflect-model', objWrapper.iDefaultTimeout).then(function(sText){
           console.info(sText);
            return sText;
        });
    } 
	
	//Richa_15042021 - Click cancel on Attachment pop up
    async clickCancelOnAttachmentPopUp()
    {
        let btnCancel = by.css("ngb-modal-window[class*='attachment-model'] button.btn.btn-secondary");
        return await objWrapper.clickOnElement(btnCancel, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on Cancel button on Attachments pop up.";
            else
                sConsole = "Fail : Fail to click on Cancel button on Attachments pop up.";
            console.info(sConsole);
            return sConsole;
        });
    }
	
	//Richa_15042021 - get tool id
    async getToolId()
    {
        let txtToolId = by.xpath("//label[text()='Tool ID']/following-sibling::input");
        return await objWrapper.getElementAttribute(txtToolId, "ng-reflect-model", objWrapper.iDefaultTimeout);
    }
	
	//Richa_15042021 - Select option from Multi select DD list
	async selectOptFromMultiSelectDDList(sDDName,sOption)
    {
        let cmbDD = by.xpath("//label[contains(text(),'"+sDDName+"')]/following-sibling::div/ng-multiselect-dropDown");
        await objWrapper.javascriptClickOnElement(cmbDD, objWrapper.iDefaultTimeout);
        // let cmbDDOption = by.xpath("//ng-multiselect-dropdown//li/div[text()='"+sOption+"']");
        let sDDOption=sOption.split("~")
        let i:any;
        for(i=0;i<sDDOption.length;i++)
        {
            let cmbDDOption = by.xpath("//ng-multiselect-dropdown//li/div[text()='"+sDDOption[i]+"']");
            await objWrapper.javascriptClickOnElement(cmbDDOption, objWrapper.iDefaultTimeout).then(function(bRes){
                if(bRes)            
                sConsole = "Pass : Selected option on "+sDDOption[i]+" from "+sDDName+" dropdown";
                else
                sConsole = "Not able to select on "+sDDOption[i]+" from "+sDDName+" dropdown";
                
            }); 
            console.log(sConsole);
        }
        await objWrapper.javascriptClickOnElement(cmbDD, objWrapper.iDefaultTimeout);
        return sConsole;
    }
	
    //Richa_20042021 - select RYG colour value
    async selectRYGColourVal(sFieldName, sRYGVal)
    {
        let objRYG = by.xpath("//label[text()='"+sFieldName+"']/following-sibling::div//input[@ng-reflect-value='"+sRYGVal+"']/following-sibling::label");
															
        return await objWrapper.clickOnElement(objRYG, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Selected value '"+sRYGVal+"' in field '"+sFieldName+"'.";
            else
                sConsole = "Fail : Fail to select value '"+sRYGVal+"' in field '"+sFieldName+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_20042021 - Click on toggle button
    async clickOnToggleField(sFieldLabel)
    {
        let sFieldLabel1, sFieldName;
        let objTAMBAState;
        switch(sFieldLabel)
        {
            case "Onsite Chamber Readiness" :
                sFieldName = "onsiteChamber";
                //objTAMBAState = by.xpath("//h3[contains(text(),'"+sFieldLabel+"')]/following-sibling::div[contains(@class, 'switchToggle')]/input");
                break;
            case "Additional CIP HW Requirement" :
                sFieldName = "additionalCIP";
                // objTAMBAState = by.xpath("//label[text()='"+sFieldLabel+"']/following-sibling::div[@class='switchToggle']/input");
                break;
            case "Shipping Details" :
                sFieldName = "isShippingDetailedRequired";
                break;
			case "Demo Issues" :
                sFieldName = "demoIssue";
                break;	  
            default :
                sFieldLabel1 = sFieldLabel.toLowerCase();
                sFieldName = objWrapper.convertToCamelCase(sFieldLabel1);
                //objTAMBAState = by.xpath("//label[text()='"+sFieldLabel+"']/following-sibling::div[@class='switchToggle']/input");
        }
        
        let objTAMBAToggle = by.css("div.switchToggle>input[name='"+sFieldName+"']+label");
         
        return await objWrapper.javascriptClickOnElement(objTAMBAToggle, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on '"+sFieldLabel+"' toggle button.";
            else
                sConsole = "Fail : Fail to click on '"+sFieldLabel+"' toggle button.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_21042021 - click on button on demo details page
    async clickOnAddShippingInfo()
    {
        let btnOnDemoDtls = by.xpath("//label[text()='Shipping Information']/following-sibling::div//button");
																						 
        return await objWrapper.clickOnElement(btnOnDemoDtls, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on Add to add shipping information on demo details page.";
            else
                sConsole = "Fail : Fail to click on Add to add shipping information on demo details page.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_21042021 - get newly added shipping link
    async getNewlyAddedShippingLink()
    {
        let tblRows = by.xpath("//table[contains(@class, 'shipping-table')]/tbody/tr");
        let iRowCnt;
        await objWrapper.getWebelementCount(tblRows).then(function(sText){iRowCnt = sText});
        let tblShippingLnk = by.xpath("//table[contains(@class, 'shipping-table')]/tbody/tr["+iRowCnt+"]/td[1]/a");
        return await objWrapper.getElementText(tblShippingLnk, objWrapper.iDefaultTimeout);
    }

	//Chakradhar_06052021 - verify newly added shipping link is apended or not
    async verifyNewlyAddedShippinglinkIsApendedorNot(sAddedlink)
    {
        let tblRows = by.xpath("//table[contains(@class, 'shipping-table')]/tbody/tr");
        let iRowCnt;
        await objWrapper.getWebelementCount(tblRows).then(function(sText){iRowCnt = sText});
        let tblShippingLnk = by.xpath("//table[contains(@class, 'shipping-table')]/tbody/tr["+iRowCnt+"]/td[1]/a");
        // return await objWrapper.getElementText(tblShippingLnk, objWrapper.iDefaultTimeout);
        await objWrapper.getElementText(tblShippingLnk, objWrapper.iDefaultTimeout).then(function(sText){
        if(sText == "http://"+sAddedlink)
        {
            sConsole= "Pass : added Link  '"+sAddedlink+"' is apended with 'http://'.";
        }
        else if(sText == sAddedlink)
        {
            sConsole= "Pass : added Links  '"+sAddedlink+"' is not apended with'http://'..";
        }
        else
        {
            sConsole= "Fail : added Links  '"+sAddedlink+"' is not apended or not same.";
        }
        });
        console.log(sConsole);
        return sConsole;
    }

    //Richa_21042021 - set Freight forwarder value
    async setFreightFwdr(sFreightFwdr)
    {
        let tblRows = by.xpath("//div[@class='shippingDetail show']//table/tbody/tr");
        let iRowCnt;
        await objWrapper.getWebelementCount(tblRows).then(function(sText){iRowCnt = sText});
        let tblFreightFwdr = by.xpath("//div[@class='shippingDetail show']//table/tbody/tr["+iRowCnt+"]/td[2]//input");
        await objWrapper.setInputValue(tblFreightFwdr, sFreightFwdr, objWrapper.iDefaultTimeout);
        return await objWrapper.getElementAttribute(tblFreightFwdr, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sFreightFwdr)
                sConsole = "Pass : Set Freight forwarder value as '"+sFreightFwdr+"'.";
            else
                sConsole = "Fail : Fail to set freight forwarder value as '"+sFreightFwdr+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_21042021 - set tracking number
    async setTrackingNumber(sTrackingNum)
    {
        let tblRows = by.xpath("//div[@class='shippingDetail show']//table/tbody/tr");
        let iRowCnt;
        await objWrapper.getWebelementCount(tblRows).then(function(sText){iRowCnt = sText});
        let tblTrackingNum = by.xpath("//div[@class='shippingDetail show']//table/tbody/tr["+iRowCnt+"]/td[3]//input");
        await objWrapper.setInputValue(tblTrackingNum, sTrackingNum, objWrapper.iDefaultTimeout);
        return await objWrapper.getElementAttribute(tblTrackingNum, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sTrackingNum)
                sConsole = "Pass : Set Tracking Number value as '"+sTrackingNum+"'.";
            else
                sConsole = "Fail : Fail to set tracking number value as '"+sTrackingNum+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_21042021 - Click on save to save table changes
    async clickSaveToSaveTblChanges()
    {
        let btnSave = by.css("a[data-original-title='Save']");
																											   
	 
 
														   
														 
	 
																													   
																		   
																							  
        return await objWrapper.clickOnElement(btnSave, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on Save to save table changes.";
            else
                sConsole = "Fail : Fail to click on Save to save table changes.";
            console.info(sConsole);
            return sConsole;
        });
    }

	//Richa_27042021 - get field val
    async getFieldVal(sFieldName)
    {
        let objField = by.xpath("//label[text()='"+sFieldName+"']/following-sibling::input");
        return await objWrapper.getElementAttribute(objField, "ng-reflect-model", objWrapper.iDefaultTimeout);
    }

   async verifyAttachmentIconIsDisplayed()
										
    {
        let objTableCell = by.xpath("//button[@data-target='#viewAttachments']");
        return await objWrapper.isElementDisplayed(objTableCell, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
               sConsole="Pass : Verified Attachment icon is displayed on Demo details page";
            else
                sConsole="Fail to verify Attachment icon on Demo details page";
            console.info(sConsole);
            return sConsole;
        });
    }

    async expandExternalLinkOnAttachmentsPopUp()
					 
    {
        let externalLink = by.xpath("//div[@class='modal-header']/h5[contains(text(),'Attachments')]/ancestor::div[@class='modal-content']//div[@id='headingExternalLink']");
        let extLink = by.xpath("//div[@class='modal-header']/h5[contains(text(),'Attachments')]/ancestor::div[@class='modal-content']//div[@id='headingExternalLink']/following-sibling::div[@id='collapseExternalLink']");
        return await objWrapper.getElementAttribute(extLink, "class",objWrapper.iDefaultTimeout).then(async function(sText){
            if(!sText.includes("show"))
            {
                return await objWrapper.clickOnElement(externalLink, objWrapper.iDefaultTimeout).then(function(bRes){
                if(bRes)
                    sConsole = "Pass : Clicked on External link to expand on Attachments pop up.";
                else
                    sConsole = "Fail : Fail to expand External Link on Attachments pop up.";
                console.info(sConsole);
                return sConsole;
                });
            }
            else
            {
                sConsole = "Pass : External link is already expanded on Attachments pop up.";
                console.info(sConsole);
                return sConsole;
            }
        });
    }

    async setLinkValInAttachmentsPopup(sFieldName, sVal)
														 
    {
        let txtField = by.xpath("//div[contains(@class,'active')]//div[@id='collapseExternalLink' and @class='collapse show']//label[contains(text(),'"+sFieldName+"')]//parent::div//input");
        await objWrapper.setInputValue(txtField, sVal, objWrapper.iDefaultTimeout);
																							  
        return await objWrapper.getElementAttribute(txtField, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
         if(sVal.includes(sText))
                sConsole = "Pass : Set value '"+sVal+"' in field '"+sFieldName+"'.";
            else
                sConsole = "Fail : Fail to set value '"+sVal+"' in field '"+sFieldName+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    async clickAddOnAttachmentsPopUp()
									 
    {
        let btnCancel = by.xpath("//div[@class='modal-content']//h5[contains(text(),'Attachments')]/parent::div[@class='modal-header']/following-sibling::div[@class='modal-body']//button[contains(text(), 'Add')]");
        return await objWrapper.clickOnElement(btnCancel, objWrapper.iDefaultTimeout).then(function(bRes){
								  
								   
				
																												   
            if(bRes)
                sConsole = "Pass : Clicked on Add button on attachments pop up";
            else
                sConsole = "Fail : Fail to click on Add button on Attachments pop up";
										   
									
				   
				
				   
																					   
            console.info(sConsole);
            return sConsole;
        });
    }


    async getExternalLinkValueOnAttachmentsPopup()
    {
      
        let linkTable = by.xpath("//div[@id='collapseExternalLink']//tbody//tr");
        let rowCount;
        await element.all(linkTable).count().then(async function(count){
            rowCount=count;
        });
        var sOptionTxt="";
        for(var iCount =1; iCount <=rowCount ; iCount++)
        {        
            let tableCell = by.xpath("//div[@id='collapseExternalLink']//tbody//tr["+iCount+"]/td[1]");
            await objWrapper.getElementText(tableCell,objWrapper.iDefaultTimeout).then(function(sTxt){
                if(iCount==1)
                    sOptionTxt=sTxt;
                else
                    sOptionTxt="~"+sTxt;
                });            
        }
        return sOptionTxt;
       
    }

    async deleteLinkOnAttachmentsPopUp(sLinkUrl)
    {
        let deleteBtn = by.xpath("//div[@id='collapseExternalLink']//tbody//tr//a[contains(text(),'"+sLinkUrl+"')]/parent::td/following-sibling::td//*[@title='Delete Link']/parent::a");
        return await objWrapper.clickOnElement(deleteBtn, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Deleted link "+sLinkUrl+" on attachments pop up";
            else
                sConsole = "Fail : Fail to Delete link "+sLinkUrl+" on Attachments pop up";
            console.info(sConsole);
            return sConsole;
        });
    }

    async clickOnLinkOnAttachmentsPopUp(sLinkUrl)
										 
    {
        let link = by.xpath("//div[@id='collapseExternalLink']//tbody//tr//a[contains(text(),'"+sLinkUrl+"')]");
        return await objWrapper.clickOnElement(link, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on link "+sLinkUrl+" on attachments pop up";
            else
                sConsole = "Fail : Fail to click link "+sLinkUrl+" on Attachments pop up";
            console.info(sConsole);
            return sConsole;
        });
    }


     //Namrata-20/04/2021- click on the calendar icon on the demo details page.
     async clickOnWaferAvailableInLabDate(sFieldName)
     {            
         let calXpath = by.xpath("//label[text()='Wafers Available in Lab']/parent::div//div//span[@class='input-group-text']");
         return await objWrapper.clickOnElementWithOutScroll(calXpath, objWrapper.iDefaultTimeout).then(function(bRes){     
          if(bRes)            
                 sConsole = "Pass : Clicked on calendar icon on "+sFieldName+" popup";
         else
             sConsole = "Not able to click on calendar icon on "+sFieldName+"popup";
         console.info(sConsole);
         return sConsole;
         });
     }

     
    async verifySectionIsDisplayed(sSection)
    {
        let objSection = by.xpath("//h3[contains(text(), '"+sSection+"')]/ancestor::div[@class='card accordion__item']");
        return await objWrapper.isElementPresent(objSection, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
            sConsole = "Pass : "+objSection+" section displayed successfully.";
        else
            sConsole = "Fail : Fail to display "+objSection+" section.";
        console.info(sConsole);
        return sConsole;
        });
    }

    async expandSection(sSection)
    {
        let objSection = by.xpath("//h3[contains(text(), '"+sSection+"')]/ancestor::div[contains(@class,'card accordion__item')]");
        return await objWrapper.getElementAttribute(objSection, "class",objWrapper.iDefaultTimeout).then(async function(sValue){
        if(sValue.includes("active"))
            sConsole = "Pass : "+objSection+" section is already expanded.";
        else
        {
            await objWrapper.clickOnElement(objSection,objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Expand "+sSection+" section";
            else
                sConsole = "Fail : Fail to expand "+sSection+" section.";
            });
        }
        console.info(sConsole);
        return sConsole;
        });
    }

    async setFreightForwarder(sFreightForwarder)
    {
        let tblRow = by.xpath("//table[@class='table table-striped top_priority mb-3 mt-1']/tbody/tr");
        let iRowCount;console.info("rc "+iRowCount);
        await objWrapper.getWebelementCount(tblRow).then(function(iCnt){iRowCount = iCnt});
        let txtFFbCat = by.xpath("//table[@class='table table-striped top_priority mb-3 mt-1']/tbody/tr["+iRowCount+"]/td[2]//input");
        await objWrapper.setInputValue(txtFFbCat, sFreightForwarder, objWrapper.iDefaultTimeout);
        return await objWrapper.getElementAttribute(txtFFbCat, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sFreightForwarder)
                sConsole = "Pass : Set Freight Forwarder value as '"+sFreightForwarder+"'";
            else
                sConsole = "Fail : Fail to set Freight Forwarder value as '"+sFreightForwarder+"'";
            console.info(sConsole);
            return sConsole;
        });
    }
  
    async selectColorRadioBtn(sFieldName, sColor)
    {
    
        let sColorValue=this.getAttributeValueforColor(sColor);
        let xpathString = "//label[contains(text(),'"+sFieldName+"')]//parent::div//input[@ng-reflect-value='"+sColorValue+"']";
        let radioField = by.xpath(xpathString+"/following-sibling::label");
        await objWrapper.clickOnElement(radioField, objWrapper.iDefaultTimeout);
        return await objWrapper.getElementAttribute(by.xpath(xpathString), "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sColorValue)
                sConsole = "Pass : Selected '"+sColor+"' radio button for field '"+sFieldName+"'.";
            else
                sConsole = "Fail : Fail to select '"+sColor+"' radio button for field '"+sFieldName+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    getAttributeValueforColor(sColor)																			   
    {
        let sColorAttrValue;
        console.log(sColor)
        switch(sColor)
        {	
            case "Green":
                sColorAttrValue = "G";
                break;
            case "Yellow":
                sColorAttrValue = "Y";
																																																											
                break;
            case "Red":
                sColorAttrValue = "R";
                break;
        
            default :
														 
            sColorAttrValue = objWrapper.convertToCamelCase(sColor);
																																  
        }
        return sColorAttrValue;
    }


    async clickOnApplicationFieldDropDown()
    {
        let appDDXpath = by.xpath("//form//label[text()='Application']/parent::div//div[@class='ng-select-container']");
    
        await objWrapper.waitForElementToBeClickable(appDDXpath, objWrapper.iDefaultTimeout);
        return await objWrapper.clickOnElementWithOutScroll(appDDXpath, objWrapper.iDefaultTimeout).then(function(bRes){    
            if(bRes)
                sConsole = "Pass : Clicked on Application drop down";
            else
                sConsole = "Not able to click on Application drop down.";
            console.info(sConsole);
            return sConsole;
        });
    }


    async selectOptionFromApplicationDDList(sFieldName, sOption)
    {
        let cmbDDXpath = by.xpath("//label[contains(text(),'"+sFieldName+"')]/parent::div//div/span[text()='"+sOption+"']");
    
        await objWrapper.waitForElementToBeClickable(cmbDDXpath, objWrapper.iDefaultTimeout);
        return await objWrapper.clickOnElement(cmbDDXpath, objWrapper.iDefaultTimeout).then(function(bRes){    
            if(bRes)
                sConsole = "Pass : Selected "+sOption+" option form "+sFieldName+" DD";
            else
                sConsole = "Not able to select "+sOption+" from "+sFieldName+" DD.";
            console.info(sConsole);
            return sConsole;
        });
    }

													
									 
	 
																					   
					
																							
																												   
																						   
	 

    async clickOnIssueTypeDD()
									  
    {
        let tblRow = by.xpath("//div[@class='demo-issues show']//table//tbody/tr");
        let iRowCount;
        await objWrapper.getWebelementCount(tblRow).then(function(iCnt){iRowCount = iCnt});
        let issueTypeXpath = by.xpath("//tr["+iRowCount+"]//td[2]//div/*[contains(@class,'ng-select ng-select-single ng-select-searchable')]");
    
        return await objWrapper.clickOnElement(issueTypeXpath, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on Issue type dropdown";
            else
                sConsole = "Failed to click on Issue type Dropdown";
            console.info(sConsole);
            return sConsole;
        });
    }

    async verifyIssueTypeDDValue(sOption)
										 
    {
       await this.clickOnIssueTypeDD();
        let issueTypeDDXpath = by.xpath("//td[2]//div/span[text()='"+sOption+"']");
       
																													   
																								 
        return await objWrapper.getElementText(issueTypeDDXpath,  objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sOption)
                sConsole = "Pass : Verified '"+sOption+"' is present under Issue Type DD";
            else
                sConsole = "Fail : Fail to verify '"+sOption+"' is present under Issue Type DD";
            console.info(sConsole);
            return sConsole;
        });
    }

   //Nidhi-04/05/2021 Verify Text in the field on the demo details page 
    async verifyTextOnDemoDetails(sLabelName, sText)
    {
        let objText = by.xpath("//label[text()='"+sLabelName+"']//parent::div//input[@ng-reflect-model='"+sText+"']");
        return await objWrapper.isElementDisplayed(objText, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Field "+sLabelName+" is having value as "+sText+".";
            else
                sConsole = "Not able to verify the details.";
            console.info(sConsole);
            return sConsole;
			 
        })
    }
	
	//Richa_30042021 - select issue type in table
    async selectIssueType(sIssueType)
    {
        let tblRows = by.xpath("//div[@class='demo-issues show']//table//tbody/tr");
        let iRowCnt;
        await objWrapper.getWebelementCount(tblRows).then(function(sText){iRowCnt = sText});
        let tblIssueType = by.xpath("//div[@class='demo-issues show']//table/tbody/tr["+iRowCnt+"]/td[2]//input");
        await objWrapper.setInputValue(tblIssueType, sIssueType, objWrapper.iDefaultTimeout);
        let objDDListItem = by.xpath("//ng-dropdown-panel//span[contains(text(), '"+sIssueType+"')]");
        return await objWrapper.clickOnElement(objDDListItem, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Selected issue type as '"+sIssueType+"'.";
            else
                sConsole = "Fail : Fail to select issue type as '"+sIssueType+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_30042021 - select wafer slot position in table
    async selectWaferSlotPosition(sWaferSlotPosition)
    {
        let tblRows = by.xpath("//div[@class='demo-issues show']//table//tbody/tr");
        let iRowCnt;
        await objWrapper.getWebelementCount(tblRows).then(function(sText){iRowCnt = sText});
		
        let tblWaferSlotPosition = by.xpath("//div[@class='demo-issues show']//table/tbody/tr["+iRowCnt+"]/td[3]//input");
        await objWrapper.setInputValue(tblWaferSlotPosition, sWaferSlotPosition, objWrapper.iDefaultTimeout);
        let objDDListItem = by.xpath("//ng-dropdown-panel//span[text() = '"+sWaferSlotPosition+"']");
        return await objWrapper.clickOnElement(objDDListItem, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Selected wafer slot position as '"+sWaferSlotPosition+"'.";
            else
                sConsole = "Fail : Fail to select wafer slot position as '"+sWaferSlotPosition+"'.";
				
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_04052021 - set Consumables value in cost Estomation
    async setConsumablesInCostEstimation(sVal)
    {
        let txtField = by.xpath("//label[text()='Consumables']//parent::div//input");
        await objWrapper.setInputValue(txtField, sVal, objWrapper.iDefaultTimeout);
        return await objWrapper.getElementAttribute(txtField, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sVal)
                sConsole = "Pass : Set value '"+sVal+"' in field Consumables.";
            else
                sConsole = "Fail : Fail to set value '"+sVal+"' in field Consumables.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_04052021 - get estimated cost
    async getEstimatedCost()
    {
        let txtEstimatedCost = by.css("h5[class*='overall-cost']");																												 
        return await objWrapper.getElementText(txtEstimatedCost, objWrapper.iDefaultTimeout).then(function(sText){
            let sCost = sText.substring(sText.indexOf("$"));
            return sCost;
        });
    }
    //Nidhi-05/05/2021 verify Multi Demo section display
    async verifyMultiDemoSectionDisplay()
    {
        let objDemoDetails = by.xpath("//h3[contains(text(),'Multi BU Demos')]");
        return await objWrapper.isElementDisplayed(objDemoDetails, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Multi BU Demo section get display";			
            else
                sConsole = "Multi BU Demos section does not display.";
            console.info(sConsole);
            return sConsole;
			 
        })
    }
	 //Nidhi-11/05/2021 verify demo number in Multi Demo section display
    async verifyDemoNumberInMultiDemoSection(sDemoNumber)
    {
        let objMultiDemo = by.xpath("//div[@class='card-body']//th[text()='Demo Number']//ancestor::table//tbody//a[text()='"+sDemoNumber+"']");
        return await objWrapper.isElementDisplayed(objMultiDemo, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : In Multi BU Demo section Correct Demo get display";			
            else
                sConsole = "In Multi BU Demo section Correct Demo Correct Demo doesn't get display.";
            console.info(sConsole);
            return sConsole;
			 
        })
    }
	
	 //Namrata 4/5/2021 - click on  newly added shipping link
    async clickOnNewlyAddedShippingLink()
    {
        let tblRows = by.xpath("//table[contains(@class, 'shipping-table')]/tbody/tr");
        let iRowCnt;
        await objWrapper.getWebelementCount(tblRows).then(function(sText){iRowCnt = sText});
        let tblShippingLnk = by.xpath("//table[contains(@class, 'shipping-table')]/tbody/tr["+iRowCnt+"]/td[1]/a");
        return await objWrapper.clickOnElement(tblShippingLnk, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on newly added Shipping link";
            else
                sConsole = "Fail : Fail to click on newly added Shipping link"; 
                console.info(sConsole);
                return sConsole;               
        });
       
    }
	
	 //Richa_10052021 - click on schedule assistant button
    async clickOnScheduleAssistant()
    {
        let btnScheduleAssistant = by.css("div.col-md-3.mb-2.schedule-assis.ml-auto>button");
        return await objWrapper.clickOnElement(btnScheduleAssistant, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on Schedule Assistant button.";
            else
                sConsole = "Fail : Fail to click on Schedule Assistant button.";
            console.info(sConsole);
            return sConsole;
        });
    }
}
