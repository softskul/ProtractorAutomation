import { wrapper } from '../utils/wrapper.util';
import { element, by, browser } from 'protractor';
import { BrowserUtil } from '../utils/browser.util';
import { SpecReporter } from 'jasmine-spec-reporter';

let objWrapper:wrapper;
let sConsole;
export class myDraftRequestPage{
    constructor()
    {
        objWrapper = new wrapper();
    }

    async verifyDraftRequestPresentInTable(sDemoName) 
    {
        let objTblDemoName = by.xpath("//div[@col-id='demoName' and contains(text(), '"+sDemoName+"')]");
        return await objWrapper.isElementPresent(objTblDemoName, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
			 
                sConsole = "Pass : Draft request with demo name'"+sDemoName+"' present on My Draft Request page.";
							
			 
            else
			 
                sConsole = "Fail : Fail to find draft request with demo name'"+sDemoName+"' on My Draft Request page.";
            console.info(sConsole);
            return sConsole;
			 
        });
    }

    async clickOnDraftedDemo(sDemoName)
    {
        let tblDemoNumCol = by.xpath("//div[@col-id='demoName' and contains(text(), '"+sDemoName+"')]/preceding-sibling::div[@col-id='demoNumber']");
        return await objWrapper.clickOnElement(tblDemoNumCol, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
			 
                sConsole = "Pass : Clicked on drafted demo number column with demo name " + sDemoName;
            
			 
            else
			 
                sConsole = "Fail : Fail to click on drafted demo number column demo name " + sDemoName;
            console.info(sConsole);
            return sConsole;
			 
        });
    }

    async getDraftedDemoNumber(sDemoName)
    {
        let tblDemoNumCol = by.xpath("//div[@col-id='demoName' and contains(text(), '"+sDemoName+"')]/preceding-sibling::div[@col-id='demoNumber']");
        return await objWrapper.getElementText(tblDemoNumCol, objWrapper.iDefaultTimeout).then(function(sText){
            console.info("Drafted demo request number is " + sText);
            return sText;
        });
    }
    async clickOnOkBtnOnPopUp()
    {  
        let objOkBtn = by.xpath("//button[contains(text(),'OK')]");
        return await objWrapper.clickOnElement(objOkBtn, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
            sConsole = "Pass : Clicked on Ok button.";   
        else
            sConsole = "Fail : Fail to click on ok button."; 
            console.info(sConsole);
            return sConsole;
        });
    }

   //Richa_23032021 - Save demo number
    async saveDemoNumber(sDemoName, sSaveLabel)
    {
        let objDemoNumber = by.xpath("//div[@col-id='demoName' and contains(text(), '"+sDemoName+"')]/preceding-sibling::div[@col-id='demoNumber']");
        await objWrapper.getElementText(objDemoNumber, objWrapper.iDefaultTimeout).then(function(sText){
            console.log(sText);
            browser.executeScript("window.localStorage.setItem('"+sSaveLabel+"', '"+sText+"');");
        });
    }
}