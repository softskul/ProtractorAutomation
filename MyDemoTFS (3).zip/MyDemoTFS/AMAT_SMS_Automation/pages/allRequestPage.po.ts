import { wrapper } from '../utils/wrapper.util';
import { element, by, browser } from 'protractor';
import { BrowserUtil } from '../utils/browser.util';
import { SpecReporter } from 'jasmine-spec-reporter';
import { allViewPage } from './allViewPage.po';
import { commonPage } from './commonPage.po';

let objWrapper:wrapper;
let objAllViewPage:allViewPage;
let objCommonPage:commonPage;
let sConsole;
export class allRequestPage{
    constructor()
    {
        objWrapper = new wrapper();
        objAllViewPage= new allViewPage();
        objCommonPage= new commonPage();
    }
//Nidhi-19/03/2021- selet the owner name from the dropdown on the all view pop up page
async setOwnerName(sLabelName, sOwnerName)
    {
      
    let txtLabel = by.xpath("//label[contains(text(),'"+sLabelName+"')]//parent::div//textarea|//label[contains(text(),'"+sLabelName+"')]//parent::div//input[1]")
    await objWrapper.setInputCharByChar(txtLabel,sOwnerName, objWrapper.iDefaultTimeout);
    return await objWrapper.getElementAttribute(txtLabel, 'ng-reflect-model', objWrapper.iDefaultTimeout).then(function(sText){
        if(sText == sOwnerName)
            sConsole = "Pass : Set "+sLabelName+" as '"+sOwnerName+"'.";
        else
            sConsole = "Not able to set "+sLabelName+" as '"+sOwnerName+"'.";
        console.info(sConsole);
        return sConsole;
    });
    }
//Nidhi-19/03/2021- selet the owner name from the dropdown on the all view pop up page
async selectOwnerName(sLabelName, sOwnerName)
    {
        let sLabelId = await objAllViewPage.getLabelId(sLabelName);
        let lstAccOwner = by.xpath("//ul[@class='list-group']//a[contains(text(),'"+sOwnerName+"')]/parent::li");
        await objWrapper.javascriptClickOnElement(lstAccOwner, objWrapper.iDefaultTimeout);
        let objSelectedOwner = by.css("div[ng-reflect-name='"+sLabelId+"']>input[name='name']");
        return await objWrapper.getElementAttribute(objSelectedOwner, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
            if(sText.includes(sOwnerName))
                sConsole = "Pass : Clicked on Account owner list option '"+sOwnerName+"'.";
            else
                sConsole = "Not able to click on Account owner list option '"+sOwnerName+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

// Nidhi- 19/03/2021 enter and select owner name from the list
async selectOwnerOnPopUp(sLabelName,sOwnerName)
{
    expect(await this.setOwnerName(sLabelName,sOwnerName)).toContain("Pass");
    await browser.sleep(15000);
    return await this.selectOwnerName(sLabelName,sOwnerName);
}
//Nidhi-23/03/2021- Click on the Attachment Icon on the Page
async clickOnTheAttachmentIcon()
{
    let objAttachIcon = by.xpath("//button[@data-target='#viewAttachments']");
    return await objWrapper.clickOnElement(objAttachIcon, objWrapper.iDefaultTimeout).then(function(bRes){
    if(bRes)
    sConsole = "Pass : Clicked on the View Attachmemt icon.";    
    else
    sConsole = "Not Clicked on the View Attachmemt icon.";   
    console.info(sConsole);
    return sConsole;  
    });
}
 //Nidhi-23/03/2021 - click on browse button on view attachment pop up
 async clickOnBrowseButtonOnViewAttachment()
 {
     let btnBrowse = by.xpath("//app-view-attachment-shared[not(@title)]//label[@for='inputGroupFile04']")
     return await objWrapper.clickOnElementUsingActionClass(btnBrowse, objWrapper.iDefaultTimeout).then(function(){
     sConsole ="Pass : Clicked on the document browse button"
     console.info(sConsole);
     return sConsole;
     
 });
}
//Nidhi-24/03/2021 - click on upload button on view attachment pop up
async clickOnUploadButtonOnViewAttachment()
{
    let btnUpload = by.xpath("//app-view-attachment-shared[not(@title)]//button[contains(text(),'Upload')]");
    //await objWrapper.javascriptClickOnElement(btnBrowse, objWrapper.iDefaultTimeout);
    return await objWrapper.clickOnElement(btnUpload, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
            sConsole = "Pass : Clicked on Upload button on the view attachment pop up";
        else
            sConsole = "Not able to click on Upload button on the view attachment pop up.";
        console.info(sConsole);
        return sConsole;
    });
}
//Nidhi-24/03/2021 - click in the table cell having speific Requestor name
async clickInTableCellDemoRequestor(sDemoName, sReqName)
{
    let  objTableCell, iRowNo;
    await objCommonPage.getRowNoForApplicationName(sDemoName).then(function(iRow){iRowNo = iRow;});
    objTableCell = by.xpath("//div[@row-index='"+iRowNo+"']//div[@role='gridcell' and @col-id='demoRequestor'][contains(text(),'"+sReqName+"')]");    
    return await objWrapper.clickOnElementWithOutScroll(objTableCell, objWrapper.iDefaultTimeout).then(function(bRes){
    if(bRes)
    sConsole = "Pass : Clicked in the col Demo Requestor cell contains Requestor Name as '"+sReqName+"' and demo name is '"+sDemoName+"'.";  
    else
    sConsole = "Not able to click in the col Demo Requestor"; 
    console.info(sConsole);
    return sConsole;
    });
}
//Nidhi-25/03/2021- Click on the Eye Icon on the Page
async clickOnTheEyeIcon()
{
    let objEyeIcon = by.xpath("//button[@data-target='#details']");
    return await objWrapper.clickOnElement(objEyeIcon, objWrapper.iDefaultTimeout).then(function(bRes){
    if(bRes)
    sConsole = "Pass : Clicked on the Eye icon.";    
    else
    sConsole = "Not Clicked on the Eye icon.";   
    console.info(sConsole);
    return sConsole;  
    });
}
//Nidhi-25/03/2021- Verify the Passed section displayed on the eye icon pop up.
async verifySectionDisplayedOnPopUp(sSectionName)
    {
        let objSection = by.xpath("//div[contains(text(),'"+sSectionName+"')]");
        return await objWrapper.isElementPresent(objSection, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Section "+sSectionName+" displayed on demo details pop up.";
            else
                sConsole = "Not able to find section "+sSectionName+" on demo details pop up.";
            console.info(sConsole);
            return sConsole;
        });
    }
//Nidhi-Select the CATRAT Manager
    async selectCATRATMngr(sCATRATMngr)
    {
        let lstCATRATMngr = by.xpath("//ul[@class='list-group']//a[contains(text(),'"+sCATRATMngr+"')]/parent::li");
        await objWrapper.javascriptClickOnElement(lstCATRATMngr, objWrapper.iDefaultTimeout);
        let objSelectedOwner = by.xpath("//label[text()='CAT/RAT Manager']/following-sibling::app-people-picker//input[@name='name_hide']");
        return await objWrapper.getElementAttribute(objSelectedOwner, "value", objWrapper.iDefaultTimeout).then(function(sText){
            console.log(sText);
            if(sText==sCATRATMngr)
            sConsole= "Pass : Clicked on CAT/RAT Manager list option '"+sCATRATMngr+"'.";
            else
            sConsole= "Fail to click on CAT/RAT Manager list option '"+sCATRATMngr+"'.";
            console.info(sConsole);
            return sConsole;
            
        });
    }
// Nidhi- 25/03/2021 Select the CAT RAT Manager
async selectRATCATManager(sLabelName,sCATRATMngr)
{
    expect(await this.setOwnerName(sLabelName,sCATRATMngr)).toContain("Pass");
    await browser.sleep(15000);
    return await this.selectCATRATMngr(sCATRATMngr);
}
//Nidhi-29/03/2021- get the Field Value as per passed Field Name.
async getFieldValueOnPopUp()
    {
        let objFieldValue = by.xpath("//label[contains(text(),'Wafer Status')]//parent::div//input");
        return await objWrapper.getElementAttribute(objFieldValue,'value',objWrapper.iDefaultTimeout).then(function(sText){
        console.info("Wafer Location value is "+sText+".");
        return sText;
        });
    }

//Nidhi-29/03/2021- check Freezed Message is present on pop or not.
async verifyFreezedMsgPresentOnPopUp()
    {   let objSection = by.css("span[class*='text-info']");
        return await objWrapper.isElementPresent(objSection, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
        sConsole = "Pass : Disply Freezed Message";
        else
        sConsole = "Does not display the Freezed Message.";
        console.info(sConsole);
        return sConsole;
        });
    }
//Nidhi-29/03/2021- Verify Frezzed Message as per wafer status
async verifyFreezedMsgOnPopUp()

    {   let sWaferLocation;
        await this.getFieldValueOnPopUp().then(function(sText){sWaferLocation = sText;});
        if(sWaferLocation == 'In transit to account'||sWaferLocation=='In transit to customer'||sWaferLocation=='No Customer Wafer'||sWaferLocation=='Customer Hand Carried'){
        await this.verifyFreezedMsgPresentOnPopUp();
        sConsole = "Wafer Location is "+sWaferLocation+" and it does not display frezzed Message";
        }
        else{
        await this.verifyFreezedMsgPresentOnPopUp();
        sConsole = "Pass : Wafer Location is "+sWaferLocation+" and it display frezzed Message";
        }
        console.info(sConsole);
        return sConsole;    
        
    }
//Nidhi- Verify that none of the field os clickable on the approval pop up.
async verifyAllFieldIsNotClickable()
{
    let objAllField = by.xpath("//fieldset[@disabled]");
    return await objWrapper.waitForElementToBeClickable(objAllField,objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
            sConsole = "Pass : All The Field are not clickable";
        else
            sConsole = "All or some of the Field are clickable";
        console.info(sConsole);
        return sConsole;
    });
}
//Nidhi-8/04/2021 verify the label is present on the pop up
async verifyLabelIsPresent(sLabelName)
{
    let objField = by.xpath("//label[contains(text(),'"+sLabelName+"')]");
    return await objWrapper.isElementPresent(objField,objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
            sConsole = "Pass : Field "+sLabelName+" is Present.";
        else
            sConsole = "Field "+sLabelName+" is not Present.";
        console.info(sConsole);
        return sConsole;
    });
}
}
