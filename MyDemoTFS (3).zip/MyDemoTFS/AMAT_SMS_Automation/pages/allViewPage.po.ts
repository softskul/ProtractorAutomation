import { wrapper } from '../utils/wrapper.util';
import { commonPage } from '../pages/commonPage.po';
import { element, by, browser } from 'protractor';
import { BrowserUtil } from '../utils/browser.util';
import { exit } from 'process';
import { isParseTreeNode, setTextRange } from 'typescript';
import { isNull } from 'util';

let objWrapper:wrapper;
let objCommonPage: commonPage;
let sConsole;
export class allViewPage{
    constructor()
    {
        objWrapper = new wrapper();
        objCommonPage = new commonPage();
    }
    
    async verifyDemoApprovalStatus(sColName, sDemoName)
    {
        let sStatus;
        await objCommonPage.goToColumn("Demo Approval")
        await objCommonPage.getTableCellValue(sColName,sDemoName).then(function(sText){sStatus = sText;});
        return sStatus;
    }

    async clickOnDemoNumber(sDemoName)
    {
        let tblDemoNumber = by.xpath("//div[@col-id='demoName' and contains(text(), '"+sDemoName+"')]/following-sibling::div[@col-id='demoNumber']//a");
        let sDemoNo = await objWrapper.getElementText(tblDemoNumber, objWrapper.iDefaultTimeout).then(function(sText){return sText;});
        return await objWrapper.clickOnElement(tblDemoNumber, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
            {
                console.info("Clicked on Demo Number '"+sDemoNo+"' cell.");
                return true;
            }
            else
            {
                console.error("Fail to click on demo number '"+sDemoNo+"'.");
                return false;
            }
        });
    }
    async clickInTableCell(sDemoName, sColName)
    {
        let sColName1 = objCommonPage.getColId(sColName);
        let objDemoName = by.xpath("//div[@col-id='demoName' and contains(text(), '"+sDemoName+"')]/parent::div");
        
        let iRow = await objWrapper.getElementAttribute(objDemoName, 'row-index', objWrapper.iMaxTimeout).then(function(iRNo){
            console.log(iRNo);
            return iRNo;
        });
        let objTableCell;
        if(sColName == 'Demo Number')
            objTableCell = by.xpath("//div[@col-id='demoName' and contains(text(), '"+sDemoName+"')]/following-sibling::div[@col-id='"+sColName1+"']//a|//div[@row-index='"+iRow+"']//div[@col-id='"+sColName1+"']//a");
		else if(sColName == "Demo Issue" || sColName == "Shipping Information")
            objTableCell = by.xpath("//div[@row-index='"+iRow+"']//div[@col-id='"+sColName1+"']//button");																					  
        else
            objTableCell = by.xpath("//div[@col-id='demoName' and contains(text(), '"+sDemoName+"')]/following-sibling::div[@col-id='"+sColName1+"']|//div[@row-index='"+iRow+"']//div[@col-id='"+sColName1+"']");
        console.log(objTableCell);
        // await objWrapper.isElementPresent(objTableCell, objWrapper.iDefaultTimeout).then(async function(bRes){
        //     if(!bRes)
        //     {
                
        //         objTableCell = by.xpath("//div[@row-index='"+iRow+"']//div[@col-id='"+sColName+"']");
        //     }
        // });
        return await objWrapper.javascriptClickOnElement(objTableCell, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked in table cell column '"+sColName+"' against Demo name '"+sDemoName+"'";
            else
                sConsole = "Fail : Fail to click in table cell column '"+sColName+"' against demo name '"+sDemoName+"'.";
            console.info(sConsole);
            return sConsole;
        });      
    }										   
    async clickOnACLApprovalInTableCell(sDemoName)
    {
        let objTableCell = by.xpath("//div[@col-id='demoName' and contains(text(), '"+sDemoName+"')]/preceding-sibling::div//button[@data-target='#status']");
        return await objWrapper.clickOnElement(objTableCell, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
            sConsole = "Pass : Clicked on ACL - Approval button in table cell against demo name '"+sDemoName+"'.";   
            else
            sConsole = "Fail to click on ACL - Approval button in table cell against demo name '"+sDemoName+"'.";
            console.info(sConsole);
            return sConsole;     
            
        });
    }

    async clickOnAddCommentsInTableCell(sDemoName)
    {
        let objTableCell = by.xpath("//div[@col-id='demoName' and contains(text(), '"+sDemoName+"')]/preceding-sibling::div//button[@data-target='#comment']");
        return await objWrapper.clickOnElement(objTableCell, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
            {
                console.info("Clicked on Add Comments button in table cell against demo name '"+sDemoName+"'.");
                return true;
            }
            else
            {
                console.error("Fail to click on Add Comments button in table cell against demo name '"+sDemoName+"'.");
                return false;
            }
        });
    } 

    async clickOnAddActionInTableCell(sDemoName)
    {
        let objTableCell = by.xpath("//div[@col-id='demoName' and contains(text(), '"+sDemoName+"')]/preceding-sibling::div//button[@data-target='#action']");
        return await objWrapper.clickOnElement(objTableCell, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
            {
                console.info("Clicked on Add Action button in table cell against demo name '"+sDemoName+"'.");
                return true;
            }
            else
            {
                console.error("Fail to click on Add Action button in table cell against demo name '"+sDemoName+"'.");
                return false;
            }
        });
    }
    
    async clickOnAddAttachmentExtLinkInTableCell(sDemoName)
    {
        let objTableCell = by.xpath("//div[@col-id='demoName' and contains(text(), '"+sDemoName+"')]/preceding-sibling::div//button[@data-target='#viewAttachments']");
        return await objWrapper.clickOnElement(objTableCell, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
            {
                console.info("Clicked on Add Attachments and External Link button in table cell against demo name '"+sDemoName+"'.");
                return true;
            }
            else
            {
                console.error("Fail to click on Add Attachment and External Link button in table cell against demo name '"+sDemoName+"'.");
                return false;
            }
        });
    }

    async clickOnViewDtlsInTableCell(sDemoName)
    {
        let objTableCell = by.xpath("//div[@col-id='demoName' and contains(text(), '"+sDemoName+"')]/preceding-sibling::div//button[@data-target='#details']");
        return await objWrapper.clickOnElement(objTableCell, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
            {
                console.info("Clicked on View Details button in table cell against demo name '"+sDemoName+"'.");
                return true;
            }
            else
            {
                console.error("Fail to click on View Details button in table cell against demo name '"+sDemoName+"'.");
                return false;
            }
        });
    }

    async setValInTableInputField(sVal)
    {
        let txtInput = by.css("input[class*='ag-text-field-input'],textarea[class*='ag-text-area-input']");
        await objWrapper.setInputValue(txtInput, sVal, objWrapper.iDefaultTimeout);
        await objWrapper.sendKeysInActiveElmnt("Enter");
        // return await objWrapper.getElementText(txtInput, objWrapper.iDefaultTimeout).then(function(sText){
        //     if(sText == sVal)
        //     {
        //         console.info("Set input value '"+sVal+"' in field.");
        //         return true;
        //     }
        //     else
        //     {
        //         console.error("Fail to set input value '"+sVal+"' in field.");
        //         return false;
        //     }
        // });
   }

    async verifyValueInTableCell(sDemoName, sColName, sExpVal)
    {
        let sColName1 = objCommonPage.getColId(sColName);
        let objDemoName = by.xpath("//div[@col-id='demoName' and contains(text(), '"+sDemoName+"')]/parent::div");
        let iRow = await objWrapper.getElementAttribute(objDemoName, 'row-index', objWrapper.iDefaultTimeout).then(function(iRNo){
            return iRNo;
        });
        let objTableCell = by.xpath("//div[@col-id='demoName' and contains(text(), '"+sDemoName+"')]/following-sibling::div[@col-id='"+sColName1+"']|//div[@row-index='"+iRow+"']//div[@col-id='"+sColName1+"' and contains(text(), '"+sExpVal+"')]|//div[@row-index='"+iRow+"']//div[@col-id='"+sColName1+"']//span[contains(text(),'"+sExpVal+"')]|//div[@row-index='"+iRow+"']//div[@col-id='"+sColName1+"']/span/span[@data-original-title='"+sExpVal+"']")
        console.info(objTableCell);
        // await objWrapper.isElementPresent(objTableCell, objWrapper.iDefaultTimeout).then(async function(bRes){
        //     if(!bRes)
        //     {
                
        //         objTableCell = by.xpath("//div[@row-index='"+iRow+"']//div[@col-id='"+sColName+"']");
        //     }
        // });
        // return await objWrapper.getElementText(objTableCell, objWrapper.iDefaultTimeout).then(function(sText){
        //     if(sText == sExpVal)
        return await objWrapper.isElementPresent(objTableCell, objWrapper.iDefaultTimeout).then(function(bRes)
        {
            if(bRes)
                sConsole = "Pass : Verified value '"+sExpVal+"' in table column '"+sColName+"' against Demo name '"+sDemoName+"'";
            else
                sConsole = "Value '"+sExpVal+"' not found in table column '"+sColName+"' against demo name '"+sDemoName+"'.";
            console.info(sConsole);
            return sConsole;
        }); 
    }

    async verifyAttributeValueInTableCell(sDemoName, sColName, sAttribute, sExpVal)
    {
        let sColName1;
        switch(sColName)
        {
            case "Current Execution Risk":
                sColName1 = "risk";
                break;
            case "Demo Completion":
                sColName1 = "scheduledCompletionDate";
                break;
            case "Performance (Spec vs. Actual)":
                sColName1 = "performance_Spec_Vs_Actual";
                break;
            case "CoO Gap (spec vs. Actual)":
                sColName1 = "coO_GAP_Spec_Vs_Actual";
                break;
            case "Onsite Chamber Readiness":
                sColName1 = "onSite_Chamber_Ready";
                break;
            case "Additional CIP HW Requirement":
                sColName1 = "additional_CIP_HW_Required";
                break;
            case "Risk/Gap Description":
                sColName1 = "risk_Gap_Description";
                break;
            case "Risk/Gap Closure Plan":
                sColName1 = "risk_Gap_Closure_Plan";
                break;
            case "TAMBA Name":
                sColName1 = "tambaID";
                break;
            case "Tech Prob":
                sColName1 = "technicalProbablityOfWin";
                break;
            case "Customer title":
                sColName1 = "title";
                break;
            case "Customer Phone":
                sColName1 = "phone";
                break;
            case "Customer e-mail":
                sColName1 = "email";
                break;
            case "Customer Mailing address":
                sColName1 = "mailingAddress";
                break;
            default:
                sColName1 = sColName.replace("/", "");
                sColName1 = sColName1.toLowerCase();
        //sColName = sColName.replace(" ", "");
                sColName1 = objWrapper.convertToCamelCase(sColName1);
        }
        console.log(sColName1);
        let objDemoName = by.xpath("//div[@col-id='demoName' and contains(text(), '"+sDemoName+"')]/parent::div");
        let iRow = await objWrapper.getElementAttribute(objDemoName, 'row-index', objWrapper.iDefaultTimeout).then(function(iRNo){
            return iRNo;
        });
        let objTableCell = by.xpath("//div[@row-index='"+iRow+"']//div[@col-id='"+sColName1+"']/span/span")
        // await objWrapper.isElementPresent(objTableCell, objWrapper.iDefaultTimeout).then(async function(bRes){
        //     if(!bRes)
        //     {
                
        //         objTableCell = by.xpath("//div[@row-index='"+iRow+"']//div[@col-id='"+sColName+"']");
        //     }
        // });
        return await objWrapper.getElementAttribute(objTableCell, sAttribute, objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sExpVal)
            {
                console.log("Verified value '"+sExpVal+"' in table column '"+sColName+"' against Demo name '"+sDemoName+"'");
                return true;
            }
            else
            {
                console.error("Fail to verify value '"+sExpVal+"' in table column '"+sColName+"' against demo name '"+sDemoName+"'.");
                return false;
            }
        }); 
    }

    async clickOnDDInTableCell(sColName)
    {
        let cmbDD = by.css("div[class*='ag-picker-field-wrapper']");
        return await objWrapper.clickOnElement(cmbDD, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
			 
                sConsole = "Pass : Clicked in column '"+sColName+"' drop down.";
							
			 
            else
			 
                sConsole = "Fail : Fail to click in column '"+sColName+"' drop down.";
            console.info(sConsole);
            return sConsole
			 
        });
    }
    async selectOptionFromDDList(sColName, sOption)
    {
        let cmbDDOption = by.xpath("//div[contains(@class, 'ag-select-list')]//span[text()='"+sOption+"']");
        return await objWrapper.clickOnElement(cmbDDOption, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
			 
                sConsole = "Pass : Selected DD option '"+sOption+"' in column '"+sColName+"'.";
							
			 
            else
			 
                sConsole = "Fail : Fail to select DD option '"+sOption+"' in column '"+sColName+"'.";
            console.info(sConsole);
            return sConsole;
			 
        });
    }

    async selectOptionFromDDInTableColumn(sColName, sOption)
    {
        expect(await this.clickOnDDInTableCell(sColName)).toContain("Pass");
        //return await this.selectAjaxDDListOption(sOption);
        return await this.selectOptionFromDDList(sColName, sOption);
    }								
    async clickCalendarOnEditPopUp()
    {
        let btnCalendar = by.css("button.input-group-text.link");
        return await objWrapper.clickOnElement(btnCalendar, objWrapper.iDefaultTimeout).then(async function(bRes){
            if(bRes)
            {
                console.info("Clicked on calendar icon on Edit Pop up.");
                await objWrapper.sendKeysInActiveElmnt("Enter");
                return true;
            }
            else
            {
                console.error("Fail to click on calendar icon on Edit pop up.");
                return false;
            }
        });
    }

    async clickTambaSearchBtnOnEditPopUp()
    {
        let btnSearch = by.xpath("//label[contains(text(), 'TAMBA Name')]/following-sibling::div/button");
        return await objWrapper.clickOnElement(btnSearch, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
            {
                console.info("Clicked on TAMBA Search button.");
                return true;
            }
            else
            {
                console.error("Fail to click on TAMBA search button.");
                return false;
            }
        });
    }

   async clickBtnOnPopUp(sPopUpName, sButtonName)
    {
        let btnOnEditPopUp = by.xpath("//h5[contains(text(),'"+sPopUpName+"')]/parent::div[@class='modal-header']/following-sibling::fieldset/div[@class='modal-footer']//button[contains(text(),'"+sButtonName+"')]|//h4[contains(text(),'"+sPopUpName+"')]/parent::div[@class='modal-header']/following-sibling::div[@class='modal-footer']//button[contains(text(),'"+sButtonName+"')]");    
        return await objWrapper.clickOnElement(btnOnEditPopUp, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
            {
                console.info("Clicked on button '"+sButtonName+"' on Edit pop up '"+sPopUpName+"'.");
                return true;
            }
            else
            {
                console.error("Fail to click on button '"+sButtonName+"' on Edit pop up '"+sPopUpName+"'.");
                return false;
            }
        });
    }
    async clickOnDDOnRATDtlsPopUp(sDDName)
    {
        let cmbHtH = by.xpath("//label[contains(text(), '"+sDDName+"')]/following-sibling::select");
        return await objWrapper.clickOnElement(cmbHtH, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
            {
                console.info("Clicked on DD '"+sDDName+"' on RAT Detail pop up.");
                return true;
            }
            else
            {
                console.error("Fail to click on DD '"+sDDName+"' on RAT details pop up.");
                return false;
            }
        })
    }

    async selectDDOptionOnRATDtlsPopUp(sDDName, sDDOption)
    {
        expect(await this.clickOnDDOnRATDtlsPopUp(sDDName)).toBeTruthy();
        let objOption = by.xpath("//label[contains(text(), '"+sDDName+"')]/following-sibling::select/option[contains(text(),'"+sDDOption+"')]");
        return await objWrapper.clickOnElement(objOption, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
            {
                console.info("Select option '"+sDDOption+"' from DD '"+sDDName+"' on RAT Detail pop up.");
                return true;
            }
            else
            {
                console.error("Fail to select option '"+sDDOption+"' from DD '"+sDDName+"' on RAT Detail pop up.");
                return false;
            }
        })
    }

    async verifyDemoNumberHyperlinkPresent(sDemoName)
    {
        let objDemoName = by.xpath("//div[@col-id='demoName' and contains(text(), '"+sDemoName+"')]/parent::div");
        let iRow = await objWrapper.getElementAttribute(objDemoName, 'row-index', objWrapper.iDefaultTimeout).then(function(iRNo){
            return iRNo;
        });
        let lnkDemoNo = by.xpath("//div[@row-index='0']//div[@col-id='demoNumber']//a");
        return await objWrapper.isElementPresent(lnkDemoNo, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
            {
                console.info("Demo number hyperlink for demo name '"+sDemoName+"' is present.");
                return true;
            }
            else
            {
                console.error("Fail to find Demo number hyperlink for demo name '"+sDemoName+"'.");
                return false;
            }
        });
    }

    async selectAjaxDDListOption(sOption)
    {
        let lstDD = by.css("div[class*='ag-popup-child']");
        let bResult =  await objWrapper.isElementPresent(lstDD, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
            {
                console.info("Drop down list displayed successfully.");
                return true;
            }
            else
            {
                console.error("Fail to find drop down list.");
                return false;
            }
        });
        if(bResult)
        {
            let lstDDOption = by.xpath("//div[contains(@class,'ag-popup-child')]//span[text()='"+sOption+"']/parent::div");
            return await objWrapper.clickOnElement(lstDDOption, objWrapper.iDefaultTimeout).then(function(bRes){
                if(bRes)
                {
                    console.info("Clicked on DD list option '"+sOption+"'.");
                    return true;
                }
                else
                {
                    console.error("Fail to click on DD list option '"+sOption+"'.");
                    return false;
                }
            });
        }
        else
        {
            return false;
        }
    }
//Nidhi-04/03/2021- Verify the Demo Status In the Grid(By Using Icon) on all the pages
    async verifyDemoStatusInGrid(sDemoName, sDemoApprovalStatus)
    {
        let objDemoStatus = by.xpath("//div[@col-id='demoName'][contains(text(),'"+sDemoName+"')]/parent::div//span[@title='"+sDemoApprovalStatus+"']");
        return await objWrapper.isElementPresent(objDemoStatus, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
               sConsole = "Pass : Demo request with demo name'"+sDemoName+"' is having demo status as '"+sDemoApprovalStatus+"'.";   
            else
              sConsole = "Verified that demo name'"+sDemoName+"' is not having demo approval status as '"+sDemoApprovalStatus+"'.";  
              console.info(sConsole);
              return sConsole; 
        });
    }
//Click on the Status dropdown on all the pages
    async clickOnStatusDD()
    {
        let cmbStatus = by.css("select[name='status']");
        return await objWrapper.clickOnElement(cmbStatus, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
            sConsole = "Pass : Clicked on Status drop down";   
        else
           sConsole =  "Fail to click on Status drop down.";  
           console.info(sConsole);
           return sConsole; 
        });
    }
//Select the status on from status dropwdown on all the pages
    async selectStatusOption(sOption)
    {
        let objOption = by.xpath("//select[@name='status']/option[contains(text(), '"+sOption+"')]");
        return await objWrapper.clickOnElement(objOption, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
            sConsole = "Pass : Selected Status option as '"+sOption+"'.";   
        else
           sConsole =  "Fail to select Status option as '"+sOption+"'.";  
           console.info(sConsole);
           return sConsole; 
        });
    }
    async selectStatusFromStatusDD(sStatus)
    {
        expect(await this.clickOnStatusDD()).toContain("Pass")
        return await this.selectStatusOption(sStatus);
    } 
//Nidhi-04/02/2021 will give the list of all the options in the status dropwdon on all the pages.
    async getStatusOptions()								 
    {
        let objOptionList = by.css("select[name='status']>option");
        return await objWrapper.getElementsText(objOptionList, 'List of Options Conatins by Status DD');
    };
//Nidhi-04/02/2021 Will give the list of the searched list on the page according to the passed searched in the search field for all the pages.
    async getSearchResults(sDemoName)								 
    {
    
    try{        
        let objSearchList = by.xpath("//div[@col-id='demoName'][contains(text(),'"+sDemoName+"')]");
        return await objWrapper.getElementsText(objSearchList, 'List of Options Conatins by Status DD').then(function(sTextList){
            if(sTextList.includes(sDemoName))
                sConsole = "Pass : Searched Results contains Status option as '"+sDemoName+"'.";   
            else
               sConsole =  "Searched Results does not contains '"+sDemoName+"'.";  
               console.info(sConsole);
               return sConsole; 
            });
        }
        catch(exception)
        { 
            console.log("Does not contain any searched Results");
        }
    };
    async clearSearchText()
    {    
        let objClearSearch = by.css("input[placeholder='Search here']");
        return await objWrapper.clearTextUsingKeys(objClearSearch, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
                sConsole = "Pass : Cleared the searched Data";   
        else
               sConsole =  "Fail to clear the searched data";  
               console.info(sConsole);
               return sConsole; 
        });
       
    }
//Nidhi-05/03/2021 Click on the Customized view button on all the pages.
    async clickOnCustomizedBtn()
    {
        let btnCustView = by.css("button[title='Customize View']");
        return await objWrapper.clickOnElement(btnCustView, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
               sConsole = "Pass : Clicked on the customized view button";   
            else
              sConsole = "Fail to click on the customized view button";  
              console.info(sConsole);
              return sConsole; 
        });
    }
    // async clickTabOnManagedViewPopUp(sTabName)
    // {
    //     let objTab = by.xpath("//ul[@class='nav-tabs nav']/li/a[text()='"+sTabName+"']");
    //     return await objWrapper.clickOnElement(objTab, objWrapper.iDefaultTimeout).then(function(bRes){
    //         if(bRes)
    //         {
    //             console.info("Clicked on tab '"+sTabName+"' on Managed View Pop up.");
    //             return true;
    //         }
    //         else
    //         {
    //             console.error("Fail to click on tab '"+sTabName+"' on managed view pop up.");
    //             return false;
    //         }
    //     });
    //}
//Nidhi-05/03/2021 check the active tab on customized pop up for all the pages.
    async VerifyActiveTabOnCustomizedView(sTabName)
    {
        let objTab = by.xpath("//ul[@class='nav-tabs nav']/li/a[text()='"+sTabName+"'][contains(@class,'active')]");
        return await objWrapper.isElementPresentWithoutWait(objTab).then(function(bRes){
        if(bRes)
            sConsole = "Pass : "+sTabName+" is an Active Tab";   
        else
            sConsole = ""+sTabName+" is not an Active Tab";  
            console.info(sConsole);
            return sConsole;
        });
    }
//Nidhi-05/03/2021 check the btn status on customized view pop up on all the pages.
    async verifyBtnIsDisabledOnCustomizedView(sbtnName)
    {
        let objBtn = by.xpath("//button[contains(text(),'"+sbtnName+"')][@disabled]");
        return await objWrapper.isElementPresent(objBtn,objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
            sConsole = "Pass : button "+sbtnName+" is disabled";   
        else
            sConsole = "button "+sbtnName+" is enabled ";  
            console.info(sConsole);
            return sConsole;
        });
    }
//Nidhi-05/03/2021 set the view name on the customized pop up on all the pages.
    async setViewNameOnCustomizedView(sViewName)
    {
        let txtViewName = by.css("input[placeholder*='View Name']");
        await objWrapper.setInputValue(txtViewName, sViewName, objWrapper.iDefaultTimeout);
        return await objWrapper.getElementAttribute(txtViewName, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
        if(sText==sViewName)
            sConsole = "Pass : Set view name as '"+sViewName+"' on Customized View pop up.";   
        else
            sConsole = "Fail to set view name as '"+sViewName+"' on Customized View pop up. ";  
            console.info(sConsole);
            return sConsole;
        });
    }
//Nidhi-05/03/2021 will give the list of all the views on all the pages.
    async getAllViews()								 
    {
        let objViewList = by.css("select[name='view']>option");
        return await objWrapper.getElementsText(objViewList, 'List of Views Conatins by View DD');
    };
////Nidhi-05/03/2021 Verify wheather view name is unique or not.
async verifyUniqueViewName(sViewName)
{
    return await this.getAllViews().then(function(sText){
        if(!sText.includes(sViewName))
            sConsole = "Pass : "+sViewName+" is unique view name";   
        else
            sConsole = ""+sViewName+"' is not unique view name";  
            console.info(sConsole);
            return sConsole;
    });
}
//Nidh-05/03/2021 select from available column list on customized pop up on all the pages.
async selectFromSelectedAvailableColList(sListName, sCol) 
    {
        let objAvailableCols = by.xpath("//div[text()='"+sListName+"']/following-sibling::ul[contains(@class,'ui-picklist-list')]//div/div");
        return await element.all(objAvailableCols).then(async function(listItems){
            let iCount;
            for(iCount = 0; iCount < listItems.length; iCount++)
            {
                let bClick = await listItems[iCount].getText().then(async function(sText){
                    if(sText == sCol)
                    {
                        await listItems[iCount].click();
                        console.info("Selected column '"+sCol+"' in '"+sListName+"' list.");
                        return true;
                    }
                   
                });
                if(bClick)
                    break;
            }
            if(iCount == listItems.length)
                sConsole = "Fail to select column '"+sCol+"' in '"+sListName+"' list.";   
            else
                sConsole = "Pass : col '"+sCol+"' is selected sucessfully.";
                console.info(sConsole);
                return sConsole;
        });
    }
//Nidhi-05/03/2021 - Add column in selected column list on customized pop up on all the pages.
async addColInSelectedColumnList()
{
    let btnAddToSelectedCol = by.css("div.ui-picklist-buttons button[icon='pi pi-angle-right']");
    return await objWrapper.clickOnElement(btnAddToSelectedCol, objWrapper.iDefaultTimeout).then(function(bRes){
    if(bRes)
        sConsole = "Pass : Clicked on button to add column in selected column list.";   
    else
        sConsole = "Fail to click on button to add column in selected column list.";  
        console.info(sConsole);
        return sConsole;
    });
       
}
//Nidhi-05/03/2021 click on the btn to save the details on the customized view pop up on all the pages.
async clickBtnOnCustomizedView(sbtnName)
{
    let objBtn = by.xpath("//button[contains(text(),'"+sbtnName+"')][not(@disabled)]");
    return await objWrapper.clickOnElement(objBtn,objWrapper.iDefaultTimeout).then(function(bRes){
    if(bRes)
        sConsole = "Pass : Clicked on "+sbtnName+" button";   
    else
        sConsole = "Fail to click on "+sbtnName+"  button ";  
        console.info(sConsole);
        return sConsole;
    });
}
//Nidhi-05/03/2021 - Verify view selected in view DD on all the pages.
async verifyViewSelectedOnPage(sViewName)
{
    let objSelectedView = by.css("select[name='view']");
    return await objWrapper.getElementAttribute(objSelectedView,'ng-reflect-model', objWrapper.iDefaultTimeout).then(function(sText){
    if(sText==sViewName)
        sConsole = "Pass : View '"+sViewName+"' is selected on page.";   
    else
        sConsole = "Default view public is set on the page.";  
        console.info(sConsole);
        return sConsole;
    });
}
//Nidhi-05/03/2021 will give the list of selected col on the customized pop up on all the pages.
async getSelectedColList()
    {
        let lstSelectedCol = by.css("ul[class*='ui-picklist-target']>li[class='ui-picklist-item']");
        return await objWrapper.getElementsText(lstSelectedCol, "Selected column list on manage view pop up is : ").then(function(sText){
            return sText+('~~');
        });
    }
//Nidhi-05/03/2021 will give the list of new view col header's
async getUnpingedColHeaders()							 
    {
        let objColHdrList = by.xpath("//div[@ref='eHeaderViewport']//span[contains(@class,'ag-header-cell-text')]");
        return await objWrapper.getElementsText(objColHdrList, 'List of all the col header is');
    };
 //Nidhi-08/03/2021 - Click on update view DD on Customized pop up for all the pages.
 async clickOnUpdateViewDDCustomizedViewPopUP(sViewScreen)
 {
    //sViewScreen = sViewScreen.objWrapper.convertToCamelCase(sViewScreen);
    let cmbUpdateView = by.css("[id='"+sViewScreen+"']");
    return await objWrapper.clickOnElement(cmbUpdateView, objWrapper.iDefaultTimeout).then(function(bRes){
    if(bRes)
        sConsole = "Pass : Clicked on update view DD on manage view pop up.";   
    else
        sConsole = "Fail to click on update view DD on manage view pop up.";  
        console.info(sConsole);
        return sConsole;
     });
 }
//Nidhi-08/03/2021 select the view from the view DD on Customized view pop on all the pages.
async selectViewToUpdateCustomizedViewPopUP(sViewName,sViewScreen)
    { 
        let sViewScr = objWrapper.convertToCamelCase(sViewScreen);
        expect(await this.clickOnUpdateViewDDCustomizedViewPopUP(sViewScr)).toContain('Pass')
        let objView = by.xpath("//select[@id='"+sViewScr+"']//option[contains(text(),'"+sViewName+"')]");
        return await objWrapper.clickOnElement(objView, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
            sConsole = "Pass : Selected view '"+sViewName+"' in update view DD on customized view pop up.";   
        else
            sConsole = "Fail to select view '"+sViewName+"' in update view DD on customized view pop up.";  
            console.info(sConsole);
            return sConsole;
         });
    }
 //Richa_28012021 - Click on tab on customized view pop up on all the pages.
 async clickTabOnCustomizedViewPopUp(sTabName)
 {
    let objTab = by.xpath("//ul[@class='nav-tabs nav']/li/a[text()='"+sTabName+"']");
    return await objWrapper.clickOnElement(objTab, objWrapper.iDefaultTimeout).then(function(bRes){
    if(bRes)
        sConsole = "Pass : Clicked on tab '"+sTabName+"' on Customized View Pop up.";   
    else
        sConsole = "Fail to click on tab '"+sTabName+"' on Customized view pop up.";  
        console.info(sConsole);
        return sConsole;

     });
 }
  //Nidhi-08/03/2021 verify column available in selected or available column list on customized pop up on all the pages.
  async verifyColPresentInSelectedAvailableColList(sListName, sCol)
  {
    let objSelectedAvailableCols = by.xpath("//div[text()='"+sListName+"']/following-sibling::ul[contains(@class,'ui-picklist-list')]//div/div[text()='"+sCol+"']");
    return await objWrapper.isElementPresent(objSelectedAvailableCols, objWrapper.iDefaultTimeout).then(function(bRes){
    if(bRes)
        sConsole = "Pass : Column '"+sCol+"' present in '"+sListName+"' list.";   
    else
       sConsole = "Fail to find Column '"+sCol+"' present in '"+sListName+"' list.";  
       console.info(sConsole);
       return sConsole;
      });
  }
   //Nidhi-08/03/2021 Remove column from selected column list on customized pop up on all the pages.
   async removeColFromSelectedColumnList()
   {
    let btnRemoveFromSelectedCol = by.css("div.ui-picklist-buttons button[icon='pi pi-angle-left']");
    return await objWrapper.clickOnElement(btnRemoveFromSelectedCol, objWrapper.iDefaultTimeout).then(function(bRes){
    if(bRes)
        sConsole = "Pass : Clicked on button to remove column from selected column list.";   
    else
       sConsole = "Fail to click on button to remove column from selected column list.";  
       console.info(sConsole);
       return sConsole;
       });
   }
//Nidhi-08-03-2021 verify that logged in user is having access to the BU present on the grid.
   async verifyBuInGridAsPerAccess(sDemoName,sColName, buList)
   {
    return await objCommonPage.getTableCellValue(sColName,sDemoName).then(function(sText){
    if(buList.includes(sText))
        sConsole ="Pass : Logged in User is having access to "+sText+" BU";   
    else
       sConsole = "Pass : Logged in User is not having access to the BU.";  
       console.info(sConsole);
       return sConsole;
    });
}
//Nidhi-12-03-2021 verify that Demo Number display as hyperlink only for ACL Approved Status.
   async verifyVisibleHyperLinkForACLStatus(sColName,sColName1,sDemoName)
   {
    let sStatus;
    await objCommonPage.goToColumn(sColName1)
    await objCommonPage.getTableCellValue(sColName1,sDemoName).then(function(sText){sStatus = sText;});
    if(sStatus.includes("ACL")){
    await objCommonPage.verifyHyperLink(sColName,sDemoName);
        sConsole ="Pass : Demo Number against Demo Name "+sDemoName+" is having "+sStatus+"."; 
    }  
    else{
       await objCommonPage.verifyHyperLink(sColName,sDemoName);
       sConsole = "Demo Number against Demo Name "+sDemoName+" is having "+sStatus+".";  
    }
       console.info(sConsole);
       return sConsole;
   }
//Nidhi-12/03/2021- Verify the Demo Status icon and click on it
async clickInTheStatusIconField(sDemoName, sDemoApprovalStatus)
{
    let sText = await this.verifyDemoStatusInGrid(sDemoName, sDemoApprovalStatus);
    let objDemoStatusIcon = by.xpath("//div[@col-id='demoName'][contains(text(),'"+sDemoName+"')]/parent::div//span[@title='"+sDemoApprovalStatus+"']");
    if (sText.includes("Pass")){
    await objWrapper.clickOnElement(objDemoStatusIcon, objWrapper.iDefaultTimeout).then(function(){
    sConsole = "Pass : Clicked on the "+sDemoApprovalStatus+" for Demo Name "+sDemoName+".";    
    });
    }
    else{
        sConsole = "Not Clicked on the "+sDemoApprovalStatus+" for Demo Name "+sDemoName+".";   
    }
    console.info(sConsole);
    return sConsole;  
    }
//Nidhi-12/03/2021- Click on the Field/Label on the POP Up as per the passed Label Name
async clickFieldOnThePopUp(sFieldName)
{

    let objLabel = by.xpath("//label[contains(text(),'"+sFieldName+"')]//parent::div//select|//label[contains(text(),'"+sFieldName+"')]//parent::div//ng-select|//label[contains(text(),'"+sFieldName+"')]//parent::div//div[@class='input-group']");
    return await objWrapper.clickOnElement(objLabel, objWrapper.iDefaultTimeout).then(function(bRes){
    if(bRes)
    sConsole = "Pass : Clicked on the "+sFieldName+".";    
    else
    sConsole = "Not Clicked on the "+sFieldName+".";   
    console.info(sConsole);
    return sConsole;  
    });
}
//Nidhi-12/03/2021- get the value of from the paricular passed field on the pop up
async getFieldValueOnPopUp(sLabelName)
{
    let txtLabel = by.xpath("//label[text()='"+sLabelName+"']//parent::div//select|//label[text()='"+sLabelName+"']//parent::div//input");
    return await objWrapper.getElementAttribute(txtLabel, 'ng-reflect-model', objWrapper.iDefaultTimeout).then(function(sText){
    return sText;
    }); 
  
}
////Nidhi-12/03/2021- will give the results as per the label id passed on the approvel view pop up
getLabelId(sColName)																			   
{
    let sColId;
    console.log(sColName)
    switch(sColName)
    {	
        case "Demo Approval":
            sColId = "demoStatus";
            break;
        case "Demo Owner":
            sColId = "demoOwner";
            break;
        case "Demo Number":
            sColId = "demoNumber";
            break;
        case "Demo Name":
            sColId = "demoName";
            break;
        case "Wafer Status":
            sColId = "waferLocation";
            break;
        case "Priority":
            sColId = "priority";
            break;
        case "Co-Owner":
            sColId = "coOwner";
            break;
        case "CAT/RAT Manager":
            sColId = "catrat";
            break;
        case "IO/Cost Center":
            sColId = "costCenter";
            break;
        case "Execution Risk":
            sColId = "risk";
            break;
        case "Schedule Completion Date Milestone Status":
            sColId = "milestoneList";
            break;
		case "Customer Engagement":
            sColId = "businessCase1";
            break;
        default :
            sColId = objWrapper.convertToCamelCase(sColName);
    }
    return sColId;
}  
//Nidhi-12/03/2021- select option from the pop up field/Label
async selectOptionsFromDDOnPopUp(sLabelName, sOption)
{
    let objCmbOption = by.xpath("//label[contains(text(),'"+sLabelName+"')]//parent::div//option[contains(text(),'"+sOption+"')]|//label[contains(text(),'"+sLabelName+"')]//parent::div//ng-select//div[@role='option']//span[text()='"+sOption+"']")
    return await objWrapper.clickOnElement(objCmbOption, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
            sConsole = "Pass : Selected option '"+sOption+"' from '"+sLabelName+"' DD.";
        else
            sConsole = "Not able to select option '"+sOption+"' from '"+sLabelName+"' DD.";
        console.info(sConsole);
        return sConsole;
    });
} 
//Nidhi-12/03/2021- set the input value for passed label name on pop up.
async setInputOnPopUp(sLabelName,sTextName)
{
    //let sLabelId = this.getLabelId(sLabelName);
    let txtLabel = by.xpath("//label[contains(text(),'"+sLabelName+"')]//parent::div//textarea|//label[contains(text(),'"+sLabelName+"')]//parent::div//input[1]")
    await objWrapper.setInputValue(txtLabel,sTextName, objWrapper.iDefaultTimeout);
    return await objWrapper.getElementAttribute(txtLabel, 'ng-reflect-model', objWrapper.iDefaultTimeout).then(function(sText){
        if(sText == sTextName)
            sConsole = "Pass : Set "+sLabelName+" as '"+sTextName+"'.";
        else
            sConsole = "Not able to set "+sLabelName+" as '"+sTextName+"'.";
        console.info(sConsole);
        return sConsole;
    });
}
    //Nidhi-12/03/2021- verify approved by col is having correct approved by username or not.
    async verifyApprovedByCol(sColName,sDemoName,sDemoOwnerName)
        {   let sApproveBy;
            await objCommonPage.getTableCellValue(sColName,sDemoName).then(function(sText){sApproveBy = sText;});
            if(sApproveBy.includes(sDemoOwnerName))
                sConsole = "Pass : Column "+sColName+" is The Correct Approved by User Name ";
            else
                sConsole = "Column "+sColName+" is having Incorrect Approved by User Name";
            console.info(sConsole);
            return sConsole;
          
     }
 //Nidhi-12/03/2021- will click on the save btn on approval view pop up  
     async clickOnSave()
    {  
        let btnSearch = by.xpath("//div[@class='modal-footer']//button[contains(text(),'Save')][not(@disabled)]");
        return await objWrapper.javascriptClickOnElement(btnSearch, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)	 
            sConsole = "Pass : Clicked on Save button."; 					 
        else 
            sConsole = "Not able to click on Save button."; 
            console.info(sConsole);
            return sConsole;
			 
        })
    }
    //Nidhi-12/03/2021- will close the pop up by clicking on the close icon
    async clickOnCloseIcon()
    {
        let btnSearch = by.xpath("//h5[@id='exampleModalLabel']//parent::div//button|//app-view-demo-shared[not(@title)]//h4[@class='modal-title']//parent::div/button|//app-view-attachment-shared[not(@title)]//button[@class='close']");
        return await objWrapper.clickOnElement(btnSearch, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)	 
            sConsole = "Pass : Clicked on close button."; 					 
        else 
            sConsole = "Not able to click on close button."; 
            console.info(sConsole);
            return sConsole;
             
        })
    }
//Nidhi-15/03/2021- verify that passed field/Label on the pop up is hidden/disabled or not. 
async verifyFieldIsDisabledOnPopUp(sLabelName)
{
    await this.verifyFieldIsMandatory(sLabelName);
    let sLabelId = this.getLabelId(sLabelName);
    let objField = by.xpath("//input[@name='"+sLabelId+"'][@readonly]|//select[@name='"+sLabelId+"'][@disabled]|//div[@ng-reflect-name='"+sLabelId+"']//input[@disabled]|//input[@name='"+sLabelId+"'][@disabled]");
    return await objWrapper.isElementPresent(objField,objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
            sConsole = "Pass : Field "+sLabelName+" is disabled.";
        else
            sConsole = "Field "+sLabelName+" is not disabled.";
        console.info(sConsole);
        return sConsole;
    });
}
//Nidhi-15/03/2021- verify that passed field is mandate or not on the pop up.
async verifyFieldIsMandatory(sLabelName)
{
     let objField = by.xpath("//label[contains(text(),'"+sLabelName+"')]/following-sibling::span[contains(text(),'*')] | //label[contains(text(),'"+sLabelName+"')]/following-sibling::div//span/*[contains(@class,'asterisk ')]");
    return await objWrapper.isElementPresentWithoutWait(objField).then(function(bRes){
        if(bRes)
            sConsole = "Pass : Field "+sLabelName+" is Mandate.";
        else
            sConsole = "Field "+sLabelName+" is not Mandate.";
        console.info(sConsole);
        return sConsole;
    });
}
//Nidhi-15/03/2021- verify that passed field on the Pop Up present or not. 
async verifyFieldIsPresentPopUp(sLabelName)
{
    let objField = by.xpath("//label[contains(text(),'"+sLabelName+"')]");
    return await objWrapper.isElementPresent(objField, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
            sConsole = "Pass : Field "+sLabelName+" is Present on the Pop Up.";
        else
            sConsole = "Field "+sLabelName+" is not Present on the Pop Up.";
        console.info(sConsole);
        return sConsole;
    });
}
//Nidhi-15/03/2021- verify save btn is disabled on pop up or not.
async verifySaveBtnIsDisabledOnPopUp()
    {
        let btnSave = by.xpath("//div[@class='modal-content']//div[@class='modal-footer']//button[contains(text(),'Save')][@disabled]");
        return await objWrapper.isElementPresentWithoutWait(btnSave).then(function(bRes){    
            if(bRes)
                sConsole = "Pass : Save Btn is Disabled please enter mandate details";
            else
                sConsole = "Save Button is not disabled.";
            console.info(sConsole);
            return sConsole;
        });
    }
//Nidhi-16/03/2021- Verify Justification comment on the approval pop up is empty or not.
async verifyCommentIsEmptyOnApprovalPopUp()
    {
        let objComment = by.css("[placeholder*='Justification']");
        return await objWrapper.getElementAttribute(objComment,'ng-reflect-model',objWrapper.iDefaultTimeout).then(function(sText){    
            if(sText=='')
                sConsole = "Pass : Justification comment section is Empty";
            else
                sConsole = "Justification comment section is having value as "+sText+".";
            console.info(sConsole);
            return sConsole;
        });
    }
//Nidhi-16/03/2021 will give the the list of the values which dropdown on the POP Up has(TAMBA POP Up)
async getOptionsOnPopUp(sFieldName)								 
{
    let objOptionList = by.xpath("//label[contains(text(),'"+sFieldName+"')]/parent::div/select/option");
    return await objWrapper.getElementsText(objOptionList, 'List of Options Conatins by "'+sFieldName+'"DD is');
};
//Nidhi-17-03-2021 Verify Almanac Link display only for closed and ACL-Approved Status Demo's
async verifyAlmanacLinkDisplay(sColName,sColName1,sDemoName)
{
 let sStatus,iRowNo;
 let sColId = objCommonPage.getColId(sColName);
 await objCommonPage.goToColumn(sColName1)
 await objCommonPage.getTableCellValue(sColName1,sDemoName).then(function(sText){sStatus = sText;});
 await objCommonPage.getRowNoForApplicationName(sDemoName).then(function(iRow){iRowNo = iRow;});
 let objHyperLink = by.xpath("//div[@row-index='"+iRowNo+"']//div[@col-id='"+sColId+"']//a[contains(text(),'Almanac')]");
 return await objWrapper.isElementPresent(objHyperLink, objWrapper.iDefaultTimeout).then(function(bRes){
    if(bRes){
        if(sStatus.includes("ACL")||sStatus.includes("Closed")){
        sConsole = "Pass : Demo Number against Demo Name "+sDemoName+" is having "+sStatus+" and Almanac link"; 
        } 
       else{
        sConsole ="Should not display Almanac link for "+sStatus+"."; 
        }     
    }  
    else{
        sConsole = "Verify Almanac link is not displayed";  
    }
        console.info(sConsole);
        return sConsole;
        });
}
//Nidhi-17-03-2021 Click on Almanac Link in the demo number table cell
async clickOnAlmanacLink(sDemoName)
    {
        let iRowNo;
        await objCommonPage.getRowNoForApplicationName(sDemoName).then(function(iRow){iRowNo = iRow;});
        let objTblLink = by.xpath("//div[@row-index='"+iRowNo+"']//div[@col-id='demoNumber']//a[contains(text(),'Almanac')]");
        return await objWrapper.javascriptClickOnElement(objTblLink, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
            sConsole = "Pass : Clicked On Almanac link against "+sDemoName+"."; 
        else
            sConsole = "Not able to click on the link"; 
            console.info(sConsole);
            return sConsole;
            
        });
}
//Nidhi-17-03-2021 Click on Demo Number Hyper Link in the demo number table cell
async clickOnHyperLinkInDemoNumber(sDemoName)
    {
        let iRowNo;
        await objCommonPage.getRowNoForApplicationName(sDemoName).then(function(iRow){iRowNo = iRow;});
        let objTblLink = by.xpath("//div[@row-index='"+iRowNo+"']//div[@col-id='demoNumber']//a[1]");
        return await objWrapper.clickOnElement(objTblLink, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
            sConsole = "Pass : Clicked On HyperLink link against "+sDemoName+"."; 
        else
            sConsole = "Not able to click on the link"; 
            console.info(sConsole);
            return sConsole;
            
        });
}
//Nidhi-17-03-2021 Click on tab step on the demo details page
async clickOnTabStep(sStepNm)
    {
        let objTabStep = by.xpath("//a[contains(text(),'"+sStepNm+"')]");
        return await objWrapper.javascriptClickOnElement(objTabStep, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
            sConsole = "Pass : Clicked On Step link "+sStepNm+"."; 
        else
            sConsole = "Not able to click on the link"; 
            console.info(sConsole);
            return sConsole;
            
        });
}
// Nidhi- 19/03/2021 click and select value from the dropdown on the pop up.
async selectValueFromDDOnPopUp(sLabelName, sOption)
{
    expect(await this.clickFieldOnThePopUp(sLabelName)).toContain("Pass");
    return await this.selectOptionsFromDDOnPopUp(sLabelName,sOption);
} 
//Nidhi-25/03/2021 give the row index specific to the passed demo number
async getRowNoForDemoNumber(sDemoNum)
    {
        let objTableCell = by.xpath("//div[@role='gridcell' and @col-id='demoNumber']//a[contains(text(),'"+sDemoNum+"')]//ancestor::div[@role='row' and contains(@class,'ag-row')]");
        return await objWrapper.getElementAttribute(objTableCell, "row-index", objWrapper.iDefaultTimeout); 
    }
//Nidhi-25/03/2021 click in the Execution table cell having specific demo Number
async clickInTheTableCellAgainstDemoNumber(sColName,sDemoNum)
    {
        let  objTableCell, iRowNo, sColId;
        await this.getRowNoForDemoNumber(sDemoNum).then(function(iRow){iRowNo = iRow;});
        sColId = await objCommonPage.getColId(sColName);
        if(sColName == 'TAMBA Name')
        {
            objTableCell = by.xpath("//div[@row-index='"+iRowNo+"']//div[@role='gridcell' and @col-id='"+sColId+"']//span");
            
        }
        else
        {
            objTableCell = by.xpath("//div[@row-index='"+iRowNo+"']//div[@role='gridcell' and @col-id='"+sColId+"']");
        }
        return await objWrapper.clickOnElementWithOutScroll(objTableCell, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
        sConsole = "Pass : Clicked in the col'"+sColName+"'cell contains Demo Name '"+sDemoNum+"'.";  
        else
        sConsole = "Not able to click in the col '"+sColName+"'cell contains Demo Name'"+sDemoNum+"'."; 
            console.info(sConsole);
            return sConsole;
        });
}

async setTextValInInputFieldOfTable(sVal)
    {
        let txtInput = by.xpath("//input[@class='ng-pristine ng-valid ng-touched']");
        await objWrapper.setAttributeUsingJavaScript(txtInput, objWrapper.iDefaultTimeout, "ng-reflect-model", sVal);
        return await objWrapper.getElementAttribute(txtInput, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sVal)
                sConsole = "Pass : Set CAT/RAT project id as '"+txtInput+"'.";
            else
                sConsole = "Fail : Fail to set CAT/RAT project id as '"+txtInput+"'.";
            console.info(sConsole);
            return sConsole;
        });
       
    }
	
	    //Richa_31032021 - verify attachments pop up displayed
    async verifyAttachmentsPopUpDisplayed()
    {
        let objAttachments = by.xpath("//div[@class='modal-content']//div[@class='modal-header']/h5[contains(text(),'Attachments')]");
        return await objWrapper.isElementPresent(objAttachments, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Attachments pop up displayed.";
            else
                sConsole = "Fail : Fail to find presence of Attachments pop up.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_06042021 - click cancel on attachments pop up
    async clickCancelOnAttachmentsPopUp()
    {
        let btnCancel = by.xpath("//div[@class='modal-content']//h5[contains(text(),'Attachments')]/parent::div[@class='modal-header']/following-sibling::div[@class='modal-footer']/button[contains(text(), 'Cancel')]");
        return await objWrapper.clickOnElement(btnCancel, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on cancel button on attachments pop up";
            else
                sConsole = "Fail : Fail to click on cancel button on Attachments pop up";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_07042021 - verify wafer type table details
    async verifyWaferTypeTableDtlsOnEditPopUp(sAMATCust, sWaferType, sExpWaferCnt)
    {
        let sName = "noOf" + sWaferType + sAMATCust + "Waffer";
        let txtNoOfWafers = by.xpath("//h5[contains(text(),'Edit')]/parent::div/following-sibling::div//input[@name='"+sName+"']");        
        return await objWrapper.getElementAttribute(txtNoOfWafers, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sExpWaferCnt)
                sConsole = "Pass : No. of '"+sWaferType+"' '"+sAMATCust+"' value displayed as '"+sExpWaferCnt+"'";
            else
                sConsole = "Fail : Fail to display No. of '"+sWaferType+"' '"+sAMATCust+"' value as '"+sExpWaferCnt+"'";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_07042021 - Click cancel on Edit pop up
    async clickCancelOnEditPopUp()
    {
        let btnCancel = by.xpath("//h5[contains(text(),'Edit')]/parent::div/following-sibling::div//button[contains(text(),'Cancel')]");
																													 
        return await objWrapper.clickOnElement(btnCancel, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on Cancel button on Edit pop up.";
            else
                sConsole = "Fail : Fail to click on Cancel button on Edit pop up.";
            console.info(sConsole);
            return sConsole;
        });
	   
    }

    //Richa_07042021 - click on update TAMBA button on approval pop up
    async clickUpdateTAMBAOnApprovalPopUp()
    {
        let btnUpdateTAMBA = by.xpath("//h5[contains(text(),'Approval View')]/parent::div/following-sibling::div//button[contains(text(), 'Update Tamba')]");
        return await objWrapper.clickOnElement(btnUpdateTAMBA, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on Update Tamba button on Approval View pop up.";
            else
                sConsole = "Fail : Fail to click on Update Tamba button on Approval View pop up.";
            console.info(sConsole);
            return sConsole;
        });
}
//Namrata-12/04/2021- fetch background color of table cell on the demo details page.
async getTableCellColor(sColName,sDemoName)
{
    
    let  objTableCell, iRowNo, sColId;
    await objCommonPage.getRowNoForApplicationName(sDemoName).then(function(iRow){iRowNo = iRow;});
    sColId = objCommonPage.getColId(sColName);
    let sBckgColor;
    objTableCell = by.xpath("//div[@row-index='"+iRowNo+"']//div[@role='gridcell' and @col-id='"+sColId+"']");
    return objWrapper.getBackgroundColourofElement(objTableCell, objWrapper.iDefaultTimeout).then(function(sText){
        if(sText.includes("rgb(115, 179, 87)"))
            sBckgColor = "green";
        else if(sText.includes("rgb(0, 187, 212)"))
            sBckgColor = "blue";
        else if(sText.includes("rgb(0,187, 212)"))
            sBckgColor = "blueColor";
        else if(sText.includes("rgb(230, 50, 61)"))
            sBckgColor = "red";
        else
            sBckgColor = sText;
        return sBckgColor;
    
    });
 
 }
 
    //Richa_21042021 - Verify shipping link on edit pop up
    async verifyShippingLinkOnEditPopUp(sShippingLink)
    {
        let tblShippingLnk = by.xpath("//h5[contains(text(),'Edit')]/parent::div/following-sibling::div[@class='modal-body']//table[contains(@class,'shipping-table')]/tbody//td/a[text()='"+sShippingLink+"']");
																								   
											  
				   
																											  
        return await objWrapper.isElementPresent(tblShippingLnk, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Shipping link '"+sShippingLink+"' present on Edit pop up.";
            else
                sConsole = "Fail : Shipping link '"+sShippingLink+"' not present on Edit pop up.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_21042021 - verify shippig details on edit pop up
    async verifyShippingDtlsOnEditPopUp(sColName, sValue)
    {
        let iCol;
        if(sColName == "Freight Forwarder")
            iCol = 2;
        else
            iCol = 3;
        let tblShippingDtls = by.xpath("//h5[contains(text(),'Edit')]/parent::div/following-sibling::div[@class='modal-body']//table/tbody//td["+iCol+"]//input");
        return await objWrapper.getValueAttributeUsingJavascript(tblShippingDtls, objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sValue)
                sConsole = "Pass : Table column '"+sColName+"' contains value '"+sValue+"' present on Edit pop up.";
            else
                sConsole = "Fail : Table column '"+sColName+"' contains value '"+sValue+"' not present on Edit pop up.";
            console.info(sConsole);
            return sConsole;
        });
    }
    //Nidhi-15/04/2021- Click on the Field/Label on the Attachment pop up.
async clickFieldOnAttachmentPopUp(sFieldName)
{
    let objLabel = by.xpath("//app-view-attachment-shared[not(@title)]//label[contains(text(),'"+sFieldName+"')]//parent::div//select");
    return await objWrapper.clickOnElement(objLabel, objWrapper.iDefaultTimeout).then(function(bRes){
    if(bRes)
    sConsole = "Pass : Clicked on the "+sFieldName+".";    
    else
    sConsole = "Not Clicked on the "+sFieldName+".";   
    console.info(sConsole);
    return sConsole;  
    });
}
//Nidhi-15/04/2021- select option from the pop up field/Label on attachment pop up
async selectOptionsFromDDOnAttachmentPopUp(sLabelName, sOption)
{
    let objCmbOption = by.xpath("//app-view-attachment-shared[not(@title)]//label[contains(text(),'"+sLabelName+"')]//parent::div//option[contains(text(),'"+sOption+"')]")
    return await objWrapper.clickOnElement(objCmbOption, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
            sConsole = "Pass : Selected option '"+sOption+"' from '"+sLabelName+"' DD.";
        else
            sConsole = "Not able to select option '"+sOption+"' from '"+sLabelName+"' DD.";
        console.info(sConsole);
        return sConsole;
    });
} 
// Nidhi- 15/04/2021 click and select value from the Attachment pop up
async selectValueFromDDOnAttachmentPopUp(sLabelName, sOption)
{
    expect(await this.clickFieldOnAttachmentPopUp(sLabelName)).toContain("Pass");
    return await this.selectOptionsFromDDOnAttachmentPopUp(sLabelName,sOption);
} 

//Nidhi-19/04/2021- Select Date in the Table cell
async selectDateInTableCell(sDay, sMonth, sYear)
{
    expect(await this.selectCalendarMonthInTableCellDD(sMonth)).toContain("Pass");
    expect(await this.selectCalendarYearInTableCellDD(sYear)).toContain("Pass");
    let objDay = by.xpath("//option[@selected][text()='"+sMonth+"']//ancestor::div//td[@data-handler='selectDay']//a[text()='"+sDay+"']");
    return await objWrapper.clickOnElement(objDay, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
            sConsole = "Pass : Selected Requested date '"+sDay+"'.";
        else
            sConsole = "Not able to select Requested date '"+sDay+"'";
        console.info(sConsole);
        return sConsole;
    });
}
//Nidhi-19/04/2021 - select calendar month in Table Cell DD
async selectCalendarMonthInTableCellDD(sMonth)
{
    let objMonthDD = by.xpath("//select[@data-handler='selectMonth']");
    await objWrapper.clickOnElement(objMonthDD, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
            sConsole = "Pass : Clicked on Calendar Month DD.";
        else
            sConsole = "Not able to click on Calendar Month DD.";
        console.info(sConsole);
    });
    let objMonth = by.xpath("//select[@data-handler='selectMonth']//option[contains(text(),'"+sMonth+"')]");
    return await objWrapper.clickOnElement(objMonth, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
            sConsole = "Pass : Selected calendar month '"+sMonth+"'.";
        else
            sConsole = "Not able to select calendar month '"+sMonth+"'.";
        console.info(sConsole);
        return sConsole;
    });
}
//Nidhi-19/04/2021 - select calendar year in Table Cell DD
async selectCalendarYearInTableCellDD(sYear)
{
    let objYearDD = by.xpath("//select[@data-handler='selectYear']");
    await objWrapper.clickOnElement(objYearDD, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
            sConsole = "Pass : Clicked on Calendar Year DD.";
        else
            sConsole = "Not able to click on Calendar Year DD.";
        console.info(sConsole);
    });
    let objYear = by.xpath("//select[@data-handler='selectYear']//option[contains(text(),'"+sYear+"')]");
    return await objWrapper.clickOnElement(objYear, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
            sConsole = "Pass : Selected calendar year '"+sYear+"'.";
        else
            sConsole = "Not able to select calendar year '"+sYear+"'.";
        console.info(sConsole);
        return sConsole;
    });
}

//Nidhi-21/04/2021 get the pinged col headers
async getPingedColHeaders()								 
    {
        let objColHdrList = by.xpath("//div[@ref='ePinnedLeftHeader']//span[contains(@class,'ag-header-cell-text')]");
        return await objWrapper.getElementsText(objColHdrList, 'List of all the col header is');
    };


	//Richa_22042021 - click DD on Edit pop up
	async selectDDValueOnEditPopUp(sDDName, sDDVal)
	{
		let cmbDD = by.xpath("//h5[contains(text(),'Edit')]/parent::div/following-sibling::div[@class='modal-body']//label[text()='"+sDDName+"']/following-sibling::div/ng-multiselect-dropdown");
		await objWrapper.clickOnElement(cmbDD, objWrapper.iDefaultTimeout);
		let cmbDDOpt = by.xpath("//h5[contains(text(),'Edit')]/parent::div/following-sibling::div[@class='modal-body']//label[text()='"+sDDName+"']/following-sibling::div/ng-multiselect-dropdown//div[text()='"+sDDVal+"']");
		return await objWrapper.clickOnElement(cmbDDOpt, objWrapper.iDefaultTimeout).then(function(bRes){
			if(bRes)
				sConsole = "Pass : Selected drop down option '"+sDDVal+"' from '"+sDDName+"' drop down on Edit pop up.";
			else
				sConsole = "Fail : Fail to select drop down option '"+sDDVal+"' from '"+sDDName+"' drop down on Edit pop up.";
			console.info(sConsole);
			return sConsole;
		});
	}
	
	//Richa_22042021 - click Add new button on Edit pop up
    async clickAddNewBtnOnEditPopUp()
    {
        let btnAddNew = by.xpath("//h5[contains(text(),'Edit')]/parent::div/following-sibling::div[@class='modal-body']//a[@title='Add New']");
		return await objWrapper.clickOnElement(btnAddNew, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on Add New button on Edit pop up.";
            else
                sConsole = "Fail : Fail to click on Add New button on Edit pop up.";
			console.info(sConsole);			   
            return sConsole;
        });
    }

    //Richa_17032021 - select secondary BU
    async selectSecondaryBUInTableOnEditPopUp(sBU)
    {
        let objTblRows = by.xpath("//table[@class='table table-striped top_priority mb-3 mt-1']/tbody//tr");
        let iRowCount = await objWrapper.getWebelementCount(objTblRows).then(function(sText){console.log(sText); return sText;});
        let cmbTblBU = by.xpath("//table[@class='table table-striped top_priority mb-3 mt-1']//tr["+iRowCount+"]//td[2]//select/option[contains(text(),'"+sBU+"')]");
        // await objWrapper.setInputValue(cmbTblBU, sBU, objWrapper.iDefaultTimeout);
        // let lstTblBuOption = by.xpath("//div[contains(@class, 'ng-dropdown-panel-items')]//span[text()='"+sBU+"']");
        return await objWrapper.clickOnElement(cmbTblBU, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Selected secondary BU as '"+sBU+"'.";
            else
                sConsole = "Fail : Fail to select secondary BU as '"+sBU+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }
	
	async verifyDemoIssueValuesinTable(sIssueCount)													 
    {		 
        let tblRow = by.xpath("//h5[contains(text(),'Edit')]/parent::div/following-sibling::div[@class='modal-body']//table//tbody/tr");
 
        return await objWrapper.getWebelementCount(tblRow).then(function(iCnt){        
            if(sIssueCount== iCnt)
                sConsole = "Pass : Verified '"+sIssueCount+"' count under Demo Issue table";
            else
                sConsole = "Fail : Fail to verify '"+sIssueCount+"' value under Demo Issue table";
            console.info(sConsole);
            return sConsole;
        });
    }
//Richa_21042021 - verify shippig details on edit pop up
    async verifyDemoIssueDtlsOnEditPopUp(sColName, sValue)
    {
        let iCol;
        if(sColName == "Issue Type")
            iCol = 2;
        else
            iCol = 3;
        let tblDemoIssueDtls = by.xpath("//h5[contains(text(),'Edit')]/parent::div/following-sibling::div[@class='modal-body']//table/tbody//td["+iCol+"]//input");
 
        return await objWrapper.getElementAttribute(tblDemoIssueDtls, "value", objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sValue)
                sConsole = "Pass : Table column '"+sColName+"' contains value '"+sValue+"' present on Edit pop up.";
            else
                sConsole = "Fail : Table column '"+sColName+"' contains value '"+sValue+"' not present on Edit pop up.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_21042021 - Verify secondary BU dtls on edit pop up
    async verifySecondaryBUDtlsOnEditPopUp(sBU, sRequestor)
    {
        let objTblRows = by.xpath("//table[@class='table table-striped top_priority mb-3 mt-1']/tbody//tr");
        let iRowCount = await objWrapper.getWebelementCount(objTblRows).then(function(sText){console.log(sText); return sText;});
        let tblSecondaryBU = by.xpath("//h5[contains(text(),'Edit')]/parent::div/following-sibling::div[@class='modal-body']//table/tbody/tr["+iRowCount+"]/td[2]//input");
        let tblSecondaryBURequestor = by.xpath("//h5[contains(text(),'Edit')]/parent::div/following-sibling::div[@class='modal-body']//table/tbody/tr["+iRowCount+"]/td[3]//input");
        let sActBU = await objWrapper.getValueAttributeUsingJavascript(tblSecondaryBU, objWrapper.iDefaultTimeout).then(function(sText){console.info(sText); return sText;});
        let sActBURequestor = await objWrapper.getValueAttributeUsingJavascript(tblSecondaryBURequestor, objWrapper.iDefaultTimeout).then(function(sText){console.info(sText); return sText;});
        if(sActBU == sBU && sActBURequestor == sRequestor)
            sConsole = "Pass : Secondary BU '"+sBU+"' with Requestor '"+sRequestor+"' displayed on Edit Pop up.";
        else
            sConsole = "Fail : Fail to display secondary BU '"+sBU+"' with requestor '"+sRequestor+"' on Edit Pop up.";
        console.info(sConsole);
        return sConsole;
    }
    //Nidhi-24/05/2021 Select the Multiple items on the pop up.
    async selectItemFromMultiSelectDDOnPopUp(sItemName)
    {
       
        let objItem = by.xpath("//input[@aria-label='multiselect-item']//parent::li//div[text()='"+sItemName+"']");
        return await objWrapper.clickOnElement(objItem, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
            sConsole = "Pass :Selected Item "+sItemName+" from filter DD";   
        else
            sConsole = "Not able to select item from Filter DD"; 
            console.info(sConsole);
            return sConsole;
        });
    }
}
