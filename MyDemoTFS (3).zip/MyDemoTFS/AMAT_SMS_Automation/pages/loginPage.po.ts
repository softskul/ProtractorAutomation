import { wrapper } from '../utils/wrapper.util';
import { element, by, browser } from 'protractor';

let objWrapper:wrapper;
let sConsole;
export class loginPage{
    constructor()
    {
        objWrapper = new wrapper();
    }

    //Richa_01032021 - set user name
    async setUserName(sUserName)
    {
        let txtUserName = by.xpath("//label[text()='User Name']/following-sibling::input");
        await objWrapper.setInputValue(txtUserName, sUserName, objWrapper.iDefaultTimeout);
        return await objWrapper.getElementAttribute(txtUserName, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sUserName)
                sConsole = "Pass : Set user name as '"+sUserName+"'.";
            else
                sConsole = "Fail : Fail to set user name as '"+sUserName+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_01032021 - set password
    async setPassword(sPassword)
    {
        let txtPassword = by.xpath("//label[text()='Password']/following-sibling::input");
        await objWrapper.setInputValue(txtPassword, sPassword, objWrapper.iDefaultTimeout);
        return await objWrapper.getElementAttribute(txtPassword, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sPassword)
                sConsole = "Pass : Set password in login page.";
            else
                sConsole = "Fail : Fail to set password in login page.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_01032021 - click login button
    async clickLogin()
    {
        let btnLogin = by.xpath("//button[text() = 'Log In']");
        return await objWrapper.clickOnElement(btnLogin, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on Log in button.";
            else
                sConsole = "Fail : Fail to click on Log in button.";
            console.info(sConsole);
            return sConsole;
        });
    }
}