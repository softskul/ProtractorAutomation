import { wrapper } from '../utils/wrapper.util';
import { element, by, browser } from 'protractor';

let objWrapper:wrapper;
let sConsole;
export class manageViewPage{
    constructor()
    {
        objWrapper = new wrapper();
    }
    async clickOnSelectView()
    {
        let objSelectView = by.xpath("//label[contains(text(),'Select View')]//parent::div//select");
        return await objWrapper.clickOnElement(objSelectView, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)			 
                sConsole = "Pass : Clicked on the select view DD";	 
            else			 
                sConsole = "Not able to click on select View DD";
            return sConsole;
        });
    }
    async selectOptionFromFromSelectViewDD(sViewScreen)
    {
        let objSelectView = by.xpath("//label[contains(text(),'Select View')]//parent::div//option[contains(text(),'"+sViewScreen+"')]");
        return await objWrapper.clickOnElement(objSelectView, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)			 
                sConsole = "Pass : Select option "+sViewScreen+" from select view DD";	 
            else			 
                sConsole = "Not able to select view from DD";
            return sConsole;
        });
    }

    async selectViewFromDD(sViewScreen){

        expect(this.clickOnSelectView()).toContain("Pass");
        return this.selectOptionFromFromSelectViewDD(sViewScreen);
    }

    async clickOnPublishButtonManageView()
    {
        let objBtn = by.xpath("//button[contains(text(),'Publish')]");
        return await objWrapper.clickOnElement(objBtn, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)			 
                sConsole = "Pass : Clicked on Publish Button";	 
            else			 
                sConsole = "Not able to Click On Publish Button";
            return sConsole;
        });
    }
    
}