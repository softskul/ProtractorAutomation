import { wrapper } from '../utils/wrapper.util';
import { element, by, browser } from 'protractor';

let objWrapper:wrapper;
let sConsole;
export class outlookPage{
    constructor()
    {
        objWrapper = new wrapper();
    }

    //Richa_01032021 - set user name
    async setMailId(sMailId)
    {
        let txtMailId = by.css("input[name='loginfmt']");
        await objWrapper.setInputValue(txtMailId, sMailId, objWrapper.iDefaultTimeout);
        // return await objWrapper.getElementAttribute(txtMailId, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
        //     if(sText == sUserName)
                sConsole = "Pass : Set user name as '"+sMailId+"'.";
            // else
            //     sConsole = "Fail : Fail to set user name as '"+sUserName+"'.";
            console.info(sConsole);
            return sConsole;
        // });
    }

    //Richa_22042021 - click on Next
    async clickNext()
    {
        let btnNext = by.css("input#idSIButton9");
        return await objWrapper.clickOnElement(btnNext, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on Next button.";
            else   
                sConsole = "Fail : Fail to click on Next button.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_22042021 - set search text
    async setMailSearchValue(sSearchVal)
    {
        let txtMailSearch = by.css("input[placeholder='Search']");
        await objWrapper.setInputValue(txtMailSearch, sSearchVal, objWrapper.iDefaultTimeout);
        // return await objWrapper.getElementAttribute(txtMailSearch, "value", objWrapper.iDefaultTimeout).then(async function(sText){
        //     if(sSearchVal == sText)
        //     {
                sConsole = "Pass : Set Search value as '"+sSearchVal+"'.";
        //         await browser.sleep(5000);
                await objWrapper.sendKeysInActiveElmnt("Enter");
        //     }
        //     else
        //         sConsole = "Fail : Fail to set search value as '"+sSearchVal+"'.";
            console.info(sConsole);
            return sConsole;
        // });
    }

    //Richa_22042021 - Click on first mail
    async clickOnFirstMail(sSearchVal)
    {
        let objFirstMail = by.xpath("//div[contains(@aria-label,'"+sSearchVal+"')]//div[@tabindex='-1']");
        return await objWrapper.clickOnElement(objFirstMail, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on first mail with text '"+sSearchVal+"'.";
            else
                sConsole = "Fail : Fail to click on first mail with text '"+sSearchVal+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_01032021 - set password
    async setPassword(sPassword)
    {
        let txtPassword = by.xpath("//label[text()='Password']/following-sibling::input");
        await objWrapper.setInputValue(txtPassword, sPassword, objWrapper.iDefaultTimeout);
        return await objWrapper.getElementAttribute(txtPassword, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sPassword)
                sConsole = "Pass : Set password in login page.";
            else
                sConsole = "Fail : Fail to set password in login page.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_01032021 - click login button
    async clickLogin()
    {
        let btnLogin = by.xpath("//button[text() = 'Log In']");
        return await objWrapper.clickOnElement(btnLogin, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on Log in button.";
            else
                sConsole = "Fail : Fail to click on Log in button.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_26042021 - verify outlook email exists
    async verifyOutllookEmailExists(sUserName, sPassword, sMailHdr)
    {
        if(sUserName != "")    //added for handling when 2 test cases run simultenaously
        {
            expect(await this.setMailId(sUserName)).toContain("Pass");
        } 
        if(sPassword != "")
        {
            expect(await this.setPassword(sPassword)).toContain("Pass");
        } 
        if(sUserName != "" ||  sPassword != "")
        {
            expect(await this.clickNext()).toContain("Pass");
        }
        await browser.sleep(20000);
        expect(await this.setMailSearchValue(sMailHdr)).toContain("Pass");
        await browser.sleep(5000);
        return await this.clickOnFirstMail(sMailHdr);
    }

    //Richa_26042021 - verify mail body contains demo name and demo number in bold
    async verifyMailBodyWithDemoNumNmInBold(sDemoName, sDemoNumber)
    {
        let objDemoNmNum = by.xpath("//div[@class='wide-content-host']//b");
        return await objWrapper.getElementText(objDemoNmNum, objWrapper.iDefaultTimeout).then(function(sText){
            console.info(sText);
            if(sText == sDemoNumber + " " + sDemoName)
                sConsole = "Pass : Mail body contains text '"+sDemoNumber +" "+ sDemoName+"' in bold.";
            else
                sConsole = "Fail : Fail to find mail body with '"+sDemoNumber +" "+ sDemoName+"' in bold.";
            console.info(sConsole);
            return sConsole;
        });
    }
       //Nidhi-04/05/2021 - click the web link to reach the demo in the email.
       async clickOnTheWebLinkToVisitDemo()
       {
           let webLink = by.xpath("//a[text()='click here'][1]");
           return await objWrapper.clickOnElement(webLink, objWrapper.iDefaultTimeout).then(function(bRes){
               if(bRes)
                   sConsole = "Pass : clicked on the Desktop Weblink";
               else
                   sConsole = "Not able to click on Desktop Web link.";
               console.info(sConsole);
               return sConsole;
           });
       }

       //Nidhi-7/05/2021 - Enter Seacrhed Emial 2nd time in same testcase
    async verifyOutllookEmailExistsSecondTime(sMailHdr)
    {
        expect(await this.setMailSearchValue(sMailHdr)).toContain("Pass");
        await browser.sleep(5000);
        return await this.clickOnFirstMail(sMailHdr);
    }
}