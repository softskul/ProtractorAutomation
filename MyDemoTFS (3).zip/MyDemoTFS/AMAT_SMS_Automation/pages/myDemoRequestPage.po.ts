import { wrapper } from '../utils/wrapper.util';
import { element, by, browser } from 'protractor';
import { BrowserUtil } from '../utils/browser.util';
import { SpecReporter } from 'jasmine-spec-reporter';

let objWrapper:wrapper;
let sConsole;
export class myDemoRequestPage{
    constructor()
    {
        objWrapper = new wrapper();
    }

    async verifyDemoPresentInTable(sDemoName) 
    {
        let objTblDemoName = by.xpath("//div[@col-id='demoName' and contains(text(), '"+sDemoName+"')]");
        return await objWrapper.isElementPresent(objTblDemoName, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Demo request with demo name'"+sDemoName+"' present on My Demo Request page.";
            else
                sConsole = "Fail : Fail to find demo request with demo name'"+sDemoName+"' on My Demo Request page.";
            console.info(sConsole);
            return sConsole;
        });
    }

    async verifyDemoApprovalStatus(sDemoName, sDemoApprovalStatus)
    {
        let tblDemoApproval = by.xpath("//div[@col-id='demoName' and contains(text(), '"+sDemoName+"')]/following-sibling::div[@col-id='stageStatus' and contains(text(), '"+sDemoApprovalStatus+"')]");
        return await objWrapper.isElementPresent(tblDemoApproval, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Demo request with demo name'"+sDemoName+"' is having demo approval status as '"+sDemoApprovalStatus+"'.";
            else
                sConsole = "Fail : Fail to find demo request with demo name'"+sDemoName+"' is having demo approval status '"+sDemoApprovalStatus+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

	//Richa_23032021 - Save demo number
    async saveDemoNumber(sDemoName)
    {
        let objDemoNumber = by.xpath("//div[@col-id='demoName' and contains(text(), '"+sDemoName+"')]/preceding-sibling::div[@col-id='demoNumber']");
        await objWrapper.getElementText(objDemoNumber, objWrapper.iDefaultTimeout).then(function(sText){
            console.log(sText);
            browser.executeScript("window.localStorage.setItem('sPrimaryDemoNo', '"+sText+"');");
        });
    }
}