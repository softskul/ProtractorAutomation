import { wrapper } from '../utils/wrapper.util';
import { element, by, browser } from 'protractor';
import { BrowserUtil } from '../utils/browser.util';

let objWrapper:wrapper;
let sConsole;
const fullMonthNames = ["dummyValue","January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
const halfMonthNames = ["dummyValue","Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];																													 
export class commonPage{
    constructor()
    {
        objWrapper = new wrapper();
    }

    //verify alert header
    async verifyAlertHeader(sAlertHeader) 
    {
        if(sAlertHeader != "")
        {
            let objAlertHeader = by.xpath("//div[@class='modal-header']/h5[contains(text(),'"+sAlertHeader+"')]|//div[@class='modal-header']/h4[contains(text(),'"+sAlertHeader+"')]");
            return await objWrapper.isElementPresent(objAlertHeader, objWrapper.iDefaultTimeout).then(function(bRes){
                if(bRes)
                    sConsole = "Pass : Verified alert header as '"+sAlertHeader+"'.";
                else
                    sConsole = "Alert is not present";
                console.info(sConsole);
                return sConsole;
            });
        }    
    }

    //verify alert message
    async verifyAlertMessage(sAlertMessage)
    {
        
        if(sAlertMessage != "")
        {
            console.log("Inside verifyAlertMessage");
            let objAlertMessage = by.xpath("//div[@class='modal-body']/div[contains(text(),'"+sAlertMessage+"')]|//div[@class='modal-body' and contains(text(),'"+sAlertMessage+"')]");
            return await objWrapper.isElementPresent(objAlertMessage, objWrapper.iDefaultTimeout).then(function(bRes){
                if(bRes)
                    sConsole = "Pass : Verified alert message displayed as '"+sAlertMessage+"'.";
                else
                    sConsole = "Fail : Fail to verify alert message as '"+sAlertMessage+"'.";
                console.info(sConsole);
                return sConsole;
            });
        }
    }

    //take action on alert
    async takeActionOnAlert(sAction)
    {
        let btnAlertAction = by.xpath("//div[@class='modal-footer']//button[contains(text(),'"+sAction+"')]");
        return await objWrapper.clickOnElement(btnAlertAction, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on alert button '"+sAction+"'.";
            else
                sConsole = "Fail : Fail to click on alert button '"+sAction+"'.";
            console.info(sConsole);
            return sConsole;
        })
    }

    //Verify alert and take action
    async verifyAlertAndTakeAction(sAlertHeader, sAlertMessage, sAlertAction)
    {
        if(sAlertHeader)
        {
            expect(await this.verifyAlertHeader(sAlertHeader)).toContain("Pass");
        }   
        console.log(sAlertMessage);
        if(sAlertMessage)
            expect(await this.verifyAlertMessage(sAlertMessage)).toContain("Pass");
        return await this.takeActionOnAlert(sAlertAction);
    }

    async clickOnGoToDD()
    {
        //let cmbGoTo = by.xpath("//label[contains(text(),'Go to')]/parent::div/following-sibling::div/select");
        let cmbGoTo = by.css("select[name='goTo']");
        return await objWrapper.clickOnElement(cmbGoTo, objWrapper.iMaxTimeout).then(function(bRes){
        if(bRes)
            sConsole = "Pass : Clicked on Go To DD to select column.";   
        else
            sConsole = "Fail to click on Go To DD."; 
            console.info(sConsole);
            return sConsole;
        });
    }

    async selectOptionFromGoToDDList(sOption)
    {
        //let lstGoTo = by.xpath("//label[contains(text(),'Go to')]/parent::div/following-sibling::div/select/option[contains(text(), '"+sOption+"')]");
        let lstGoTo = by.xpath("//select[@name='goTo']//option[contains(text(), '"+sOption+"')]");
        return await objWrapper.clickOnElement(lstGoTo, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
            sConsole = "Pass : Selected Go To column option '"+sOption+"'.";   
        else
            sConsole = "Fail to select Go to column option '"+sOption+"'."; 
            console.info(sConsole);
            return sConsole;
        });
    }

    async goToColumn(sColName)
    {
        expect(await this.clickOnGoToDD()).toContain("Pass");
        return await this.selectOptionFromGoToDDList(sColName);
        
    }
	
	async verifyGoToDDIsPresent()
	
    {
        let cmbGoTo = by.xpath("//label[contains(text(), 'Go to')]/parent::div//following-sibling::div/select");
																								  
        return await objWrapper.isElementPresent(cmbGoTo, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
            {
                console.info("Verified that Go To DD is present.");
                return true;
            }
            else
            {
                console.error("Fail to verify that Go To DD is present.");
								   
                return false;
            }
        })
    }

    async verifySearchTextBoxIsPresent()
    {
        let txtSearch = by.css("input[placeholder='Search here']");
        return await objWrapper.isElementPresent(txtSearch, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
            sConsole = "Pass : Verified Search Text box is present.";   
        else
            sConsole = "Fail : Fail to verify Search Text box."; 
            console.info(sConsole);
            return sConsole;
        });
    }

    async verifySearchBtnIsPresent()
    {
        let btnSearch = by.xpath("//input[@name='filterText']/following-sibling::div/button");
        return await objWrapper.isElementPresent(btnSearch, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
            {
                console.info("Verified that search button is present.");
                return true;
            }
            else
            {
                console.error("Fail to verify that search button is present.");
                return false;
            }
        });
    }

    async verifyExportBtnPresent()
    {
        let btnExport = by.css("button[title='Export To Excel']");
        return await objWrapper.isElementPresent(btnExport, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
            sConsole = "Pass : Verified that Export button is present.";   
        else
            sConsole = "Verified that Export button is present."; 
            console.info(sConsole);
            return sConsole;
        });
    }

    //set search text like demo name
    async setSearchText(sSearchVal) 
    {
        let txtSearch = by.css("input[placeholder='Search here']");
        await objWrapper.clickOnElement(txtSearch, objWrapper.iDefaultTimeout);
        await objWrapper.setInputValue(txtSearch, sSearchVal, objWrapper.iDefaultTimeout);
        return await objWrapper.getElementAttribute(txtSearch, 'ng-reflect-model', objWrapper.iDefaultTimeout).then(function(sText){
        console.log(sText);
        if(sSearchVal == sText)	 
            sConsole = "Pass : Set search text as '"+sSearchVal+"'.";    
        else	 
            sConsole = "Not able to set search text as '"+sSearchVal+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    async clickOnSearch()
    {
        let btnSearch = by.css("[class*='group-append']>button");
        return await objWrapper.clickOnElement(btnSearch, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)	 
            sConsole = "Pass : Clicked on Search button."; 					 
        else 
            sConsole = "Not able to click on search button."; 
            console.info(sConsole);
            return sConsole;
			 
        })
    }

    async searchRequest(sSearchVal)
    {
        expect(await this.setSearchText(sSearchVal)).toContain("Pass");
        return await this.clickOnSearch();
    }

    async waitTillInvisibilityOfLoadingIcon()
    {
        let iCounter = 0;
        let objLoadIcon = by.css("div.spinner-border.text-info");
        do
        {
            browser.sleep(objWrapper.iMinTimeout);
            iCounter = iCounter + 1;
        }while(await objWrapper.isElementPresentWithoutWait(objLoadIcon) || iCounter < 20);
    }

    //Pass sDate as Today, Tomorrow, Yesterday
    async selectDateFromCalendar(sDate)
    {
        if(sDate == "" || sDate == "Today")
        {
            await objWrapper.sendKeysInActiveElmnt("Enter");
        }
		else if(sDate== "Next" || sDate=="Tomorrow")
        {
           let nextDate;
           await this.getDt("Tomorrow","dd/mm/yyyy", false).then(function(sDate){nextDate=sDate;});           
           let dateSplit = nextDate.split("/");          
            await this.selectDateFromdd(dateSplit[0], fullMonthNames[dateSplit[1]], dateSplit[2]);
        }
        else if(sDate.includes("Next_HalfMonth") || sDate.includes("Tomorrow_HalfMonth"))
        {
           let nextDate;
           await this.getDt("Tomorrow","dd/mm/yyyy", false).then(function(sDate){nextDate=sDate;});           
           let dateSplit = nextDate.split("/");
           await this.selectDateFromdd(dateSplit[0], halfMonthNames[dateSplit[1]], dateSplit[2]);
        }
    }
	async clickExportButton(pageName)
    {
        let exportBtn = by.xpath("//button[@title='Export To Excel']");
        return await objWrapper.clickOnElement(exportBtn, objWrapper.iDefaultTimeout).then(async function(bRes){
            if(bRes)
               sConsole = "Pass : Clicked on Export button on "+pageName+" page";   
            else
              sConsole = "Fail to click on Export button on"+pageName+" page.";  
              console.info(sConsole);
              return sConsole; 
        });
    }
    async verifyColumnPresentInExcelHeader(expectedheader,actualheaderList)
    {
       
        let columnHeaderList = actualheaderList.split("~");
       
        let bFlag:boolean=false;
         for(var iCount = 0; iCount < columnHeaderList.length; iCount++)
         { 
            if(expectedheader==columnHeaderList[iCount])
            {
                bFlag=true;
                break;
            }
        }                      
       
        if(bFlag)
        {
            console.info("Verfied " +expectedheader+" column is present in excel header");
            return true;
        }
        else
         {
            console.info(+expectedheader+" header is not present in excel header");
            return false;
         }   
         
    }

    async deleteFileFromDownloadsDir(fileName:String)
    {
       const fs = require('fs')
       const os = require('os');
       const directory = os.homedir()+"/Downloads";
       let path ;
        
       if(fileName.includes("/") || fileName.includes("\\"))
            path = fileName;
        else
            path = directory+fileName;
            
        fs.exists(path, (exist) => {
            if(exist){
                fs.unlink(path, (err) => {
                    if (err) {
                        console.error(err);
                        return false;
                    }
                    else
                    {
                        console.info("Deleted "+fileName+" file from Downloads Directory");
                        return true;        
                    }
                }); 
            }
            else{
                console.log("No Files deleted from Downloads Directory");
                return true;
            }
        });     
    }


    async getCurrentDate(dateFormat)
    {
        let currentDate;
        var today = new Date();
        let dd = today.getDate();        
        var mm = today.getMonth()+1; 
        var yyyy = today.getFullYear();
        var hh = today.getHours();
        var mins = today.getMinutes();
        let dd_str,mm_str,hh_str,mins_str;

        if(dd<10) 
            dd_str = '0'+dd;
        else
            dd_str = dd.toString();
        
        if(mm<10) 
            mm_str = '0'+mm;
        else
            mm_str = mm.toString();

        // if(hh<10) 
        //     hh_str = '0'+hh;
        // else
            hh_str = hh.toString();

        if (mins < 10) 
            mins_str = "0" + mins;
        else
            mins_str = mins.toString();     

        switch(dateFormat)
        {
            case "mm-dd-yyyy":
                    currentDate = mm_str+'-'+dd_str+'-'+yyyy;
                    console.log(currentDate);
                    break;

            case "mm/dd/yyyy" :
                    currentDate = mm_str+'/'+dd_str+'/'+yyyy;
                    console.log(currentDate);
                    break;
                    
            case "mm/dd/yyyy hh:mins" :
                    currentDate = mm_str+'/'+dd_str+'/'+yyyy+' '+hh_str+':'+mins_str;
                    console.log(currentDate);
                    break;
            default :
                    currentDate = mm+'/'+dd+'/'+yyyy;
                    console.log(currentDate);
                    break;
        }
        return currentDate;
    }
    
    async verifyColumnNameNotPresentInGoToDD(sColumnName,sPageName)
    {
        await this.clickOnGoToDD();
        let bFlag= true;
        let lstGoTo = by.xpath("//label[contains(text(),'Go to')]/parent::div/following-sibling::div/select/option");
        return await objWrapper.getWebElements(lstGoTo).then(async function(objElements){
        
            var sOptionTxt;
             for(var iCount = 0; iCount < objElements.length ; iCount++)
             {           
                await objElements[iCount].getText().then(function(sTxt){
                    sOptionTxt=sTxt;
                 });

                if(sColumnName==sOptionTxt.replace(/^\s+|\s+$/g, ''))
                {
                    bFlag=false;
                    break;
                }
            
            }
            if(bFlag)
                console.log(sColumnName+" is not present in Go to drop down list on "+sPageName+" page")
            else 
                console.log(sColumnName+" is present in Go to drop down list on "+sPageName+" page")
             return bFlag;
        });    
    }

    //Richa_Jan2021 - select calendar month
    async selectCalendarMonth(sMonth)
    {
        let objMonthDD = by.xpath("//select[@title='Select month'] | //select[@data-handler='selectMonth']");
        await objWrapper.clickOnElement(objMonthDD, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on Calendar Month DD.";
            else
                sConsole = "Fail : Fail to click on Calendar Month DD.";
            console.info(sConsole);
        });
        let objMonth = by.xpath("//select[@title='Select month']/option[@aria-label='"+sMonth+"'] | //select[@data-handler='selectMonth']/option[text()='"+sMonth+"']");
        return await objWrapper.clickOnElement(objMonth, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Selected calendar month '"+sMonth+"'.";
            else
                sConsole = "Fail : Fail to select calendar month '"+sMonth+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_Jan2021 - select calendar year
    async selectCalendarYear(sYear)
    {
       let objYearDD = by.xpath("//select[@title='Select year'] | //select[@data-handler='selectYear']");
        await objWrapper.clickOnElement(objYearDD, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on Calendar Year DD.";
            else
                sConsole = "Fail : Fail to click on Calendar Year DD.";
            console.info(sConsole);
        });
        let objYear = by.xpath("//select[@title='Select year']/option[@value='"+sYear+"'] | //select[@data-handler='selectYear']/option[@value='"+sYear+"']");
        return await objWrapper.clickOnElement(objYear, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Selected calendar year '"+sYear+"'.";
            else
                sConsole = "Fail : Fail to select calendar year '"+sYear+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_Jan2021 - select calendar date
    async selectDateFromdd(sDay, sMonth, sYear)
    {
        expect(await this.selectCalendarMonth(sMonth)).toContain("Pass");
        expect(await this.selectCalendarYear(sYear)).toContain("Pass");
        let objDay = by.xpath("//div[contains(@class,'ngb-dp-day') and contains(@aria-label,'"+sMonth+"')]/div[text()='"+sDay+"']");
        return await objWrapper.clickOnElement(objDay, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Selected Requested date '"+sDay+"'.";
            else
                sConsole = "Fail : Fail to select Requested date '"+sDay+"'";
            console.info(sConsole);
            return sConsole;
        });
    }
	
	async getTableHeaders()								 
    {
        let objColHdrList = by.css("div.ag-header.ag-pivot-off span.ag-header-cell-text");
        return await objWrapper.getElementsText(objColHdrList, 'List of all the col header is');
    };
    //Nidhi-04/03/2021 Will give the Latest or First Demo Name in the 1st Row on all the Page
    async getTheLatestDemoNm()
    {  
        let objltDemoNm = by.css("div[row-index='0']>[col-id='demoName']");
        return await objWrapper.getElementText(objltDemoNm,objWrapper.iDefaultTimeout ).then(function(sText){
        console.log("Latest Demo Name is "+sText+".")
        return sText;
        });
    }
    async clickOnSortingIcon(sDemoLblNm)  
    {   
        let objSorting = by.xpath("//span[contains(text(),'"+sDemoLblNm+"')]");
        return await objWrapper.doubleClickOnElement(objSorting,objWrapper.iDefaultTimeout ).then(function(sbes){
        if(sbes)
            sConsole = "Pass : Clicked on desc sorting icon of col : '"+sDemoLblNm+"'";   
           else
            sConsole = "Fail : Fail to click desc on sorting icon of col :'"+sDemoLblNm+"'."; 
            console.info(sConsole);
            return sConsole;
        });
    }
    async verifySortingIcon(sColName)  
    {   
        let objSorting = by.xpath(" //span[contains(text(),'"+sColName+"')]//following-sibling::span[not(contains(@class,'ag-hidden'))]");
        return await objWrapper.isElementPresent(objSorting,objWrapper.iDefaultTimeout ).then(function(sbes){
        if(sbes)
            sConsole = "Pass : Yes, Sorting Icon is present '"+sColName+"'";   
           else
            sConsole = "Fail : No, sorting Icon is not present on the:'"+sColName+"'."; 														   
            console.info(sConsole);
            return sConsole;
        });
    }

    async verifySorting(sColName)
    {  
        expect(await this.clickOnSortingIcon(sColName)).toContain("Pass");
        expect(await this.verifySortingIcon(sColName)).toContain("Pass");
        return await this.getTheLatestDemoNm();
    };
    async verifyHyperLink(sColName, sDemoName)
    {
        let iRowNo;
        let sColId = this.getColId(sColName);
        await this.getRowNoForApplicationName(sDemoName).then(function(iRow){iRowNo = iRow;});
        let objHyperLink = by.xpath("//div[@row-index='"+iRowNo+"']//div[@col-id='"+sColId+"'][contains(@style, '#13a4e8')]|//div[@row-index='"+iRowNo+"']//div[@col-id='"+sColId+"']//a");
        return await objWrapper.isElementPresent(objHyperLink, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
            sConsole = "Pass :'"+sColName+"'Display as hyperlink against Demo Name "+sDemoName+".";   
        else
            sConsole = ""+sColName+"'Does Not Display as hyperlink against Demo Name "+sDemoName+"."; 
            console.info(sConsole);
            return sConsole;
        });
    }
    getColId(sColName)									  										   
    {
        let sColId;
        console.log(sColName)
        switch(sColName)
        {	
            case "Demo Name":
                sColId = "demoName";
                break;
            case "Demo Number":
                sColId = "demoNumber";
                break;	
            case "Demo Approval":
                sColId = "stageStatus";
                break;	
            case "Account Adoption Prob %":
                sColId = "adoptionProbability";
            case "BU":
                sColId = "businessUnit";
                break;
            case "Account":
                sColId = "customer";					
                break;	
            case "Account Owner":
                sColId = "accountOwner";
                break;
            case "Customer title":
                sColId = "title";
                break;  	
            case "Approved By":
                sColId = "approvedBy";
                break;
            case "TAMBA Name":
                sColId = "tambaID";
                break;	 
            case "Other Groups":
                sColId = "otherSecurityGroup";
                break;
            case "Current Execution Risk": case "Execution Risk":
                sColId = "risk";
                break;
            case "Wafer Location":
                sColId = "waferLocation";
                break;  
            case "Demo Requestor":
                sColId = "demoRequestor";
                break;
            case "Eng.":
                sColId = "engineer";
                break;
            case "Duration (wk)":
                sColId = "duration_Per_Week";
                break;
            case "Demo Owner":
                sColId = "demoOwner";
                 break; 
            case "Co-Owner":
                sColId = "coOwner";
                break;
            case "Customer Wafer Destination":
                sColId = "customerWaferRoom";
                break;
            case "IO#/ Cost Center":
                sColId = "costCenter";
                break;
            case "Substrate Type":
                sColId = "substrate";
                break;
            case "Eng.":
                sColId = "engineer";
                break;
            case "AMAT Product":
                sColId = "productLine";
                break; 
            case "Demo Start":
                sColId = "scheduleStartDate";
                break;
            case "Demo Completion":
                sColId = "scheduleCompletionDate";
                break;  
			case "TEM Spls/wk":
                sColId = "temPerWeek";
                break;
            case "SEM Spls/wk":
                sColId = "semPerWeek";
                break;
            case "Chamber Usage (H/Day)":
                sColId = "chamber_Usage_Per_Day";
                break;
            case "Duration (wk)":
                sColId = "duration_Per_Week";
                break;
            case "BM Owner":
                sColId = "bmApprover";
                break;
            case "CAT/RAT Manager":
                sColId = "catratManager";
                break;
            case "KPU Head/GPM":
                sColId = "kpuHeadAndGPM";
                break;
            case "Customer Wafer Destination":
                sColId = "customerWaferRoom";
                break;
            case "Tool ID":
                sColId = "toolID";
                break;
            case "Lab Ready":
                sColId = "configChangeDate";
                break;
			case "Customer Engagement":
                sColId = "businessCase";
                break;
            case "Performance (Spec vs. Actual)":
                sColId = "performance_Spec_Vs_Actual";
                break;  
            case "CoO Gap (spec vs. Actual)":
                sColId = "coO_GAP_Spec_Vs_Actual";
                break;  
            case "Onsite Chamber Readiness":
                sColId = "onSite_Chamber_Ready";
                break;  
            case "Additional CIP HW Requirement":
                sColId = "additional_CIP_HW_Required";
                break;  			
            case "CIP HW Shipment Target":
                sColId = "ciP_HW_Shipment_TargetDate";
                break;
            case "Schedule to close the DPY Gaps":
                sColId = "schedule_Close_DPYDate";
                break;
            case "Shipping Information":
                sColId = "shippingInfoCount";
                break;
            case "Wafer Available in Lab":
                sColId = "waferAvailableInLabDate";
				break; 
			case "Risk/Gap Description":
                sColId = "risk_Gap_Description";
                break;  	
			case "Risk/Gap Closure Plan":
                sColId = "risk_Gap_Closure_Plan";
                break; 
            case "Onsite Chamber Readiness":
                sColId = "onSite_Chamber_Ready";							
                break;
            case "Team Member":
                sColId = "teamMember";
                break;  
			case "Demo Issue":
                sColId = "demoIssueCount";
                break;
            case "Priority":
                sColId = "priority";
                break;		
			case "Estimated Cost":
                sColId = "totalCost";
                break;
            case "Demo Location":
                sColId = "demoLocation";
                break;
            default :
                sColId = sColName.replace("/", "");
                sColId = sColId.toLowerCase();
        //sColName = sColName.replace(" ", "");
                sColId = objWrapper.convertToCamelCase(sColId);
        }
        return sColId;
    }
async clickInTheTableCell(sColName,sDemoName)
    {
        let  objTableCell, iRowNo, sColId;
        await this.getRowNoForApplicationName(sDemoName).then(function(iRow){iRowNo = iRow;});
        sColId = this.getColId(sColName);
        if(sColName == 'Wafer Type'||sColName == 'Substrate Type'||sColName == 'Customer Wafer Destination'||sColName == 'TAMBA Name'||sColName == 'Other Groups'||sColName == 'Demo Name'||sColName == 'Current Execution Risk'||sColName == 'Wafer Location'||sColName == 'Demo Requestor'||sColName == 'Eng.'||sColName == 'Duration (wk)'||sColName == 'BU'||sColName == 'Demo Owner' || sColName == 'Account Owner' || sColName == 'Productivity Owner'|| sColName == 'Co-Owner' || sColName == 'Account' || sColName == 'Demo Type' || sColName == 'AMAT Product' || sColName == 'Execution Risk'|| sColName == 'Demo Completion'|| sColName == 'Wafer Available in Lab'|| sColName == 'Team Member'|| sColName == 'Customer Engagement' || sColName == 'CIP HW Shipment Target' || sColName == 'Schedule to close the DPY Gaps' || sColName == 'Risk/Gap Description' || sColName == 'Risk/Gap Closure Plan' || sColName == 'Demo Issues' || sColName == 'Team Member' || sColName == 'CAT/RAT Manager' || sColName == 'KPU Head/GPM'|| sColName == 'Priority'|| sColName == 'Demo Start'|| sColName == 'Lab Ready'|| sColName == 'Demo Location')
		 
            objTableCell = by.xpath("//div[@row-index='"+iRowNo+"']//div[@role='gridcell' and @col-id='"+sColId+"']");
        else if(sColName == 'Demo Number')
        {
            objTableCell = by.xpath("//div[@row-index='"+iRowNo+"']//div[@role='gridcell' and @col-id='"+sColId+"']//a");
            await objWrapper.isElementPresent(objTableCell, objWrapper.iDefaultTimeout).then(function(bRes){
                if(!bRes)
                    objTableCell = by.xpath("//div[@row-index='"+iRowNo+"']//div[@role='gridcell' and @col-id='"+sColId+"']");
            })
        }																																															  
        else
        {
            objTableCell = by.xpath("//div[@row-index='"+iRowNo+"']//div[@role='gridcell' and @col-id='"+sColId+"']//span");
        }
        return await objWrapper.javascriptClickOnElement(objTableCell, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
			sConsole = "Pass : Clicked in the col'"+sColName+"'cell contains Demo Name '"+sDemoName+"'.";  
        else
			sConsole = "Not able to click in the col '"+sColName+"'cell contains Demo Name'"+sDemoName+"'."; 
		console.info(sConsole);
		return sConsole;
	});
}
async getTableCellValue(sColName,sDemoName)
{
    try{
    let  objTableCell, iRowNo, sColId;
    await this.getRowNoForApplicationName(sDemoName).then(function(iRow){iRowNo = iRow;});
    sColId = this.getColId(sColName);	 
    if(sColName == 'BU'||sColName == 'Demo Approval'||sColName == 'Approved By'||sColName == 'Demo Number'||sColName == 'Demo Owner'|| sColName == 'Account Owner' || sColName == 'Productivity Owner' || sColName == 'Co-Owner'|| sColName == 'Demo Type' || sColName == 'Demo Location' || sColName == 'Tool ID' || sColName == 'Chamber Position'|| sColName == 'Account'|| sColName == 'BM Owner' || sColName == 'Team Member'|| sColName == 'CAT/RAT Manager' || sColName == 'KPU Head/GPM' || sColName == 'Dimension' || sColName == 'Demo Development Stage')
    {
        objTableCell = by.xpath("//div[@row-index='"+iRowNo+"']//div[@role='gridcell' and @col-id='"+sColId+"']");
    }
    else
    {
        objTableCell = by.xpath("//div[@row-index='"+iRowNo+"']//div[@role='gridcell' and @col-id='"+sColId+"']//span");
    }
    return await objWrapper.getElementText(objTableCell, objWrapper.iDefaultTimeout).then(function(sText){
        console.info("Cell text in column '"+sColName+"' against application name '"+sDemoName+"' is '"+sText+"'.");
        return sText;
    });
}
catch(exception){
    console.log("Error while getting text of coloumn '"+sColName+"'" + exception);
        return null;
}

}
    async verifyPublicPersonalViewDDIsPresent()
    {
        let cmbPersonalPublic = by.css("select[name='view']");
        return await objWrapper.isElementPresent(cmbPersonalPublic, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
            sConsole = "Pass : Verified that Public Personal View DD is present.";   
        else
            sConsole = "Fail : Fail to verify that Public Personal view DD is present."; 
            console.info(sConsole);
            return sConsole;
        });
    }
    async verifyPublishBtnPresent()
    {
        let btnPublish = by.css("button[title*='Enable Publish']");
        return await objWrapper.isElementDisplayed(btnPublish, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
            sConsole = "Pass : Verified that Publish Button is Present by default disabled";   
            else
            sConsole = "Verify that Publish Button is not present."; 
            console.info(sConsole);
            return sConsole;
        });
    }

    async verifyStatusDDIsPresentWithDefVal(sDefVal)
    {
        let cmbStatus = by.css("select[name='status']");
        expect(await objWrapper.isElementPresent(cmbStatus, objWrapper.iDefaultTimeout)).toBe(true);
        return await objWrapper.getElementAttribute(cmbStatus, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
        if(sText == sDefVal)
            sConsole = "Pass : Verified Status DD is present with default value as '"+sDefVal+"'.";   
        else
        sConsole = "Not able to verify Status DD is present with default value as '"+sDefVal+"'."; 
        console.info(sConsole);
        return sConsole;
        });
    }

    async verifyCustomizedViewBtnIsPresent()
    {
        let btnCustView = by.css("button[title='Customize View']");
        return await objWrapper.isElementPresent(btnCustView, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
               sConsole = "Pass : Verified that Customized View button is present.";   
            else
              sConsole = "Verified that Customized View button is not present.";  
              console.info(sConsole);
              return sConsole; 
        });
    }
    async getGoToOptionsList()								 
    {
        let objOptionList = by.css("select[name='goTo']>option");
        return await objWrapper.getElementsText(objOptionList, 'List of Options Conatins by Go To DD');
    };

    async verifyTableHeaderIsPresent(sTableHdr)
    {
        let objTblHeader = by.xpath("//div[@class='ag-root ag-unselectable ag-layout-normal']//span[@class='ag-header-cell-text' and contains(text(), '"+sTableHdr+"')]");
        return await objWrapper.isElementPresent(objTblHeader, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Col '"+sTableHdr+"' is present.";
            else
                sConsole = "Col '"+sTableHdr+"' not present.";
            console.info(sConsole);
            return sConsole;
        });
        
    }
	
	async verifyGoToDDIsPresentWithDefVal(sDefVal)
    
    {
        let cmbGoTo = by.css("select[name='goTo'][ng-reflect-model='']");
        expect(await objWrapper.isElementPresent(cmbGoTo, objWrapper.iDefaultTimeout)).toBe(true);
        return await objWrapper.getElementAttribute(cmbGoTo,"ng-reflect-model",objWrapper.iDefaultTimeout).then(function(sText){
        if(sText == sDefVal)
            sConsole = "Pass : Verified Go To DD is present with default value as '"+sDefVal+"'.";   
																   
							
			 
        else
			 
            sConsole = "Fail : Fail to verify Go To DD is present with default value as '"+sDefVal+"'."; 
            console.info(sConsole);
            return sConsole;
        });
		  
    }
	
	//Richa_09032021 - Click on step selector
    async clickOnStepSelector(sStep)									   
    {
        sStep = sStep.toLowerCase();
        let objStepSelector = by.xpath("//app-request-sidebar//li/a[@id='"+sStep+"']");													   
        return await objWrapper.javascriptClickOnElement(objStepSelector, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked on '"+sStep+"' in sidebar.";
            else
                sConsole = "Fail : Fail to click on '"+sStep+"' in sidebar.";
														  
            console.info(sConsole);
            return sConsole;
        });	
    }
	
	async getRowNoForApplicationName(sDemoName)
    {

        try{
        let sColId = this.getColId("Demo Name");
        let objTableCell = by.xpath("//div[@role='gridcell' and @col-id='"+sColId+"'][contains(text(),'"+sDemoName+"')]/ancestor::div[@role='row' and contains(@class,'ag-row')]");
        return await objWrapper.getElementAttribute(objTableCell, "row-index", objWrapper.iDefaultTimeout); 
        }
        catch(exception){
            console.log("Fail to verify the row value");
            return -1;
        }
        
    }
//Nidhi-03/09/2021  check the col is present on specific index or not.
async getColByColIndex(sColName, sColIndex)
{
    let objColIndex = by.xpath("//span[@aria-colindex='"+sColIndex+"'][contains(text(),'"+sColName+"')]");
    return await objWrapper.isElementPresent(objColIndex, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
            sConsole = "Pass : Col '"+sColName+"' is on index "+sColIndex+".";
        else 
            sConsole = "Col '"+sColName+"' index is changed.";
        console.info(sConsole);
        return sConsole;
    });
    
}
//Nidhi-03/09/2021 moving of all from one positon to another.
async moveColumn(sSourceCol, sTargetCol, sColIndex)
{
    let sColOrderBefMove = await this.getColByColIndex(sSourceCol, sColIndex);
    let sColIdSource = this.getColId(sSourceCol);
    let sColIdTarget = this.getColId(sTargetCol);
    let objSource = by.xpath("//div[contains(@class, 'ag-header')]//div[@col-id='"+sColIdSource+"']");
    let objTarget = by.xpath("//div[contains(@class, 'ag-header')]//div[@col-id='"+sColIdTarget+"']");
    await objWrapper.elementDragDrop(objSource, objTarget, objWrapper.iDefaultTimeout);
    let sColOrderAftMove = await this.getColByColIndex(sSourceCol, sColIndex);
    if(sColOrderAftMove != sColOrderBefMove)
        sConsole = "Pass : Column '"+sSourceCol+"' moved to column '"+sTargetCol+"' position.";
    else
        sConsole = "Fail : Fail to move column '"+sSourceCol+"' to column '"+sTargetCol+"' position.";
    console.log(sConsole);
    return sConsole;
}
//Nidhi-09/03/2021 verify that 2 demo's have the same BU or not
async verifyContainsSameBU(sRowOfCol,sDemoName1,sDemoName2)
{
    let sBuRowText1,sBuRowText2;
    await this.getTableCellValue(sRowOfCol,sDemoName1).then(function(sText){sBuRowText1 = sText;});
    await this.getTableCellValue(sRowOfCol,sDemoName2).then(function(sText){sBuRowText2 = sText;});
    if(sBuRowText1 == sBuRowText2)
        sConsole = "Pass : Demo '"+sDemoName1+"' and '"+sDemoName2+"' has same BU Value.";
    else
        sConsole = "Demo '"+sDemoName1+"' and '"+sDemoName2+"' does not have same BU Value.";
    console.log(sConsole);
    return sConsole;
}
//Nidhi-09/03/2021 verify that 2 demo's have the same Status or not
async verifyContainsSameStatus(sRowOfCol,sDemoName1,sDemoName2)
{
    let sBuRowText1,sBuRowText2;
    await this.goToColumn("Demo Approval");
    await this.getTableCellValue(sRowOfCol,sDemoName1).then(function(sText){sBuRowText1 = sText;});
    await this.getTableCellValue(sRowOfCol,sDemoName2).then(function(sText){sBuRowText2 = sText;});
    if(sBuRowText1 == sBuRowText2)
        sConsole = "Pass : Demo '"+sDemoName1+"' and '"+sDemoName2+"' has same Status .";
    else
        sConsole = "Demo '"+sDemoName1+"' and '"+sDemoName2+"' does not have same status.";
    console.log(sConsole);
    return sConsole;
}
 //Nidhi-03/09/2021 Swapping of 2 row from one positon to another if they have same status and same BU 
 async moveRow(sRowOfCol1,sRowOfCol2,sDemoName1,sDemoName2)
 {
    let iRowNoSource, iRowNoTarget, sTextRow1,sTextRow2;
    
    await this.verifyContainsSameBU(sRowOfCol1,sDemoName1,sDemoName2).then(function(bRes){sTextRow1 = bRes;});
    await this.verifyContainsSameStatus(sRowOfCol2,sDemoName1,sDemoName2).then(function(bRes){sTextRow2 = bRes;});
    
    await this.getRowNoForApplicationName(sDemoName1).then(function(iRow){iRowNoSource = iRow;});
    let objSource = by.xpath("//div[@row-index='"+iRowNoSource+"']//div[@col-id='0']//div[contains(@class,'ag-row-drag')]");

    await this.getRowNoForApplicationName(sDemoName2).then(function(iRow){iRowNoTarget = iRow;});
    let objTarget = by.xpath("//div[@row-index='"+iRowNoTarget+"']//div[@col-id='0']//div[contains(@class,'ag-row-drag')]");

    if(sTextRow1.includes('Pass') && sTextRow2.includes('Pass')){
    await objWrapper.elementDragDrop(objSource, objTarget, objWrapper.iDefaultTimeout);
    sConsole = "Pass : Row Swapped sucessfully";
    }
    else{
    await objWrapper.elementDragDrop(objSource, objTarget, objWrapper.iDefaultTimeout);
    let sAlert="Row can be swapped between same BU and Status"
    expect(await this.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await this.takeActionOnAlert("OK")).toContain('Pass');

    sConsole = "Not able to swap rows : Row can be swapped between same BU and Status";
    }
    console.info(sConsole);
    return sConsole;
} 
//Nidhi-11-03-2021 will give the list of data contains by particluar col
async geColDataList(sColName)								 
{
let sColId= this.getColId(sColName)
let objSearchList = by.xpath("//div[@col-id='"+sColId+"'][@role='gridcell']");
return await objWrapper.getElementsText(objSearchList, 'List of Data Conatins by Col is').then(function(sTextList){
return sTextList; 
});
};
//Nidhi-16/03/2021 click in the table cell using the java script click element
async clickInTheTableCellUsingJavaScript(sColName,sDemoName)
{
    let  objTableCell, iRowNo, sColId;
    await this.getRowNoForApplicationName(sDemoName).then(function(iRow){iRowNo = iRow;});
    sColId = this.getColId(sColName);
    if(sColName == 'Substrate Type'||sColName == 'TAMBA Name'||sColName == 'Demo Number'||sColName == 'Other Groups'||sColName == 'Demo Requestor'||sColName == 'Demo Name'||sColName == 'BU'||sColName == 'Demo Owner' ||sColName == 'Customer Engagement')
    {
        objTableCell = by.xpath("//div[@row-index='"+iRowNo+"']//div[@role='gridcell' and @col-id='"+sColId+"']");
    }
    else
    {
        objTableCell = by.xpath("//div[@row-index='"+iRowNo+"']//div[@role='gridcell' and @col-id='"+sColId+"']//span");
    }
    return await objWrapper.javascriptClickOnElement(objTableCell, objWrapper.iDefaultTimeout).then(function(bRes){
    if(bRes)
        sConsole = "Pass : Clicked in the col'"+sColName+"'cell contains '"+sDemoName+"'.";   
    else
        sConsole = "Fail : Fail to click in the col '"+sColName+"'cell contains '"+sDemoName+"'."; 
        console.info(sConsole);
        return sConsole;
    });
}
//Switch back to the parent window
async switchtoParentTab()
 {              
    let objwinHandles = browser.getAllWindowHandles();
    objwinHandles.then(function(handles) 
    {
         let  parentWindow=handles[0];
         browser.switchTo().window(parentWindow);
    });
}
//Switch back to the new window
async switchtoNewTab() 
{              
    let objwinHandles = browser.getAllWindowHandles();
    objwinHandles.then(function(handles) 
    {
        let newWindow = handles[1];     
        browser.switchTo().window(newWindow);
    });
}
// close the current tab.
async closeTab()
{
    browser.driver.close();
}
//Nidhi-18-03-2021 verify the application header
async verifyPageHeader(sSiteName) 
{
    let objDetails = by.css("[class='app-logo']>img[alt*='"+sSiteName+"']");
    return await objWrapper.isElementDisplayed(objDetails, objWrapper.iDefaultTimeout).then(function(bRes){
    if(bRes)
        sConsole = "Pass : User is on '"+sSiteName+"'.";   
    else
        sConsole = "User is not on '"+sSiteName+"'."; 
        console.info(sConsole);
        return sConsole;
        
    });
}

    //Richa_02032021 - set value in people picker
    async setValInPeoplePicker(sFieldName, sValue)
    {
        let txtPplPicker = by.xpath("//label[contains(text(),'"+sFieldName+"')]/following-sibling::app-people-picker//input[@name='name']");
        await objWrapper.setInputValue(txtPplPicker, sValue, objWrapper.iDefaultTimeout);
        return await objWrapper.getElementAttribute(txtPplPicker, 'ng-reflect-model', objWrapper.iDefaultTimeout).then(function(sText){
            if(sText == sValue)
                sConsole = "Pass : Set '"+sFieldName+"' as '"+sValue+"'.";
            else
                sConsole = "Fail : Fail to set '"+sFieldName+"' as '"+sValue+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Richa_02032021 - select value from people picker
    async selectPeoplePickerVal(sFieldName, sValue)
    {
        expect(await this.setValInPeoplePicker(sFieldName, sValue)).toContain("Pass");
        await browser.sleep(5000);
        let lstPplPicker = by.xpath("//ul[@class='list-group']//a[contains(text(),'"+sValue+"')]/parent::li");
        await objWrapper.javascriptClickOnElement(lstPplPicker, objWrapper.iDefaultTimeout);
        let objSelectedPplPicker = by.xpath("//label[contains(text(), '"+sFieldName+"')]/following-sibling::app-people-picker//input[@name='name_hide']");
        return await objWrapper.getElementAttribute(objSelectedPplPicker, "ng-reflect-model", objWrapper.iDefaultTimeout).then(function(sText){
            if(sText.match(sValue))
                sConsole = "Pass : Clicked on '"+sFieldName+"' list option '"+sValue+"'.";
            else	
                sConsole = "Fail : Fail to click on '"+sFieldName+"' list option '"+sValue+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }
//Nidhi-23-03-2021 click on the ok on pop up
async clickOnOkBtnOnPopUp()
{  
    let objOkBtn = by.xpath("//button[contains(text(),'OK')]");
    return await objWrapper.clickOnElement(objOkBtn, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
        sConsole = "Pass : Clicked on Ok button.";   
    else
        sConsole = "Not able to click on ok button."; 
        console.info(sConsole);
        return sConsole;
    });
}
//Nidhi-23/03/2021 - Click on table cell dropdown
async clickOnDDInTableCellUsingJavaScript(sColName)
{
    let cmbDD = by.css("div[class*='ag-picker-field-wrapper']");
    return await objWrapper.javascriptClickOnElement(cmbDD, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
            sConsole ="Pass : Clicked in column '"+sColName+"' drop down.";
        else
            sConsole="Not able to click in column '"+sColName+"' drop down.";
            console.info(sConsole);
            return sConsole;
        
    });
}

//Nidhi-23/03/2021 - select the value from cell dropdown
async selectOptionFromGridDDListUsingJavaScript(sColName, sOption)
{
    let cmbDDOption = by.xpath("//div[contains(@class, 'ag-select-list')]//span[text()='"+sOption+"']|//div[contains(@class, 'ag-rich-select-list')]//div[text()='"+sOption+"']");
    return await objWrapper.javascriptClickOnElement(cmbDDOption, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
        sConsole="Pass : Selected DD option '"+sOption+"' in column '"+sColName+"'."
        else
        sConsole="Not able select DD option '"+sOption+"' in column '"+sColName+"'."
        console.info(sConsole);
        return sConsole;
      
    });
}
//Nidhi-23/03/2021 - Module to click and select value from cell dropdown
async selectOptionFromDDInTableColumn(sColName, sOption)
{
    expect(await this.clickOnDDInTableCellUsingJavaScript(sColName)).toContain("Pass");
    return await this.selectOptionFromGridDDListUsingJavaScript(sColName, sOption);
   
}									
    async setTextInTableCell(sColName, sComment)
    {
    
        let sColId = this.getColId(sColName)
        let txtComment = by.xpath("//div[@col-id='"+sColId+"']//numeric-cell//input");
        await objWrapper.setInputValue(txtComment, sComment, objWrapper.iDefaultTimeout);
        return await objWrapper.getElementAttribute(txtComment, 'value', objWrapper.iDefaultTimeout).then(function(sText){
        if(sText)
        sConsole="Pass : Entered Text for '"+sText+"' for column name '"+sColName+"."
        else
        sConsole="Fail to Enter Text for '"+sText+"' for column name '"+sColName+"."
        console.info(sConsole);
        return sConsole;
    });
    
}
    async clickOnGripIcon()
    {

        let sGripIcon = by.css("[class*='ag-row-drag']");
        return await objWrapper.javascriptClickOnElement(sGripIcon, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
            {
                console.info("Pass : clicked on Grip Icon");
                return true;
            }
            else
            {
                console.error("Not able to click on the grip icon");
                return false;
            }
        });
        
    }
    
    async clickOnDemoNumberHyperLink(sColName, sDemoName)
    {
        let iRowNo;
        let sColId = this.getColId(sColName);
        await this.getRowNoForApplicationName(sDemoName).then(function(iRow){iRowNo = iRow;});
        let objHyperLink = by.xpath("//div[@row-index='"+iRowNo+"']//div[@col-id='"+sColId+"'][contains(@style, '#13a4e8')]|//div[@row-index='"+iRowNo+"']//div[@col-id='"+sColId+"']//a");
        return await objWrapper.clickOnElement(objHyperLink, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
            sConsole = "Pass :'Clicked on Hyperlink of Demo -"+sDemoName;   
        else
            sConsole = "Failed to click on hyperlink of Demo -"+sDemoName; 
            console.info(sConsole);
     
       return sConsole;
        });
    }
	
	//Richa_05042021- get date in the uploaded details section for specific field against specified document
    async getDateTimeAgainstDocOnAttachmentsPopUp(sDocNameWithExtn)
    {   
        let tblCell = by.xpath("//h5[text()='Attachments']/parent::div/following-sibling::div//table//a[text()='"+sDocNameWithExtn+"']/parent::td/following-sibling::td[2]");
        return await objWrapper.getElementText(tblCell,objWrapper.iDefaultTimeout).then(function(sText){
            console.info("Date time value against document '"+sDocNameWithExtn+"' on Attachments pop up is "+ sText);
																			
			
																		   
								   
            return sText;
        });
        
    }
	
	//Richa_05042021 - click in table button
    async clickInTableButton(sDemoName, sBtnName)												
    {
        let objTblCell = by.xpath("//div[@col-id='demoName' and contains(text(), '"+sDemoName+"')]/preceding-sibling::div[@col-id='0']//span[@title='"+sBtnName+"']/button");
        return await objWrapper.clickOnElement(objTblCell, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Clicked in table button '"+sBtnName+"' against demo name '"+sDemoName+"'.";
															
							
			 
            else
                sConsole = "Fail : Fail to click in table button '"+sBtnName+"' against demo name '"+sDemoName+"'.";
            console.info(sConsole);
            return sConsole;
			 
        });
		
    }
    // Nidhi-12/04/2021 click on the Menu Icon on the table header coloumn
    async clickOnTableHdrMenuIcon(sColName)
    {
        let objMenuIcon = by.xpath("//span[contains(text(),'"+sColName+"')]//parent::div/parent::div/span");
        return await objWrapper.clickOnElement(objMenuIcon, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
            sConsole = "Pass :'Clicked on Table Header Menu Icon of coloumn -"+sColName;   
        else
            sConsole = "Not able to click on Table Header of Menu Icon"; 
            console.info(sConsole);
            return sConsole;
        });
    }
     // Nidhi-12/04/2021 click on the Filter Icon on the table header menu.
    async clickOnTableHdrFilterIcon()
    {
        let objFilterIcon = by.css("[class*='ag-popup']>div>span[aria-label='filter']");
        return await objWrapper.clickOnElement(objFilterIcon, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
            sConsole = "Pass :'Clicked on Table Header Menu's Filter Icon";   
        else
            sConsole = "Not able to click on TableHeader Menu's Filter Icon"; 
            console.info(sConsole);
            return sConsole;
        });
    }
//Nidhi-12/04/2021 Select the Utem from Table Header Filter Icon.
    async selectItemFromMutiSelectDD(sItemName)
    {
       
        let objItem = by.xpath("//span[contains(text(),'"+sItemName+"')]");
        return await objWrapper.clickOnElement(objItem, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
            sConsole = "Pass :Selected Item "+sItemName+" from filter DD";   
        else
            sConsole = "Not able to select item from Filter DD"; 
            console.info(sConsole);
            return sConsole;
        });
    }
 // Nidhi-12/04/2021 click on the Publish Button.
 async clickOnPublishBtn()
 {
     let objFilterIcon = by.css("button[title*='Enable Publish']");
     return await objWrapper.clickOnElement(objFilterIcon, objWrapper.iDefaultTimeout).then(function(bRes){
     if(bRes)
         sConsole = "Pass : Clicked on the publish button";   
     else
         sConsole = "Not able to click on publish button"; 
         console.info(sConsole);
         return sConsole;
     });
 }
 async verifyFieldisNotEditable(sColName, sDemoName)
    {
        let iRowNo;
        let sColId = this.getColId(sColName);
        await this.getRowIDForApplicationName(sDemoName).then(function(iRow){iRowNo = iRow;});console.log("row N "+iRowNo);
        let objHyperLink = by.xpath("//div[@row-id='"+iRowNo+"']//div[@col-id='"+sColId+"']");
        return await objWrapper.getElementAttribute(objHyperLink, "class", objWrapper.iDefaultTimeout).then(function(sValue){
            if(sValue.includes("not-inline-editing"))
            sConsole = "Fail : "+sDemoName+" field is not editable";   
        else
            sConsole = "Pass : "+sDemoName+" field is editable"; 
            console.info(sConsole);
            return sConsole;
        });
    }
    async getRowIDForApplicationName(sDemoName)
    {
        let sColId = this.getColId("Demo Name");
        let objTableCell = by.xpath("//div[@role='gridcell' and @col-id='"+sColId+"'][contains(text(),'"+sDemoName+"')]/ancestor::div[@role='row' and contains(@class,'ag-row')]");
        console.log(objTableCell);
        return await objWrapper.getElementAttribute(objTableCell, "row-id", objWrapper.iDefaultTimeout); 
    }


    async clickOnBtnOnPopup(sButtonName)
    {
        let btnSubmit = by.xpath("//div[@class='modal-body']/parent::div//button[contains(text(), '"+sButtonName+"')]");
        return await objWrapper.clickOnElement(btnSubmit, objWrapper.iDefaultTimeout).then(function(bRes){    
            if(bRes)
                sConsole = "Pass : Clicked on "+sButtonName+" button";
            else
                sConsole = "Not able to click on "+sButtonName+" button.";
            console.info(sConsole);
            return sConsole;
        });
    }
    //Nidhi-14/04/2021-Get the Table Attrbute value and compare it with the Expected Cell value
	async verifyAttributeValueInTableCell(sColName, sDemoName, sCellValue)
    {   
	
	    let  objTableCell, iRowNo, sColId;
        await this.getRowNoForApplicationName(sDemoName).then(function(iRow){iRowNo = iRow;});
        sColId = this.getColId(sColName);
        if(sColName == 'Substrate Typ'||sColName == 'Customer Wafer Destination'||sColName == 'TAMBA Name'||sColName == 'Demo Number'||sColName == 'Other Groups'||sColName == 'Demo Name'||sColName == 'Wafer Location'||sColName == 'Demo Requestor'||sColName == 'Eng.'||sColName == 'Duration (wk)'||sColName == 'BU'||sColName == 'Demo Owner' || sColName == 'Account Owner' || sColName == 'Productivity Owner'|| sColName == 'Co-Owner' || sColName == 'Account' || sColName == 'Demo Type' || sColName == 'AMAT Product')
        {
            objTableCell = by.xpath("//div[@row-index='"+iRowNo+"']//div[@role='gridcell' and @col-id='"+sColId+"']");console.log(objTableCell);
        }
        else
        {
            objTableCell = by.xpath("//div[@row-index='"+iRowNo+"']//div[@role='gridcell' and @col-id='"+sColId+"']//span");
        }
        return await objWrapper.getElementAttribute(objTableCell, "Value", objWrapper.iDefaultTimeout).then(function(sText){
            console.log(sText);
           if(sText == sCellValue)
           sConsole = "Pass : Verified value '"+sCellValue+"' in table column '"+sColName+"' against Demo name '"+sDemoName+"'";
             
            else
            sConsole = "Fail to verify value '"+sCellValue+"' in table column '"+sColName+"' against demo name '"+sDemoName+"'.";
            console.info(sConsole);
            return sConsole;
            
        }); 
    }
    ////Nidhi-14/04/202- Verify Expected Cell value is present or not
    async verifyTextValueInTableCell(sColName, sDemoName, sCellValue)
    {   
	
	    let  objTableCell, iRowNo, sColId;
        await this.getRowNoForApplicationName(sDemoName).then(function(iRow){iRowNo = iRow;});
        sColId = this.getColId(sColName);

        try{
        if(sColName == 'Substrate Type'||sColName == 'Customer Wafer Destination'||sColName == 'TAMBA Name'||sColName == 'Demo Number'||sColName == 'Other Groups'||sColName == 'Demo Name'||sColName == 'Wafer Location'||sColName == 'Demo Requestor'||sColName == 'Eng.'||sColName == 'Duration (wk)'||sColName == 'BU'||sColName == 'Demo Owner' || sColName == 'Account Owner' || sColName == 'Productivity Owner'|| sColName == 'Co-Owner' || sColName == 'Account' || sColName == 'Demo Type' || sColName == 'AMAT Product'|| sColName == 'Wafer Available in Lab' || sColName == 'CAT/RAT Manager' || sColName == 'KPU Head/GPM' || sColName == "Customer Wafer Destination" ||sColName == 'Customer Engagement' ||  sColName == 'CIP HW Shipment Target' || sColName == 'Schedule to close the DPY Gaps' ||  sColName == 'Risk/Gap Description' ||  sColName == 'Risk/Gap Closure Plan' || sColName == 'IO#/ Cost Center' ||  sColName == 'Team Member'||  sColName == 'Demo Location')
        {
            objTableCell = by.xpath("//div[@row-index='"+iRowNo+"']//div[@role='gridcell' and @col-id='"+sColId+"' and contains(text(),'"+sCellValue+"')]");
        }
        else
        {
            objTableCell = by.xpath("//div[@row-index='"+iRowNo+"']//div[@role='gridcell' and @col-id='"+sColId+"']//span[contains(text(),'"+sCellValue+"')]")
        }
        return objWrapper.isElementPresent(objTableCell, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
        sConsole = "Pass : Verified value '"+sCellValue+"' in table column '"+sColName+"' against Demo name '"+sDemoName+"'"; 
        else
        sConsole = "Fail to verify value '"+sCellValue+"' in table column '"+sColName+"' against demo name '"+sDemoName+"'.";
        console.info(sConsole);
        return sConsole;
        });
    }
    catch(exception){
        console.log("Fail to verify value '"+sCellValue+"' in table column '"+sColName+"' against demo name '"+sDemoName+"'.");
            return null;
    }
    
    }

    async getShippingInfoCountfromTableCell(sDemoName)
    {
        try{
        let  objTableCell, iRowNo, sColId;
        await this.getRowNoForApplicationName(sDemoName).then(function(iRow){iRowNo = iRow;});
        objTableCell = by.xpath("//div[@row-index='"+iRowNo+"']//div[@role='gridcell' and @col-id='shippingInfoCount']//mark");
       
        return await objWrapper.getElementText(objTableCell, objWrapper.iDefaultTimeout).then(function(sText){
            console.info("Count on Shipment Truck against application name '"+sDemoName+"' is '"+sText+"'.");
            return sText;
        });
        }
        catch(exception){
            console.log("Error while getting shipment Truck count for '"+sDemoName+"'" + exception);
                return null;
        }
    
    }

    //Namrata-23/04/2021-Get the specified Table Attrbute value and compare it with the Expected Cell value
	async verifySpecificAttributeValueInTableCell(sColName, sDemoName, sAttrValue, sCellValue)
    {   
	
	    let  objTableCell, iRowNo, sColId;
        await this.getRowNoForApplicationName(sDemoName).then(function(iRow){iRowNo = iRow;});
        sColId = this.getColId(sColName);
        if(sColName == 'Demo Type' || sColName == 'AMAT Product')
        {
            objTableCell = by.xpath("//div[@row-index='"+iRowNo+"']//div[@role='gridcell' and @col-id='"+sColId+"']");
        }
        else
        {
            objTableCell = by.xpath("//div[@row-index='"+iRowNo+"']//div[@role='gridcell' and @col-id='"+sColId+"']/span/span");
        }
        return await objWrapper.getElementAttribute(objTableCell, sAttrValue, objWrapper.iDefaultTimeout).then(function(sText){
            console.log(sText);
           if(sText == sCellValue)
            sConsole = "Verified value '"+sCellValue+"' in table column '"+sColName+"' against Demo name '"+sDemoName+"'";
             
            else
            sConsole = "Fail to verify value '"+sCellValue+"' in table column '"+sColName+"' against demo name '"+sDemoName+"'.";
            console.info(sConsole);
            return sConsole;
            
        }); 
    }

    async selectDateFromCalendarTable(sDay, sMonth, sYear)
    {
        let monthNo =-1;
        expect(await this.selectCalendarYear(sYear)).toContain("Pass");
        expect(await this.selectCalendarMonth(sMonth)).toContain("Pass");
        monthNo = fullMonthNames.indexOf(sMonth)-1;
        if(monthNo==-1)
         monthNo = halfMonthNames.indexOf(sMonth)-1; 
        
        let objDay = by.xpath("//td[@data-month='"+monthNo+"']/a[text()='"+sDay+"']");
        return await objWrapper.clickOnElement(objDay, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Selected date '"+sDay+"'.";           
            else
                sConsole = "Fail : Fail to select date '"+sDay+"'";
            console.info(sConsole);
            return sConsole;
        });
    }

    //Pass sDate as Today, Tomorrow, Yesterday
    async selectDateFromCalendarInTable(sDate)
    {
        if(sDate == "" || sDate == "Today")
        {
            await objWrapper.sendKeysInActiveElmnt("Enter");
        }
        else if(sDate=="Next" || sDate=="Tomorrow" )
        {
           let nextDate;
           await this.getDt("Tomorrow","dd/mm/yyyy", false).then(function(sDate){nextDate=sDate;});           
           let dateSplit = nextDate.split("/");          
            await this.selectDateFromCalendarTable(dateSplit[0], fullMonthNames[dateSplit[1]], dateSplit[2]);
        }
        else if(sDate.includes("Next_HalfMonth") || sDate.includes("Tomorrow_HalfMonth"))
        {
           let nextDate;
           await this.getDt("Tomorrow","dd/mm/yyyy", false).then(function(sDate){nextDate=sDate;});           
           let dateSplit = nextDate.split("/");console.info("hh"+halfMonthNames[dateSplit[1]]);
           await this.selectDateFromCalendarTable(dateSplit[0], halfMonthNames[dateSplit[1]], dateSplit[2]);
        }
    }

    async setTextInTableCellTextarea(sComment)
    {   

        let txtComment = by.xpath("//textarea[@ref='eInput']");
        return await objWrapper.setInputValue(txtComment, sComment, objWrapper.iDefaultTimeout).then(async function(bRes){
        if(bRes)
         sConsole="Pass : Entered Text for '"+sComment+"' in textarea.";
        else
         sConsole="Fail to Enter Text for '"+sComment+"' in textarea";
         await objWrapper.sendKeysInActiveElmnt("Enter");
        console.info(sConsole);
        return sConsole;
    });
    
}

async getDt(sTodayTomYest, dateFormat, isSingleDigit)
    {
        let sDt;
        var sDate ;
        let dd, mm, yyyy, hh, mins;
        if(sTodayTomYest == "Today")
        {
            sDate = new Date();
            
        }      
        else if(sTodayTomYest == "Yesterday")
        {
            sDate = new Date(new Date().getTime() - 24 * 60 * 60 * 1000);
        }
              
        else if (sTodayTomYest == "Tomorrow")
        {
            sDate = new Date(new Date().getTime() + 24 * 60 * 60 * 1000);
        }
 
        dd = sDate.getDate();
        mm = sDate.getMonth()+1; 
        yyyy = sDate.getFullYear();
        hh = sDate.getHours();
        mins = sDate.getMinutes();
        let dd_str,mm_str,hh_str,mins_str;
 
        if(dd<10 && isSingleDigit==false) 
            dd_str = '0'+dd;
        else
            dd_str = dd.toString();
        
        if(mm<10) 
            mm_str = '0'+mm;
        else
            mm_str = mm.toString();

        hh_str = hh.toString();

        if (mins < 10) 
            mins_str = "0" + mins;
        else
            mins_str = mins.toString();          
 
        switch(dateFormat)
        {
            case "mm-dd-yyyy":
                    sDt = mm_str+'-'+dd_str+'-'+yyyy;
                    console.log(sDt);
                    break;
 
            case "mm/dd/yyyy" :
                    sDt = mm_str+'/'+dd_str+'/'+yyyy;
                    console.log(sDt);
                    break;
                    
            case "mm/dd/yyyy hh:mins" :
                    sDt = mm_str+'/'+dd_str+'/'+yyyy+' '+hh_str+':'+mins_str;
                    console.log(sDt);
                    break;
            default :
                    sDt = dd+'/'+mm+'/'+yyyy;
                    console.log(sDt);
                    break;
        }
        return sDt;
    }


    async sendKeysInDateTypeTableCell(sColName,sDemoName,skeys)
    {
        let  objTableCell, iRowNo, sColId;
        await this.getRowNoForApplicationName(sDemoName).then(function(iRow){iRowNo = iRow;});
        sColId = this.getColId(sColName);
        objTableCell = by.xpath("//div[@row-index='"+iRowNo+"']//div[@role='gridcell' and @col-id='"+sColId+"']/input");console.log(objTableCell);
       
       
        return await objWrapper.clickOnElement(objTableCell, objWrapper.iDefaultTimeout).then(async function(bRes){
        if(bRes)
        {
            let keysList =skeys.split("~");
            for(var i=0; i<keysList.length; i++)
                await objWrapper.sendKeysInActiveElmnt(keysList[i]);   
            sConsole = "Pass : Pressed key "+skeys+"' in cell contains Demo Name '"+sDemoName+"'.";  
               
        }  
        else
        sConsole = "Not able to click in the col '"+sColName+"'cell contains Demo Name'"+sDemoName+"'."; 
            console.info(sConsole);
            return sConsole;
        });
      
    }
    
    async removeSelectedPeople(sFieldName, sUserName)
    {      
       
        let objSelectedPpl= by.xpath("//label[contains(text(), '"+sFieldName+"')]/following-sibling::app-people-picker//li[text()=' "+sUserName+" ']//a[text()='x']");
        await objWrapper.clickOnElement(objSelectedPpl,  objWrapper.iDefaultTimeout);
        let objSelectedPplXpath = by.xpath("//label[contains(text(), '"+sFieldName+"')]/following-sibling::app-people-picker//ul");
        return await objWrapper.getElementText(objSelectedPplXpath, objWrapper.iDefaultTimeout).then(function(sText){
            if(sText.includes(sUserName))
                 sConsole = "Fail : Fail to click remove  user '"+sUserName+"' from '"+sFieldName+"'.";               
            else	
                sConsole = "Pass : Removed User '"+sUserName+"' from'"+sFieldName+"'.";
            console.info(sConsole);
            return sConsole;
        });
    }
	
    //Nidhi-05/05/2021 - Select requestor in secondary BU table
    async selectRequestorInSecBUTbl(sRequestorInit,sRequestor)
    {
        let objTblRows = by.xpath("//table[@class='table table-striped top_priority mb-3 mt-1']/tbody//tr");
        let iRowCount = await objWrapper.getWebelementCount(objTblRows).then(function(sText){console.log(sText); return sText;});
        let txtTblRequestor = by.xpath("//table[@class='table table-striped top_priority mb-3 mt-1']//tr["+iRowCount+"]//td[3]//input");
        await objWrapper.setInputCharByChar(txtTblRequestor, sRequestorInit, objWrapper.iDefaultTimeout);
        await browser.sleep(objWrapper.iMaxTimeout);
        let lstRequestorOpt = by.xpath("//div[@class='completer-dropdown']//span[@class='completer-list-item' and text()='"+sRequestor+"']");
        return await objWrapper.clickOnElement(lstRequestorOpt, objWrapper.iDefaultTimeout).then(function(bRes){
            if(bRes)
                sConsole = "Pass : Selected Requestor as '"+sRequestor+"' in table.";
            else
                sConsole = "Fail : Fai to select Requestor as '"+sRequestor+"' in table.";
            console.info(sConsole);
            return sConsole;
        });
    }

async clickInTheTableCellWithoutJavascript(sColName,sDemoName)															  
    {
        let  objTableCell, iRowNo, sColId;
        await this.getRowNoForApplicationName(sDemoName).then(function(iRow){iRowNo = iRow;});
        sColId = this.getColId(sColName);
        if(sColName == 'Wafer Type'||sColName == 'Substrate Type'||sColName == 'Customer Wafer Destination'||sColName == 'TAMBA Name'||sColName == 'Other Groups'||sColName == 'Demo Name'||sColName == 'Current Execution Risk'||sColName == 'Wafer Location'||sColName == 'Demo Requestor'||sColName == 'Eng.'||sColName == 'Duration (wk)'||sColName == 'BU'||sColName == 'Demo Owner' || sColName == 'Account Owner' || sColName == 'Productivity Owner'|| sColName == 'Co-Owner' || sColName == 'Account' || sColName == 'Demo Type' || sColName == 'AMAT Product' || sColName == 'Execution Risk'|| sColName == 'Demo Completion'|| sColName == 'Wafer Available in Lab'|| sColName == 'Team Member'|| sColName == 'Customer Engagement' || sColName == 'CIP HW Shipment Target' || sColName == 'Schedule to close the DPY Gaps' || sColName == 'Risk/Gap Description' || sColName == 'Risk/Gap Closure Plan' || sColName == 'Demo Issues' || sColName == 'Team Member' || sColName == 'CAT/RAT Manager' || sColName == 'KPU Head/GPM')
		 
            objTableCell = by.xpath("//div[@row-index='"+iRowNo+"']//div[@role='gridcell' and @col-id='"+sColId+"']");
        else if(sColName == 'Demo Number')
        {
            objTableCell = by.xpath("//div[@row-index='"+iRowNo+"']//div[@role='gridcell' and @col-id='"+sColId+"']//a");
            await objWrapper.isElementPresent(objTableCell, objWrapper.iDefaultTimeout).then(function(bRes){
                if(!bRes)
                    objTableCell = by.xpath("//div[@row-index='"+iRowNo+"']//div[@role='gridcell' and @col-id='"+sColId+"']");
            })
        }																																															  
        else
        {
            objTableCell = by.xpath("//div[@row-index='"+iRowNo+"']//div[@role='gridcell' and @col-id='"+sColId+"']//span");
        }
        return await objWrapper.clickOnElement(objTableCell, objWrapper.iDefaultTimeout).then(function(bRes){
        if(bRes)
			sConsole = "Pass : Clicked in the col'"+sColName+"'cell contains Demo Name '"+sDemoName+"'.";  
        else
			sConsole = "Not able to click in the col '"+sColName+"'cell contains Demo Name'"+sDemoName+"'."; 
		console.info(sConsole);
		return sConsole;
	});
}

}

