import {browser, element, ExpectedConditions, by} from 'protractor';
import {homePage} from '../../pages/homePage.po';
import { commonPage } from '../../pages/commonPage.po';
import { newDemoRequest } from '../../pages/newDemoRequest.po';
import { myDraftRequestPage } from '../../pages/myDraftRequestPage.po';
import { myDemoRequestPage } from '../../pages/myDemoRequestPage.po';
import { dataProvider} from "../../data/dataProvider";
import { loginPage } from '../../pages/loginPage.po';
import { allViewPage } from '../../pages/allViewPage.po';
import{ adminAccessViewPage } from '../../pages/adminAccessViewPage.po';
import { excelWrapper } from '../../utils/excel.util';
import { allRequestPage } from '../../pages/allRequestPage.po';
import { demoDetailsPage } from '../../pages/demoDetailsPage.po';
import {grantDemoAccessPage } from '../../pages/grantDemoAccessPage.po';
import { wrapper } from '../../utils/wrapper.util';
import { Console } from 'console';
import { win32 } from 'path';
import * as cp from 'child_process';
import { approvalsPage } from '../../pages/approvalsPage.po';
import { outlookPage } from '../../pages/outlookPage.po';
import { clearScreenDown } from 'readline';

describe('All View Page Test cases', () => {
    const path = win32;
    let objHomePage:homePage;
    let objNewDemoRequest:newDemoRequest;
    let objMyDraftRequest:myDraftRequestPage;
    let objCommonPage: commonPage;
    let objMyDemoRequest: myDemoRequestPage;
    let objDemoDetailsPage: demoDetailsPage;
    let objLoginPage:loginPage;
    let objAllViewPage:allViewPage;
    let objGrantDemoAccessPage:grantDemoAccessPage;
    let objadminAccessViewPage:adminAccessViewPage;
    let objExcelWrapper:excelWrapper;
    let objAllRequestPage: allRequestPage;
    let objOutlookPage : outlookPage;
    let objApprovalsPage: approvalsPage;
    let objWrapper:wrapper;
    let objLoginData = dataProvider.getJsonData("./data/login.json", "login");
    let sDemoName , sDemoNameALD
    let sAlertMessage = "", sViewNm;
    

    beforeEach(async () => {
       
        objHomePage = new homePage();
        objNewDemoRequest = new newDemoRequest();
        objMyDraftRequest = new myDraftRequestPage();
        objCommonPage = new commonPage();
        objMyDemoRequest = new myDemoRequestPage();
        objLoginPage = new loginPage();
        objAllViewPage = new allViewPage();
        objExcelWrapper = new excelWrapper();
        objadminAccessViewPage= new adminAccessViewPage();
        objDemoDetailsPage = new demoDetailsPage();
        objWrapper = new wrapper();
        objAllRequestPage = new allRequestPage();
        objGrantDemoAccessPage = new grantDemoAccessPage();
        objApprovalsPage = new approvalsPage();
        objOutlookPage= new outlookPage();
        
        await browser.waitForAngularEnabled(false);
        //Open application Url
        await objHomePage.openApplication('/');        
    });

    afterEach(() => {
        
    });
it('TC_Pre-Requisite.', async(done)=>{
         let objData = dataProvider.getJsonData("./data/allView.json", "TC_Pre-Requisite");
         console.log(objData);
         //Login My Demo application
         expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
         expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
         expect(await objLoginPage.clickLogin()).toContain("Pass");
         await browser.waitForAngularEnabled(true);
         expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
         //select menu option
         expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
         expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
         expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
         expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
       
         var iRandomNum = Math.floor(1000 + Math.random() * 9000);
         sDemoName = "TestDemo_AllView" + iRandomNum;
         console.log(sDemoName);
 
         expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
         expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
       
         expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
         expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
         expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
         expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
         expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
         expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
         expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
         expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
        
         expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
         expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
         expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

         let sLoggedInUser;
         await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
         expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
         expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
         expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
         expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
         expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
         expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
         expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
      
         //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
         expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
         expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
         expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
         expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
         expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");
         browser.sleep(50000);
         expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
         expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');
         done();
}); 
it('TC_01-Verify that user shall be to launch All View page successfully and UI Components shall load as expected.', async(done)=>{
        let objData = dataProvider.getJsonData("./data/allView.json", "TC_01");
        console.log(objData);
        let sLoggedInUser;
        //BU Super User Check publish button visible
        expect(await objLoginPage.setUserName(objLoginData.userNameBUSuperUser)).toContain('Pass');
        expect(await objLoginPage.setPassword(objLoginData.passwordBUSuperUser)).toContain('Pass');
        expect(await objLoginPage.clickLogin()).toContain('Pass');
        await browser.waitForAngularEnabled(true);
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        expect(await objCommonPage.verifyPublishBtnPresent()).toContain("Pass");
        //Other User Check publish button not visible
        await browser.waitForAngularEnabled(false);
        await objHomePage.openApplication('/'); 
        expect(await objLoginPage.setUserName(objLoginData.userNameBUExecutiveUser)).toContain('Pass');
        expect(await objLoginPage.setPassword(objLoginData.passwordBUExecutiveUser)).toContain('Pass');
        expect(await objLoginPage.clickLogin()).toContain('Pass');
        await browser.waitForAngularEnabled(true);
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        expect(await objCommonPage.verifyPublishBtnPresent()).not.toContain("Pass");
        //Global Admin User Check publish button visible
        await browser.waitForAngularEnabled(false);
        await objHomePage.openApplication('/'); 
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
        expect(await objLoginPage.clickLogin()).toContain('Pass')
        await browser.waitForAngularEnabled(true);
        expect(await objHomePage.verifyHomePageDisplayed()).toContain('Pass');
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        expect(await objCommonPage.verifyPublicPersonalViewDDIsPresent()).toContain('Pass');
        expect(await objCommonPage.verifyStatusDDIsPresentWithDefVal("Active")).toContain('Pass');
        expect(await objCommonPage.verifyGoToDDIsPresentWithDefVal("")).toContain('Pass');
        expect(await objCommonPage.verifySearchTextBoxIsPresent()).toContain('Pass');
        expect(await objCommonPage.verifyPublishBtnPresent()).toContain("Pass");
        expect(await objCommonPage.verifyExportBtnPresent()).toContain("Pass");
        expect(await objCommonPage.verifyCustomizedViewBtnIsPresent()).toContain("Pass");
        done();
});
it('TC_02-"Verify that user shall be able to view required column in the grid using Goto drodpown on All View page.', async(done)=>{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_02");
    console.log(objData);
    let sLoggedInUser;
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain('Pass')
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain('Pass');
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    //let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    expect(await objCommonPage.verifyStatusDDIsPresentWithDefVal("Active")).toContain('Pass');
    expect(await objAllViewPage.selectStatusOption("ALL Status")).toContain('Pass');
    expect(await objCommonPage.searchRequest("TestDemo_7695")).toContain('Pass');
    expect(await objAllViewPage.verifyDemoStatusInGrid("TestDemo_7695","ACL-Approved")).toContain('Pass');
    expect(await objCommonPage.searchRequest("TestDemo_2441")).toContain('Pass');
    expect(await objAllViewPage.verifyDemoStatusInGrid("TestDemo_2441","BCL-On Hold")).toContain('Pass');
    expect(await objCommonPage.searchRequest("TestDemo_1621")).toContain('Pass');
    expect(await objAllViewPage.verifyDemoStatusInGrid("TestDemo_1621","New Request")).toContain('Pass'); 
    expect(await objAllViewPage.clickOnStatusDD()).toContain('Pass');
    expect(await objAllViewPage.getStatusOptions()).toContain(objData.statusOptions);
    //expect(await objAllViewPage.selectStatusOption("ALL Status")).toContain('Pass');
    expect(await objAllViewPage.selectStatusFromStatusDD("Active")).toContain('Pass');
    expect(await objAllViewPage.selectStatusFromStatusDD("ACL - Approved")).toContain('Pass');
    expect(await objAllViewPage.selectStatusFromStatusDD("BCL - On Hold")).toContain('Pass');
    expect(await objAllViewPage.selectStatusFromStatusDD("New Request")).toContain('Pass');
    expect(await objAllViewPage.selectStatusFromStatusDD("Rejected")).toContain('Pass');
    expect(await objAllViewPage.selectStatusFromStatusDD("Cancelled")).toContain('Pass');
    expect(await objAllViewPage.selectStatusFromStatusDD("Closed")).toContain('Pass');
    done();  
});
it('TC_03-"Verify that user shall be able to view required column in the grid using Goto drodpown on All View page.', async(done)=>{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_03");
    console.log(objData);
    let sLoggedInUser;
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain('Pass')
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain('Pass');
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    //let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    expect(await objCommonPage.verifyGoToDDIsPresentWithDefVal("")).toContain('Pass');
    expect(await objCommonPage.clickOnGoToDD()).toContain('Pass');
    expect(await objCommonPage.getGoToOptionsList()).toContain(objData.goToOptions);
    expect(await objCommonPage.selectOptionFromGoToDDList("Account Adoption Prob %")).toContain("Pass");
    expect(await objCommonPage.verifyTableHeaderIsPresent("Account Adoption Prob %")).toContain("Pass");
    done();  
});
it('TC_04-"Verify that user shall be able to search required content using Search Field on All View.', async(done)=>{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_04");
    console.log(objData);
    let sLoggedInUser;
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain('Pass')
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain('Pass');
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    //let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    expect(await objCommonPage.verifyStatusDDIsPresentWithDefVal("Active")).toContain('Pass');
    console.log("Default Grid View before entering Search text");
    await objCommonPage.getTheLatestDemoNm();
    //Search Entred
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.getSearchResults(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.clearSearchText()).toContain('Pass');
    expect(await objCommonPage.clickOnSearch()).toContain('Pass');
    console.log("Default Grid View After Clearing Entered Search Text");
    await objCommonPage.getTheLatestDemoNm();
    done();  
});
it('TC_05-"Verify that user shall be able to export all the data present on the All View Grid in an Excel report using Export Button.', async(done)=>{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_05");
    console.log(objData);
    let sLoggedInUser;
    const os = require('os'); 
    const sDownloadPath = os.homedir()+"/Downloads/";
    await objCommonPage.deleteFileFromDownloadsDir(sDownloadPath + objData.excelFileName +".xlsx"); 
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain('Pass')
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain('Pass');
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    //let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objCommonPage.clickExportButton('All View')).toContain('Pass');
    await browser.sleep(5000);
    expect(await objExcelWrapper.readExcelHeader(sDownloadPath + objData.excelFileName +".xlsx", objData.excelFileSheetName)).toContain(objData.excelHeaderList);
    done();  
});
it('TC_06-"Verify that user shall be able to create more than one customize view on All View using Customize View Button.', async (done)=>
    {
        let objData = dataProvider.getJsonData("./data/allView.json", "TC_06");
        console.log(objData);
        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sViewNm = "TestView"+ iRandomNum;
        console.log(sViewNm);

       //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");
        await browser.waitForAngularEnabled(true);
        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
        expect(await objAllViewPage.verifyUniqueViewName(sViewNm)).toContain("Pass");
        expect(await objAllViewPage.clickOnCustomizedBtn()).toContain('Pass');
        expect(await objCommonPage.verifyAlertHeader("All View")).toContain('Pass');
        expect(await objAllViewPage.VerifyActiveTabOnCustomizedView("Create")).toContain('Pass');
        expect(await objAllViewPage.verifyBtnIsDisabledOnCustomizedView("Create")).toContain('Pass');
        expect(await objAllViewPage.setViewNameOnCustomizedView(sViewNm)).toContain('Pass');
        let sColList = (objData.availableColsSelection).split("~");
        for(var iCount = 0; iCount < sColList.length; iCount++)
        {
            expect(await objAllViewPage.selectFromSelectedAvailableColList("Available Columns", sColList[iCount])).toContain('Pass');
            expect(await objAllViewPage.addColInSelectedColumnList()).toContain('Pass');
        }
        let sSelectedColList = await objAllViewPage.getSelectedColList();
        expect(await objAllViewPage.verifyBtnIsDisabledOnCustomizedView("Create")).not.toContain('Pass');
        expect(await objAllViewPage.clickBtnOnCustomizedView("Create")).toContain('Pass')
        let sAlert="Successfully created "+sViewNm+" view"
        expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
        expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
        // expect(await objAllViewPage.verifyViewSelectedOnPage(sViewNm)).toContain('Pass');
        expect(await objAllViewPage.getUnpingedColHeaders()).toEqual(sSelectedColList);
        done();
});
it('TC_07-"Verify that user shall be able to able to update customize view on All View using Customize View Button.', async (done)=>
    {
        let objData = dataProvider.getJsonData("./data/allView.json", "TC_07");
        console.log(objData);
       //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");
        await browser.waitForAngularEnabled(true);
        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
        expect(await objAllViewPage.clickOnCustomizedBtn()).toContain('Pass');
        expect(await objCommonPage.verifyAlertHeader("All View")).toContain('Pass');
        expect(await objAllViewPage.clickTabOnCustomizedViewPopUp("Update")).toContain('Pass')
        expect(await objAllViewPage.VerifyActiveTabOnCustomizedView("Update")).toContain('Pass');
        expect(await objAllViewPage.verifyBtnIsDisabledOnCustomizedView("Update")).toContain('Pass');
        expect(await objAllViewPage.selectViewToUpdateCustomizedViewPopUP(sViewNm,"Update View")).toContain('Pass');
        let sAvailableColList = (objData.availableColsSelection).split("~");
        for(var iCount = 0; iCount < sAvailableColList.length; iCount++)        {
            expect(await objAllViewPage.selectFromSelectedAvailableColList("Available Columns", sAvailableColList[iCount])).toContain('Pass');
            expect(await objAllViewPage.addColInSelectedColumnList()).toContain('Pass');
            expect(await objAllViewPage.verifyColPresentInSelectedAvailableColList("Selected Columns", sAvailableColList[iCount])).toContain('Pass');
        }
        let sColList = (objData.selectedColsSelection).split("~");
        for(var iCount = 0; iCount < sColList.length; iCount++)
        {
            expect(await objAllViewPage.selectFromSelectedAvailableColList("Selected Columns", sColList[iCount])).toContain('Pass');
            expect(await objAllViewPage.removeColFromSelectedColumnList()).toContain('Pass');
            expect(await objAllViewPage.verifyColPresentInSelectedAvailableColList("Available Columns", sColList[iCount])).toContain('Pass');
        }
        expect(await objAllViewPage.verifyBtnIsDisabledOnCustomizedView("Update")).not.toContain('Pass');
        expect(await objAllViewPage.clickBtnOnCustomizedView("Update")).toContain('Pass');
        sAlertMessage = "Successfully updated "+sViewNm+" view";
        expect(await objCommonPage.verifyAlertMessage(sAlertMessage)).toContain('Pass');
        expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
        done();
});
it('TC_08-"Verify that when user login as Global Admin in My Demo QA then he/she shall be able to see All Demos from All the BUs in the Grid of All View Page(ALD).', async (done)=>
    {
        let objData = dataProvider.getJsonData("./data/allView.json", "TC_08");
         console.log(objData);
         //Login My Demo application
         expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
         expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
         expect(await objLoginPage.clickLogin()).toContain("Pass");
         await browser.waitForAngularEnabled(true);
         expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
         //select menu option
         expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
         expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
         expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
         expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
       
         var iRandomNum = Math.floor(1000 + Math.random() * 9000);
         sDemoNameALD = "TestDemo_AllView" + iRandomNum;
         console.log(sDemoNameALD);
 
         expect(await objNewDemoRequest.enterDemoName(sDemoNameALD)).toContain("Pass");
         expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
       
         expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
         expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
         expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
         expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
         expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
         expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
         expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
         expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
        
         expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
         expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
         expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

         let sLoggedInUser;
         await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
         expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
         expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
         expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
         expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
         expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
         expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
         expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
      
         //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
         expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
         expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
         expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
         expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
         expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");
         browser.sleep(50000);
         expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
         expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');
         done();

        //Checking Data for ALD BU.
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
        expect(await objCommonPage.searchRequest(sDemoNameALD)).toContain('Pass');
        expect(await objCommonPage.geColDataList("BU")).toContain("BU~ALD");
        expect(await objAllViewPage.clearSearchText()).toContain('Pass');
        done();
});
it('TC_08_1-"Verify that when user login as Global Admin in My Demo QA then he/she shall be able to see All Demos from All the BUs in the Grid of All View Page.(DCVD)', async (done)=>
    {
        let objData = dataProvider.getJsonData("./data/allView.json", "TC_08_1");
         console.log(objData);
         //Login My Demo application
         expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
         expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
         expect(await objLoginPage.clickLogin()).toContain("Pass");
         await browser.waitForAngularEnabled(true);
         expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
         //select menu option
         expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
         expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
         expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
         expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
       
         var iRandomNum = Math.floor(1000 + Math.random() * 9000);
         sDemoName = "TestDemo_AllView" + iRandomNum;
         console.log(sDemoName);
 
         expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
         expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
       
         expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
         expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
         expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
         expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
         expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
         expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
         expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
         expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
        
         expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
         expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
         expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

         let sLoggedInUser;
         await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
         expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
         expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
         expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
         expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
         expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
         expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
         expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
      
         //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
         expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
         expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
         expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
         expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
         expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");
         expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
         expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');
         done();

        //Checking Data for ALD BU.
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
        expect(await objCommonPage.geColDataList("BU")).toContain("BU~DCVD");
        expect(await objAllViewPage.clearSearchText()).toContain('Pass');
        done();
});
it('TC_08_2-"Verify that when user login as Global Admin in My Demo QA then he/she shall be able to see All Demos from All the BUs in the Grid of All View Page.(ETCH)', async (done)=>
    {
        let objData = dataProvider.getJsonData("./data/allView.json", "TC_08_2");
         console.log(objData);
         //Login My Demo application
         expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
         expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
         expect(await objLoginPage.clickLogin()).toContain("Pass");
         await browser.waitForAngularEnabled(true);
         expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
         //select menu option
         expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
         expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
         expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
         expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
       
         var iRandomNum = Math.floor(1000 + Math.random() * 9000);
         sDemoName = "TestDemo_AllView" + iRandomNum;
         console.log(sDemoName);
 
         expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
         expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
       
         expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
         expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
         expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
         expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
         expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
         expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
         expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
         expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
        
         expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
         expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
         expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

         let sLoggedInUser;
         await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
         expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
         expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
         expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
         expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
         expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
         expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
         expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
      
         //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
         expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
         expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
         expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
         expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
         expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");
         expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
         expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');
         done();

        //Checking Data for ALD BU.
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
        expect(await objCommonPage.geColDataList("BU")).toContain("BU~Etch");
        expect(await objAllViewPage.clearSearchText()).toContain('Pass');
        done();
});
it('TC_08_3-"Verify that when user login as Global Admin in My Demo QA then he/she shall be able to see All Demos from All the BUs in the Grid of All View Page.(SRP)', async (done)=>
    {
        let objData = dataProvider.getJsonData("./data/allView.json", "TC_08_3");
         console.log(objData);
         //Login My Demo application
         expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
         expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
         expect(await objLoginPage.clickLogin()).toContain("Pass");
         await browser.waitForAngularEnabled(true);
         expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
         //select menu option
         expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
         expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
         expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
         expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
       
         var iRandomNum = Math.floor(1000 + Math.random() * 9000);
         sDemoName = "TestDemo_AllView" + iRandomNum;
         console.log(sDemoName);
 
         expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
         expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
       
         expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
         expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
         expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
         expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
         expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
         expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
         expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
         expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
        
         expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
         expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
         expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

         let sLoggedInUser;
         await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
         expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
         expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
         expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
         expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
         expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
         expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
         expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
      
         //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
         expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
         expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
         expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
         expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
         expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");
         expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
         expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');
         done();

        //Checking Data for ALD BU.
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
        expect(await objCommonPage.geColDataList("BU")).toContain("BU~SRP");
        expect(await objAllViewPage.clearSearchText()).toContain('Pass');
        done();
});
it('TC_08_4-"Verify that when user login as Global Admin in My Demo QA then he/she shall be able to see All Demos from All the BUs in the Grid of All View Page.', async (done)=>
    {
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_08_4");
        console.log(objData);
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");
        await browser.waitForAngularEnabled(true);
        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
         
       //Checking Data for CMP BU.
       expect(await objCommonPage.searchRequest(objData.demoCMP)).toContain('Pass');
       expect(await objAllViewPage.verifyBuInGridAsPerAccess(objData.demoCMP,"BU",objData.buList)).toContain('Pass');
       expect(await objAllViewPage.clearSearchText()).toContain('Pass');
  
       //Checking Data for EPG BU.
       expect(await objCommonPage.searchRequest(objData.demoEPG)).toContain('Pass');
       expect(await objAllViewPage.verifyBuInGridAsPerAccess(objData.demoEPG,"BU",objData.buList)).toContain('Pass');
       expect(await objAllViewPage.clearSearchText()).toContain('Pass');
       //Checking Data for EPI BU.
       expect(await objCommonPage.searchRequest(objData.demoEPI)).toContain('Pass');
       expect(await objAllViewPage.verifyBuInGridAsPerAccess(objData.demoEPI,"BU",objData.buList)).toContain('Pass');
       expect(await objAllViewPage.clearSearchText()).toContain('Pass')
       
       //Checking Data for FEP BU.
       expect(await objCommonPage.searchRequest(objData.demoFEP)).toContain('Pass');
       expect(await objAllViewPage.verifyBuInGridAsPerAccess(objData.demoFEP,"BU",objData.buList)).toContain('Pass');
       expect(await objAllViewPage.clearSearchText()).toContain('Pass');
       //Checking Data for MDP BU.
       expect(await objCommonPage.searchRequest(objData.demoMDP)).toContain('Pass');
       expect(await objAllViewPage.verifyBuInGridAsPerAccess(objData.demoMDP,"BU",objData.buList)).toContain('Pass');
       expect(await objAllViewPage.clearSearchText()).toContain('Pass');
       //Checking Data for METALSPKG BU.
       expect(await objCommonPage.searchRequest(objData.demoMETALSPKG)).toContain('Pass');
       expect(await objAllViewPage.verifyBuInGridAsPerAccess(objData.demoMETALSPKG,"BU",objData.buList)).toContain('Pass');
       expect(await objAllViewPage.clearSearchText()).toContain('Pass');
       //Checking Data for PPC BU.
       expect(await objCommonPage.searchRequest(objData.demoPPC)).toContain('Pass');
       expect(await objAllViewPage.verifyBuInGridAsPerAccess(objData.demoPPC,"BU",objData.buList)).toContain('Pass');
       expect(await objAllViewPage.clearSearchText()).toContain('Pass');
       
       //Checking Data for VSE BU.
       expect(await objCommonPage.searchRequest(objData.demoVSE)).toContain('Pass');
       expect(await objAllViewPage.verifyBuInGridAsPerAccess(objData.demoVSE,"BU",objData.buList)).toContain('Pass');
       expect(await objAllViewPage.clearSearchText()).toContain('Pass'); 
       done();
});
it('TC_09-"Verify that when user login as BU Super User in My Demo then he/she shall be able to see All Demos in the Grid of All View Page from BUs for which he/she is a BU Super User.', async (done)=>
    {
        let objData = dataProvider.getJsonData("./data/allView.json", "TC_09");
        console.log(objData);
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");
        await browser.waitForAngularEnabled(true);
        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
         //Go To Admin Access view page and check and get the BU's Bu User name has
        expect(await objHomePage.selectMenuOption("Admin", "Admin Access View")).toContain('Pass');

        let sBuList = await objadminAccessViewPage.getTableCellValue("BU",objLoginData.userNameBUSuperUser);
        let sBu = sBuList.toUpperCase();
        console.log(sBu);
        
        // Take Login as BU Super User
        await browser.waitForAngularEnabled(false)
        await objHomePage.openApplication('/');     
        //Login My Demo application
        console.log("Logged in as a BU Super User")
        expect(await objLoginPage.setUserName(objLoginData.userNameBUSuperUser)).toContain('Pass');
        expect(await objLoginPage.setPassword(objLoginData.passwordBUSuperUser)).toContain('Pass');
        expect(await objLoginPage.clickLogin()).toContain("Pass");
        await browser.waitForAngularEnabled(true);
        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
        let sLoggedInUser;
        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});

        expect(await objCommonPage.searchRequest(sDemoNameALD)).toContain('Pass');
        expect(sBu).toContain(await objCommonPage.getTableCellValue("BU", sDemoNameALD));
        done();
    
});
it('TC_Pre-Requisite.', async(done)=>{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_Pre-Requisite");
    console.log(objData);
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    //select menu option
    expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
    expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
  
    var iRandomNum = Math.floor(1000 + Math.random() * 9000);
    sDemoName = "TestDemo_AllView" + iRandomNum;
    console.log(sDemoName);

    expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
    expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
  
    expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
    expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
   
    expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
    expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
    expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
    expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
    expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
 
    //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
    expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
    expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
    expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
    expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");
    browser.sleep(50000);
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
    expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');


    done();
});
it('TC_10-"Verify that when user login as Demo Owner in My Demo QA then he/she shall be able to see only those demos and related data for which he/she has access.', async (done)=>
     {
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_10");
    console.log(objData);

    // Login as Global Admin User
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    
    //Search or the demo which is having status as new request and make it approved 
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"New Request")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
    expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objData.demoOwner)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
        
    // Take Login as ACcount Super User
    await browser.waitForAngularEnabled(false)
    await objHomePage.openApplication('/');      
    expect(await objLoginPage.setUserName(objLoginData.userNameDemoOwner)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordDemoOwner)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
     
    //Go TO All View page and go on the demo details page
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.getSearchResults(sDemoName)).toContain('Pass');
    done();
});
it('TC_10_1-"Verify that when user login as Team Member in My Demo QA then he/she shall be able to see only those demos and related data for which he/she has access.', async (done)=>
     {
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_10");
    console.log(objData);

    // Login as Global Admin User
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    
    //Search or the demo which is having status as new request and make it approved 
    expect(await objHomePage.selectMenuOption("All Demo's", "Grant Demo Access")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Team Member",sDemoName)).toContain('Pass');
    expect(await objGrantDemoAccessPage.selectOwnerFromDD("Team Member",objData.teamMember)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

    // Take Login as Team Member
    await browser.waitForAngularEnabled(false)
    await objHomePage.openApplication('/');      
    expect(await objLoginPage.setUserName(objLoginData.userNameTeamMember)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordTeamMember)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
     
    //Go TO All View page and and Seacg for demo.
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.getSearchResults(sDemoName)).toContain('Pass');
    
    done();
});
it('TC_10_2-"Verify that when user login as RAT CAT Manager in My Demo QA then he/she shall be able to see only those demos and related data for which he/she has access.', async (done)=>
     {
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_10");
    console.log(objData);

    // Login as Global Admin User
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    
    //Search or the demo and update CAT RAT Manager 
    expect(await objHomePage.selectMenuOption("All Demo's", "Grant Demo Access")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Name",sDemoName)).toContain('Pass');
    expect(await objGrantDemoAccessPage.removeOwnerName("Team Member")).toContain('Pass');
    expect(await objGrantDemoAccessPage.selectOwnerFromDD("CAT/RAT Manager",objData.catRatManager)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    
    // Take Login as CAT RAT Manager 
    await browser.waitForAngularEnabled(false)
    await objHomePage.openApplication('/');      
    expect(await objLoginPage.setUserName(objLoginData.userNameCATRATManager)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordCATRATManager)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
     
    //Go TO All View page and and Search for demo.
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.getSearchResults(sDemoName)).toContain('Pass');
    
    done();
});
it('TC_10_3-"Verify that when user login as KPU GPU Head in My Demo QA then he/she shall be able to see only those demos and related data for which he/she has access.', async (done)=>
     {
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_10");
    console.log(objData);

    // Login as Global Admin User
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    
    //Search or the demo and update KPU Head GPM
    expect(await objHomePage.selectMenuOption("All Demo's", "Grant Demo Access")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Name",sDemoName)).toContain('Pass');
    expect(await objGrantDemoAccessPage.removeOwnerName("CAT/RAT Manager")).toContain('Pass');
    expect(await objGrantDemoAccessPage.selectOwnerFromDD("KPU Head/GPM",objData.kpuHeadGpm)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

    // Take Login as KPU Head GPM
    await browser.waitForAngularEnabled(false)
    await objHomePage.openApplication('/');      
    expect(await objLoginPage.setUserName(objLoginData.userNameKPUGPMHead)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordKPUGPMHead)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
     
    //Go TO All View page and and Search for demo.
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.getSearchResults(sDemoName)).toContain('Pass');
    
    done();
});
it('TC_10_4-"Verify that when user login as Account Owner in My Demo QA then he/she shall be able to see only those demos and related data for which he/she has access.', async (done)=>
     {
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_10");
    console.log(objData);

    // Login as Global Admin User
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    
    //Search or the demo and update Account Owner
    expect(await objHomePage.selectMenuOption("All Demo's", "Grant Demo Access")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Name",sDemoName)).toContain('Pass');
    expect(await objGrantDemoAccessPage.removeOwnerName("KPU Head/GPM")).toContain('Pass');
    expect(await objGrantDemoAccessPage.removeOwnerName("Account Owner")).toContain('Pass');
    expect(await objGrantDemoAccessPage.selectOwnerFromDD("Account Owner",objData.accountOwner)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

    // Take Login as Account Owner
    await browser.waitForAngularEnabled(false)
    await objHomePage.openApplication('/');      
    expect(await objLoginPage.setUserName(objLoginData.userNameAccountOwner)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordAccountOwner)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
     
    //Go TO All View page and and Search for demo.
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
expect(await objAllViewPage.getSearchResults(sDemoName)).toContain('Pass');
    
    done();
});
it('TC_10_5-"Verify that when user login as Other Group User in My Demo QA then he/she shall be able to see only those demos and related data for which he/she has access.', async (done)=>
     {
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_10");
    console.log(objData);

    // Login as Global Admin User
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    
    //Search or the demo and update Other Group
    expect(await objHomePage.selectMenuOption("All Demo's", "Grant Demo Access")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Name",sDemoName)).toContain('Pass');
    expect(await objAllViewPage.setInputOnPopUp("Other Group",objData.otherGroup)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

    // Take Login as other group user
    await browser.waitForAngularEnabled(false)
    await objHomePage.openApplication('/');      
    expect(await objLoginPage.setUserName(objLoginData.userNameOtherGroupUser)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordOtherGroupUser)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
     
    //Go TO All View page and and Search for demo.
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.getSearchResults(sDemoName)).toContain('Pass');
    done();
});
it('TC_Pre-Requisite.', async(done)=>{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_Pre-Requisite");
    console.log(objData);
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    //select menu option
    expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
    expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
  
    var iRandomNum = Math.floor(1000 + Math.random() * 9000);
    sDemoName = "TestDemo_AllView" + iRandomNum;
    console.log(sDemoName);

    expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
    expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
  
    expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
    expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
   
    expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
    expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
    expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
    expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
    expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
 
    //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
    expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
    expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
    expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
    expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");
    browser.sleep(50000);
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
    expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');
    done();
});
it('TC_11-"Verify that when user login as Account Super User in My Demo QA then he/she shall be able to see All Demos  in the Grid of All View Page from Accounts for which he/she is a Account Super User .', async (done)=>
     {
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_11");
    console.log(objData);

    // Login as Global Admin User
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    
    //Go To Account Coloumn and get the account details.
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objCommonPage.goToColumn("Account")).toContain('Pass');
    let sDemoAccount = await objCommonPage.getTableCellValue("Account", sDemoName);
    console.log(sDemoAccount);

    //Go To Admin Access view page and check Account Super User is having access to what accounts.
    expect(await objHomePage.selectMenuOption("Admin", "Admin Access View")).toContain('Pass');
    let sAccount = await objadminAccessViewPage.getTableCellValue("Account",objLoginData.userNameAccountSuperUser);
    let sAccountName = sAccount.toUpperCase();
    console.log(sAccountName);
    expect(sAccountName).toContain(sDemoAccount);
        
     // Take Login as ACcount Super User
    await browser.waitForAngularEnabled(false)
    await objHomePage.openApplication('/');      
    expect(await objLoginPage.setUserName(objLoginData.userNameAccountSuperUser)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordAccountSuperUser)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
     
    //Go TO All View page and go on the demo details page
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    done();
});
it('TC_12-"Verify that following columns are pinned in All View and User shall not be able to move them to unpinned columns section.1)Icons2)BU3)Priority4)Demo Name5)Demo Owner6)Internal Demo7)Demo Number', async (done)=>

{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_12");
    console.log(objData);
   //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    expect(await objCommonPage.goToColumn("Account")).toContain('Pass');
    expect(await objCommonPage.moveColumn("BU","Account","2")).not.toContain('Pass');
    done();
});
it('TC_13-"Verify the following in All View page of MyDemo QA.1.User shall be able to swap the rows up and down only if demos present in both rows are belongs to same status and BU.2.User shall be able to swap the columns internally among the pinned columns section.3.User shall be able to swap the columns internally among unpinned columns section.', async (done)=>

{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_13");
    console.log(objData);
   //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")
    //User is on All view Page
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    expect(await objCommonPage.searchRequest(objData.bU)).toContain('Pass');
    //Swapping row having has same status and belongs to same BU.
    expect(await objCommonPage.goToColumn("Demo Approval")).toContain('Pass');
    await objCommonPage.moveRow("BU","Demo Approval",objData.soureRowDemo,objData.targetRowDemo);
    //Swapping row having has different status and belongs to different BUs.
    await objCommonPage.moveRow("BU","Demo Approval",objData.soureRowDemo1,objData.targetRowDemo1);
   
    //Col Swap for pinnged col
    expect(await objCommonPage.moveColumn("BU","Demo Name","2")).toContain('Pass');
    //Col Swap for Unpinnged col
    expect(await objCommonPage.moveColumn("Competitor Tool","Demo Approval","56")).toContain('Pass');
    done();
});
it('TC_14-"Verify that BU Super/Global Admin shall be able to publish global view by using BU Filter and Publish button on All View.', async (done)=>
{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_14");
    console.log(objData);
   //Login My Demo application as Global Admin User
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")
    //User is on All view Page
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    //Click on the Filter Icon and select the item from it
    expect(await objCommonPage.verifyPublishBtnPresent()).toContain("Pass");
    expect(await objCommonPage.clickOnTableHdrMenuIcon("BU")).toContain("Pass");
    expect(await objCommonPage.clickOnTableHdrFilterIcon()).toContain("Pass");
    expect(await objCommonPage.selectItemFromMutiSelectDD("(Select All)")).toContain("Pass");
    expect(await objCommonPage.selectItemFromMutiSelectDD("CMP")).toContain("Pass");
    expect(await objCommonPage.clickOnTableHdrFilterIcon()).toContain("Pass");
    
    let sDemoName = await objCommonPage.geColDataList("Demo Name")
    let sDemoNameRow = sDemoName.split("~");
    let soureRowDemo = sDemoNameRow[0]
    let targetRowDemo = sDemoNameRow[1]
    //Swapping row having has same status and belongs to same BU.
    await objCommonPage.moveRow("BU","Demo Approval",soureRowDemo,targetRowDemo);
    //publish the view
    expect(await objCommonPage.clickOnPublishBtn()).toContain("Pass");
    let sAlert="View Published."
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
  
    await browser.waitForAngularEnabled(false);
    await objHomePage.openApplication('/');
     //Login My Demo application as Global Admin User
    expect(await objLoginPage.setUserName(objLoginData.userNameBUSuperUser)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordBUSuperUser)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    //Check User have the same published view
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.clickOnTableHdrMenuIcon("BU")).toContain("Pass");
    expect(await objCommonPage.clickOnTableHdrFilterIcon()).toContain("Pass");
    expect(await objCommonPage.selectItemFromMutiSelectDD("(Select All)")).toContain("Pass");
    expect(await objCommonPage.selectItemFromMutiSelectDD("CMP")).toContain("Pass");
    expect(await objCommonPage.clickOnTableHdrFilterIcon()).toContain("Pass");
    expect(await objCommonPage.getTheLatestDemoNm()).toContain(targetRowDemo);
    done();
});
it('TC_Pre-Requisite.', async(done)=>{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_Pre-Requisite");
    console.log(objData);
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    //select menu option
    expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
    expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
  
    var iRandomNum = Math.floor(1000 + Math.random() * 9000);
    sDemoName = "TestDemo_AllView" + iRandomNum;
    console.log(sDemoName);

    expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
    expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
  
    expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
    expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
   
    expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
    expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
    expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
    expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
    expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
 
    //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
    expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
    expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
    expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
    expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
    expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');

    //Approve the Newly created Demo on All view Page
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"New Request")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
    expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objData.otherGroupDemoOwner)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    done();
   
}); 
it('TC_15-"Verify that Demo number of Approved Demos will appear as Hyperlink by clicking which user shall be able to reach Demo Details page of the clicked demo.', async (done)=>

{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_15");
    console.log(objData);
    //Login My Demo application as BU Super User
    expect(await objLoginPage.setUserName(objLoginData.userNameBUSuperUser)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordBUSuperUser)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")
    //User is on All view Page
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    //Checking for Approved Demo if it have demo number as hyperlink or not
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.verifyVisibleHyperLinkForACLStatus("Demo Number","Demo Approval",sDemoName)).toContain("Pass");
    expect(await objAllViewPage.clickOnHyperLinkInDemoNumber(sDemoName)).toContain('Pass');

    expect(await objHomePage.getCurrentUrl("request_demo")).toContain("Pass");

    expect(await objDemoDetailsPage.clickFieldOnDemoDetailsWithoutScroll("Substrate Type")).toContain("Pass");
    expect(await objDemoDetailsPage.selectOptionFromFieldOnDemoDetails("Substrate Type",objData.substrateTypeDemo)).toContain("Pass");

    expect(await objDemoDetailsPage.clickFieldOnDemoDetails("Execution Risk")).toContain("Pass");
    expect(await objDemoDetailsPage.selectOptionFromFieldOnDemoDetails("Execution Risk",objData.exeRisk)).toContain("Pass");
    expect(await objDemoDetailsPage.clickOnSubmitDemoDetails()).toContain("Pass");

    let sAlert="Demo Details Submitted Successfully."
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

    //Login My Demo application as other group User

    await browser.waitForAngularEnabled(false);
    await objHomePage.openApplication('/');
   
    expect(await objLoginPage.setUserName(objLoginData.userNameOtherGroupUser)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordOtherGroupUser)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    //User is on All view Page
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');

    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.verifyVisibleHyperLinkForACLStatus("Demo Number","Demo Approval",sDemoName)).toContain("Pass");
    expect(await objAllViewPage.clickOnHyperLinkInDemoNumber(sDemoName)).toContain('Pass');

    expect(await objHomePage.getCurrentUrl("request_demo")).toContain("Pass");

    expect(await objDemoDetailsPage.clickFieldOnDemoDetailsWithoutScroll("Substrate Type")).toContain("Pass");
    expect(await objDemoDetailsPage.selectOptionFromFieldOnDemoDetails("Substrate Type",objData.substrateTypeDemo)).toContain("Pass");
    done();
});
it('TC_16-"Verify that Almanac link will be displayed for a demo on All View & Demo Details page for a user based on following conditions.1.Demo Should be ACL-Approved/Closed2.User should be Internal User', async (done)=>
{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_16");
    console.log(objData);
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")
    //User is on All view Page
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
   //Search for almanc
    expect(await objCommonPage.searchRequest("Almanac")).toContain('Pass');
    //Checking for closed status
    expect(await objAllViewPage.selectStatusFromStatusDD("Closed")).toContain('Pass');
    let sDemoNameList1 = await objCommonPage.geColDataList("Demo Name")
    let demoName1 = sDemoNameList1.split("~");
    console.log(demoName1[0]);
    expect(await objAllViewPage.verifyAlmanacLinkDisplay("Demo Number","Demo Approval",demoName1[0])).toContain('Pass');
    expect(await objAllViewPage.clickOnAlmanacLink(demoName1[1])).toContain('Pass');
    await objCommonPage.switchtoNewTab();
    expect(await objCommonPage.verifyPageHeader("My Demo - Almanac")).toContain("Pass");
    await browser.sleep(5000);
    await objCommonPage.closeTab();
    await objCommonPage.switchtoParentTab();
    
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    //checking for approved status
    expect(await objAllViewPage.selectStatusFromStatusDD("ACL - Approved")).toContain('Pass');
    let sDemoNameList = await objCommonPage.geColDataList("Demo Name")
    let demoName = sDemoNameList.split("~");
    console.log(demoName[0]);
    expect(await objAllViewPage.verifyAlmanacLinkDisplay("Demo Number","Demo Approval",demoName[0])).toContain('Pass');
    expect(await objAllViewPage.clickOnHyperLinkInDemoNumber(demoName[1])).toContain('Pass');
    expect(await objHomePage.getCurrentUrl("request_demo")).toContain("Pass");
    expect(await objAllViewPage.clickOnTabStep("Almanac")).toContain("Pass");
    await objCommonPage.switchtoNewTab();
    expect(await objCommonPage.verifyPageHeader("My Demo - Almanac")).toContain("Pass");
    await browser.sleep(5000);
    await objCommonPage.closeTab();
    await objCommonPage.switchtoParentTab();
    await browser.sleep(5000);

    await browser.waitForAngularEnabled(false);
    await objHomePage.openApplication('/');
     //Login My Demo application as Global Admin User
    expect(await objLoginPage.setUserName(objLoginData.userNameOtherGroupUser)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordOtherGroupUser)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    //User is on All view Page
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
   //Search for almanc
    expect(await objCommonPage.searchRequest("Almanac")).toContain('Pass');
    done();
    
});
it('TC_Pre-Requisite.', async(done)=>{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_Pre-Requisite");
    console.log(objData);
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    //select menu option
    expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
    expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
  
    var iRandomNum = Math.floor(1000 + Math.random() * 9000);
    sDemoName = "TestDemo_AllView" + iRandomNum;
    console.log(sDemoName);

    expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
    expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
  
    expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
    expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
   
    expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
    expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
    expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
    expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
    expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
 
    //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
    expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
    expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
    expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
    expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
    expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');
    done();
   
}); 
it('TC_17-"Verify that when user logs in as Global Admin/BU Super User then he/she should be able to change the status of the required demo', async (done)=>
{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_17");
    console.log(objData);

    //Login My Demo application as BU Super User
    expect(await objLoginPage.setUserName(objLoginData.userNameBUSuperUser)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordBUSuperUser)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")
    //User is on All view Page
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    //Search or the demo which is having status as new request and make it approved 
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"New Request")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
    expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objData.demoOwner)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    done();
    
});
it('TC_Pre-Requisite-Create Demo Uploading Documents',async(done)=>{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_Pre-Requisite_1");
    console.log(objData);
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    //Create a new demo by uploading wafer stack and CustSpec Documents
    expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
    expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
   
    var iRandomNum = Math.floor(1000 + Math.random() * 9000);
    sDemoName = "TestDemo_AllView" + iRandomNum;
    console.log(sDemoName);

    expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
    expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
   
    expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
    expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
    
    expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
    expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
    expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
    expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
    expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
    await objNewDemoRequest.clickOnBrowseButtonAgainstField("Customer Spec");
    const filePath = path.resolve('./autoItScripts/TestUpload_CustSpec.xlsx');
    const exePath = path.resolve('./autoItScripts/browseFile.exe')
    //await browser.sleep(5000);
    cp.execSync(exePath + ' ' + filePath);
    await browser.sleep(5000);
    expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
    expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Customer Spec")).toContain("Pass");
    expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
    expect(await objNewDemoRequest.verifyChkboxStatusAgainstField("Customer Spec", "Upload", "true")).toContain("Pass");
    let sTodayDateCust = await objCommonPage.getCurrentDate("mm/dd/yyyy hh:mins");
    console.log(sTodayDateCust);
    expect(await objNewDemoRequest.verifyDateTimeAgainstField("Customer Spec")).toContain(sTodayDateCust);

    expect(await objNewDemoRequest.clickWaferStackOption(objData.waferStackOption)).toContain("Pass");
    await objNewDemoRequest.clickOnBrowseButtonAgainstField("Wafer Stack");
    const filePath1 = path.resolve('./autoItScripts/TestUpload_WaferStack.xlsx');
    //await browser.sleep(5000);
    cp.execSync(exePath + ' ' + filePath1);
    await browser.sleep(5000);
    expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
    expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Wafer Stack")).toContain("Pass");
    expect(await objNewDemoRequest.verifyChkboxStatusAgainstField("Wafer Stack", "Upload", "true")).toContain("Pass");
    expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
    let sTodayDateWafer = await objCommonPage.getCurrentDate("mm/dd/yyyy hh:mins");
    console.log(sTodayDateWafer);
    expect(await objNewDemoRequest.verifyDateTimeAgainstField("Wafer Stack")).toContain(sTodayDateWafer);
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
    expect(await objCommonPage.clickOnOkBtnOnPopUp()).toContain('Pass');


    //Approve the Newly created Demo on All view Page
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"New Request")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
    expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objData.demoOwner)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    done();
});
it('TC_18-"Verify that when user logs in as Demo Owner then he/she is able to change the status of the to only closed in All View.', async (done)=>
{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_18");
    console.log(objData);
    // Login as Global Admin User and Update Data Report to the Newly Created Demo.
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")

    //Go to All view Page and  Change the Exceution Risk to complete and update wafer location 
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objCommonPage.goToColumn("Current Execution Risk")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Current Execution Risk",sDemoName)).toContain('Pass');
    expect(await objCommonPage.selectOptionFromDDInTableColumn("Current Execution Risk","Complete")).toContain('Pass');

    expect(await objCommonPage.goToColumn("Wafer Location")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Wafer Location",sDemoName)).toContain('Pass');
    expect(await objCommonPage.selectOptionFromDDInTableColumn("Wafer Location","In transit to account")).toContain('Pass');

    // Attach the demo report by clicking on the attachement icon
    expect(await objAllRequestPage.clickOnTheAttachmentIcon()).toContain('Pass');
    expect(await objAllRequestPage.clickOnBrowseButtonOnViewAttachment()).toContain("Pass");
    const filePath = path.resolve('./autoItScripts/Data_Report.xlsx');
    const exePath = path.resolve('./autoItScripts/browseFile.exe')
    cp.execSync(exePath + ' ' + filePath);
   
    expect(await objAllViewPage.selectValueFromDDOnAttachmentPopUp("Security", objData.ddSecurityVal)).toContain("Pass");
    expect(await objAllViewPage.selectValueFromDDOnAttachmentPopUp("Category", "Demo Report")).toContain("Pass");
    
    expect(await objAllRequestPage.clickOnUploadButtonOnViewAttachment()).toContain("Pass");
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');


    //Login as Demo Owner.
    await browser.waitForAngularEnabled(false);
    await objHomePage.openApplication('/');
    expect(await objLoginPage.setUserName(objLoginData.userNameDemoOwner)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordDemoOwner)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");


    // After attaching the demo report chainging status of demo to close
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"ACL-Approved")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","Closed")).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert3="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert3)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    done();
    
});
it('TC_Pre-Requisite.', async(done)=>{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_Pre-Requisite");
    console.log(objData);
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    //select menu option
    expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
    expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
  
    var iRandomNum = Math.floor(1000 + Math.random() * 9000);
    sDemoName = "TestDemo_AllView" + iRandomNum;
    console.log(sDemoName);

    expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
    expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
  
    expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
    expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
   
    expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
    expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
    expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
    expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
    expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
 
    //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
    expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
    expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
    expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
    expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
    expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');


    //Approve the Newly created Demo on All view Page
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"New Request")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
    expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objData.demoOwner)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    done();
   
}); 
it('TC_19-"Verify that if user logs in as Global Admin he/she will be able to edit all the fields in All View Screen.', async (done)=>
{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_19");
    console.log(objData);
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    
    // Go to All view and select Demo Completion as completed
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');

    //1. Verify that substrate type is selected as Full Wafer then user shall be able to update values of related fields on the displayed pop up in All view.
    expect(await objCommonPage.goToColumn("Substrate Type")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCellUsingJavaScript("Substrate Type",sDemoName)).toContain('Pass');
    
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Substrate Type","Full Wafer")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Wafer Size","200")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Substrate Material","SOI")).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    expect(await objCommonPage.verifyTextValueInTableCell("Substrate Type", sDemoName, "Full Wafer")).toContain("Pass");


    //2. Verify that substrate type is selected as Coupon then user shall be able to update values of related fields on the displayed pop up in All view.
    expect(await objCommonPage.goToColumn("Substrate Type")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCellUsingJavaScript("Substrate Type",sDemoName)).toContain('Pass');
    
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Substrate Type","Coupon")).toContain('Pass');
    expect(await objAllViewPage.setInputOnPopUp("Dimensions","200")).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    expect(await objCommonPage.verifyTextValueInTableCell("Substrate Type", sDemoName, "Coupon")).toContain("Pass");


    //3. Verify that substrate type is selected as Other then user shall be able to update values of related fields on the displayed pop up in All view.
    expect(await objCommonPage.goToColumn("Substrate Type")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCellUsingJavaScript("Substrate Type",sDemoName)).toContain('Pass');
    
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Substrate Type","Other")).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    expect(await objCommonPage.verifyTextValueInTableCell("Substrate Type", sDemoName, "Other")).toContain("Pass");


    //4. Verify that user shall not be able to include  BU Demo MultiType in Demo type field on All View when the demos status is other than New Request.
    expect(await objCommonPage.goToColumn("Demo Type")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Type",sDemoName)).toContain('Pass');
    
    expect(await objAllViewPage.selectDDValueOnEditPopUp("Demo Type", "Multi BU Demo")).toContain("Pass");
    expect(await objAllViewPage.clickOnSave()).toContain("Pass");
    sAlertMessage = "You Choose Multi BU Demo as Demo Type Please make atleast one entry in Secondary BU table.";
    expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');
    
    //5. Verify that when current execution risk is updated to complete then Lab Ready, Demo Start Demo Completion date shall be marked as complete
    //Update value the Execution Risk to complete View
    expect(await objCommonPage.goToColumn("Current Execution Risk")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Current Execution Risk",sDemoName)).toContain('Pass');
    expect(await objCommonPage.selectOptionFromDDInTableColumn("Current Execution Risk","Complete")).toContain('Pass');
    expect(await objCommonPage.verifyTextValueInTableCell("Current Execution Risk", sDemoName, "C")).toContain("Pass");

    // Check Demo Completion marked as completed 
    expect(await objCommonPage.goToColumn("Demo Completion")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Completion",sDemoName)).toContain("Pass");
    expect(await objAllViewPage.getFieldValueOnPopUp("Schedule Completion Date Milestone Status")).toContain("Completed");
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');


    // Check Demo Start marked as completed 
    expect(await objCommonPage.goToColumn("Demo Start")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Start",sDemoName)).toContain("Pass");
    expect(await objAllViewPage.getFieldValueOnPopUp("Demo Start Milestone Status")).toContain("Completed");
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');

    // Check Lab Ready marked as completed 
    expect(await objCommonPage.goToColumn("Lab Ready")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Lab Ready",sDemoName)).toContain("Pass");
    expect(await objAllViewPage.getFieldValueOnPopUp("Lab Ready Milestone Status")).toContain("Completed");
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');

    //6. Verify that when the Demo Location values is updated then its related values shall be updatable or populated appropriately in My Demo Application.
    expect(await objCommonPage.goToColumn("Demo Location")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Location",sDemoName)).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Location",objData.demoLocation)).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Tool Name",objData.toolName)).toContain('Pass');
    expect(await objAllViewPage.getFieldValueOnPopUp("Tool ID")).toContain(objData.toolId);
    expect(await objAllViewPage.clickFieldOnThePopUp("Chamber Position")).toContain("Pass");
    expect(await objAllViewPage.selectItemFromMultiSelectDDOnPopUp(objData.chamberPosition)).toContain("Pass");
    expect(await objAllViewPage.getFieldValueOnPopUp("Chamber Config")).toContain(objData.chamberConfig);
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    expect(await objCommonPage.verifyTextValueInTableCell("Demo Location", sDemoName, objData.demoLocation)).toContain("Pass");
    done();
});
it('TC_19_1-"Verify that if user logs in as BU super User then he/she will be able to edit all the fields in All View Screen.', async (done)=>
{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_19");
    console.log(objData);
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameBUSuperUser)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordBUSuperUser)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    
    // Go to All view and select Demo Completion as completed
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');

    //1. Verify that substrate type is selected as Full Wafer then user shall be able to update values of related fields on the displayed pop up in All view.
    expect(await objCommonPage.goToColumn("Substrate Type")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCellUsingJavaScript("Substrate Type",sDemoName)).toContain('Pass');
    
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Substrate Type","Full Wafer")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Wafer Size","200")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Substrate Material","SOI")).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    expect(await objCommonPage.verifyTextValueInTableCell("Substrate Type", sDemoName, "Full Wafer")).toContain("Pass");


    //2. Verify that substrate type is selected as Coupon then user shall be able to update values of related fields on the displayed pop up in All view.
    expect(await objCommonPage.goToColumn("Substrate Type")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCellUsingJavaScript("Substrate Type",sDemoName)).toContain('Pass');
    
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Substrate Type","Coupon")).toContain('Pass');
    expect(await objAllViewPage.setInputOnPopUp("Dimensions","200")).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    expect(await objCommonPage.verifyTextValueInTableCell("Substrate Type", sDemoName, "Coupon")).toContain("Pass");


    //3. Verify that substrate type is selected as Other then user shall be able to update values of related fields on the displayed pop up in All view.
    expect(await objCommonPage.goToColumn("Substrate Type")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCellUsingJavaScript("Substrate Type",sDemoName)).toContain('Pass');
    
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Substrate Type","Other")).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    expect(await objCommonPage.verifyTextValueInTableCell("Substrate Type", sDemoName, "Other")).toContain("Pass");


    //4. Verify that user shall not be able to include  BU Demo MultiType in Demo type field on All View when the demos status is other than New Request.
    expect(await objCommonPage.goToColumn("Demo Type")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Type",sDemoName)).toContain('Pass');
    
    expect(await objAllViewPage.selectDDValueOnEditPopUp("Demo Type", "Multi BU Demo")).toContain("Pass");
    expect(await objAllViewPage.clickOnSave()).toContain("Pass");
    sAlertMessage = "You Choose Multi BU Demo as Demo Type Please make atleast one entry in Secondary BU table.";
    expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');
    
    //5. Verify that when current execution risk is updated to complete then Lab Ready, Demo Start Demo Completion date shall be marked as complete
    //Update value the Execution Risk to complete View
    expect(await objCommonPage.goToColumn("Current Execution Risk")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Current Execution Risk",sDemoName)).toContain('Pass');
    expect(await objCommonPage.selectOptionFromDDInTableColumn("Current Execution Risk","Complete")).toContain('Pass');
    expect(await objCommonPage.verifyTextValueInTableCell("Current Execution Risk", sDemoName, "C")).toContain("Pass");

    // Check Demo Completion marked as completed 
    expect(await objCommonPage.goToColumn("Demo Completion")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Completion",sDemoName)).toContain("Pass");
    expect(await objAllViewPage.getFieldValueOnPopUp("Schedule Completion Date Milestone Status")).toContain("Completed");
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');


    // Check Demo Start marked as completed 
    expect(await objCommonPage.goToColumn("Demo Start")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Start",sDemoName)).toContain("Pass");
    expect(await objAllViewPage.getFieldValueOnPopUp("Demo Start Milestone Status")).toContain("Completed");
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');

    // Check Lab Ready marked as completed 
    expect(await objCommonPage.goToColumn("Lab Ready")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Lab Ready",sDemoName)).toContain("Pass");
    expect(await objAllViewPage.getFieldValueOnPopUp("Lab Ready Milestone Status")).toContain("Completed");
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');

    //6. Verify that when the Demo Location values is updated then its related values shall be updatable or populated appropriately in My Demo Application.
    expect(await objCommonPage.goToColumn("Demo Location")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Location",sDemoName)).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Location",objData.demoLocation)).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Tool Name",objData.toolName)).toContain('Pass');
    expect(await objAllViewPage.getFieldValueOnPopUp("Tool ID")).toContain(objData.toolId);
    expect(await objAllViewPage.clickFieldOnThePopUp("Chamber Position")).toContain("Pass");
    expect(await objAllViewPage.selectItemFromMultiSelectDDOnPopUp(objData.chamberPosition)).toContain("Pass");
    expect(await objAllViewPage.selectItemFromMultiSelectDDOnPopUp(objData.chamberPosition)).toContain("Pass");
    expect(await objAllViewPage.getFieldValueOnPopUp("Chamber Config")).toContain(objData.chamberConfig);
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    expect(await objCommonPage.verifyTextValueInTableCell("Demo Location", sDemoName, objData.demoLocation)).toContain("Pass");

    done();
});
it('TC_19_2-"Verify that if user logs in as KPU Head then he/she will be able to edit all the fields in All View Screen.', async (done)=>
{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_19");
    console.log(objData);
    // Login as Global Admin User
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
     
    //Search or the demo and update KPU Head GPM
    expect(await objHomePage.selectMenuOption("All Demo's", "Grant Demo Access")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Name",sDemoName)).toContain('Pass');
    expect(await objGrantDemoAccessPage.selectOwnerFromDD("KPU Head/GPM",objData.kpuHeadGpm)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
 
    // Take Login as KPU Head GPM
    await browser.waitForAngularEnabled(false)
    await objHomePage.openApplication('/');      
    expect(await objLoginPage.setUserName(objLoginData.userNameKPUGPMHead)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordKPUGPMHead)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    

    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');

    //1. Verify that substrate type is selected as Full Wafer then user shall be able to update values of related fields on the displayed pop up in All view.
    expect(await objCommonPage.goToColumn("Substrate Type")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCellUsingJavaScript("Substrate Type",sDemoName)).toContain('Pass');
    
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Substrate Type","Full Wafer")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Wafer Size","200")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Substrate Material","SOI")).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    expect(await objCommonPage.verifyTextValueInTableCell("Substrate Type", sDemoName, "Full Wafer")).toContain("Pass");


    //2. Verify that substrate type is selected as Coupon then user shall be able to update values of related fields on the displayed pop up in All view.
    expect(await objCommonPage.goToColumn("Substrate Type")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCellUsingJavaScript("Substrate Type",sDemoName)).toContain('Pass');
    
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Substrate Type","Coupon")).toContain('Pass');
    expect(await objAllViewPage.setInputOnPopUp("Dimensions","200")).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    expect(await objCommonPage.verifyTextValueInTableCell("Substrate Type", sDemoName, "Coupon")).toContain("Pass");


    //3. Verify that substrate type is selected as Other then user shall be able to update values of related fields on the displayed pop up in All view.
    expect(await objCommonPage.goToColumn("Substrate Type")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCellUsingJavaScript("Substrate Type",sDemoName)).toContain('Pass');
    
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Substrate Type","Other")).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    expect(await objCommonPage.verifyTextValueInTableCell("Substrate Type", sDemoName, "Other")).toContain("Pass");


    //4. Verify that user shall not be able to include  BU Demo MultiType in Demo type field on All View when the demos status is other than New Request.
    expect(await objCommonPage.goToColumn("Demo Type")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Type",sDemoName)).toContain('Pass');
    
    expect(await objAllViewPage.selectDDValueOnEditPopUp("Demo Type", "Multi BU Demo")).toContain("Pass");
    expect(await objAllViewPage.clickOnSave()).toContain("Pass");
    sAlertMessage = "You Choose Multi BU Demo as Demo Type Please make atleast one entry in Secondary BU table.";
    expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');
    
    //5. Verify that when current execution risk is updated to complete then Lab Ready, Demo Start Demo Completion date shall be marked as complete
    //Update value the Execution Risk to complete View
    expect(await objCommonPage.goToColumn("Current Execution Risk")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Current Execution Risk",sDemoName)).toContain('Pass');
    expect(await objCommonPage.selectOptionFromDDInTableColumn("Current Execution Risk","Complete")).toContain('Pass');
    expect(await objCommonPage.verifyTextValueInTableCell("Current Execution Risk", sDemoName, "C")).toContain("Pass");

    // Check Demo Completion marked as completed 
    expect(await objCommonPage.goToColumn("Demo Completion")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Completion",sDemoName)).toContain("Pass");
    expect(await objAllViewPage.getFieldValueOnPopUp("Schedule Completion Date Milestone Status")).toContain("Completed");
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');


    // Check Demo Start marked as completed 
    expect(await objCommonPage.goToColumn("Demo Start")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Start",sDemoName)).toContain("Pass");
    expect(await objAllViewPage.getFieldValueOnPopUp("Demo Start Milestone Status")).toContain("Completed");
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');

    // Check Lab Ready marked as completed 
    expect(await objCommonPage.goToColumn("Lab Ready")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Lab Ready",sDemoName)).toContain("Pass");
    expect(await objAllViewPage.getFieldValueOnPopUp("Lab Ready Milestone Status")).toContain("Completed");
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');

    //6. Verify that when the Demo Location values is updated then its related values shall be updatable or populated appropriately in My Demo Application.
    expect(await objCommonPage.goToColumn("Demo Location")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Location",sDemoName)).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Location",objData.demoLocation)).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Tool Name",objData.toolName)).toContain('Pass');
    expect(await objAllViewPage.getFieldValueOnPopUp("Tool ID")).toContain(objData.toolId);
    expect(await objAllViewPage.clickFieldOnThePopUp("Chamber Position")).toContain("Pass");
    expect(await objAllViewPage.selectItemFromMultiSelectDDOnPopUp(objData.chamberPosition)).toContain("Pass");
    expect(await objAllViewPage.selectItemFromMultiSelectDDOnPopUp(objData.chamberPosition)).toContain("Pass");
    expect(await objAllViewPage.getFieldValueOnPopUp("Chamber Config")).toContain(objData.chamberConfig);
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    expect(await objCommonPage.verifyTextValueInTableCell("Demo Location", sDemoName, objData.demoLocation)).toContain("Pass");

    done();
});
it('TC_Pre-Requisite.', async(done)=>{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_Pre-Requisite");
    console.log(objData);
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    //select menu option
    expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
    expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
  
    var iRandomNum = Math.floor(1000 + Math.random() * 9000);
    sDemoName = "TestDemo_AllView" + iRandomNum;
    console.log(sDemoName);

    expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
    expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
  
    expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
    expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
   
    expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
    expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
    expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
    expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
    expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
 
    //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
    expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
    expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
    expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
    expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
    expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');


    //Approve the Newly created Demo on All view Page
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"New Request")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
    expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objData.demoOwner)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    done();
   
});
it('TC_20-"Verify that when user logs in as Demo Owner the he/she shall be able to all the field values including Priority in All View and Status should only can set as closed.', async (done)=>
{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_20");
    console.log(objData);
    // Login as Demo Owner .
    expect(await objLoginPage.setUserName(objLoginData.userNameDemoOwner)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordDemoOwner)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    

    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');


    //1. Verify that substrate type is selected as Full Wafer then user shall be able to update values of related fields on the displayed pop up in All view.
    expect(await objCommonPage.goToColumn("Substrate Type")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCellUsingJavaScript("Substrate Type",sDemoName)).toContain('Pass');
    
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Substrate Type","Full Wafer")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Wafer Size","200")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Substrate Material","SOI")).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    expect(await objCommonPage.verifyTextValueInTableCell("Substrate Type", sDemoName, "Full Wafer")).toContain("Pass");


    //2. Verify that substrate type is selected as Coupon then user shall be able to update values of related fields on the displayed pop up in All view.
    expect(await objCommonPage.goToColumn("Substrate Type")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCellUsingJavaScript("Substrate Type",sDemoName)).toContain('Pass');
    
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Substrate Type","Coupon")).toContain('Pass');
    expect(await objAllViewPage.setInputOnPopUp("Dimensions","200")).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    expect(await objCommonPage.verifyTextValueInTableCell("Substrate Type", sDemoName, "Coupon")).toContain("Pass");


    //3. Verify that substrate type is selected as Other then user shall be able to update values of related fields on the displayed pop up in All view.
    expect(await objCommonPage.goToColumn("Substrate Type")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCellUsingJavaScript("Substrate Type",sDemoName)).toContain('Pass');
    
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Substrate Type","Other")).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    expect(await objCommonPage.verifyTextValueInTableCell("Substrate Type", sDemoName, "Other")).toContain("Pass");


    //4. Verify that user shall not be able to include  BU Demo MultiType in Demo type field on All View when the demos status is other than New Request.
    expect(await objCommonPage.goToColumn("Demo Type")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Type",sDemoName)).toContain('Pass');
    
    expect(await objAllViewPage.selectDDValueOnEditPopUp("Demo Type", "Multi BU Demo")).toContain("Pass");
    expect(await objAllViewPage.clickOnSave()).toContain("Pass");
    sAlertMessage = "You Choose Multi BU Demo as Demo Type Please make atleast one entry in Secondary BU table.";
    expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');
    
    //5. Verify that when current execution risk is updated to complete then Lab Ready, Demo Start Demo Completion date shall be marked as complete
    //Update value the Execution Risk to complete View
    expect(await objCommonPage.goToColumn("Current Execution Risk")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Current Execution Risk",sDemoName)).toContain('Pass');
    expect(await objCommonPage.selectOptionFromDDInTableColumn("Current Execution Risk","Complete")).toContain('Pass');
    expect(await objCommonPage.verifyTextValueInTableCell("Current Execution Risk", sDemoName, "C")).toContain("Pass");

    // Check Demo Completion marked as completed 
    expect(await objCommonPage.goToColumn("Demo Completion")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Completion",sDemoName)).toContain("Pass");
    expect(await objAllViewPage.getFieldValueOnPopUp("Schedule Completion Date Milestone Status")).toContain("Completed");
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');


    // Check Demo Start marked as completed 
    expect(await objCommonPage.goToColumn("Demo Start")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Start",sDemoName)).toContain("Pass");
    expect(await objAllViewPage.getFieldValueOnPopUp("Demo Start Milestone Status")).toContain("Completed");
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');

    // Check Lab Ready marked as completed 
    expect(await objCommonPage.goToColumn("Lab Ready")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Lab Ready",sDemoName)).toContain("Pass");
    expect(await objAllViewPage.getFieldValueOnPopUp("Lab Ready Milestone Status")).toContain("Completed");
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');

    //6. Verify that when the Demo Location values is updated then its related values shall be updatable or populated appropriately in My Demo Application.
    expect(await objCommonPage.goToColumn("Demo Location")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Location",sDemoName)).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Location",objData.demoLocation)).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Tool Name",objData.toolName)).toContain('Pass');
    expect(await objAllViewPage.getFieldValueOnPopUp("Tool ID")).toContain(objData.toolId);
    expect(await objAllViewPage.clickFieldOnThePopUp("Chamber Position")).toContain("Pass");
    expect(await objAllViewPage.selectItemFromMultiSelectDDOnPopUp(objData.chamberPosition)).toContain("Pass");
    expect(await objAllViewPage.getFieldValueOnPopUp("Chamber Config")).toContain(objData.chamberConfig);
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    expect(await objCommonPage.verifyTextValueInTableCell("Demo Location", sDemoName, objData.demoLocation)).toContain("Pass");


    //0.Demo Owner Should have access to update and Priority col.
    expect(await objCommonPage.clickInTheTableCell("Priority",sDemoName)).toContain('Pass');
    expect(await objCommonPage.selectOptionFromDDInTableColumn("Priority", "Low")).toContain("Pass");

    //0.Demo Owner Should have access to update and Status col only to closed
    //Go to All view Page and  Change the Exceution Risk to complete and update wafer location and close the demo.
    expect(await objCommonPage.goToColumn("Current Execution Risk")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Current Execution Risk",sDemoName)).toContain('Pass');
    expect(await objCommonPage.selectOptionFromDDInTableColumn("Current Execution Risk","Complete")).toContain('Pass');
 
    expect(await objCommonPage.goToColumn("Wafer Location")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Wafer Location",sDemoName)).toContain('Pass');
    expect(await objCommonPage.selectOptionFromDDInTableColumn("Wafer Location","In transit to account")).toContain('Pass');
 
    // Attach the demo report by clicking on the attachement icon
    expect(await objAllRequestPage.clickOnTheAttachmentIcon()).toContain('Pass');
    expect(await objAllRequestPage.clickOnBrowseButtonOnViewAttachment()).toContain("Pass");
    const filePath = path.resolve('./autoItScripts/Data_Report.xlsx');
    const exePath = path.resolve('./autoItScripts/browseFile.exe')
    cp.execSync(exePath + ' ' + filePath);
    
    expect(await objAllViewPage.selectValueFromDDOnAttachmentPopUp("Security", objData.ddSecurityVal)).toContain("Pass");
    expect(await objAllViewPage.selectValueFromDDOnAttachmentPopUp("Category", "Demo Report")).toContain("Pass");
     
    expect(await objAllRequestPage.clickOnUploadButtonOnViewAttachment()).toContain("Pass");
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');
    //Close the Demo
    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"ACL-Approved")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","Closed")).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');


    done();
});
it('TC_Pre-Requisite.', async(done)=>{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_Pre-Requisite");
    console.log(objData);
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    //select menu option
    expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
    expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
  
    var iRandomNum = Math.floor(1000 + Math.random() * 9000);
    sDemoName = "TestDemo_AllView" + iRandomNum;
    console.log(sDemoName);

    expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
    expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
  
    expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
    expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
   
    expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
    expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
    expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
    expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
    expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
 
    //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
    expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
    expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
    expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
    expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
    expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');


    //Approve the Newly created Demo on All view Page
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"New Request")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
    expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objData.demoOwner)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    done();
   
});
it('TC_20_1-"Verify that when user logs in as CAT/RAT Manager the he/she shall be able to all the field values in All View except Status and Priority Fields.', async (done)=>
{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_20");
    console.log(objData);
    // Login as Global Admin User
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    
    //Search or the demo and update CAT RAT Manager 
    expect(await objHomePage.selectMenuOption("All Demo's", "Grant Demo Access")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Name",sDemoName)).toContain('Pass');
    expect(await objGrantDemoAccessPage.selectOwnerFromDD("CAT/RAT Manager",objData.catRatManager)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    
    // Take Login as CAT RAT Manager 
    await browser.waitForAngularEnabled(false)
    await objHomePage.openApplication('/');      
    expect(await objLoginPage.setUserName(objLoginData.userNameCATRATManager)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordCATRATManager)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");    

    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');


    //CAT RAT Manager Should not have access to update status and Priority.
    expect(await objCommonPage.clickInTheTableCell("Priority",sDemoName)).toContain('Pass');
    expect(await objCommonPage.clickOnDDInTableCellUsingJavaScript("Priority")).not.toContain("Pass");

    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"ACL-Approved")).toContain('Pass');
    expect(await objCommonPage.verifyAlertHeader("Approval View")).not.toContain('Pass');

    //1. Verify that substrate type is selected as Full Wafer then user shall be able to update values of related fields on the displayed pop up in All view.
    expect(await objCommonPage.goToColumn("Substrate Type")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCellUsingJavaScript("Substrate Type",sDemoName)).toContain('Pass');
    
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Substrate Type","Full Wafer")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Wafer Size","200")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Substrate Material","SOI")).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    expect(await objCommonPage.verifyTextValueInTableCell("Substrate Type", sDemoName, "Full Wafer")).toContain("Pass");


    //2. Verify that substrate type is selected as Coupon then user shall be able to update values of related fields on the displayed pop up in All view.
    expect(await objCommonPage.goToColumn("Substrate Type")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCellUsingJavaScript("Substrate Type",sDemoName)).toContain('Pass');
    
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Substrate Type","Coupon")).toContain('Pass');
    expect(await objAllViewPage.setInputOnPopUp("Dimensions","200")).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    expect(await objCommonPage.verifyTextValueInTableCell("Substrate Type", sDemoName, "Coupon")).toContain("Pass");


    //3. Verify that substrate type is selected as Other then user shall be able to update values of related fields on the displayed pop up in All view.
    expect(await objCommonPage.goToColumn("Substrate Type")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCellUsingJavaScript("Substrate Type",sDemoName)).toContain('Pass');
    
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Substrate Type","Other")).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    expect(await objCommonPage.verifyTextValueInTableCell("Substrate Type", sDemoName, "Other")).toContain("Pass");


    //4. Verify that user shall not be able to include  BU Demo MultiType in Demo type field on All View when the demos status is other than New Request.
    expect(await objCommonPage.goToColumn("Demo Type")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Type",sDemoName)).toContain('Pass');
    
    expect(await objAllViewPage.selectDDValueOnEditPopUp("Demo Type", "Multi BU Demo")).toContain("Pass");
    expect(await objAllViewPage.clickOnSave()).toContain("Pass");
    sAlertMessage = "You Choose Multi BU Demo as Demo Type Please make atleast one entry in Secondary BU table.";
    expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');
    
    //5. Verify that when current execution risk is updated to complete then Lab Ready, Demo Start Demo Completion date shall be marked as complete
    //Update value the Execution Risk to complete View
    expect(await objCommonPage.goToColumn("Current Execution Risk")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Current Execution Risk",sDemoName)).toContain('Pass');
    expect(await objCommonPage.selectOptionFromDDInTableColumn("Current Execution Risk","Complete")).toContain('Pass');
    expect(await objCommonPage.verifyTextValueInTableCell("Current Execution Risk", sDemoName, "C")).toContain("Pass");

    // Check Demo Completion marked as completed 
    expect(await objCommonPage.goToColumn("Demo Completion")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Completion",sDemoName)).toContain("Pass");
    expect(await objAllViewPage.getFieldValueOnPopUp("Schedule Completion Date Milestone Status")).toContain("Completed");
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');


    // Check Demo Start marked as completed 
    expect(await objCommonPage.goToColumn("Demo Start")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Start",sDemoName)).toContain("Pass");
    expect(await objAllViewPage.getFieldValueOnPopUp("Demo Start Milestone Status")).toContain("Completed");
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');

    // Check Lab Ready marked as completed 
    expect(await objCommonPage.goToColumn("Lab Ready")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Lab Ready",sDemoName)).toContain("Pass");
    expect(await objAllViewPage.getFieldValueOnPopUp("Lab Ready Milestone Status")).toContain("Completed");
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');

    //6. Verify that when the Demo Location values is updated then its related values shall be updatable or populated appropriately in My Demo Application.
    expect(await objCommonPage.goToColumn("Demo Location")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Location",sDemoName)).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Location",objData.demoLocation)).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Tool Name",objData.toolName)).toContain('Pass');
    expect(await objAllViewPage.getFieldValueOnPopUp("Tool ID")).toContain(objData.toolId);
    expect(await objAllViewPage.clickFieldOnThePopUp("Chamber Position")).toContain("Pass");
    expect(await objAllViewPage.selectItemFromMultiSelectDDOnPopUp(objData.chamberPosition)).toContain("Pass");
    expect(await objAllViewPage.getFieldValueOnPopUp("Chamber Config")).toContain(objData.chamberConfig);
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    expect(await objCommonPage.verifyTextValueInTableCell("Demo Location", sDemoName, objData.demoLocation)).toContain("Pass");

    done();
});
it('TC_20_2-"Verify that when user logs in as Team Member the he/she shall be able to all the field values in All View except Status and Priority Fields.', async (done)=>
{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_20");
    console.log(objData);
    // Login as Global Admin User
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    
    //Search or the demo which is having status as new request and make it approved 
    expect(await objHomePage.selectMenuOption("All Demo's", "Grant Demo Access")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Team Member",sDemoName)).toContain('Pass');
    //expect(await objGrantDemoAccessPage.removeOwnerName("CAT/RAT Manager")).toContain('Pass');
    expect(await objGrantDemoAccessPage.selectOwnerFromDD("Team Member",objData.teamMember)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

    // Take Login as Team Member
    await browser.waitForAngularEnabled(false)
    await objHomePage.openApplication('/');      
    expect(await objLoginPage.setUserName(objLoginData.userNameTeamMember)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordTeamMember)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');


    //Team Member Should not have access to update status and Priority.
    expect(await objCommonPage.clickInTheTableCell("Priority",sDemoName)).toContain('Pass');
    expect(await objCommonPage.clickOnDDInTableCellUsingJavaScript("Priority")).not.toContain("Pass");

    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"ACL-Approved")).toContain('Pass');
    expect(await objCommonPage.verifyAlertHeader("Approval View")).not.toContain('Pass');

    //1. Verify that substrate type is selected as Full Wafer then user shall be able to update values of related fields on the displayed pop up in All view.
    expect(await objCommonPage.goToColumn("Substrate Type")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCellUsingJavaScript("Substrate Type",sDemoName)).toContain('Pass');
    
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Substrate Type","Full Wafer")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Wafer Size","200")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Substrate Material","SOI")).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    expect(await objCommonPage.verifyTextValueInTableCell("Substrate Type", sDemoName, "Full Wafer")).toContain("Pass");


    //2. Verify that substrate type is selected as Coupon then user shall be able to update values of related fields on the displayed pop up in All view.
    expect(await objCommonPage.goToColumn("Substrate Type")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCellUsingJavaScript("Substrate Type",sDemoName)).toContain('Pass');
    
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Substrate Type","Coupon")).toContain('Pass');
    expect(await objAllViewPage.setInputOnPopUp("Dimensions","200")).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    expect(await objCommonPage.verifyTextValueInTableCell("Substrate Type", sDemoName, "Coupon")).toContain("Pass");


    //3. Verify that substrate type is selected as Other then user shall be able to update values of related fields on the displayed pop up in All view.
    expect(await objCommonPage.goToColumn("Substrate Type")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCellUsingJavaScript("Substrate Type",sDemoName)).toContain('Pass');
    
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Substrate Type","Other")).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    expect(await objCommonPage.verifyTextValueInTableCell("Substrate Type", sDemoName, "Other")).toContain("Pass");


    //4. Verify that user shall not be able to include  BU Demo MultiType in Demo type field on All View when the demos status is other than New Request.
    expect(await objCommonPage.goToColumn("Demo Type")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Type",sDemoName)).toContain('Pass');
    
    expect(await objAllViewPage.selectDDValueOnEditPopUp("Demo Type", "Multi BU Demo")).toContain("Pass");
    expect(await objAllViewPage.clickOnSave()).toContain("Pass");
    sAlertMessage = "You Choose Multi BU Demo as Demo Type Please make atleast one entry in Secondary BU table.";
    expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');
    
    //5. Verify that when current execution risk is updated to complete then Lab Ready, Demo Start Demo Completion date shall be marked as complete
    //Update value the Execution Risk to complete View
    expect(await objCommonPage.goToColumn("Current Execution Risk")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Current Execution Risk",sDemoName)).toContain('Pass');
    expect(await objCommonPage.selectOptionFromDDInTableColumn("Current Execution Risk","Complete")).toContain('Pass');
    expect(await objCommonPage.verifyTextValueInTableCell("Current Execution Risk", sDemoName, "C")).toContain("Pass");

    // Check Demo Completion marked as completed 
    expect(await objCommonPage.goToColumn("Demo Completion")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Completion",sDemoName)).toContain("Pass");
    expect(await objAllViewPage.getFieldValueOnPopUp("Schedule Completion Date Milestone Status")).toContain("Completed");
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');


    // Check Demo Start marked as completed 
    expect(await objCommonPage.goToColumn("Demo Start")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Start",sDemoName)).toContain("Pass");
    expect(await objAllViewPage.getFieldValueOnPopUp("Demo Start Milestone Status")).toContain("Completed");
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');

    // Check Lab Ready marked as completed 
    expect(await objCommonPage.goToColumn("Lab Ready")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Lab Ready",sDemoName)).toContain("Pass");
    expect(await objAllViewPage.getFieldValueOnPopUp("Lab Ready Milestone Status")).toContain("Completed");
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');

    //6. Verify that when the Demo Location values is updated then its related values shall be updatable or populated appropriately in My Demo Application.
    expect(await objCommonPage.goToColumn("Demo Location")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Location",sDemoName)).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Location",objData.demoLocation)).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Tool Name",objData.toolName)).toContain('Pass');
    expect(await objAllViewPage.getFieldValueOnPopUp("Tool ID")).toContain(objData.toolId);
    expect(await objAllViewPage.clickFieldOnThePopUp("Chamber Position")).toContain("Pass");
    expect(await objAllViewPage.selectItemFromMultiSelectDDOnPopUp(objData.chamberPosition)).toContain("Pass");
    expect(await objAllViewPage.selectItemFromMultiSelectDDOnPopUp(objData.chamberPosition)).toContain("Pass");
    expect(await objAllViewPage.getFieldValueOnPopUp("Chamber Config")).toContain(objData.chamberConfig);
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    expect(await objCommonPage.verifyTextValueInTableCell("Demo Location", sDemoName, objData.demoLocation)).toContain("Pass");

    done();
});
it('TC_20_3-"Verify that when user logs in as Account Owner the he/she shall be able to all the field values in All View except Status and Priority Fields.', async (done)=>
{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_20");
    console.log(objData);
    // Login as Global Admin User
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
     
    //Search or the demo and update Account Owner
    expect(await objHomePage.selectMenuOption("All Demo's", "Grant Demo Access")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Name",sDemoName)).toContain('Pass');
    expect(await objGrantDemoAccessPage.removeOwnerName("Team Member")).toContain('Pass');
    expect(await objGrantDemoAccessPage.selectOwnerFromDD("Account Owner",objData.accountOwner)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
 
    // Take Login as Account Owner
    await browser.waitForAngularEnabled(false)
    await objHomePage.openApplication('/');      
    expect(await objLoginPage.setUserName(objLoginData.userNameAccountOwner)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordAccountOwner)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    

    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');


    //Account Should not have access to update status and Priority.
    expect(await objCommonPage.clickInTheTableCell("Priority",sDemoName)).toContain('Pass');
    expect(await objCommonPage.clickOnDDInTableCellUsingJavaScript("Priority")).not.toContain("Pass");

    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"ACL-Approved")).toContain('Pass');
    expect(await objCommonPage.verifyAlertHeader("Approval View")).not.toContain('Pass');

    //1. Verify that substrate type is selected as Full Wafer then user shall be able to update values of related fields on the displayed pop up in All view.
    expect(await objCommonPage.goToColumn("Substrate Type")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCellUsingJavaScript("Substrate Type",sDemoName)).toContain('Pass');
    
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Substrate Type","Full Wafer")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Wafer Size","200")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Substrate Material","SOI")).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    expect(await objCommonPage.verifyTextValueInTableCell("Substrate Type", sDemoName, "Full Wafer")).toContain("Pass");


    //2. Verify that substrate type is selected as Coupon then user shall be able to update values of related fields on the displayed pop up in All view.
    expect(await objCommonPage.goToColumn("Substrate Type")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCellUsingJavaScript("Substrate Type",sDemoName)).toContain('Pass');
    
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Substrate Type","Coupon")).toContain('Pass');
    expect(await objAllViewPage.setInputOnPopUp("Dimensions","200")).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    expect(await objCommonPage.verifyTextValueInTableCell("Substrate Type", sDemoName, "Coupon")).toContain("Pass");


    //3. Verify that substrate type is selected as Other then user shall be able to update values of related fields on the displayed pop up in All view.
    expect(await objCommonPage.goToColumn("Substrate Type")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCellUsingJavaScript("Substrate Type",sDemoName)).toContain('Pass');
    
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Substrate Type","Other")).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    expect(await objCommonPage.verifyTextValueInTableCell("Substrate Type", sDemoName, "Other")).toContain("Pass");


    //4. Verify that user shall not be able to include  BU Demo MultiType in Demo type field on All View when the demos status is other than New Request.
    expect(await objCommonPage.goToColumn("Demo Type")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Type",sDemoName)).toContain('Pass');
    
    expect(await objAllViewPage.selectDDValueOnEditPopUp("Demo Type", "Multi BU Demo")).toContain("Pass");
    expect(await objAllViewPage.clickOnSave()).toContain("Pass");
    sAlertMessage = "You Choose Multi BU Demo as Demo Type Please make atleast one entry in Secondary BU table.";
    expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');
    
    //5. Verify that when current execution risk is updated to complete then Lab Ready, Demo Start Demo Completion date shall be marked as complete
    //Update value the Execution Risk to complete View
    expect(await objCommonPage.goToColumn("Current Execution Risk")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Current Execution Risk",sDemoName)).toContain('Pass');
    expect(await objCommonPage.selectOptionFromDDInTableColumn("Current Execution Risk","Complete")).toContain('Pass');
    expect(await objCommonPage.verifyTextValueInTableCell("Current Execution Risk", sDemoName, "C")).toContain("Pass");

    // Check Demo Completion marked as completed 
    expect(await objCommonPage.goToColumn("Demo Completion")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Completion",sDemoName)).toContain("Pass");
    expect(await objAllViewPage.getFieldValueOnPopUp("Schedule Completion Date Milestone Status")).toContain("Completed");
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');


    // Check Demo Start marked as completed 
    expect(await objCommonPage.goToColumn("Demo Start")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Start",sDemoName)).toContain("Pass");
    expect(await objAllViewPage.getFieldValueOnPopUp("Demo Start Milestone Status")).toContain("Completed");
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');

    // Check Lab Ready marked as completed 
    expect(await objCommonPage.goToColumn("Lab Ready")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Lab Ready",sDemoName)).toContain("Pass");
    expect(await objAllViewPage.getFieldValueOnPopUp("Lab Ready Milestone Status")).toContain("Completed");
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');

    //6. Verify that when the Demo Location values is updated then its related values shall be updatable or populated appropriately in My Demo Application.
    expect(await objCommonPage.goToColumn("Demo Location")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Location",sDemoName)).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Location",objData.demoLocation)).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Tool Name",objData.toolName)).toContain('Pass');
    expect(await objAllViewPage.getFieldValueOnPopUp("Tool ID")).toContain(objData.toolId);
    expect(await objAllViewPage.clickFieldOnThePopUp("Chamber Position")).toContain("Pass");
    expect(await objAllViewPage.selectItemFromMultiSelectDDOnPopUp(objData.chamberPosition)).toContain("Pass");
    expect(await objAllViewPage.selectItemFromMultiSelectDDOnPopUp(objData.chamberPosition)).toContain("Pass");
    expect(await objAllViewPage.getFieldValueOnPopUp("Chamber Config")).toContain(objData.chamberConfig);
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    expect(await objCommonPage.verifyTextValueInTableCell("Demo Location", sDemoName, objData.demoLocation)).toContain("Pass");

    done();
});
it('TC_21-"Verify that when user logged in as Other Group User of a particular demo then he/she shall not be able to edit any fields in All View page.', async (done)=>
{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_21");
    console.log(objData);
    // Login as Global Admin User
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    
    //Search or the demo and update Other Group
    expect(await objHomePage.selectMenuOption("All Demo's", "Grant Demo Access")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Name",sDemoName)).toContain('Pass');
    expect(await objAllViewPage.setInputOnPopUp("Other Group",objData.otherGroup)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

    // Take Login as other group user
    await browser.waitForAngularEnabled(false)
    await objHomePage.openApplication('/');      
    expect(await objLoginPage.setUserName(objLoginData.userNameOtherGroupUser)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordOtherGroupUser)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');


    //Account Should not have access to update status and Priority.
    expect(await objCommonPage.clickInTheTableCell("Priority",sDemoName)).toContain('Pass');
    expect(await objCommonPage.clickOnDDInTableCellUsingJavaScript("Priority")).not.toContain("Pass");

    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"ACL-Approved")).toContain('Pass');
    expect(await objCommonPage.verifyAlertHeader("Approval View")).not.toContain('Pass');

    //1.2.3. Verify that substrate type is selected as Full Wafer then user shall be able to update values of related fields on the displayed pop up in All view.
    expect(await objCommonPage.goToColumn("Substrate Type")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCellUsingJavaScript("Substrate Type",sDemoName)).toContain('Pass');
    expect(await objCommonPage.verifyAlertHeader("Edit")).not.toContain('Pass');

    //4. Verify that user shall not be able to include  BU Demo MultiType in Demo type field on All View when the demos status is other than New Request.
    expect(await objCommonPage.goToColumn("Demo Type")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Type",sDemoName)).toContain('Pass');
    expect(await objCommonPage.verifyAlertHeader("Edit")).not.toContain('Pass');
    
    //5. Verify that when current execution risk is updated to complete then Lab Ready, Demo Start Demo Completion date shall be marked as complete
    //Update value the Execution Risk to complete View
    expect(await objCommonPage.goToColumn("Current Execution Risk")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Current Execution Risk",sDemoName)).toContain('Pass');
    expect(await objCommonPage.clickOnDDInTableCellUsingJavaScript("Current Execution Risk")).not.toContain("Pass")

    //6. Verify that when the Demo Location values is updated then its related values shall be updatable or populated appropriately in My Demo Application.
    expect(await objCommonPage.goToColumn("Demo Location")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Location",sDemoName)).toContain('Pass');
    expect(await objCommonPage.verifyAlertHeader("Edit")).not.toContain('Pass');
    
    done();
});
it('TC_22-"Verify that when user swap the particular rows or particular columns then he/she should be able to save that changes in Personal View created using customize view button.', async (done)=>
{
            let objData = dataProvider.getJsonData("./data/allView.json", "TC_22");
            console.log(objData);
           //Login My Demo application
            expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
            expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
            expect(await objLoginPage.clickLogin()).toContain("Pass");
            await browser.waitForAngularEnabled(true);
            expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")
            expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
            expect(await objAllViewPage.clickOnCustomizedBtn()).toContain('Pass');
            expect(await objCommonPage.verifyAlertHeader("All View")).toContain('Pass');
            expect(await objAllViewPage.clickTabOnCustomizedViewPopUp("Update")).toContain('Pass')
            expect(await objAllViewPage.VerifyActiveTabOnCustomizedView("Update")).toContain('Pass');
            expect(await objAllViewPage.verifyBtnIsDisabledOnCustomizedView("Update")).toContain('Pass');
             expect(await objAllViewPage.selectViewToUpdateCustomizedViewPopUP(sViewNm,"Update View")).toContain('Pass');
            let sAvailableColList = (objData.availableColsList).split("~");
            for(var iCount = 0; iCount < sAvailableColList.length; iCount++)        {
                expect(await objAllViewPage.selectFromSelectedAvailableColList("Available Columns", sAvailableColList[iCount])).toContain('Pass');
                expect(await objAllViewPage.addColInSelectedColumnList()).toContain('Pass');
                expect(await objAllViewPage.verifyColPresentInSelectedAvailableColList("Selected Columns", sAvailableColList[iCount])).toContain('Pass');
            }
            let sSelectedColList = (objData.selectedColsList).split("~");
            for(var iCount = 0; iCount < sSelectedColList.length; iCount++)
            {
                expect(await objAllViewPage.selectFromSelectedAvailableColList("Selected Columns", sSelectedColList[iCount])).toContain('Pass');
                expect(await objAllViewPage.removeColFromSelectedColumnList()).toContain('Pass');
                expect(await objAllViewPage.verifyColPresentInSelectedAvailableColList("Available Columns", sSelectedColList[iCount])).toContain('Pass');
            }
            expect(await objAllViewPage.verifyBtnIsDisabledOnCustomizedView("Update")).not.toContain('Pass');
            expect(await objAllViewPage.clickBtnOnCustomizedView("Update")).toContain('Pass');
            sAlertMessage = "Successfully updated "+sViewNm+" view";
            expect(await objCommonPage.verifyAlertMessage(sAlertMessage)).toContain('Pass');
            expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
            done();
});
it('Delete view created using Customized view', async (done)=>
    {
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");
        await browser.waitForAngularEnabled(true);
        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');

        

        expect(await objAllViewPage.clickOnCustomizedBtn()).toContain('Pass');
        expect(await objCommonPage.verifyAlertHeader("All View")).toContain('Pass');
        expect(await objAllViewPage.clickTabOnCustomizedViewPopUp("Delete")).toContain('Pass')
        
        expect(await objAllViewPage.selectViewToUpdateCustomizedViewPopUP(sViewNm,"Delete View")).toContain('Pass');
        expect(await objAllViewPage.clickBtnOnCustomizedView("Delete")).toContain('Pass');
        sAlertMessage = "Do you really want to delete ?";
        expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
        sAlertMessage = ""+sViewNm+" view has been deleted";
        expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
        done();
});
it('TC_23-"Verify that when the demo request has no previous risk then it should be same as current risk field and When the current risk field is updated for the first time then the previous value will get current risk field value', async (done)=>
{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_23");
    console.log(objData);
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    //select menu option
    expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
    expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
    var iRandomNum = Math.floor(1000 + Math.random() * 9000);
    let sTC_23_DemoName = "TC_23_TestDemo_" + iRandomNum;
    console.log(sTC_23_DemoName);

    expect(await objNewDemoRequest.enterDemoName(sTC_23_DemoName)).toContain("Pass");
    expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");

    expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
    expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");

    expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
    expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
    expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
    expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
    expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");


    expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
    expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
    expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
    expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");

    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
    expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');
  
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sTC_23_DemoName)).toContain('Pass');
    expect(await objCommonPage.goToColumn("Previous Execution Risk")).toBeTruthy();
    expect(await objCommonPage.verifyTextValueInTableCell( "Previous Execution Risk",sTC_23_DemoName, objData.beforeExecRisk)).toBeTruthy();
    expect(await objCommonPage.verifyTextValueInTableCell( "Current Execution Risk",sTC_23_DemoName, objData.beforeExecRisk)).toBeTruthy();
    
    expect(await objCommonPage.goToColumn("Current Execution Risk")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Current Execution Risk",sTC_23_DemoName)).toContain('Pass');
    expect(await objCommonPage.selectOptionFromDDInTableColumn("Current Execution Risk",objData.currentExecRiskvalue)).toContain('Pass');
    
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sTC_23_DemoName)).toContain('Pass');
    expect(await objCommonPage.verifyTextValueInTableCell( "Current Execution Risk",sTC_23_DemoName, objData.afterExecRisk)).toBeTruthy();
    expect(await objCommonPage.verifyTextValueInTableCell( "Previous Execution Risk",sTC_23_DemoName,objData.afterExecRisk)).toBeTruthy();
    done();
});
it('TC_Pre-Requisite.', async(done)=>{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_Pre-Requisite");
    console.log(objData);
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    //select menu option
    expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
    expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
  
    var iRandomNum = Math.floor(1000 + Math.random() * 9000);
    sDemoName = "TestDemo_AllView" + iRandomNum;
    console.log(sDemoName);

    expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
    expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
  
    expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
    expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
   
    expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
    expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
    expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
    expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
    expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
 
    //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
    expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
    expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
    expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
    expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");
    browser.sleep(50000);
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
    expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');
    done();
});
it('TC_24-"Account super User will have edit access to the demos under the account for which he/she is account super.', async (done)=>
{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_24");
    console.log(objData);

    // Login as Global Admin User
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    
    //Approve New Created Demo and Assign Demo Owner as Account Super User.
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"New Request")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
    expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objData.demoOwner)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully";
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

     // Take Login as ACcount Super User
    await browser.waitForAngularEnabled(false);
    await objHomePage.openApplication('/');      
    expect(await objLoginPage.setUserName(objLoginData.userNameAccountSuperUser)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordAccountSuperUser)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
     
    //Go TO All View page and go on the demo details page
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
        //Edit the details on the demo details page.
    expect(await objAllViewPage.clickOnHyperLinkInDemoNumber(sDemoName)).toContain('Pass');
    expect(await objHomePage.getCurrentUrl("request_demo")).toContain("Pass");

    expect(await objDemoDetailsPage.clickFieldOnDemoDetailsWithoutScroll("Substrate Type")).toContain("Pass");
    expect(await objDemoDetailsPage.selectOptionFromFieldOnDemoDetails("Substrate Type",objData.substrateTypeDemo)).toContain("Pass");

    expect(await objDemoDetailsPage.clickFieldOnDemoDetails("Execution Risk")).toContain("Pass");
    expect(await objDemoDetailsPage.selectOptionFromFieldOnDemoDetails("Execution Risk",objData.exeRisk)).toContain("Pass");
    expect(await objDemoDetailsPage.clickOnSubmitDemoDetails()).toContain("Pass");
    let sAlert0="Demo Details Submitted Successfully."
    expect(await objCommonPage.verifyAlertMessage(sAlert0)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    expect(await objHomePage.getCurrentUrl("all-view")).toContain("Pass");
  
    done();
});
it('TC_25-Verify that BM approval toggle button should not be mandatory on TAMBA pop up in all the view screen.', async (done)=>
 {
        let objData = dataProvider.getJsonData("./data/allView.json", "TC_25");
         console.log(objData);
         //Login My Demo application
         expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
         expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
         expect(await objLoginPage.clickLogin()).toContain("Pass");
         await browser.waitForAngularEnabled(true);
         expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
        

         //create new demo
         expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
         expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
         expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
         expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
       
         var iRandomNum = Math.floor(1000 + Math.random() * 9000);
         let sDemoName = "TestDemo_AllView" + iRandomNum;
         console.log(sDemoName);
 
         expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
         expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
       
         expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
         expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
         expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
         expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
         expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
         expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
         expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
         expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
        
         expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
         expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
         expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");



         let sLoggedInUser;
         await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
         expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
         expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
         expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
         expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
         expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
         expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
         expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
         await objNewDemoRequest.clickOnBrowseButtonAgainstField("Customer Spec");
         const filePath = path.resolve('./autoItScripts/TestUpload_CustSpec.xlsx');
         const exePath = path.resolve('./autoItScripts/browseFile.exe')
         //await browser.sleep(5000);
         cp.execSync(exePath + ' ' + filePath);
         await browser.sleep(5000);
         expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
         expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Customer Spec")).toContain("Pass");
         expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");

         expect(await objNewDemoRequest.clickWaferStackOption(objData.waferStackOption)).toContain("Pass");
         await objNewDemoRequest.clickOnBrowseButtonAgainstField("Wafer Stack");
         const filePath1 = path.resolve('./autoItScripts/TestUpload_WaferStack.xlsx');

         //await browser.sleep(5000);
         cp.execSync(exePath + ' ' + filePath1);
         await browser.sleep(5000);
         expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
         expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Wafer Stack")).toContain("Pass");
         expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
         expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
         sAlertMessage = "Demo Request submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
       


       //Searched for the demo Name
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
        expect(await objCommonPage.goToColumn("TAMBA Name")).toContain('Pass');
        expect(await objCommonPage.clickInTheTableCellUsingJavaScript("TAMBA Name",sDemoName)).toContain('Pass');
        expect(await objNewDemoRequest.toggleField(objData.bmApprovedToggle, true)).toContain("Pass");
        expect(await objAllViewPage.verifyFieldIsMandatory("BM Owner")).toContain('Pass');
        expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');

        //create new Internal demo
        expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
        
        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        let sInternalDemoName = "Internal_TestDemo_" + iRandomNum;
        console.log(sInternalDemoName);

        expect(await objNewDemoRequest.enterDemoName(sInternalDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.toggleField('Internal Demo', true)).toContain("Pass");
        expect(await objNewDemoRequest.setInternalAccount(objData.internalAccount)).toContain("Pass");
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.setInternalAccountOwner(sLoggedInUser)).toContain("Pass");
 
     
        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");
      
        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Customer Spec");
       
        cp.execSync(exePath + ' ' + filePath);
        await browser.sleep(5000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Customer Spec")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");

        expect(await objNewDemoRequest.clickWaferStackOption(objData.waferStackOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Wafer Stack");
       
        cp.execSync(exePath + ' ' + filePath1);
        await browser.sleep(5000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Wafer Stack")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
        sAlertMessage = "Demo Request submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
      
        //Searched for the demo Name
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
        expect(await objCommonPage.searchRequest(sInternalDemoName)).toContain('Pass');
        expect(await objCommonPage.goToColumn("TAMBA Name")).toContain('Pass');
        expect(await objCommonPage.clickInTheTableCellUsingJavaScript("TAMBA Name",sInternalDemoName)).toContain('Pass');
        expect(await objNewDemoRequest.toggleField(objData.bmApprovedToggle, true)).toContain("Pass");
        expect(await objAllViewPage.verifyFieldIsMandatory("BM Owner")).toContain('not');
        expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');      
       
        done();
});
it('TC_Pre-Requisite.', async(done)=>{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_Pre-Requisite");
    console.log(objData);
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    //select menu option
    expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
    expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
  
    var iRandomNum = Math.floor(1000 + Math.random() * 9000);
    sDemoName = "TestDemo_AllView" + iRandomNum;
    console.log(sDemoName);

    expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
    expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
  
    expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
    expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
   
    expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
    expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
    expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
    expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
    expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
 
    //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
    expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
    expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
    expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
    expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
    expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');

    //Approve the Newly created Demo on All view Page
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"New Request")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
    expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objData.demoOwner)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    done();
   
}); 
it('TC_27-"Verify that user shall be able to see Approved by column in Grid so that he or she will get to know that who approved the demo', async (done)=>
{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_27");
    console.log(objData);
   //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")
    //User is on All view Page
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    //Take the approved demo
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    //go to the Approved By col and get the value of the user for particular Demo name
    expect(await objCommonPage.goToColumn("Approved By")).toContain('Pass');
    expect(await objAllViewPage.verifyApprovedByCol("Approved By",sDemoName,sLoggedInUser)).toContain('Pass');
    done();
    
});
it('TC_28-"When a demo is updated from Grid view,Verify that the landing page shall be grid view instead of the home page', async (done)=>
{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_28");
    console.log(objData);
   //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")
    //User is on All view Page
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    //Checking for Approved Demo if it have demo number as hyperlink or not
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.verifyVisibleHyperLinkForACLStatus("Demo Number","Demo Approval",sDemoName)).toContain("Pass");
    expect(await objCommonPage.clickInTheTableCell("Demo Number",sDemoName)).toContain('Pass');
    expect(await objDemoDetailsPage.clickFieldOnDemoDetailsWithoutScroll("Substrate Type")).toContain("Pass");
    expect(await objDemoDetailsPage.selectOptionFromFieldOnDemoDetails("Substrate Type",objData.substrateType)).toContain("Pass");
    expect(await objDemoDetailsPage.clickFieldOnDemoDetails("Execution Risk")).toContain("Pass");
    expect(await objDemoDetailsPage.selectOptionFromFieldOnDemoDetails("Execution Risk",objData.exeRisk)).toContain("Pass");
    expect(await objDemoDetailsPage.clickOnSubmitDemoDetails()).toContain("Pass");
    let sAlert="Demo Details Submitted Successfully."
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    expect(await objHomePage.getCurrentUrl("all-view")).toContain("Pass");

    //Update value from GRID View
    expect(await objCommonPage.goToColumn("Current Execution Risk")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Current Execution Risk",sDemoName)).toContain('Pass');
    expect(await objCommonPage.selectOptionFromDDInTableColumn("Current Execution Risk","Low")).toContain('Pass');
    expect(await objHomePage.getCurrentUrl("all-view")).toContain("Pass");
   
    done();
});
it('TC_29-Verify that whenever Execution Risk is marked as complete then there will be expected changes in Demo Completion and demo milestones status',async (done)=>
{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_29");
    console.log(objData);
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    // Go to All view and select Demo Completion as completed
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');

    //Update value the Execution Risk to complete View
    expect(await objCommonPage.goToColumn("Current Execution Risk")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Current Execution Risk",sDemoName)).toContain('Pass');
    expect(await objCommonPage.selectOptionFromDDInTableColumn("Current Execution Risk","Complete")).toContain('Pass');
    expect(await objCommonPage.verifyTextValueInTableCell("Current Execution Risk", sDemoName, "C")).toContain("Pass");

    // Check Demo Completion marked as completed 
    expect(await objCommonPage.goToColumn("Demo Completion")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Completion",sDemoName)).toContain("Pass");
    expect(await objAllViewPage.getFieldValueOnPopUp("Schedule Completion Date Milestone Status")).toContain("Completed");
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');


    // Check Demo Start marked as completed 
    expect(await objCommonPage.goToColumn("Demo Start")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Start",sDemoName)).toContain("Pass");
    expect(await objAllViewPage.getFieldValueOnPopUp("Demo Start Milestone Status")).toContain("Completed");
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');

    // Check Lab Ready marked as completed 
    expect(await objCommonPage.goToColumn("Lab Ready")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Lab Ready",sDemoName)).toContain("Pass");
    expect(await objAllViewPage.getFieldValueOnPopUp("Lab Ready Milestone Status")).toContain("Completed");
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');
    done();
});
it('TC_Pre-Requisite.', async(done)=>{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_Pre-Requisite");
    console.log(objData);
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    //select menu option
    expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
    expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
  
    var iRandomNum = Math.floor(1000 + Math.random() * 9000);
    sDemoName = "TestDemo_AllView" + iRandomNum;
    console.log(sDemoName);

    expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
    expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
  
    expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
    expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
   
    expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
    expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
    expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
    expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
    expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
 
    expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
    expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
    expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
    expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
    expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');
    done();
   
});
it('TC_30-Verify that productivity owner field is added to all view screens in MyDemo Application', async (done)=>
{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_30");
    console.log(objData);
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    // Go to All view and select Demo Completion as completeds
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objCommonPage.goToColumn("Productivity Owner")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Productivity Owner",sDemoName)).toContain("Pass");
    expect(await objAllRequestPage.selectOwnerOnPopUp("Productivity Owner",objData.productivityOwner)).toContain("Pass")
    expect(await objCommonPage.clickOnBtnOnPopup("Save")).toContain("Pass");
    expect(await objCommonPage.verifyTextValueInTableCell("Productivity Owner", sDemoName, objData.productivityOwner)).toContain("Pass");

    //Approve the Newly created Demo on All view Page
    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"New Request")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
    expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",sLoggedInUser)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');	

    
    let sDemoNumber = await objCommonPage.getTableCellValue("Demo Number",sDemoName);
    console.log(sDemoNumber);

    // Checking Email Notification for status change
    let sMailHeader = "Status change for Demo Request "+sDemoNumber+"";
    await browser.waitForAngularEnabled(false);
    await browser.sleep(50000);
    await objHomePage.openWebmail(objLoginData.outlookUrl);
    expect(await objOutlookPage.verifyOutllookEmailExists(objLoginData.outlookUserName, "", sMailHeader)).toContain("Pass");
    //expect(await objOutlookPage.verifyOutllookEmailExistsSecondTime( sMailHeader)).toContain("Pass");
    await browser.sleep(5000);
    expect(await objOutlookPage.verifyMailBodyWithDemoNumNmInBold(sDemoName, sDemoNumber)).toContain("Pass");
    done();
});
it('TC_30_1-Verify that productivity owner field is added to all view screens in MyDemo Application-Updating Milestone', async (done)=>
{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_30");
    console.log(objData);
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    // Go to All view and and get the demo Number
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    

    // Go to All View and update the milestone values
    expect(await objCommonPage.goToColumn("Current Execution Risk")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Current Execution Risk",sDemoName)).toContain('Pass');
    expect(await objCommonPage.selectOptionFromDDInTableColumn("Current Execution Risk","Complete")).toContain('Pass');

    let sDemoNumber = await objCommonPage.getTableCellValue("Demo Number",sDemoName);
    console.log(sDemoNumber);
   
    // Checking Email Notification for milestone update
    let sMailHeader1 = "MileStone change for Demo Request "+sDemoNumber+"";
    await browser.waitForAngularEnabled(false);
    await browser.sleep(50000);
    await objHomePage.openWebmail(objLoginData.outlookUrl);
    expect(await objOutlookPage.verifyOutllookEmailExistsSecondTime(sMailHeader1)).toContain("Pass");
    done();
});
it('TC_31-"Verify that when a user reach demo details from any of the view screen then when he reach back to the same view screen the changes or settings made by user should remain same', async (done)=>
{
     let objData = dataProvider.getJsonData("./data/allView.json", "TC_31");
     console.log(objData);
    //Login My Demo application as global admin user
     expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
     expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
     expect(await objLoginPage.clickLogin()).toContain("Pass");
     await browser.waitForAngularEnabled(true);
     expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")
     
     expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
     let sLoggedInUser;
     await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
     //Search for the demo Name
     expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
     //get first Demo Name after searching
     let sFirstDemoName = await objCommonPage.getTheLatestDemoNm();
     //click on the hyperlink
     expect(await objCommonPage.clickInTheTableCell("Demo Number",sFirstDemoName)).toContain('Pass');   
      //verified request page 
     expect(await objHomePage.getCurrentUrl("request_demo")).toContain("Pass");
     //navigated to previous page
     await browser.driver.navigate().back();
     console.info("Clicked on back button on browser")
     //verified all view page
     expect(await objHomePage.getCurrentUrl("all-view")).toContain("Pass");
     expect(await objCommonPage.getTheLatestDemoNm()).toContain(sFirstDemoName);
     done();
});
it('TC_Pre-Requisite.', async(done)=>{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_Pre-Requisite");
    console.log(objData);
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    //select menu option
    expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
    expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
  
    var iRandomNum = Math.floor(1000 + Math.random() * 9000);
    sDemoName = "TestDemo_AllView" + iRandomNum;
    console.log(sDemoName);

    expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
    expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
  
    expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
    expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
   
    expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
    expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
    expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
    expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
    expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
 
    //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
    expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
    expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
    expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
    expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
    expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');
    done();
   
});
it('TC_32-"Verify that all the fields except Demo Approval & Justication are hidden while updating the status to reject, or on hold from New Request and those fields shall be made as non-mandatory.', async (done)=>
{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_32");
    console.log(objData);
   //Login My Demo application as BU Super User
    expect(await objLoginPage.setUserName(objLoginData.userNameBUSuperUser)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordBUSuperUser)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")
    //User is on All view Page
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    //Search or the demo which is having status as new request and selecting it's status as "BCL - On Hold"
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"New Request")).toContain('Pass');
    expect(await objAllViewPage.clickFieldOnThePopUp("Demo Approval")).toContain('Pass');
    expect(await objAllViewPage.selectOptionsFromDDOnPopUp("Demo Approval","BCL - On Hold")).toContain('Pass');
    expect(await objAllViewPage.setInputOnPopUp("Justification","Testing for BCL-hold")).toContain('Pass');
    //verifying field is mandate/disabled or not in the same method
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Demo Number")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Demo Name")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Wafer Status")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Priority")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Demo Owner")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Co-Owner")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("CAT/RAT Manager")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Execution Risk")).toContain('Pass');
    //selecting it's status as "Rejected"
    expect(await objAllViewPage.selectOptionsFromDDOnPopUp("Demo Approval","Rejected")).toContain('Pass');
    expect(await objAllViewPage.setInputOnPopUp("Justification","Testing for rejected")).toContain('Pass');
     //verifying field is mandate/disabled or not in the same method
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Demo Number")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Demo Name")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Wafer Status")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Priority")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Demo Owner")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Co-Owner")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("CAT/RAT Manager")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Execution Risk")).toContain('Pass');
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');
    done();
});
it('TC_33-"Verify that all the fields except Demo Approval & Justication are hidden while updating the status to Cancel, or on hold from Approved Request and those fields shal be made as non-mandatory.', async (done)=>
{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_33");
    console.log(objData);
   //Login My Demo application as BU Super User
    expect(await objLoginPage.setUserName(objLoginData.userNameBUSuperUser)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordBUSuperUser)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")

   //Approve the Newly created Demo on All view Page
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"New Request")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
    expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objData.demoOwner)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    
    //Search or the demo which is having status as approved and selecting it's status as "BCL - On Hold"
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"ACL-Approved")).toContain('Pass');
    expect(await objAllViewPage.clickFieldOnThePopUp("Demo Approval")).toContain('Pass');
    expect(await objAllViewPage.selectOptionsFromDDOnPopUp("Demo Approval","BCL - On Hold")).toContain('Pass');
    expect(await objAllViewPage.setInputOnPopUp("Justification","Testing for BCL-hold")).toContain('Pass');
    //verifying field is mandate/disabled or not in the same method
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Demo Number")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Demo Name")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Wafer Status")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Priority")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Demo Owner")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Co-Owner")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("CAT/RAT Manager")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Execution Risk")).toContain('Pass');
    //selecting it's status as "Cancel"
    expect(await objAllViewPage.selectOptionsFromDDOnPopUp("Demo Approval","Cancelled")).toContain('Pass');
    expect(await objAllViewPage.setInputOnPopUp("Justification","Testing for Cancel")).toContain('Pass');
     //verifying field is mandate/disabled or not in the same method
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Demo Number")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Demo Name")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Wafer Status")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Priority")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Demo Owner")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Co-Owner")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("CAT/RAT Manager")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Execution Risk")).toContain('Pass');
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');
    done();
});
it('TC_34-"verify that justification field shall be made as mandatory whenver user changes the status of demo other than Approved/closed on Views Screen', async (done)=>
{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_34");
    console.log(objData);
   //Login My Demo application as BU Super User
    expect(await objLoginPage.setUserName(objLoginData.userNameBUSuperUser)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordBUSuperUser)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")
    //User is on All view Page
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    //Search or the demo which is having status as approved and selecting it's status as "BCL - On Hold"
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"ACL-Approved")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsPresentPopUp("Justification")).not.toContain('Pass');
    expect(await objAllViewPage.clickFieldOnThePopUp("Demo Approval")).toContain('Pass');
    expect(await objAllViewPage.selectOptionsFromDDOnPopUp("Demo Approval","BCL - On Hold")).toContain('Pass');
    //verifying field is field is present and mandate
    expect(await objAllViewPage.verifyFieldIsPresentPopUp("Justification")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsMandatory("Justification")).toContain('Pass');
    //Entering data in the Justification Field.
    expect(await objAllViewPage.setInputOnPopUp("Justification","Testing for BCL-hold")).toContain('Pass');
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');
    done();
});
it('TC_35-"Verify that user shall not be able to submit the changes on approval screen without filling the mandatory fields', async (done)=>
{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_34");
    console.log(objData);
   //Login My Demo application as BU Super User
    expect(await objLoginPage.setUserName(objLoginData.userNameBUSuperUser)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordBUSuperUser)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")
    //User is on All view Page
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    //Search or the demo which is having status as approved and selecting it's status as "BCL - On Hold"
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"ACL-Approved")).toContain('Pass');
    expect(await objAllViewPage.clickFieldOnThePopUp("Demo Approval")).toContain('Pass');
    expect(await objAllViewPage.selectOptionsFromDDOnPopUp("Demo Approval","BCL - On Hold")).toContain('Pass');
    //verifying field is field is present and mandate
    expect(await objAllViewPage.verifyFieldIsPresentPopUp("Justification")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsMandatory("Justification")).toContain('Pass');
    //checking save btn without entering mandate field
    expect(await objAllViewPage.verifySaveBtnIsDisabledOnPopUp()).toContain('Pass');
    //Entering data in the Justification Field.
    expect(await objAllViewPage.setInputOnPopUp("Justification","Testing for BCL-hold")).toContain('Pass');
    //checking save btn after entering mandate field
    expect(await objAllViewPage.verifySaveBtnIsDisabledOnPopUp()).not.toContain('Pass');
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');
    done();
});
it('TC_36-"Verify that the grid data on All View shall be exported into excel file.', async (done)=>
 {
     let objData = dataProvider.getJsonData("./data/allView.json", "TC_36");
     console.log(objData);
     const os = require('os'); 
     const sDownloadPath = os.homedir()+"/Downloads/";
     await objCommonPage.deleteFileFromDownloadsDir(sDownloadPath+"All View"+".xlsx");
    //Login My Demo application as global admin user
     expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
     expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
     expect(await objLoginPage.clickLogin()).toContain("Pass");
     await browser.waitForAngularEnabled(true);
     expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
     //verify and click on export button from ALL view
     expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
     expect(await objCommonPage.verifyExportBtnPresent()).toContain('Pass'); 
     expect(await objCommonPage.clickExportButton("All View")).toContain("Pass");
     await browser.sleep(5000);
     //verify demoName is present in excel exported from ALL view
     expect(await objExcelWrapper.verifyExcelCellValuesofSingleRowForSpecifiedColumn(sDownloadPath + objData.excelFileName+".xlsx",objData.excelFileName,objData.excelCoumnName,sDemoName)).toBe(true);
     done();
});
it('TC_37-Verify that user shall not be able to add random text in people picker on view screens.There should be a validation', async (done)=>
{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_37");
    console.log(objData);
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    //select menu option
    expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
    expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");

    var iRandomNum = Math.floor(1000 + Math.random() * 9000);
    let sDemoName = "TestDemo_AllView" + iRandomNum;
    console.log(sDemoName);

    expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
    expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");

    expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
    expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");

    expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
    expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
    expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
    expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
    expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");


    expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
    expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
    expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
    expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");

    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
    expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');
    
   
    //search request and update demo owner name
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Owner",sDemoName)).toContain('Pass');
    expect(await objCommonPage.selectPeoplePickerVal("Demo Owner",sLoggedInUser)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');

    //fetch all existing values and update dummy values
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Owner",sDemoName)).toContain('Pass');
    let sCo_Owner;
    objCommonPage.getTableCellValue("Co-Owner",sDemoName).then(function(sText){sCo_Owner=sText });
    expect(await objCommonPage.setValInPeoplePicker("Demo Owner","abcd")).toContain('Pass');
    expect(await objCommonPage.setValInPeoplePicker("Co-Owner","abcd")).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');    
    
    expect(await objCommonPage.goToColumn("Account Owner")).toContain("Pass")
    let sAcc_Owner;
    objCommonPage.getTableCellValue("Account Owner",sDemoName).then(function(sText){sAcc_Owner=sText });
    expect(await objCommonPage.clickInTheTableCell("Account Owner",sDemoName)).toContain('Pass');
    expect(await objCommonPage.setValInPeoplePicker("Account Owner","abcd")).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');   

    expect(await objCommonPage.goToColumn("Productivity Owner")).toContain("Pass")
    let sProd_Owner;
    objCommonPage.getTableCellValue("Productivity Owner",sDemoName).then(function(sText){sProd_Owner = sText;});    
    expect(await objCommonPage.clickInTheTableCell("Productivity Owner",sDemoName)).toContain('Pass');
    expect(await objCommonPage.setValInPeoplePicker("Productivity Owner","abcd")).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');

    //Vrif the values are not updated
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(objCommonPage.getTableCellValue("Demo Owner",sDemoName)).toContain(sLoggedInUser);
    expect(objCommonPage.getTableCellValue("Co-Owner",sDemoName)).toContain(sCo_Owner);
    expect(await objCommonPage.goToColumn("Account Owner")).toContain("Pass")
    expect(objCommonPage.getTableCellValue("Account Owner",sDemoName)).toContain(sAcc_Owner);
    expect(await objCommonPage.goToColumn("Productivity Owner")).toContain("Pass")
    expect(objCommonPage.getTableCellValue("Productivity Owner",sDemoName)).toBeCloseTo(sProd_Owner);
    done();
});
it('TC_Pre-Requisite-Create Demo Uploading Documents',async(done)=>{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_Pre-Requisite_1");
    console.log(objData);
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    //Create a new demo by uploading wafer stack and CustSpec Documents
    expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
    expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
   
    var iRandomNum = Math.floor(1000 + Math.random() * 9000);
    sDemoName = "TestDemo_AllView" + iRandomNum;
    console.log(sDemoName);

    expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
    expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
   
    expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
    expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
    
    expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
    expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
    expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
    expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
    expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
    await objNewDemoRequest.clickOnBrowseButtonAgainstField("Customer Spec");
    const filePath = path.resolve('./autoItScripts/TestUpload_CustSpec.xlsx');
    const exePath = path.resolve('./autoItScripts/browseFile.exe')
    //await browser.sleep(5000);
    cp.execSync(exePath + ' ' + filePath);
    await browser.sleep(5000);
    expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
    expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Customer Spec")).toContain("Pass");
    expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
    expect(await objNewDemoRequest.verifyChkboxStatusAgainstField("Customer Spec", "Upload", "true")).toContain("Pass");

    expect(await objNewDemoRequest.clickWaferStackOption(objData.waferStackOption)).toContain("Pass");
    await objNewDemoRequest.clickOnBrowseButtonAgainstField("Wafer Stack");
    const filePath1 = path.resolve('./autoItScripts/TestUpload_WaferStack.xlsx');
    //await browser.sleep(5000);
    cp.execSync(exePath + ' ' + filePath1);
    await browser.sleep(5000);
    expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
    expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Wafer Stack")).toContain("Pass");
    expect(await objNewDemoRequest.verifyChkboxStatusAgainstField("Wafer Stack", "Upload", "true")).toContain("Pass");
    expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
   
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
    expect(await objCommonPage.clickOnOkBtnOnPopUp()).toContain('Pass'); 
    done();
});
it('TC_38-"Verify the required changes in demo decision status + 1.User should be able to undo closed back to approved, and Approved to closed and BCL-Closed', async (done)=>
{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_38");
    console.log(objData);

    // Login as Global Admin User
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

     //Approve the Newly created Demo on All view Page
     expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
     expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
     expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"New Request")).toContain('Pass');
     expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
     expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
     expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objData.demoOwner)).toContain('Pass');
     expect(await objAllViewPage.clickOnSave()).toContain('Pass');
     let sAlert="Approval Saved Successfully"
     expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
     expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

     //Go to All view Page and  Change the Exceution Risk to complete and update wafer location and close the demo (Checking Approved to closed)
    expect(await objCommonPage.goToColumn("Current Execution Risk")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Current Execution Risk",sDemoName)).toContain('Pass');
    expect(await objCommonPage.selectOptionFromDDInTableColumn("Current Execution Risk","Complete")).toContain('Pass');
 
    expect(await objCommonPage.goToColumn("Wafer Location")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Wafer Location",sDemoName)).toContain('Pass');
    expect(await objCommonPage.selectOptionFromDDInTableColumn("Wafer Location","In transit to account")).toContain('Pass');
 
    // Attach the demo report by clicking on the attachement icon
    expect(await objAllRequestPage.clickOnTheAttachmentIcon()).toContain('Pass');
    expect(await objAllRequestPage.clickOnBrowseButtonOnViewAttachment()).toContain("Pass");
    const filePath = path.resolve('./autoItScripts/Data_Report.xlsx');
    const exePath = path.resolve('./autoItScripts/browseFile.exe')
    cp.execSync(exePath + ' ' + filePath);
    
    expect(await objAllViewPage.selectValueFromDDOnAttachmentPopUp("Security", objData.ddSecurityVal)).toContain("Pass");
    expect(await objAllViewPage.selectValueFromDDOnAttachmentPopUp("Category", "Demo Report")).toContain("Pass");
     
    expect(await objAllRequestPage.clickOnUploadButtonOnViewAttachment()).toContain("Pass");
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');
    //Close the Demo
    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"ACL-Approved")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","Closed")).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');


    //Check the Closed to Approved 
    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"Closed")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');


    //  //Check the Approved to BCL Hold 
    //  expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"ACL-Approved")).toContain('Pass');
    //  expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","BCL - On Hold")).toContain('Pass');
    //  expect(await objAllViewPage.setInputOnPopUp("Justification","Testing for BCL-Hold")).toContain('Pass');
    //  expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    //  expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    //  expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');


    //  //BCL-Hold to closed
    //  expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"BCL-On Hold")).toContain('Pass');
    //  expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","Closed")).toContain('Pass');
    //  expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    //  expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    //  expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    done();
   
});
it('TC_Pre-Requisite.', async(done)=>{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_Pre-Requisite");
    console.log(objData);
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    //select menu option
    expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
    expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
  
    var iRandomNum = Math.floor(1000 + Math.random() * 9000);
    sDemoName = "TestDemo_AllView" + iRandomNum;
    console.log(sDemoName);

    expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
    expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
  
    expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
    expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
   
    expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
    expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
    expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
    expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
    expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
 
    //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
    expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
    expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
    expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
    expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
    expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');
    done();
   
});
it('TC_38_1-"Verify the required changes in demo decision status->Rejected  - ACL or Back to Draft (Justification required) For this change demo should be returned to a draft stage and the requestion will receive a notification of the changeed.', async (done)=>
{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_38");
    console.log(objData);

    // Login as Global Admin User
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

    //Go to All View Page and Reject the newly created Demo
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"New Request")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","Rejected")).toContain('Pass');
    expect(await objAllViewPage.setInputOnPopUp("Justification","Testing for rejected")).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully";
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

    let sDemoNumber = await objCommonPage.getTableCellValue("Demo Number",sDemoName);
    console.log(sDemoNumber);

    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});

    // Rejected To Draft
    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"Rejected")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","Draft")).toContain('Pass');
    expect(await objAllViewPage.setInputOnPopUp("Justification","Testing for Draft")).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass'); 


    // Checking Email Notification for send back for updation(Rejected to Draft)
    let sMailHeader = "Demo Request "+sDemoNumber+" send back for updation";
    await browser.waitForAngularEnabled(false);
    await browser.sleep(5000);
    await objHomePage.openWebmail(objLoginData.outlookUrl);
    expect(await objOutlookPage.verifyOutllookEmailExistsSecondTime(sMailHeader)).toContain("Pass");
    await browser.sleep(5000);
    expect(await objOutlookPage.verifyMailBodyWithDemoNumNmInBold(sDemoName, sDemoNumber)).toContain("Pass");
    done();
   
});
it('TC_Pre-Requisite.', async(done)=>{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_Pre-Requisite");
    console.log(objData);
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    //select menu option
    expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
    expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
  
    var iRandomNum = Math.floor(1000 + Math.random() * 9000);
    sDemoName = "TestDemo_AllView" + iRandomNum;
    console.log(sDemoName);

    expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
    expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
  
    expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
    expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
   
    expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
    expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
    expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
    expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
    expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
 
    //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
    expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
    expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
    expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
    expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
    expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');
    done();
   
});
it('TC_38_2-"Verify the required changes in demo decision status->Approved to cancelled and cencelled to Approved', async (done)=>
{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_38");
    console.log(objData);

    // Login as Global Admin User
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

     //Approve the Newly created Demo on All view Page
     expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
     expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
     expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"New Request")).toContain('Pass');
     expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
     expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
     expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objData.demoOwner)).toContain('Pass');
     expect(await objAllViewPage.clickOnSave()).toContain('Pass');
     let sAlert="Approval Saved Successfully"
     expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
     expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

    //Check Approved to cancelled

    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"ACL-Approved")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","Cancelled")).toContain('Pass');
    expect(await objAllViewPage.setInputOnPopUp("Justification","Testing for Cancelled")).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

    

    // cancelled to Approved
    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"Cancelled")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    done();
   
});
it('TC_Pre-Requisite.', async(done)=>{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_Pre-Requisite");
    console.log(objData);
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    //select menu option
    expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
    expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
  
    var iRandomNum = Math.floor(1000 + Math.random() * 9000);
    sDemoName = "TestDemo_AllView" + iRandomNum;
    console.log(sDemoName);

    expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
    expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
  
    expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
    expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
   
    expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
    expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
    expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
    expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
    expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
 
    //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
    expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
    expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
    expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
    expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
    expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');

    //Hold the Newly created Demo on All view Page
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"New Request")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","BCL - On Hold")).toContain('Pass');
    expect(await objAllViewPage.setInputOnPopUp("Justification","Testing for BCL-hold")).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    done();
   
});
it('TC_39-"Verify that when ever approval status is changed then the existing comment in comment section should be cleared so that user can enter new comment and submit it', async (done)=>
{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_39");
    console.log(objData);
   //Login My Demo application as BU Super User
    expect(await objLoginPage.setUserName(objLoginData.userNameBUSuperUser)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordBUSuperUser)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")
    //User is on All view Page
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    //Searched for the demo which is having status as "BCL - On Hold"
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"BCL-On Hold")).toContain('Pass');
    //Checking Justifictaion comment is having value before changing the status
    expect(await objAllViewPage.verifyCommentIsEmptyOnApprovalPopUp()).not.toContain('Pass');
    expect(await objAllViewPage.clickFieldOnThePopUp("Demo Approval")).toContain('Pass');
    expect(await objAllViewPage.selectOptionsFromDDOnPopUp("Demo Approval","Cancelled")).toContain('Pass');
     //Checking Justifictaion comment value is empty after changing status.
    expect(await objAllViewPage.verifyCommentIsEmptyOnApprovalPopUp()).toContain('Pass');
    //Entering data in the Justification Field.
    expect(await objAllViewPage.setInputOnPopUp("Justification","Testing for Cancelled")).toContain('Pass');
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');
    done();
});
it('TC_Pre-Requisite.', async(done)=>{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_Pre-Requisite");
    console.log(objData);
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    //select menu option
    expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
    expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
  
    var iRandomNum = Math.floor(1000 + Math.random() * 9000);
    sDemoName = "TestDemo_AllView" + iRandomNum;
    console.log(sDemoName);

    expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
    expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
  
    expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
    expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
   
    expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
    expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
    expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
    expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
    expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
 
    //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
    expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
    expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
    expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
    expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
    expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');

    //Approve the Newly created Demo on All view Page
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"New Request")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
    expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objLoginData.userNameAccountExecSuperUser)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    done();
   
});
it('TC_40-Verify that Account Executive User will be able to see Demo Details page with Read only mode for assigned demo request', async (done)=>
{ 
   //Login My Demo application as Account Executive User
    expect(await objLoginPage.setUserName(objLoginData.userNameAccountExecSuperUser)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordAccountExecSuperUser)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    //User is on All view Page
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    expect(await objAllViewPage.selectStatusFromStatusDD("ACL - Approved")).toContain("Pass");
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.clickOnHyperLinkInDemoNumber(sDemoName)).toContain('Pass');
    expect(await objDemoDetailsPage.verifyFieldIsDisabledOnDemoDetailsPage("Demo Number")).toContain('Pass');
    expect(await objDemoDetailsPage.verifyFieldIsDisabledOnDemoDetailsPage("Demo Name")).toContain('Pass');    
    expect(await objDemoDetailsPage.verifyFieldIsDisabledOnDemoDetailsPage("Demo Owner")).toContain('Pass');
    expect(await objDemoDetailsPage.verifyFieldIsDisabledOnDemoDetailsPage("Co-Owner")).toContain('Pass');
    expect(await objDemoDetailsPage.verifyFieldIsDisabledOnDemoDetailsPage("Account")).toContain('Pass');
    expect(await objDemoDetailsPage.verifyFieldIsDisabledOnDemoDetailsPage("Demo Type")).toContain('Pass');
    expect(await objDemoDetailsPage.clickOnBtn("Cancel")).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
 
    // expect(await objCommonPage.clickInTheTableCell("Demo Name",sDemoName)).toContain('Pass');
    // expect(await objCommonPage.verifyFieldisNotEditable("Demo Name",sDemoName)).toContain('Fail');
    // expect(await objCommonPage.clickInTheTableCell("Demo Owner",sDemoName)).toContain('Pass');
    // expect(await objCommonPage.verifyAlertHeader("Edit")).toContain('Fail');
    // expect(await objCommonPage.clickInTheTableCell("Co-Owner",sDemoName)).toContain('Pass');
    // expect(await objCommonPage.verifyAlertHeader("Edit")).toContain('Fail');
    // expect(await objCommonPage.goToColumn("Account")).toBeTruthy();
    // expect(await objCommonPage.clickInTheTableCell("Account",sDemoName)).toContain('Pass');
    // expect(await objCommonPage.verifyAlertHeader("Edit")).toContain('Fail');
    // expect(await objCommonPage.goToColumn("Account Owner")).toBeTruthy();
    // expect(await objCommonPage.clickInTheTableCell("Account Owner",sDemoName)).toContain('Pass');
    // expect(await objCommonPage.verifyAlertHeader("Edit")).toContain('Fail');
    // expect(await objCommonPage.goToColumn("Demo Type")).toBeTruthy();
    // expect(await objCommonPage.clickInTheTableCell("Demo Type",sDemoName)).toContain('Pass');
    // expect(await objCommonPage.verifyAlertHeader("Edit")).toContain('Fail');  
    done();
});
it('TC_41-"In View screens tamba popup and 29 field options should be Yes and No', async (done)=>
{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_41");
    console.log(objData);
   //Login My Demo application as global admin user
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")
    //User is on All view Page
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    //Searched for the demo Name
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objCommonPage.goToColumn("TAMBA Name")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCellUsingJavaScript("TAMBA Name",sDemoName)).toContain('Pass');
    expect(await objNewDemoRequest.toggleField('TAMBA', false)).toContain("Pass");
    expect(await objAllViewPage.clickFieldOnThePopUp("29% List")).toContain('Pass');
    expect(await objAllViewPage.getOptionsOnPopUp("29% List")).toContain(objData.ddList);
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');
    done();
});
it('TC_Pre-Requisite.', async(done)=>{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_Pre-Requisite");
    console.log(objData);
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    //select menu option
    expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
    expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
  
    var iRandomNum = Math.floor(1000 + Math.random() * 9000);
    sDemoName = "TestDemo_AllView" + iRandomNum;
    console.log(sDemoName);

    expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
    expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
  
    expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
    expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
   
    expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
    expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
    expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
    expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
    expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
 
    //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
    expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
    expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
    expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
    expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
    expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');


    //Approve the Newly created Demo on All view Page
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"New Request")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
    expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objData.demoOwner)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    done();
   
});
it('TC_42-"Verify that Other Group User is able to access Demo Details page of assigned Demo Request with Read Only Mode access.', async (done)=>
     {
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_42");
    console.log(objData);

    // Login as Global Admin User
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    
    //Search or the demo and update Other Group
    expect(await objHomePage.selectMenuOption("All Demo's", "Grant Demo Access")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Name",sDemoName)).toContain('Pass');
    expect(await objAllViewPage.setInputOnPopUp("Other Group",objData.otherGroup)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

    // Take Login as other group user
    await browser.waitForAngularEnabled(false)
    await objHomePage.openApplication('/');      
    expect(await objLoginPage.setUserName(objLoginData.userNameOtherGroupUser)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordOtherGroupUser)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
     
    //Go TO All View page and and Search for demo.
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');


    //Edit the details on the demo details page.
    expect(await objAllViewPage.clickOnHyperLinkInDemoNumber(sDemoName)).toContain('Pass');
    expect(await objHomePage.getCurrentUrl("request_demo")).toContain("Pass");
 
    expect(await objDemoDetailsPage.clickFieldOnDemoDetailsWithoutScroll("Substrate Type")).toContain("Pass");
    // expect(await objDemoDetailsPage.selectOptionFromFieldOnDemoDetails("Substrate Type",objData.substrateTypeDemo)).not.toContain("Pass");
 
    expect(await objDemoDetailsPage.clickFieldOnDemoDetails("Execution Risk")).toContain("Pass");
    // expect(await objDemoDetailsPage.selectOptionFromFieldOnDemoDetails("Execution Risk",objData.exeRisk)).toContain("Pass");
    // expect(await objDemoDetailsPage.clickOnSubmitDemoDetails()).toContain("Pass");
    // let sAlert1="Demo Details Submitted Successfully."
    // expect(await objCommonPage.verifyAlertMessage(sAlert1)).toContain('Pass');
    // expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
   
    done();
});
it('TC_Pre-Requisite-Create Demo Uploading Documents',async(done)=>{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_Pre-Requisite_1");
    console.log(objData);
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    //Create a new demo by uploading wafer stack and CustSpec Documents
    expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
    expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
   
    var iRandomNum = Math.floor(1000 + Math.random() * 9000);
    sDemoName = "TestDemo_AllView" + iRandomNum;
    console.log(sDemoName);

    expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
    expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
   
    expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
    expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
    
    expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
    expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
    expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
    expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
    expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
    await objNewDemoRequest.clickOnBrowseButtonAgainstField("Customer Spec");
    const filePath = path.resolve('./autoItScripts/TestUpload_CustSpec.xlsx');
    const exePath = path.resolve('./autoItScripts/browseFile.exe')
    //await browser.sleep(5000);
    cp.execSync(exePath + ' ' + filePath);
    await browser.sleep(5000);
    expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
    expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Customer Spec")).toContain("Pass");
    expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
    expect(await objNewDemoRequest.verifyChkboxStatusAgainstField("Customer Spec", "Upload", "true")).toContain("Pass");
    

    expect(await objNewDemoRequest.clickWaferStackOption(objData.waferStackOption)).toContain("Pass");
    await objNewDemoRequest.clickOnBrowseButtonAgainstField("Wafer Stack");
    const filePath1 = path.resolve('./autoItScripts/TestUpload_WaferStack.xlsx');
    //await browser.sleep(5000);
    cp.execSync(exePath + ' ' + filePath1);
    await browser.sleep(5000);
    expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
    expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Wafer Stack")).toContain("Pass");
    expect(await objNewDemoRequest.verifyChkboxStatusAgainstField("Wafer Stack", "Upload", "true")).toContain("Pass");
    expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
    expect(await objCommonPage.clickOnOkBtnOnPopUp()).toContain('Pass');


    //Go to All View Page and Approve the demo by assigninng demo owner as account super user. 
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"New Request")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
    expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objLoginData.userNameAccountSuperUser)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully";
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    done();
});
it('TC-45_Verify that writing access will be provided to Account Super User for the related demo requests',async(done)=>{
    
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_45");
    console.log(objData);
    //Login My Demo application as Account Super User
    expect(await objLoginPage.setUserName(objLoginData.userNameAccountSuperUser)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordAccountSuperUser)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

    //Go to All View Page page search for the apporved demo and try to make changes to it
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    
    // Edit the Demo Details from the All view page like wafer location, Substrate Typ
    expect(await objCommonPage.goToColumn("Wafer Location")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Wafer Location",sDemoName)).toContain('Pass');
    expect(await objCommonPage.selectOptionFromDDInTableColumn("Wafer Location",objData.waferLocation)).toContain('Pass');

    expect(await objCommonPage.goToColumn("Substrate Typ")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCellUsingJavaScript("Substrate Type",sDemoName)).toContain('Pass');
    
    expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');

    //Edit the details on the demo details page.
    expect(await objAllViewPage.clickOnHyperLinkInDemoNumber(sDemoName)).toContain('Pass');
    expect(await objHomePage.getCurrentUrl("request_demo")).toContain("Pass");

    expect(await objDemoDetailsPage.clickFieldOnDemoDetailsWithoutScroll("Substrate Type")).toContain("Pass");
    expect(await objDemoDetailsPage.selectOptionFromFieldOnDemoDetails("Substrate Type",objData.substrateTypeDemo)).toContain("Pass");

    expect(await objDemoDetailsPage.clickFieldOnDemoDetails("Execution Risk")).toContain("Pass");
    expect(await objDemoDetailsPage.selectOptionFromFieldOnDemoDetails("Execution Risk",objData.exeRisk)).toContain("Pass");
    expect(await objDemoDetailsPage.clickOnSubmitDemoDetails()).toContain("Pass");
    let sAlert="Demo Details Submitted Successfully."
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    
    done();
});
it('TC-47_Verify that customer wafer Destination &  wafer available in lab field is present in the view screen and User should be able to update values.',async(done)=>{
    
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_47");
    console.log(objData);

    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

    //Go to All view page 
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    
    // Verify Customer Wafer Destination col
    expect(await objCommonPage.goToColumn("Customer Wafer Destination")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Customer Wafer Destination",sDemoName)).toContain('Pass');
    expect(await objCommonPage.selectOptionFromDDInTableColumn("Customer Wafer Destination",objData.custWaferDest)).toContain('Pass');
    expect(await objCommonPage.verifyTextValueInTableCell("Customer Wafer Destination",sDemoName, objData.custWaferDest)).toContain('Pass');
   
     // Verify wafer available in lab col
    expect(await objCommonPage.goToColumn("Wafer Available in Lab")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Wafer Available in Lab",sDemoName)).toContain('Pass');
   
    expect(await objAllViewPage.selectDateInTableCell("1", "Mar", "2021")).toContain("Pass");
    // await objWrapper.sendKeysInActiveElmnt("Enter");
    // expect(await objCommonPage.verifyTextValueInTableCell("Wafer Available in Lab",sDemoName, "03/01/2021")).toContain('Pass');
       
   
    
    done();
})
it('TC-48_Verify that whenever user export data of all view in excel then he or she should be able to see customer wafer Destination column with values in it.'+
   'TC_26-"Verify that user shall be able to add or update values in customer wafer Destination column via all view screen only when it is empty',async(done)=>{
    
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_48");
    console.log(objData);
    const os = require('os'); 
    const sDownloadPath = os.homedir()+"/Downloads/";
    await objCommonPage.deleteFileFromDownloadsDir(sDownloadPath + objData.excelFileName +".xlsx"); 
    
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

    //Go to All View Page and click on the eye icon of newly created demo
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    
    expect(await objCommonPage.goToColumn("Customer Wafer Destination")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Customer Wafer Destination",sDemoName)).toContain('Pass');
    expect(await objCommonPage.selectOptionFromDDInTableColumn("Customer Wafer Destination",objData.custWaferDest)).toContain('Pass');
    // await objWrapper.sendKeysInActiveElmnt("Enter");
    expect(await objCommonPage.clickExportButton('All View')).toContain('Pass');
    // Verify Downloaded Excel is having col customer wafer Destination along with it's value 
    await browser.sleep(5000);     
    expect(await objExcelWrapper.verifyExcelCellValuesofSingleRowForSpecifiedColumn(sDownloadPath + objData.excelFileName+".xlsx",objData.excelFileName,objData.excelCoumnName,objData.custWaferDest)).toBe(true);
    
    done();
});
it('TC_49-"Verify that whenever demo owner is changed for any demo request then new demo owner shall get an email notification', async (done)=>
{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_49");
    console.log(objData);

    // Login as Global Admin User
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

    //Go to All View Page and change the demo owner 
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');

    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});

    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"ACL-Approved")).toContain('Pass');
    expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",sLoggedInUser)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully";
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

    let sDemoNumber = await objCommonPage.getTableCellValue("Demo Number",sDemoName);
    console.log(sDemoNumber);

    

    // Checking Email Notification for status change which new demo owner shouls get recevie
    let sMailHeader = "Status change for Demo Request "+sDemoNumber+"";
    await browser.waitForAngularEnabled(false);
    await browser.sleep(5000);
    await objHomePage.openWebmail(objLoginData.outlookUrl);
    expect(await objOutlookPage.verifyOutllookEmailExistsSecondTime(sMailHeader)).toContain("Pass");
    await browser.sleep(5000);
    expect(await objOutlookPage.verifyMailBodyWithDemoNumNmInBold(sDemoName, sDemoNumber)).toContain("Pass");
    done();
   
});
it('TC-50_Verify that customer spec table get displayed on view details page for user in mydemo application.',async(done)=>{
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

    //Go to All View Page and click on the eye icon of newly created demo
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllRequestPage.clickOnTheEyeIcon()).toContain('Pass');
    let sAlert="Demo Detail"
    expect(await objCommonPage.verifyAlertHeader(sAlert)).toContain('Pass');
    expect(await objAllRequestPage.verifySectionDisplayedOnPopUp("Customer Spec information")).toContain('Pass');
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass'); 
    done();
});
it('TC_51-"Verify that when a user reach demo details from any of the view screen then when he reach back to the same view screen the changes or settings made by user should remain same', async (done)=>
{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_51");
    console.log(objData);
   //Login My Demo application as global admin user
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")
    //User is on All view Page
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    //Searched for the demo Name
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    //performed sorting
    let firstDemoNameInGrid = await objCommonPage.verifySorting("Demo Name");
    //clicked on the hyperlink
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.verifyVisibleHyperLinkForACLStatus("Demo Number","Demo Approval",sDemoName)).toContain("Pass");
    expect(await objCommonPage.clickInTheTableCell("Demo Number",sDemoName)).toContain('Pass');
    //User is on the DEmo details page
    expect(await objHomePage.getCurrentUrl("request_demo")).toContain("Pass");
    //perfomed browser back
    await browser.driver.navigate().back();
    //User is on the all view page
    expect(await objHomePage.getCurrentUrl("all-view")).toContain("Pass");
    expect(await objCommonPage.getTheLatestDemoNm()).toContain(firstDemoNameInGrid);
    done();
});
it('TC_52-"Verify that Special Groups Involved field is added on All the view screens in MyDemo Application', async (done)=>
{
   //Login My Demo application as global admin user
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    //User is on All view Page
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    //go to col Special Group involved
    expect(await objCommonPage.goToColumn("Special Group involved")).toContain('Pass');
    //check col is acutlly present in headers or not.
    expect(await objCommonPage.getTableHeaders()).toContain("Special Group involved");
    done();
});
it('TC_54-"Verify that Other User Groups field has been added in grid of Grant Demo Access page', async (done)=>
{
    let objData = dataProvider.getJsonData("./data/allView.json", "TC_54");
    console.log(objData);
   //Login My Demo application as global admin user
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    //User is on Grant demo access Page
    expect(await objHomePage.selectMenuOption("All Demo's", "Grant Demo Access")).toContain('Pass');
    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    //Searched for other group name
    expect(await objCommonPage.searchRequest(objData.otherGroupName)).toContain('Pass');
    let sDemoNameList = await objCommonPage.geColDataList("Demo Name");
    let demoName = sDemoNameList.split("~");
    console.log(demoName[0]);
    //User is on All View Page
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    //Searched for Demo Name having other group name
    expect(await objCommonPage.searchRequest(demoName[0])).toContain('Pass');
    //go to col other group
    expect(await objCommonPage.goToColumn("Other Groups")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Other Groups",demoName[0])).toContain('Pass');
    // //check col is acutlly present in headers or not.
    expect(await objAllViewPage.setInputOnPopUp("Other Group",objData.otherGroupNmPopUp)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    done();
});
});
