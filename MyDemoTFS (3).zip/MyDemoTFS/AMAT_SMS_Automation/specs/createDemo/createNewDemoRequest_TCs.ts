import {browser, element, ExpectedConditions, by} from 'protractor';
import {homePage} from '../../pages/homePage.po';
import { loginPage } from '../../pages/loginPage.po';
import { newDemoRequest } from '../../pages/newDemoRequest.po';
import { dataProvider} from "../../data/dataProvider";
import { commonPage } from '../../pages/commonPage.po';
import { myDemoRequestPage } from '../../pages/myDemoRequestPage.po';
import * as cp from 'child_process';
import { win32 } from 'path';
import { approvalsPage } from '../../pages/approvalsPage.po';
import { myDraftRequestPage } from '../../pages/myDraftRequestPage.po';
import { demoDetailsPage } from '../../pages/demoDetailsPage.po';
import { allViewPage } from '../../pages/allViewPage.po';				 
import { outlookPage } from '../../pages/outlookPage.po';
import { allRequestPage } from '../../pages/allRequestPage.po';
												 

describe('Create new demo request module test cases', () => {
    const path = win32;
    let objHomePage:homePage;
    let objNewDemoRequest:newDemoRequest;
    let objLoginPage:loginPage;
    let objCommonPage:commonPage;
    let objMyDemoRequestPage:myDemoRequestPage;
    let objApprovalsPage: approvalsPage;
	let objMyDraftRequestPage:myDraftRequestPage;										 
    let objDemoDetailsPage: demoDetailsPage;
    let objAllViewPage: allViewPage;
    let objOutlookPage:outlookPage;
    let objAllRequestPage: allRequestPage;						   
    let sDemoName = "", sAlertMessage = "", sLoggedInUser;
    let objLoginData = dataProvider.getJsonData("./data/login.json", "login");

    beforeEach(async () => {
        objHomePage = new homePage();
        objNewDemoRequest = new newDemoRequest();
        objCommonPage = new commonPage();
        objMyDemoRequestPage = new myDemoRequestPage();
        objMyDraftRequestPage = new myDraftRequestPage();								   
        objLoginPage = new loginPage();
        objApprovalsPage = new approvalsPage();
		objDemoDetailsPage = new demoDetailsPage();
        objAllViewPage = new allViewPage();
		objOutlookPage = new outlookPage();	
        objAllRequestPage = new allRequestPage();								   
        await browser.waitForAngularEnabled(false);
        //Open application Url
        await objHomePage.openApplication('/');        
    });

    afterEach(() => {

    });

    it('TC_01 - Verify that user shall be able to create a new demo request successfully with TAMBA YES using MyDemo Application, '+
    'TC_63 - Verify that whenever user creates or update status of demo request then there will be a change in mail description', async(done)=>{										
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_01");
        console.info(objData);

        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        await browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");

        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_CreateDemo" + iRandomNum;

        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");;
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).not.toContain("Pass");
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).not.toContain("Pass");

        expect(await objNewDemoRequest.verifyToggleForFieldIsPresent('TAMBA')).toContain("Pass");

        expect(await objNewDemoRequest.verifyToggleForFieldIsPresent('Internal Demo')).toContain("Pass");
        expect(await objNewDemoRequest.toggleField('TAMBA', false)).toContain("Pass");
        expect(await objNewDemoRequest.toggleField('Internal Demo', true)).toContain("Pass");
        expect(await objNewDemoRequest.verifyPrimaryBUIsMandatoryWhenInternalDemo()).toContain("Pass");
        expect(await objNewDemoRequest.toggleField('Internal Demo', false)).toContain("Pass");

        expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
        
        expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
        expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
        await objNewDemoRequest.verifyTambaDtlsOnNewDemoForm();
        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
        
        //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
        expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
        expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
        expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
        expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");;
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
        sAlertMessage = "Demo Request submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        expect(await objHomePage.selectMenuOption("Requests", "My Demo Request")).toContain("Pass");
        expect(await objMyDemoRequestPage.verifyDemoPresentInTable(sDemoName)).toContain("Pass");
        expect(await objMyDemoRequestPage.verifyDemoApprovalStatus(sDemoName, objData.expDemoStatus)).toContain("Pass");
		let sDemoNumber = await objCommonPage.getTableCellValue("Demo Number", sDemoName).then(function(sText){return sText;});
        // let sDemoNumber = "Etch-051521";
        // sDemoName = "TestInternalDemo_5933";
        let sMailHeader = "Demo Request "+sDemoNumber+" created";
        await browser.waitForAngularEnabled(false);
        await objHomePage.openWebmail(objLoginData.outlookUrl);
        expect(await objOutlookPage.verifyOutllookEmailExists(objLoginData.outlookUserName, "", sMailHeader)).toContain("Pass");
        await browser.sleep(5000);
        expect(await objOutlookPage.verifyMailBodyWithDemoNumNmInBold(sDemoName, sDemoNumber)).toContain("Pass");																					 

        done();
    });
    
    it('TC_18 - Verify that when a demo is created the numerical portion of the number needs to be unique)', async(done)=>{
        //In dev environment demo number format is BU-050000
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_01");
        console.info(objData);
        //Here we are using demo name that is created in previous test TC_01
        //sDemoName = "TestDemo_1678";
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        await browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "My Demo Request")).toContain("Pass");
        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');

        let sDemoNumFormat = objData.primaryBu + "-05"; 
        let sDemoNum = await objCommonPage.getTableCellValue("Demo Number", sDemoName).then(function(sText){return sText;});
        expect(sDemoNum).toContain(sDemoNumFormat);
        sDemoNumFormat = sDemoNumFormat + "0000";
        expect(sDemoNumFormat.length).toEqual(sDemoNum.length);

        done();
    });

    it('TC_02 - Verify that user shall be able to create a new demo request with assigning estimator successfully using MyDemo Application'+ 
        'TC_05 - Verify that the following changes are done in MyDemo Applications.'+
        '1.In the demo request form Estimation shall be renamed to Resource Estimation to Execute Demo (Optional)'+
        '2.A tool tip shall be added on the estimator Name', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_02");
        console.info(objData);

        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        await browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");

        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_CreateDemo" + iRandomNum;

        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");;
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).not.toContain("Pass");
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).not.toContain("Pass");

        expect(await objNewDemoRequest.verifyToggleForFieldIsPresent('TAMBA')).toContain("Pass");

        expect(await objNewDemoRequest.verifyToggleForFieldIsPresent('Internal Demo')).toContain("Pass");
        expect(await objNewDemoRequest.toggleField('TAMBA', false)).toContain("Pass");
        expect(await objNewDemoRequest.toggleField('Internal Demo', true)).toContain("Pass");
        expect(await objNewDemoRequest.verifyPrimaryBUIsMandatoryWhenInternalDemo()).toContain("Pass");
        expect(await objNewDemoRequest.toggleField('Internal Demo', false)).toContain("Pass");

        expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
        
        expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
        expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
        await objNewDemoRequest.verifyTambaDtlsOnNewDemoForm();
        expect(await objNewDemoRequest.toggleField('Internal Demo', true)).toContain("Fail");
        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        expect(await objNewDemoRequest.toggleField("Resource Estimation to Execute Demo (Optional)", true)).toContain("Pass");
        expect(await objNewDemoRequest.verifyEstimatorNameTooltip(objData.sEstimatorNmToolTip)).toContain("Pass");
        expect(await objNewDemoRequest.selectPeoplePickerVal("Estimator Name", objData.estimatorNm)).toContain("Pass");
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
        
        //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
        expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
        expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
        expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
        expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");;
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
        sAlertMessage = "Demo Request submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        expect(await objHomePage.selectMenuOption("Requests", "My Demo Request")).toContain("Pass");
        expect(await objMyDemoRequestPage.verifyDemoPresentInTable(sDemoName)).toContain("Pass");
        expect(await objMyDemoRequestPage.verifyDemoApprovalStatus(sDemoName, objData.expDemoStatus)).toContain("Pass");

        done();
    });

    it('TC_09_1 - Verify that whenver user clicks on step numbers present beside the demo request forms then he/she shall not be able to move to that step.', async(done)=>{
        //Here we are using demo name that is created in previous test TC_02
        //sDemoName = "TestDemo_3322";
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        await browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "My Demo Request")).toContain("Pass");
        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');

        expect(await objCommonPage.clickInTheTableCell("Demo Number", sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        expect(await objCommonPage.clickOnStepSelector("Step2")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).not.toContain("Pass");

        done();
    });

    it('TC_09_2 - Verify that when user is logged in as estimator and  clicks on step numbers present beside the demo request forms then he/she shall not be able to move to that step.', async(done)=>{
        //Here we are using demo name that is created in previous test TC_02
        //sDemoName = "TestDemo_3322";
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameEstimator)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordEstimator)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        await browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        //select menu option
        expect(await objHomePage.selectMenuOption("My Action", "My Demo Tasks")).toContain("Pass");
        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');

        expect(await objCommonPage.clickInTheTableCell("Demo Number", sDemoName)).toContain("Pass");
        //expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        expect(await objCommonPage.clickOnStepSelector("Step2")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).not.toContain("Pass");
        
        done();
    });    

    it('TC_03 - verify that there is a BM Approval toggle button added on opportunity info screen', async(done)=>{

        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        await browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");

        expect(await objNewDemoRequest.toggleField('BM Approved', true)).toContain("Pass");
        expect(await objNewDemoRequest.verifyBMOwnerIsDisplayedAndMandatory()).toContain("Pass");
    
        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        expect(await objNewDemoRequest.selectPeoplePickerVal("BM Owner", sLoggedInUser)).toContain("Pass");

        done();
    });

    it('TC_04 - Verify that user shall provide Other value for the field AMAT Product on opportunity info screen', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_04");
        console.info(objData);

        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        await browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_CreateDemo" + iRandomNum;

        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");;
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnDropDownOption("AMAT Product", objData.amatProd)).toContain("Pass");
        expect(await objNewDemoRequest.setOtherAMATProdVal(objData.otherAmatProd)).toContain("Pass");

        done();
    });

    it('TC_05 - Verify that In the demo request form Customer Wafers/Consumables details section is renamed as Customer Consumables Details', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_05");
        console.info(objData);

        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        await browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_CreateDemo" + iRandomNum;

        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");;
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");

        expect(await objNewDemoRequest.verifyConsumablesDtlSectionPresent()).toContain("Pass");

        done();
    });

    it('TC_07 - Verify that whenever user missed to fill mandatory fields and clicks on submit button he/she shall get a pop up warning to fill mandatory fields', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_07");
        console.info(objData);

        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        await browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_CreateDemo" + iRandomNum;

        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");;
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");

        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");  
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass"); 
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Submit")).toContain("Pass"); 
        expect(await objNewDemoRequest.getSubmitBtnTooltip()).toEqual(objData.submitBtnTooltip);    

        done();
    });

    it('TC_08 - verify that customer spec and Wafer Stack checkbox selection is saved when user clicks on previous/save&submit button.', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_08");
        console.info(objData);

        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        await browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");

        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_CreateDemo" + iRandomNum;

        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");;
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).not.toContain("Pass");
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).not.toContain("Pass");

        expect(await objNewDemoRequest.verifyToggleForFieldIsPresent('TAMBA')).toContain("Pass");

        expect(await objNewDemoRequest.verifyToggleForFieldIsPresent('Internal Demo')).toContain("Pass");
        expect(await objNewDemoRequest.toggleField('TAMBA', false)).toContain("Pass");
        expect(await objNewDemoRequest.toggleField('Internal Demo', true)).toContain("Pass");
        expect(await objNewDemoRequest.verifyPrimaryBUIsMandatoryWhenInternalDemo()).toContain("Pass");
        expect(await objNewDemoRequest.toggleField('Internal Demo', false)).toContain("Pass");

        expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
        
        expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
        expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
        await objNewDemoRequest.verifyTambaDtlsOnNewDemoForm();
        expect(await objNewDemoRequest.toggleField('Internal Demo', true)).toContain("Fail");
        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        expect(await objNewDemoRequest.toggleField("Resource Estimation to Execute Demo (Optional)", true)).toContain("Pass");
        // expect(await objNewDemoRequest.verifyEstimatorNameTooltip(objData.sEstimatorNmToolTip)).toContain("Pass");
        expect(await objNewDemoRequest.selectPeoplePickerVal("Estimator Name", sLoggedInUser)).toContain("Pass");
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        // expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption1)).toContain("Pass");
        
        // //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
        // expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
        // expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
        // expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
        // expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
        // expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");

        expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Customer Spec");
        const filePath = path.resolve('./autoItScripts/TestUpload_CustSpec.xlsx');
        const exePath = path.resolve('./autoItScripts/browseFile.exe')
        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath);
        await browser.sleep(10000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Customer Spec")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");

        expect(await objNewDemoRequest.clickWaferStackOption(objData.waferStackOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Wafer Stack");
        const filePath1 = path.resolve('./autoItScripts/TestUpload_WaferStack.xlsx');

        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath1);
        await browser.sleep(10000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Wafer Stack")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");

        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Previous")).toContain("Pass"); 
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass"); 
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.verifyChkboxStatusAgainstField("Customer Spec", "Upload", "true")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.verifyChkboxStatusAgainstField("Wafer Stack", "Upload", "true")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");

        done();
    });

    it('TC_10, TC_17 - Veirfy that Demo type should be multi select field and DYP, PME, Engineering, Tool Selection, Other demo type DD values are present in Mydemo Application.', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_10");
        console.info(objData);

        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        await browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");

        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_CreateDemo" + iRandomNum;

        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");;
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).not.toContain("Pass");
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).not.toContain("Pass");

        expect(await objNewDemoRequest.verifyToggleForFieldIsPresent('TAMBA')).toContain("Pass");

        expect(await objNewDemoRequest.verifyToggleForFieldIsPresent('Internal Demo')).toContain("Pass");
        expect(await objNewDemoRequest.toggleField('TAMBA', false)).toContain("Pass");
        expect(await objNewDemoRequest.toggleField('Internal Demo', true)).toContain("Pass");
        expect(await objNewDemoRequest.verifyPrimaryBUIsMandatoryWhenInternalDemo()).toContain("Pass");
        expect(await objNewDemoRequest.toggleField('Internal Demo', false)).toContain("Pass");

        expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
        
        expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
        expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
        await objNewDemoRequest.verifyTambaDtlsOnNewDemoForm();
        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnDemoTypeDD()).toContain("Pass");
        let sDemoTp = (objData.demoType).split("~");
        for(var iCount = 0; iCount < sDemoTp.length; iCount++)
        {
            expect(await objNewDemoRequest.selectDemoTypeFromList(sDemoTp[iCount])).toContain("Pass");
        }
        // expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
        
        //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
        expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
        expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
        expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
        expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");;
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
        sAlertMessage = "Demo Request submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        expect(await objHomePage.selectMenuOption("Requests", "My Demo Request")).toContain("Pass");
        expect(await objMyDemoRequestPage.verifyDemoPresentInTable(sDemoName)).toContain("Pass");
        expect(await objMyDemoRequestPage.verifyDemoApprovalStatus(sDemoName, objData.expDemoStatus)).toContain("Pass");

        done();
    }); 

    it('TC_11 - Verify that there will be field added in New Request form named Tamba Status for which user shall be to select any one of the following values from the dropdown.'+
        '1.PTOR 2.DTOR 3.Lost 4.Forfeit 5.Open', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_11");
        console.info(objData);

        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        await browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        expect(await objNewDemoRequest.getDDValues("TAMBA Status")).toEqual(objData.expTAMBAStatusDDVal);  

        done();
    });

    it('TC_12 - Verify that in MyDemo Application,All the areas where there are list of values that is greated than 10 items need to be a look ahead on create demo request screen' +
        'Verified for Account, Managed Account, Primary BU, Application Segment, Application, Device Type, AMAT Product, Application Name (Customer), AMAT Node, Customer Node, Competitor Company, Competitor Tool ', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_12");
        console.info(objData);

        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        await browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        
        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_CreateDemo" + iRandomNum;

        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnDropDownOption("Account", objData.account)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnDropDownOption("Managed Account", objData.mngdAccount)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnDropDownOption("Primary BU", objData.primaryBu)).toContain("Pass");

        expect(await objNewDemoRequest.clickOnDropDownOption("Application Segment", objData.appSeg)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnDropDownOption("Application", objData.application)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnDropDownOption("Device Type", objData.deviceType)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnDropDownOption("AMAT Product", objData.amatProd)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnDropDownOption("Application Name (Customer)", objData.appNameCust)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnDropDownOption("AMAT Node", objData.amatNode)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnDropDownOption("Customer Node", objData.custNode)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnDropDownOption("Competitor Company", objData.comptComp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnDropDownOption("Competitor Tool", objData.comptTool)).toContain("Pass");

        done();
    });

    it('TC_13 - Verify that when Internal Demo toggle button is made as Yes then required changes appear on Opportunity Information section '+
    'of opportunity Info page while creating New Demo Request.', async(done)=>{

        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        await browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        expect(await objNewDemoRequest.toggleField('Internal Demo', true)).toContain("Pass");
        expect(await objNewDemoRequest.verifyPrimaryBUIsMandatoryWhenInternalDemo()).toContain("Pass"); 

        done();
    });

    it('TC_14 - Verify that when Internal Demo toggle button is made as Yes then required changes are appear on Customer section of opportunity Info page '+
        'while creating New Demo Request', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_14");
        console.info(objData);

        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        await browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        expect(await objNewDemoRequest.toggleField("Internal Demo", true)).toContain("Pass");
        expect(await objNewDemoRequest.setInternalAccount(objData.internalAccount)).toContain("Pass");
        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        expect(await objNewDemoRequest.setInternalAccountOwner(sLoggedInUser)).toContain("Pass");

        done();
    });   

    it('TC_15_1 - Verify that when Demo is made as internal then the customer spec section of that demo is not made as mandatory', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_15_1");
        console.info(objData);

        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        await browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        
        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestInternalDemo_" + iRandomNum;

        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        
        

        expect(await objNewDemoRequest.toggleField('Internal Demo', true)).toContain("Pass");
        expect(await objNewDemoRequest.setInternalAccount(objData.internalAccount)).toContain("Pass");
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.setInternalAccountOwner(sLoggedInUser)).toContain("Pass");

        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustSpecFieldIsMandatory()).not.toContain("Pass");

        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
        sAlertMessage = "Demo Request submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        expect(await objHomePage.selectMenuOption("Requests", "My Demo Request")).toContain("Pass");
        expect(await objMyDemoRequestPage.verifyDemoPresentInTable(sDemoName)).toContain("Pass");
        expect(await objMyDemoRequestPage.verifyDemoApprovalStatus(sDemoName, objData.expDemoStatus)).toContain("Pass");

        done();
    });

    it('TC_15_2 - Verify that when Demo is having primary BU as VSE then the customer spec section of that demo is not made as mandatory'+
       'TC_36 - Verify that there is a separate document upload section other than customer spec and wafer stack upload sections shall be displayed  in customer spec page when the primary BU values is VSE while creating demo request', async(done)=>{
       																																																														  
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_15_2");
        console.info(objData);

        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        await browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        
        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_CreateDemo" + iRandomNum;

        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");;
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");

        expect(await objNewDemoRequest.clickOnDropDownOption("Application Segment", objData.appSeg)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnDropDownOption("Device Type", objData.deviceType)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnDropDownOption("AMAT Node", objData.amatNode)).toContain("Pass");

        expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustSpecFieldIsMandatory()).not.toContain("Pass");

        await objNewDemoRequest.clickOnAdditionalDocumentBrowseButton();
        const filePath = path.resolve('./autoItScripts/TestUpload.xlsx');
        const exePath = path.resolve('./autoItScripts/browseFile.exe')
        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath);
        await browser.sleep(7000);
        expect(await objNewDemoRequest.verifyAdditionalDocumentBrowsed("TestUpload.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnAdditionalDocumentUploadButton()).toContain("Pass");
        expect(await objNewDemoRequest.verifyAdditionalDocumentUploaded("TestUpload.xlsx")).toContain("Pass");
        
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
        sAlertMessage = "Demo Request submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        expect(await objHomePage.selectMenuOption("Requests", "My Demo Request")).toContain("Pass");
        expect(await objMyDemoRequestPage.verifyDemoPresentInTable(sDemoName)).toContain("Pass");
        expect(await objMyDemoRequestPage.verifyDemoApprovalStatus(sDemoName, objData.expDemoStatus)).toContain("Pass");

        done();
    });

    it('TC_16_1 - Verify that when a request is submitted for approval then before it gets approved the requester of that request should be able to add TAMBA to that particular demo and submit the same request again', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_16_1");
        console.info(objData);
        
        
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_CreateDemo" + iRandomNum;

        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");;
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");

        expect(await objNewDemoRequest.clickOnDropDownOption("Application Segment", objData.appSegment)).toContain("Pass");//DRAM: EUV
        expect(await objNewDemoRequest.clickOnDropDownOption("Device Type", objData.deviceType)).toContain("Pass");//FDSOI
        expect(await objNewDemoRequest.clickOnDropDownOption("AMAT Node", objData.amatNode)).toContain("Pass");//10nm
        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");
        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Customer Spec");
        const filePath = path.resolve('./autoItScripts/TestUpload_CustSpec.xlsx');
        const exePath = path.resolve('./autoItScripts/browseFile.exe')
        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath);
        await browser.sleep(7000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Customer Spec")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");

        expect(await objNewDemoRequest.clickWaferStackOption(objData.waferStackOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Wafer Stack");
        const filePath1 = path.resolve('./autoItScripts/TestUpload_WaferStack.xlsx');

        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath1);
        await browser.sleep(7000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Wafer Stack")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
        sAlertMessage = "Demo Request submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        expect(await objHomePage.selectMenuOption("Requests", "My Demo Request")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');

        expect(await objCommonPage.clickInTheTableCell("Demo Number", sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
        // expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
        await objNewDemoRequest.verifyTambaDtlsOnNewDemoForm();
        
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");

        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");

        sAlertMessage = "Demo Request updated Successfully";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        expect(await objHomePage.selectMenuOption("Requests", "My Demo Request")).toContain("Pass");
        expect(await objMyDemoRequestPage.verifyDemoPresentInTable(sDemoName)).toContain("Pass");
        expect(await objMyDemoRequestPage.verifyDemoApprovalStatus(sDemoName, objData.expDemoStatus)).toContain("Pass");

        done();
    });

    it('TC_16_2 - Verify that when a request is submitted for approval then before it gets approved the requester of that request should be able to update the TAMBA linked to that particular demo and submit the same request again', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_16_1");
        console.info(objData);
        // sDemoName = "TestDemo_8787";
        
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        expect(await objHomePage.selectMenuOption("Requests", "My Demo Request")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');

        expect(await objCommonPage.clickInTheTableCell("Demo Number", sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
        // expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
        await objNewDemoRequest.verifyTambaDtlsOnNewDemoForm();
        
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");

        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");

        sAlertMessage = "Demo Request updated Successfully";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        expect(await objHomePage.selectMenuOption("Requests", "My Demo Request")).toContain("Pass");
        expect(await objMyDemoRequestPage.verifyDemoPresentInTable(sDemoName)).toContain("Pass");
        expect(await objMyDemoRequestPage.verifyDemoApprovalStatus(sDemoName, objData.expDemoStatus)).toContain("Pass");

        done();
    });

    it('TC_16_3 - Verify that when a request is submitted for approval then before it gets approved the requester of that request should be able to remove the TAMBA linked to that particular demo and submit the same request again', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_16_1");
        console.info(objData);
        // sDemoName = "TestDemo_8787";
        
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        expect(await objHomePage.selectMenuOption("Requests", "My Demo Request")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');

        expect(await objCommonPage.clickInTheTableCell("Demo Number", sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        expect(await objNewDemoRequest.toggleField('TAMBA', false)).toContain("Pass");
        expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");;

        expect(await objNewDemoRequest.clickOnDropDownOption("Application Segment", objData.appSegment)).toContain("Pass");//DRAM: EUV
        expect(await objNewDemoRequest.clickOnDropDownOption("Device Type", objData.deviceType)).toContain("Pass");//FDSOI
        expect(await objNewDemoRequest.clickOnDropDownOption("AMAT Node", objData.amatNode)).toContain("Pass");//10nm
        
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");

        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");

        sAlertMessage = "Demo Request updated Successfully";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        expect(await objHomePage.selectMenuOption("Requests", "My Demo Request")).toContain("Pass");
        expect(await objMyDemoRequestPage.verifyDemoPresentInTable(sDemoName)).toContain("Pass");
        expect(await objMyDemoRequestPage.verifyDemoApprovalStatus(sDemoName, objData.expDemoStatus)).toContain("Pass");

        done();
    });

    it('TC_16_4 - Verify that when a request is submitted for approval then before it gets approved the requester of that request should be able to edit customer spec of that particular demo and submit the same request again', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_16_4");
        console.info(objData);
        // sDemoName = "TestDemo_1996";
        
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        expect(await objHomePage.selectMenuOption("Requests", "My Demo Request")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');

        expect(await objCommonPage.clickInTheTableCell("Demo Number", sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
        
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");

        expect(await objNewDemoRequest.clickOnBrowseButtonAgainstField("Customer Spec")).toContain("Pass");
        const filePath = path.resolve('./autoItScripts/TestUpload_CustSpec2.xlsx');
        const exePath = path.resolve('./autoItScripts/browseFile.exe')
        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath);
        await browser.sleep(7000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Customer Spec", "TestUpload_CustSpec2.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Customer Spec")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Customer Spec", "TestUpload_CustSpec2.xlsx")).toContain("Pass");

        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Previous")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.clickOnBrowseButtonAgainstField("Customer Spec")).toContain("Pass");

        const filePath1 = path.resolve('./autoItScripts/TestUpload_CustSpec1.xlsx');
        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath1);
        await browser.sleep(10000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Customer Spec", "TestUpload_CustSpec1.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Customer Spec")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Customer Spec", "TestUpload_CustSpec1.xlsx")).toContain("Pass");

        expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
        
        //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
        expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
        expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
        expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
        expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");

        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");

        sAlertMessage = "Demo Request updated Successfully";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        expect(await objHomePage.selectMenuOption("Requests", "My Demo Request")).toContain("Pass");
        expect(await objMyDemoRequestPage.verifyDemoPresentInTable(sDemoName)).toContain("Pass");
        expect(await objMyDemoRequestPage.verifyDemoApprovalStatus(sDemoName, objData.expDemoStatus)).toContain("Pass");

        done();
    });

    it('TC_16_5 - Verify that when a request is submitted for approval then before it gets approved the requester of that request should be able to edit customer spec of that particular demo and submit the same request again', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_16_5");
        console.info(objData);
        // sDemoName = "TestDemo_1992";
        
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        expect(await objHomePage.selectMenuOption("Requests", "My Demo Request")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');

        expect(await objCommonPage.clickInTheTableCell("Demo Number", sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
        
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");

        expect(await objNewDemoRequest.clickDeleteAgainstUploadedDoc("Customer Spec", "TestUpload_CustSpec2.xlsx")).toContain("Pass");
        expect(await objCommonPage.verifyAlertAndTakeAction("", "Do you really want to delete the file?", "OK"));
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Customer Spec", "TestUpload_CustSpec2.xlsx")).not.toContain("Pass");

        expect(await objNewDemoRequest.clickAddManualCustSpecDtls()).toContain("Pass");
        
        //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
        expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
        expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
        expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
        expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");

        expect(await objNewDemoRequest.selectCustSpecAttrbForEdit(objData.attributeCategory)).toContain("Pass");
        expect(await objNewDemoRequest.clickEditManualCustSpecDtls()).toContain("Pass");
        expect(await objNewDemoRequest.selectWeighPriority(objData.newWeightProperty)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");

        expect(await objNewDemoRequest.selectCustSpecAttrbForEdit(objData.attributeCategory)).toContain("Pass");
        expect(await objNewDemoRequest.clickDeleteManualCustSpecDtls()).toContain("Pass");        
        expect(await objCommonPage.verifyAlertAndTakeAction("", "Do you really want to delete ?", "OK"));

        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");

        sAlertMessage = "Demo Request updated Successfully";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        expect(await objHomePage.selectMenuOption("Requests", "My Demo Request")).toContain("Pass");
        expect(await objMyDemoRequestPage.verifyDemoPresentInTable(sDemoName)).toContain("Pass");
        expect(await objMyDemoRequestPage.verifyDemoApprovalStatus(sDemoName, objData.expDemoStatus)).toContain("Pass");

        done();
    });

    it('TC_16_6 - Verify that when a request is submitted for approval then before it gets approved the requester of that request should be able to edit customer spec of that particular demo and submit the same request again', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_16_6");
        console.info(objData);
        // sDemoName = "TestDemo_1996";
        
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        expect(await objHomePage.selectMenuOption("Requests", "My Demo Request")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');

        expect(await objCommonPage.clickInTheTableCell("Demo Number", sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
        
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");

        expect(await objNewDemoRequest.clickOnBrowseButtonAgainstField("Wafer Stack")).toContain("Pass");

        const filePath1 = path.resolve('./autoItScripts/TestUpload_WaferStack1.xlsx');
        const exePath = path.resolve('./autoItScripts/browseFile.exe')
        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath1);
        await browser.sleep(10000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Wafer Stack", "TestUpload_WaferStack1.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Wafer Stack")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Wafer Stack", "TestUpload_WaferStack1.xlsx")).toContain("Pass");

        expect(await objNewDemoRequest.clickWaferStackOption(objData.waferStackOption)).toContain("Pass");
        expect(await objNewDemoRequest.setManualWaferStackComment(objData.waferStackComment)).toContain("Pass");
        expect(await objNewDemoRequest.setManualWaferStackComment(objData.waferStackComment1)).toContain("Pass");

        expect(await objNewDemoRequest.clickDeleteAgainstUploadedDoc("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
        expect(await objCommonPage.verifyAlertAndTakeAction("", "Do you really want to delete the file?", "OK"));
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).not.toContain("Pass");

        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");

        sAlertMessage = "Demo Request updated Successfully";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        expect(await objHomePage.selectMenuOption("Requests", "My Demo Request")).toContain("Pass");
        expect(await objMyDemoRequestPage.verifyDemoPresentInTable(sDemoName)).toContain("Pass");
        expect(await objMyDemoRequestPage.verifyDemoApprovalStatus(sDemoName, objData.expDemoStatus)).toContain("Pass");

        done();
    });
	it('TC_19 - Verify that substrate material have feautures which are applied in MyDemo', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_19");
        console.info(objData);
        
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        await browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        
        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_CreateDemo" + iRandomNum;

        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");;
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).not.toContain("Pass");
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).not.toContain("Pass");

        expect(await objNewDemoRequest.verifyToggleForFieldIsPresent('TAMBA')).toContain("Pass");

        expect(await objNewDemoRequest.verifyToggleForFieldIsPresent('Internal Demo')).toContain("Pass");
        expect(await objNewDemoRequest.toggleField('TAMBA', false)).toContain("Pass");
        expect(await objNewDemoRequest.toggleField('Internal Demo', true)).toContain("Pass");
        expect(await objNewDemoRequest.verifyPrimaryBUIsMandatoryWhenInternalDemo()).toContain("Pass");
        expect(await objNewDemoRequest.toggleField('Internal Demo', false)).toContain("Pass");

        expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
        
        expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
        expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
        await objNewDemoRequest.verifyTambaDtlsOnNewDemoForm();
        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        expect(await objNewDemoRequest.verifySubstrateMaterialDDExists()).toContain("Pass");
        expect(await objNewDemoRequest.verifySubstrateMaterialDDIsNotMandatory()).toContain("Pass");
        expect(await objNewDemoRequest.verifyDefValInSubstrateMaterialDD(objData.defSubstrateMaterialVal)).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateMaterial(objData.substrateMaterial)).toContain("Pass");
        expect(await objNewDemoRequest.verifyTextFieldDisplayedForOtherSubstrateMaterial()).toContain("Pass");

        done();
    });

    it('TC_20 - Verify that when user selects Thin Flat as substrate material value then mandatory conditions will be applied on the particular fields', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_20");
        console.info(objData);
        
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        await browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        
        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_CreateDemo" + iRandomNum;

        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");;
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).not.toContain("Pass");
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).not.toContain("Pass");

        expect(await objNewDemoRequest.verifyToggleForFieldIsPresent('TAMBA')).toContain("Pass");

        expect(await objNewDemoRequest.verifyToggleForFieldIsPresent('Internal Demo')).toContain("Pass");
        expect(await objNewDemoRequest.toggleField('TAMBA', false)).toContain("Pass");
        expect(await objNewDemoRequest.toggleField('Internal Demo', true)).toContain("Pass");
        expect(await objNewDemoRequest.verifyPrimaryBUIsMandatoryWhenInternalDemo()).toContain("Pass");
        expect(await objNewDemoRequest.toggleField('Internal Demo', false)).toContain("Pass");

        expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
        
        expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
        expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
        await objNewDemoRequest.verifyTambaDtlsOnNewDemoForm();
        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        
        expect(await objNewDemoRequest.selectSubstrateMaterial(objData.substrateMaterial)).toContain("Pass");
        expect(await objNewDemoRequest.verifyWaferThicknessIsMandatory()).toContain("Pass");
        expect(await objNewDemoRequest.setWaferThickness(objData.waferThickness)).toContain("Pass");
        expect(await objNewDemoRequest.verifyFrontsideProtectionOrCarrierTypeDDIsMandatory()).toContain("Pass");

        done();
    });

    it('TC_21 - Verify that when user selects Thin Taiko as substrate material value then mandatory conditions will be applied on the particular fields', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_21");
        console.info(objData);
        
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        await browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        
        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_CreateDemo" + iRandomNum;

        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");;
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).not.toContain("Pass");
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).not.toContain("Pass");

        expect(await objNewDemoRequest.verifyToggleForFieldIsPresent('TAMBA')).toContain("Pass");

        expect(await objNewDemoRequest.verifyToggleForFieldIsPresent('Internal Demo')).toContain("Pass");
        expect(await objNewDemoRequest.toggleField('TAMBA', false)).toContain("Pass");
        expect(await objNewDemoRequest.toggleField('Internal Demo', true)).toContain("Pass");
        expect(await objNewDemoRequest.verifyPrimaryBUIsMandatoryWhenInternalDemo()).toContain("Pass");
        expect(await objNewDemoRequest.toggleField('Internal Demo', false)).toContain("Pass");

        expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
        
        expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
        expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
        await objNewDemoRequest.verifyTambaDtlsOnNewDemoForm();
        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        
        expect(await objNewDemoRequest.selectSubstrateMaterial(objData.substrateMaterial)).toContain("Pass");
        expect(await objNewDemoRequest.verifyWaferThicknessIsMandatory()).toContain("Pass");
        expect(await objNewDemoRequest.setWaferThickness(objData.waferThickness)).toContain("Pass");
        expect(await objNewDemoRequest.verifyFrontsideProtectionOrCarrierTypeDDIsMandatory()).toContain("Pass");

        done();
    });

    it('TC_22 - Verify that when user selects Coupon as substrate type value then dimensions field should be displayed', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_22");
        console.info(objData);
        
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        await browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        
        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_CreateDemo" + iRandomNum;

        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");;
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).not.toContain("Pass");
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).not.toContain("Pass");

        expect(await objNewDemoRequest.verifyToggleForFieldIsPresent('TAMBA')).toContain("Pass");

        expect(await objNewDemoRequest.verifyToggleForFieldIsPresent('Internal Demo')).toContain("Pass");
        expect(await objNewDemoRequest.toggleField('TAMBA', false)).toContain("Pass");
        expect(await objNewDemoRequest.toggleField('Internal Demo', true)).toContain("Pass");
        expect(await objNewDemoRequest.verifyPrimaryBUIsMandatoryWhenInternalDemo()).toContain("Pass");
        expect(await objNewDemoRequest.toggleField('Internal Demo', false)).toContain("Pass");

        expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
        
        expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
        expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
        await objNewDemoRequest.verifyTambaDtlsOnNewDemoForm();
        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        
        expect(await objNewDemoRequest.verifyFieldIsMandatory("Dimensions")).not.toContain("Pass");
        expect(await objNewDemoRequest.setDimensions(objData.dimensions)).toContain("Pass");

        done();
    });

    it('TC_23 - Verify that Primary BU and Secondary BU dropdowns include only required BUs in MyDemo Application', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_23");
        console.info(objData);
        
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        await browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.openDDList("Primary BU")).toContain("Pass");

        expect(await objNewDemoRequest.getDDValues("Primary BU")).toEqual(objData.expBUList);

        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnAddSecondaryBU()).toContain("Pass");
        expect(await objNewDemoRequest.openBUDDListInSecondaryBUTable()).toContain("Pass");
        expect(await objNewDemoRequest.getDDValues("Secondary BU")).toEqual(objData.expPrimaryBUs);

        done();
    });

    it('TC_24 - Verify that there is field by name Customer Wafer Destination present in opportunity info screen while creating demo request, '+
        'TC_25 - Verify that customer wafer Destination field is dropdown and have search functionality included', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_24");
        console.info(objData);
        
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        
        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_CreateDemo" + iRandomNum;

        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");;
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");

        expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
        
        expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
        expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
        await objNewDemoRequest.verifyTambaDtlsOnNewDemoForm();

        expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        expect(await objNewDemoRequest.selectCustWaferDestDDVal(objData.custWaferDest)).toContain("Pass");

        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Save As Draft")).toContain("Pass");
        sAlertMessage = "Request is Saved Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        
        expect(await objHomePage.selectMenuOption("Requests", "My Draft Request")).toContain("Pass");
        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');  
        expect(await objCommonPage.clickInTheTableCell('Demo Number',sDemoName)).toContain('Pass');
        expect(await objNewDemoRequest.verifyDemoInfoSectionDisplayed()).toContain('Pass');
        expect(await objNewDemoRequest.verifyValSelectedInCustWaferDestDD(objData.custWaferDest)).toContain("Pass");
        expect(await objNewDemoRequest.selectCustWaferDestDDVal(objData.custWaferDest1)).toContain("Pass");

        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        
        expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Customer Spec");
        const filePath = path.resolve('./autoItScripts/TestUpload_CustSpec.xlsx');
        const exePath = path.resolve('./autoItScripts/browseFile.exe')
        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath);
        await browser.sleep(7000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Customer Spec")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
        
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
        sAlertMessage = "Demo Request submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        expect(await objHomePage.selectMenuOption("Requests", "My Demo Request")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');  
        expect(await objCommonPage.clickInTheTableCell('Demo Number',sDemoName)).toContain('Pass');
        expect(await objNewDemoRequest.verifyDemoInfoSectionDisplayed()).toContain('Pass');
        expect(await objNewDemoRequest.verifyValSelectedInCustWaferDestDD(objData.custWaferDest1)).toContain("Pass");

        done();
    });

    it('TC_26 - Verify that user shall be able to create a demo request with demo type as Multi BU Demo,'+
       'TC_28 - Verify that whenever user selects Multi BU Demo as demo type then there will be two additional fields by name BU and Requester are populated,'+
       'TC_30 - Verify that user shall be able to provide the BU name for which the selected account is not associated in BU field and also primary BU value should not populate in BU field', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_26");
        console.info(objData);
        
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        
        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_CreateDemo" + iRandomNum;

        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");;
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");

        expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
        
        expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
        expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
        await objNewDemoRequest.verifyTambaDtlsOnNewDemoForm();

        expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnAddSecondaryBU()).toContain("Pass");
    
        expect(await objNewDemoRequest.openBUDDListInSecondaryBUTable()).toContain("Pass");
        expect(await objNewDemoRequest.getDDValues("Secondary BU")).toEqual(objData.expSecondaryBUs);
        expect(await objNewDemoRequest.selectSecondaryBUInTable(objData.secBU1)).toContain("Pass");
        expect(await objNewDemoRequest.selectRequestorInSecBUTbl(objData.requestor1)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnAddSecondaryBU()).toContain("Pass");
        expect(await objNewDemoRequest.selectSecondaryBUInTable(objData.secBU1)).toContain("Pass");
        expect(await objNewDemoRequest.selectRequestorInSecBUTbl(objData.requestor1)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSaveSecondaryBU()).toContain("Pass");
        sAlertMessage = "Secondary BU should be unique, please select another BU.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK"));
        expect(await objNewDemoRequest.selectSecondaryBUInTable(objData.secBU2)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSaveSecondaryBU()).toContain("Pass");

        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        
        expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Customer Spec");
        const filePath = path.resolve('./autoItScripts/TestUpload_CustSpec.xlsx');
        const exePath = path.resolve('./autoItScripts/browseFile.exe')
        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath);
        await browser.sleep(7000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Customer Spec")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");

        expect(await objNewDemoRequest.clickWaferStackOption(objData.waferStackOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Wafer Stack");
        const filePath1 = path.resolve('./autoItScripts/TestUpload_WaferStack.xlsx');
        const exePath1 = path.resolve('./autoItScripts/browseFile.exe')
        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath1);
        await browser.sleep(7000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Wafer Stack")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");																												  
        
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
        sAlertMessage = "Demo Request submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        expect(await objHomePage.selectMenuOption("Requests", "My Demo Request")).toContain("Pass");

        expect(await objMyDemoRequestPage.verifyDemoPresentInTable(sDemoName)).toContain("Pass");
		await objMyDemoRequestPage.saveDemoNumber(sDemoName); 													  

        done();
    });

    it('TC_27_1 - Verify that demo draft of each BU will be created once demo request with demo type multi BU is approved - Approve Request with BU Super User account', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_27");
        console.info(objData);
        
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameBUSuperUser)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordBUSuperUser)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
        //await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});

        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

																								  
        expect(await objCommonPage.searchRequest(sDemoName)).toContain("Pass");
        await browser.sleep(5000);
        expect(await objCommonPage.clickInTableButton(sDemoName, "New Request")).toContain("Pass");
        
        expect(await objCommonPage.verifyAlertHeader("Approval View")).toContain("Pass");
        expect(await objApprovalsPage.selectDemoApproval(objData.demoApprovalStatus)).toContain("Pass");
        expect(await objApprovalsPage.selectPriority(objData.priority)).toContain("Pass");
        
        expect(await objApprovalsPage.setDemoOwner(sLoggedInUser)).toContain("Pass");
																									   
        expect(await objApprovalsPage.selectExecutionRisk("Medium")).toContain("Pass"); 
        await objApprovalsPage.clickOnSaveApprovalView();
        sAlertMessage = "Approval Saved Successfully"
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");

																									   
																			   
																				  
																											 

        done();
    });

    it('TC_27_2 - Verify that demo draft of each BU will be created once demo request with demo type multi BU is approved - Login with requestor account and verify draft requests', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_26");
        console.info(objData);
        // sDemoName = "TestDemo_1272"
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameSecondaryBURequestor)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordSecondaryBURequestor)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        expect(await objHomePage.selectMenuOption("Requests", "My Draft Request")).toContain("Pass");
        let sSearchText = objData.secBU1 + " " + sDemoName;
        expect(await objCommonPage.searchRequest(sSearchText)).toContain("Pass");
        expect(await objMyDraftRequestPage.verifyDraftRequestPresentInTable(sDemoName)).toContain("Pass");
        sSearchText = objData.secBU2 + " " + sDemoName;
        
        expect(await objHomePage.clickOnMenuOption("Home")).toContain("Pass");
        expect(await objHomePage.selectMenuOption("Requests", "My Draft Request")).toContain("Pass");
        expect(await objCommonPage.searchRequest(sSearchText)).toContain("Pass");
        expect(await objMyDraftRequestPage.verifyDraftRequestPresentInTable(sDemoName)).toContain("Pass");

        done();
    });

    it('TC_33 - Verify the Document flow from primary Demo and Wafer stack and Customer Spec documentÂ  is as expected - Attach customer spec and wafer stack document and delete previously attached customer spec document after approval', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_33");
        console.info(objData);
        // sDemoName = "TestDemo_3634";
        
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
        await browser.sleep(5000)
        expect(await objCommonPage.clickInTheTableCell("Demo Number", sDemoName)).toContain("Pass");
        expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain("Pass");
        expect(await objDemoDetailsPage.clickOnAttachmentsBtn()).toContain("Pass");
        expect(await objDemoDetailsPage.verifyAttachmentsPopUpDisplayed()).toContain("Pass");

        //Add customer Spec doc
        expect(await objDemoDetailsPage.clickBrowseOnAttachmentsPopUp()).toContain("Pass");
        // await browser.sleep(6000);
        // expect(await objDemoDetailsPage.clickBrowseOnAttachmentsPopUp()).toContain("Pass");
        const filePath = path.resolve('./autoItScripts/TestUpload_CustSpec1.xlsx');
        const exePath = path.resolve('./autoItScripts/browseFile.exe')
        // await browser.sleep(6000);
        cp.execSync(exePath + ' ' + filePath);
        await browser.sleep(7000);
        
        // cp.execSync(exePath + ' ' + filePath);
        // await browser.sleep(10000);

        expect(await objDemoDetailsPage.selectDDValOnAttachmentsPopUp("Security", objData.security)).toContain("Pass");//External - BU And Account
        expect(await objDemoDetailsPage.selectDDValOnAttachmentsPopUp("Category", objData.category)).toContain("Pass");//Customer Spec
        
        expect(await objDemoDetailsPage.verifyFileBrowsedOnAttachmentsPopUp("TestUpload_CustSpec1.xlsx")).toContain("Pass");
        
        expect(await objDemoDetailsPage.clickUploadBtnOnAttachmentsPopUp()).toContain("Pass");
        await browser.sleep(7000);
        expect(await objDemoDetailsPage.verifyDocUploadedOnAttachmentsPopUp("TestUpload_CustSpec1.xlsx")).toContain("Pass");
        
        //Add wafer stack doc
        expect(await objDemoDetailsPage.clickBrowseOnAttachmentsPopUp()).toContain("Pass");

        const filePath1 = path.resolve('./autoItScripts/TestUpload_WaferStack1.xlsx');
        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath1);
        await browser.sleep(10000);
        expect(await objDemoDetailsPage.verifyFileBrowsedOnAttachmentsPopUp("TestUpload_WaferStack1.xlsx")).toContain("Pass");
        expect(await objDemoDetailsPage.selectDDValOnAttachmentsPopUp("Security", objData.security1)).toContain("Pass");//Internal - BU Only
        expect(await objDemoDetailsPage.selectDDValOnAttachmentsPopUp("Category", objData.category1)).toContain("Pass");//Wafer Stack
        expect(await objDemoDetailsPage.clickUploadBtnOnAttachmentsPopUp()).toContain("Pass");
        await browser.sleep(7000);

        //For Internal - BU Only it will not display the uploaded File 
        expect(await objDemoDetailsPage.verifyDocUploadedOnAttachmentsPopUp("TestUpload_WaferStack1.xlsx")).not.toContain("Pass");

        //Delete customer spec
        expect(await objDemoDetailsPage.deleteUploadedDocOnAttachmentsPopUp("TestUpload_CustSpec.xlsx")).toContain("Pass");
        sAlertMessage = "Do you really want to delete the file?"
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        expect(await objDemoDetailsPage.verifyDocUploadedOnAttachmentsPopUp("TestUpload_CustSpec.xlsx")).not.toContain("Pass");
        expect(await objDemoDetailsPage.deleteUploadedDocOnAttachmentsPopUp("TestUpload_WaferStack.xlsx")).toContain("Pass");
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        expect(await objDemoDetailsPage.verifyDocUploadedOnAttachmentsPopUp("TestUpload_WaferStack.xlsx")).not.toContain("Pass");
        expect(await objDemoDetailsPage.clickCancelOnAttachmentPopUp()).toContain("Pass");
        done();
    });

    it('TC_33_1 - Verify the Document flow from primary Demo and Wafer stack and Customer Spec document  is as expected - Verify that secondary demo only contains cust spec and wafer stack documents attached before approval of primary demo. User can attach docs to secondary demo and those can be differenciated', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_33");
        console.info(objData);
        // sDemoName = "TestDemo_1272";
        let sSearchText = objData.bu + " " + sDemoName;
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameSecondaryBURequestor)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordSecondaryBURequestor)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        expect(await objHomePage.selectMenuOption("Requests", "My Draft Request")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sSearchText)).toContain('Pass');

        expect(await objCommonPage.clickInTheTableCell("Demo Number", sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");

        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDeleteBtnPresentAgainstUploadedDoc("Customer Spec", "TestUpload_CustSpec.xlsx")).not.toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Customer Spec", "TestUpload_CustSpec1.xlsx")).not.toContain("Pass");

        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDeleteBtnPresentAgainstUploadedDoc("Wafer Stack", "TestUpload_WaferStack.xlsx")).not.toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Wafer Stack", "TestUpload_WaferStack1.xlsx")).not.toContain("Pass");

        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Customer Spec");
        const filePath = path.resolve('./autoItScripts/TestUpload_CustSpec_Sec.xlsx');
        const exePath = path.resolve('./autoItScripts/browseFile.exe')
        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath);
        // await objNewDemoRequest.clickOnBrowseButtonAgainstField("Customer Spec");
        // cp.execSync(exePath + ' ' + filePath);
        await browser.sleep(7000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Customer Spec", "TestUpload_CustSpec_Sec.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Customer Spec")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Customer Spec", "TestUpload_CustSpec_Sec.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDeleteBtnPresentAgainstUploadedDoc("Customer Spec", "TestUpload_CustSpec_Sec.xlsx")).toContain("Pass");

        expect(await objNewDemoRequest.clickWaferStackOption(objData.waferStackOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Wafer Stack");
        const filePath1 = path.resolve('./autoItScripts/TestUpload_WaferStack_Sec.xlsx');

        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath1);
        await browser.sleep(7000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Wafer Stack", "TestUpload_WaferStack_Sec.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Wafer Stack")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Wafer Stack", "TestUpload_WaferStack_Sec.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDeleteBtnPresentAgainstUploadedDoc("Wafer Stack", "TestUpload_WaferStack_Sec.xlsx")).toContain("Pass");
        
        done();
    });
	
    it('TC_29 - Verify that user shall be able to add upto 10 values in BU Field and Requester name will be people picker along with mandatory field sign iff BU is selected ', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_29");
        console.info(objData);
        
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        
        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_CreateDemo" + iRandomNum;

        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");;
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");

        expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
        
        expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
        expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
        await objNewDemoRequest.verifyTambaDtlsOnNewDemoForm();

        expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        let sBUSelectionList = (objData.buSelectionList).split("~")
        for(let iCount = 0; iCount < sBUSelectionList.length; iCount++)
        {
            expect(await objNewDemoRequest.clickOnAddSecondaryBU()).toContain("Pass");
            if(iCount == 10)
                expect(await objCommonPage.verifyAlertAndTakeAction("", "Maximum 10 BUs can be added as secondary demo", "OK")).toContain("Pass");
            else
                expect(await objNewDemoRequest.selectSecondaryBUInTable(sBUSelectionList[iCount])).toContain("Pass");
        }
       
        expect(await objNewDemoRequest.clickOnSaveSecondaryBU()).toContain("Pass");
        for(let iCount = 1; iCount <= 10; iCount++)
        {
            expect(await objCommonPage.verifyAlertMessage( "Row "+iCount+":Requestor is required")).toContain("Pass");
        }
        expect(await objCommonPage.takeActionOnAlert("OK")).toContain("Pass");

        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        
        sAlertMessage = "Please perform neccessary action on Secondary BU table.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK"));

        done();
    });

    it('TC_34 - Verify that when internal demo toggle button is on then user should not be able to turn on tamba toggle button', async(done)=>{
        // let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_26");
        // console.info(objData);
        // sDemoName = "TestDemo_1272"
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameSecondaryBURequestor)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordSecondaryBURequestor)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.toggleField("Internal Demo", true)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnToggleField("TAMBA")).toContain("Pass");
        expect(await objNewDemoRequest.verifyToggleFieldState("TAMBA", false)).toContain("Pass");

        done();
    });

   it('TC_35 - Verify that time stamp on loaded document is included in following sections of Mydemo application'+
    '1 In attachment section of entire mydemo application'+
    '2 After uploading documents in Customer spec and Wafer Stack', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_35");
        console.info(objData);

        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");

        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_CreateDemo" + iRandomNum;

        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");;
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");

        expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
        
        expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
        expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
        await objNewDemoRequest.verifyTambaDtlsOnNewDemoForm();

        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        // expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption1)).toContain("Pass");
        
        // //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
        // expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
        // expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
        // expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
        // expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
        // expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");

        expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Customer Spec");
        const filePath = path.resolve('./autoItScripts/TestUpload_CustSpec.xlsx');
        const exePath = path.resolve('./autoItScripts/browseFile.exe')
        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath);
        await browser.sleep(10000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Customer Spec")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
        let sTodayDateCust = await objCommonPage.getCurrentDate("mm/dd/yyyy hh:mins");
        console.log(sTodayDateCust);
        expect(await objNewDemoRequest.getDateTimeAgainstDocInField("Customer Spec", "TestUpload_CustSpec.xlsx")).toEqual(sTodayDateCust);

        expect(await objNewDemoRequest.clickWaferStackOption(objData.waferStackOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Wafer Stack");
        const filePath1 = path.resolve('./autoItScripts/TestUpload_WaferStack.xlsx');

        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath1);
        await browser.sleep(10000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Wafer Stack")).toContain("Pass");
        let sTodayDateWaferStack = await objCommonPage.getCurrentDate("mm/dd/yyyy hh:mins");
        console.log(sTodayDateWaferStack);
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.getDateTimeAgainstDocInField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toEqual(sTodayDateWaferStack);

        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
        sAlertMessage = "Demo Request submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        
        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});

        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');

																								  
																			   
								  
        expect(await objCommonPage.clickInTableButton(sDemoName, "Attachment and External Link")).toContain("Pass");
        expect(await objAllViewPage.verifyAttachmentsPopUpDisplayed()).toContain("Pass");
        expect(await objCommonPage.getDateTimeAgainstDocOnAttachmentsPopUp("TestUpload_CustSpec.xlsx")).toEqual(sTodayDateCust);
        expect(await objCommonPage.getDateTimeAgainstDocOnAttachmentsPopUp("TestUpload_WaferStack.xlsx")).toEqual(sTodayDateWaferStack);
        expect(await objAllViewPage.clickCancelOnAttachmentsPopUp()).toContain("Pass");
        await browser.sleep(5000);
        expect(await objCommonPage.clickInTableButton(sDemoName, "New Request")).toContain("Pass");
        
        expect(await objCommonPage.verifyAlertHeader("Approval View")).toContain("Pass");
        expect(await objApprovalsPage.selectDemoApproval(objData.demoApprovalStatus)).toContain("Pass");
        expect(await objApprovalsPage.selectPriority(objData.priority)).toContain("Pass");
        
        expect(await objApprovalsPage.setDemoOwner(sLoggedInUser)).toContain("Pass");
																										 
        expect(await objApprovalsPage.selectExecutionRisk("Medium")).toContain("Pass"); 
        await objApprovalsPage.clickOnSaveApprovalView();
        sAlertMessage = "Approval Saved Successfully"
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");


        expect(await objCommonPage.clickInTheTableCell("Demo Number", sDemoName)).toContain("Pass");
        expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain("Pass");
        expect(await objDemoDetailsPage.clickOnAttachmentsBtn()).toContain("Pass");
        expect(await objDemoDetailsPage.verifyAttachmentsPopUpDisplayed()).toContain("Pass");
        expect(await objCommonPage.getDateTimeAgainstDocOnAttachmentsPopUp("TestUpload_CustSpec.xlsx")).toEqual(sTodayDateCust);
        expect(await objCommonPage.getDateTimeAgainstDocOnAttachmentsPopUp("TestUpload_WaferStack.xlsx")).toEqual(sTodayDateWaferStack);
		expect(await objDemoDetailsPage.clickCancelOnAttachmentPopUp()).toContain("Pass");																				  
        done();
    });
it('TC_15_1 - Verify that when Demo is made as internal then the customer spec section of that demo is not made as mandatory', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_15_1");
        console.info(objData);

        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        await browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        
        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestInternalDemo_" + iRandomNum;

        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        
        

        expect(await objNewDemoRequest.toggleField('Internal Demo', true)).toContain("Pass");
        expect(await objNewDemoRequest.setInternalAccount(objData.internalAccount)).toContain("Pass");
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.setInternalAccountOwner(sLoggedInUser)).toContain("Pass");

        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustSpecFieldIsMandatory()).not.toContain("Pass");

        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
        sAlertMessage = "Demo Request submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        expect(await objHomePage.selectMenuOption("Requests", "My Demo Request")).toContain("Pass");
        expect(await objMyDemoRequestPage.verifyDemoPresentInTable(sDemoName)).toContain("Pass");
        expect(await objMyDemoRequestPage.verifyDemoApprovalStatus(sDemoName, objData.expDemoStatus)).toContain("Pass");

        done();
    });

    it('TC_15_2 - Verify that when Demo is having primary BU as VSE then the customer spec section of that demo is not made as mandatory'+
       'TC_36 - Verify that there is a separate document upload section other than customer spec and wafer stack upload sections shall be displayed  in customer spec page when the primary BU values is VSE while creating demo request', async(done)=>{
       																																																														  
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_15_2");
        console.info(objData);

        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        await browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        
        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_CreateDemo" + iRandomNum;

        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");;
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");

        expect(await objNewDemoRequest.clickOnDropDownOption("Application Segment", objData.appSeg)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnDropDownOption("Device Type", objData.deviceType)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnDropDownOption("AMAT Node", objData.amatNode)).toContain("Pass");

        expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustSpecFieldIsMandatory()).not.toContain("Pass");

        await objNewDemoRequest.clickOnAdditionalDocumentBrowseButton();
        const filePath = path.resolve('./autoItScripts/TestUpload.xlsx');
        const exePath = path.resolve('./autoItScripts/browseFile.exe')
        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath);
        await browser.sleep(7000);
        expect(await objNewDemoRequest.verifyAdditionalDocumentBrowsed("TestUpload.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnAdditionalDocumentUploadButton()).toContain("Pass");
        expect(await objNewDemoRequest.verifyAdditionalDocumentUploaded("TestUpload.xlsx")).toContain("Pass");
        
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
        sAlertMessage = "Demo Request submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        expect(await objHomePage.selectMenuOption("Requests", "My Demo Request")).toContain("Pass");
        expect(await objMyDemoRequestPage.verifyDemoPresentInTable(sDemoName)).toContain("Pass");
        expect(await objMyDemoRequestPage.verifyDemoApprovalStatus(sDemoName, objData.expDemoStatus)).toContain("Pass");

        done();
    }); 
    it('TC_37 - Verify that when user  selects Special group owned radio button then 3 additional fields shall be displayed', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_37");
        console.info(objData);
        // sDemoName = "TestDemo_1272"
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.toggleField("Special Group Demo", true)).toContain("Pass");
        let sSpecialGrpRbtn = (objData.specialGrpRbtns).split("~");
        
        for(let iCount = 0; iCount < sSpecialGrpRbtn.length; iCount++)
        {
            expect(await objNewDemoRequest.verifyRadioBtnPresent(sSpecialGrpRbtn[iCount])).toContain("Pass");
        }
        expect(await objNewDemoRequest.clickOnRadioBtn("Special Group Owned")).toContain("Pass");
        expect(await objNewDemoRequest.toggleField("TAMBA", true)).toContain("Pass");
        expect(await objNewDemoRequest.verifyFieldIsPresent("Special Group")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnDropDownOption("Special Group", objData.specialGroup)).toContain("Pass");
        expect(await objNewDemoRequest.verifyFieldIsPresent("Tamba BU")).toContain("Pass");
        expect(await objNewDemoRequest.verifyFieldIsNonEditable("Tamba BU", "", "dd")).toContain("Pass");
        expect(await objNewDemoRequest.verifyFieldIsPresent("Additional TAMBA")).toContain("Pass");
		expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
        expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
        //await objNewDemoRequest.verifyTambaDtlsOnNewDemoForm();
        expect(await objNewDemoRequest.clickOnAdditionalTAMBASearchBtn()).toContain("Pass");
        expect(await objNewDemoRequest.selectFromBUOnAdditionalBUTambaSearchPopUp(objData.additionaBu)).toContain("Pass");
        expect(await objNewDemoRequest.clickGoOnAdditionalBUTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.selectTambaRowOnAdditionalTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSubmitOnAdditionalTambaSearchPopUp()).toContain("Pass");																					  
        // expect(await objNewDemoRequest.verifyFieldIsEditable("Additional TAMBA", "", "input")).not.toContain("Pass");

        done();
    });

    it('TC_38 - Verify that when user  selects BU owned radio button then additional dropdown field shall be displayed', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_38");
        console.info(objData);
        // sDemoName = "TestDemo_1272"
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.toggleField("Special Group Demo", true)).toContain("Pass");
        let sSpecialGrpRbtn = (objData.specialGrpRbtns).split("~");
        expect(await objNewDemoRequest.clickOnRadioBtn("BU Owned")).toContain("Pass");
        for(let iCount = 0; iCount < sSpecialGrpRbtn.length; iCount++)
        {
            expect(await objNewDemoRequest.verifyRadioBtnPresent(sSpecialGrpRbtn[iCount])).toContain("Pass");
        }

        
        expect(await objNewDemoRequest.verifySpecialGrpToBeInformedDDPresent()).toContain("Pass");

        //expect(await objNewDemoRequest.clickOnDropDown("Special Group to be Informed")).toContain("Pass");
        let sSpecialGrpOptions = (objData.specialGrpOptions).split("~");
        for(let iCount = 0; iCount < sSpecialGrpOptions.length; iCount++)
        {
            expect(await objNewDemoRequest.selectOptionFromMultiSelectList("Special Group to be Informed", sSpecialGrpOptions[iCount])).toContain("Pass");
        }
        let sSpecialGrpDeselectOptions = (objData.specialGrpDeselectOptions).split("~");
        for(let iCount = 0; iCount < sSpecialGrpDeselectOptions.length; iCount++)
        {
            expect(await objNewDemoRequest.deselectOptionFromMultiSelectList("Special Group to be Informed", sSpecialGrpDeselectOptions[iCount])).toContain("Pass");
        }

        done();
    });

    it('TC_39 - Verify that user shall be able to submit an internal demo with special group disabled', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_39");
        console.info(objData);

        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        
        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestInternalDemo_" + iRandomNum;

        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        
        

        expect(await objNewDemoRequest.toggleField('Internal Demo', true)).toContain("Pass");
        expect(await objNewDemoRequest.setInternalAccount(objData.internalAccount)).toContain("Pass");
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.setInternalAccountOwner(sLoggedInUser)).toContain("Pass");

        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        expect(await objNewDemoRequest.selectWaferSize(objData.waferSize)).toContain("Pass");
        expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Customer Spec");
        const filePath = path.resolve('./autoItScripts/TestUpload_CustSpec.xlsx');
        const exePath = path.resolve('./autoItScripts/browseFile.exe')
        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath);
        await browser.sleep(10000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Customer Spec")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");

        expect(await objNewDemoRequest.clickWaferStackOption(objData.waferStackOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Wafer Stack");
        const filePath1 = path.resolve('./autoItScripts/TestUpload_WaferStack.xlsx');

        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath1);
        await browser.sleep(10000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Wafer Stack")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");

        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
        sAlertMessage = "Demo Request submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        expect(await objHomePage.selectMenuOption("Requests", "My Demo Request")).toContain("Pass");
        expect(await objMyDemoRequestPage.verifyDemoPresentInTable(sDemoName)).toContain("Pass");
        expect(await objMyDemoRequestPage.verifyDemoApprovalStatus(sDemoName, objData.expDemoStatus)).toContain("Pass");

        done();
    });

it('TC_40 - Verify that user shall be able to submit an internal demo with special group enabled with BU Owned selected', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_40");
        console.info(objData);

        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
        

        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        
        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestInternalDemo_" + iRandomNum;

        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        
        expect(await objNewDemoRequest.toggleField('Internal Demo', true)).toContain("Pass");
        expect(await objNewDemoRequest.toggleField("Special Group Demo", true)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRadioBtn("BU Owned")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnDropDown("Special Group to be Informed")).toContain("Pass");
        let sSpecialGrpOptions = (objData.specialGrpOptions).split("~");
        for(let iCount = 0; iCount < sSpecialGrpOptions.length; iCount++)
        {
            expect(await objNewDemoRequest.selectOptionFromMultiSelectList("Special Group to be Informed", sSpecialGrpOptions[iCount])).toContain("Pass");
        }
        expect(await objNewDemoRequest.setInternalAccount(objData.internalAccount)).toContain("Pass");
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.setInternalAccountOwner(sLoggedInUser)).toContain("Pass");

        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        expect(await objNewDemoRequest.selectWaferSize(objData.waferSize)).toContain("Pass");
        // expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
        // await objNewDemoRequest.clickOnBrowseButtonAgainstField("Customer Spec");
        // const filePath = path.resolve('./autoItScripts/TestUpload_CustSpec.xlsx');
        // const exePath = path.resolve('./autoItScripts/browseFile.exe')
        // //await browser.sleep(5000);
        // cp.execSync(exePath + ' ' + filePath);
        // await browser.sleep(5000);
        // expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
        // expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Customer Spec")).toContain("Pass");
        // expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");

        // expect(await objNewDemoRequest.clickWaferStackOption(objData.waferStackOption)).toContain("Pass");
        // await objNewDemoRequest.clickOnBrowseButtonAgainstField("Wafer Stack");
        // const filePath1 = path.resolve('./autoItScripts/TestUpload_WaferStack.xlsx');

        // //await browser.sleep(5000);
        // cp.execSync(exePath + ' ' + filePath1);
        // await browser.sleep(5000);
        // expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
        // expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Wafer Stack")).toContain("Pass");
        // expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");

        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
        sAlertMessage = "Demo Request submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain("Pass");
        await browser.sleep(5000);
        expect(await objCommonPage.clickInTableButton(sDemoName, "New Request")).toContain("Pass");
        
        expect(await objCommonPage.verifyAlertHeader("Approval View")).toContain("Pass");
        expect(await objApprovalsPage.selectDemoApproval(objData.demoApprovalStatus)).toContain("Pass");
        expect(await objApprovalsPage.selectPriority(objData.priority)).toContain("Pass");
        expect(await objApprovalsPage.selectExecutionRisk("Medium")).toContain("Pass"); 
        expect(await objApprovalsPage.setDemoOwner(sLoggedInUser)).toContain("Pass");
        
        await objApprovalsPage.clickOnSaveApprovalView();
        sAlertMessage = "Approval Saved Successfully"
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        // sDemoName = "TestInternalDemo_7084";

        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');

        expect(await objAllViewPage.clickInTableCell(sDemoName, "Demo Number")).toContain("Pass");
        expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain("Pass");

        expect(await objDemoDetailsPage.expandSection("Demo Issue")).toContain("Pass");
        expect(await objDemoDetailsPage.clickOnToggleField("Demo Issue")).toContain("Pass");
        expect(await objDemoDetailsPage.selectIssueType(objData.issueType)).toContain("Pass");
        expect(await objDemoDetailsPage.selectWaferSlotPosition(objData.waferSlotPosition)).toContain("Pass");
        expect(await objDemoDetailsPage.clickSaveToSaveTblChanges()).toContain("Pass");
        
        expect(await objDemoDetailsPage.clickOnSubmitDemoDetails()).toContain("Pass");

        sAlertMessage = "Demo Details Submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        // sDemoName = "TestDemo_6561";

        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
        expect(await objCommonPage.goToColumn("Demo Issue")).toContain("Pass");
        expect(await objAllViewPage.clickInTableCell(sDemoName, "Demo Issue")).toContain("Pass");
        expect(await objAllViewPage.clickCancelOnEditPopUp()).toContain("Pass");
        expect(await objAllViewPage.clickInTableCell(sDemoName, "Demo Issue")).toContain("Pass");
        // expect(await objAllViewPage.clickCancelOnEditPopUp()).toContain("Pass");
        await browser.sleep(5000);
        expect(await objCommonPage.verifyAlertHeader("Edit")).toContain("Pass");
        // expect(await objAllViewPage.verifyDemoIssueDtlsOnEditPopUp("Issue Type", objData.issueType)).toContain("Pass");
        // expect(await objAllViewPage.verifyDemoIssueDtlsOnEditPopUp("Wafer Slot Position", objData.waferSlotPosition)).toContain("Pass");
        expect(await objAllViewPage.clickCancelOnEditPopUp()).toContain("Pass");

        done();
    });

    it('TC_41 - Verify that user shall be able to submit an internal demo with special group enabled with Special Group Owned selected', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_41");
        console.info(objData);

        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
        

        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        
        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestInternalDemo_" + iRandomNum;

        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        
        expect(await objNewDemoRequest.toggleField('Internal Demo', true)).toContain("Pass");
        expect(await objNewDemoRequest.toggleField("Special Group Demo", true)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRadioBtn("Special Group Owned")).toContain("Pass");
        
        expect(await objNewDemoRequest.setInternalAccount(objData.internalAccount)).toContain("Pass");
        // expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.setInternalAccountOwner(sLoggedInUser)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnDropDownOption("Special Group", objData.specialGroup)).toContain("Pass");

        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        expect(await objNewDemoRequest.selectWaferSize(objData.waferSize)).toContain("Pass");
        // expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
        // await objNewDemoRequest.clickOnBrowseButtonAgainstField("Customer Spec");
        // const filePath = path.resolve('./autoItScripts/TestUpload_CustSpec.xlsx');
        // const exePath = path.resolve('./autoItScripts/browseFile.exe')
        // //await browser.sleep(5000);
        // cp.execSync(exePath + ' ' + filePath);
        // await browser.sleep(5000);
        // expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
        // expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Customer Spec")).toContain("Pass");
        // expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");

        // expect(await objNewDemoRequest.clickWaferStackOption(objData.waferStackOption)).toContain("Pass");
        // await objNewDemoRequest.clickOnBrowseButtonAgainstField("Wafer Stack");
        // const filePath1 = path.resolve('./autoItScripts/TestUpload_WaferStack.xlsx');

        // //await browser.sleep(5000);
        // cp.execSync(exePath + ' ' + filePath1);
        // await browser.sleep(5000);
        // expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
        // expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Wafer Stack")).toContain("Pass");
        // expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");

        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
        sAlertMessage = "Demo Request submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain("Pass");
        await browser.sleep(5000);
        expect(await objCommonPage.clickInTableButton(sDemoName, "New Request")).toContain("Pass");
        
        expect(await objCommonPage.verifyAlertHeader("Approval View")).toContain("Pass");
        expect(await objApprovalsPage.selectDemoApproval(objData.demoApprovalStatus)).toContain("Pass");
        expect(await objApprovalsPage.selectPriority(objData.priority)).toContain("Pass");
        expect(await objApprovalsPage.selectExecutionRisk("Medium")).toContain("Pass"); 
        expect(await objApprovalsPage.setDemoOwner(sLoggedInUser)).toContain("Pass");
        
        await objApprovalsPage.clickOnSaveApprovalView();
        sAlertMessage = "Approval Saved Successfully"
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        // sDemoName = "TestInternalDemo_3674";

        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');

        expect(await objAllViewPage.clickInTableCell(sDemoName, "Demo Number")).toContain("Pass");
        expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain("Pass");

        expect(await objDemoDetailsPage.expandSection("Cost Estimation")).toContain("Pass");
        expect(await objDemoDetailsPage.setConsumablesInCostEstimation(objData.consumables)).toContain("Pass");
        expect(await objDemoDetailsPage.setFieldValInDemoDtlsPage("Justification", objData.justification)).toContain("Pass");
        expect(await objDemoDetailsPage.setFieldValInDemoDtlsPage("Pattern Wafer", objData.patternWafer)).toContain("Pass");
        expect(await objDemoDetailsPage.setFieldValInDemoDtlsPage("Blanket Wafer", objData.blanketWafer)).toContain("Pass");
        expect(await objDemoDetailsPage.setFieldValInDemoDtlsPage("Labor charges", objData.laborChrg)).toContain("Pass");
        expect(await objDemoDetailsPage.setFieldValInDemoDtlsPage("Bay / Tool charges", objData.bayToolChrg)).toContain("Pass");
        expect(await objDemoDetailsPage.setFieldValInDemoDtlsPage("Tool Depreciation Cost", objData.toolDepCost)).toContain("Pass");
        
        expect(await objDemoDetailsPage.clickOnSubmitDemoDetails()).toContain("Pass");

        sAlertMessage = "Demo Details Submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");

        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');

        expect(await objAllViewPage.clickInTableCell(sDemoName, "Demo Number")).toContain("Pass");
        expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain("Pass");

        expect(await objDemoDetailsPage.expandSection("Cost Estimation")).toContain("Pass");
        let sCostEstimated = await objDemoDetailsPage.getEstimatedCost();
        sCostEstimated = sCostEstimated.replace("$0", "$");
        // sDemoName = "TestDemo_6561";

        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
        expect(await objCommonPage.goToColumn("Estimated Cost")).toContain("Pass");
        expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "Estimated Cost", sCostEstimated)).toContain("Pass");

        done();
    });
    it('TC_42 - Verify that user shall be able to submit an external demo with Tamba enabled and Special Group demos toggle disabled', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_42");
        console.info(objData);

        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_CreateDemo" + iRandomNum;

        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");;
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");

        expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
        
        expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
        expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
        await objNewDemoRequest.verifyTambaDtlsOnNewDemoForm();

        expect(await objNewDemoRequest.toggleField("Special Group Demo", false)).toContain("Pass");
        
        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        
        expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Customer Spec");
        const filePath = path.resolve('./autoItScripts/TestUpload_CustSpec.xlsx');
        const exePath = path.resolve('./autoItScripts/browseFile.exe')
        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath);
        await browser.sleep(10000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Customer Spec")).toContain("Pass");
        let sTodayDateCust = await objCommonPage.getCurrentDate("mm/dd/yyyy hh:mins");
        console.log(sTodayDateCust);
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.getDateTimeAgainstDocInField("Customer Spec", "TestUpload_CustSpec.xlsx")).toEqual(sTodayDateCust);

        expect(await objNewDemoRequest.clickWaferStackOption(objData.waferStackOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Wafer Stack");
        const filePath1 = path.resolve('./autoItScripts/TestUpload_WaferStack.xlsx');

        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath1);
        await browser.sleep(10000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Wafer Stack")).toContain("Pass");
        let sTodayDateWaferStack = await objCommonPage.getCurrentDate("mm/dd/yyyy hh:mins");
        console.log(sTodayDateWaferStack);
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.getDateTimeAgainstDocInField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toEqual(sTodayDateWaferStack);

        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
        sAlertMessage = "Demo Request submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        
        expect(await objHomePage.selectMenuOption("Requests", "My Demo Request")).toContain("Pass");
        expect(await objMyDemoRequestPage.verifyDemoPresentInTable(sDemoName)).toContain("Pass");
        expect(await objMyDemoRequestPage.verifyDemoApprovalStatus(sDemoName, objData.expDemoStatus)).toContain("Pass"); 
		done();
    });
	
	
    it('TC_53 - Verify that user shall be able to add Multi BU demo type and secondary BU along with requester for the demo request with status Pending for Approval', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_53");
        console.info(objData);
        //sDemoName = "TestDemo_2787";
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");
        expect(await objCommonPage.searchRequest(sDemoName)).toContain("Pass");
        // await browser.sleep(5000);
        expect(await objCommonPage.goToColumn("Demo Type")).toContain("Pass");
        expect(await objAllViewPage.clickInTableCell(sDemoName, "Demo Type")).toContain("Pass");
                
        expect(await objCommonPage.verifyAlertHeader("Edit")).toContain("Pass");
        expect(await objAllViewPage.selectDDValueOnEditPopUp("Demo Type", objData.demoType)).toContain("Pass");
        expect(await objAllViewPage.clickOnSave()).toContain("Pass");
        sAlertMessage = "You Choose Multi BU Demo as Demo Type Please make atleast one entry in Secondary BU table.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");

        expect(await objAllViewPage.clickAddNewBtnOnEditPopUp()).toContain("Pass");
        expect(await objAllViewPage.selectSecondaryBUInTableOnEditPopUp(objData.secBU1)).toContain("Pass");
        expect(await objNewDemoRequest.selectRequestorInSecBUTbl(objData.requestor1)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSaveSecondaryBU()).toContain("Pass");
        expect(await objAllViewPage.clickOnSave()).toContain("Pass");
        await objCommonPage.waitTillInvisibilityOfLoadingIcon();
        expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "Demo Type", objData.demoType)).toContain("Pass");
        //verify value in table cell - currently value not getting saved so sure in which format it appears

        done();
    });

    it('TC_42_1 - Approve demo using BU super user account', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_42");
        console.info(objData);
        
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameBUSuperUser)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordBUSuperUser)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
        //await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});

        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain("Pass");
        await browser.sleep(5000);
        expect(await objCommonPage.clickInTableButton(sDemoName, "New Request")).toContain("Pass");
        
        expect(await objCommonPage.verifyAlertHeader("Approval View")).toContain("Pass");
        expect(await objApprovalsPage.selectDemoApproval(objData.demoApprovalStatus)).toContain("Pass");
        expect(await objApprovalsPage.selectPriority(objData.priority)).toContain("Pass");
        
        expect(await objApprovalsPage.setDemoOwner(sLoggedInUser)).toContain("Pass");
        expect(await objApprovalsPage.selectExecutionRisk("Medium")).toContain("Pass"); 
        await objApprovalsPage.clickOnSaveApprovalView();
        sAlertMessage = "Approval Saved Successfully"
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");

        //expect(await objHomePage.selectMenuOption("Approvals", "Approved Requests")).toContain("Pass");
        //expect(await objCommonPage.searchRequest(sDemoName)).toContain("Pass");
        //expect(await objCommonPage.goToColumn("Demo Approval")).toContain("Pass");
        //expect(await objApprovalsPage.verifyDemoApprovalStatus(sDemoName, "ACL-Approved")).toContain("Pass");

        done();
    });

    it('TC_42_2 - Submit demo details using Demo Owner account', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_42");
        console.info(objData);
        // sDemoName = "TestDemo_1512";
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');

        expect(await objCommonPage.clickInTheTableCell("Demo Number",sDemoName)).toContain("Pass");
        expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain("Pass");

        expect(await objDemoDetailsPage.setFieldValInDemoDtlsPage("IO#/CC", objData.ioCCVal)).toContain("Pass");
        expect(await objDemoDetailsPage.selectDDOptionOnDemoDtlsPage("Substrate Type", objData.substrateTypeDemoDtls)).toContain("Pass");
        
        expect(await objDemoDetailsPage.clickOnSubmitDemoDetails()).toContain("Pass");

        sAlertMessage = "Demo Details Submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");

        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
        expect(await objCommonPage.goToColumn("IO#/ Cost Center")).toContain("Pass");
        expect(await objCommonPage.verifyTextValueInTableCell( "IO#/ Cost Center",sDemoName, objData.ioCCVal)).toContain("Pass");
        expect(await objCommonPage.goToColumn("Substrate Type")).toContain("Pass");
        expect(await objCommonPage.verifyTextValueInTableCell( "Substrate Type",sDemoName, objData.substrateTypeDemoDtls)).toContain("Pass");
        done();
    });

    it('TC_43 - Verify that user shall be able to submit an external demo with Tamba disabled and Special Group demos toggle disabled - Create demo with TAMBA and Special group demo disabled', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_43");
        console.info(objData);

        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_CreateDemo" + iRandomNum;

        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");;
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");

        expect(await objNewDemoRequest.toggleField('TAMBA', false)).toContain("Pass");
        
        expect(await objNewDemoRequest.toggleField("Special Group Demo", false)).toContain("Pass");

        expect(await objNewDemoRequest.clickOnDropDownOption("Application Segment", objData.appSegment)).toContain("Pass");//DRAM: EUV
        expect(await objNewDemoRequest.clickOnDropDownOption("Device Type", objData.deviceType)).toContain("Pass");//FDSOI
        expect(await objNewDemoRequest.clickOnDropDownOption("AMAT Node", objData.amatNode)).toContain("Pass");//10nm
        
        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        
        expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Customer Spec");
        const filePath = path.resolve('./autoItScripts/TestUpload_CustSpec.xlsx');
        const exePath = path.resolve('./autoItScripts/browseFile.exe')
        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath);
        await browser.sleep(10000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Customer Spec")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");

        expect(await objNewDemoRequest.clickWaferStackOption(objData.waferStackOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Wafer Stack");
        const filePath1 = path.resolve('./autoItScripts/TestUpload_WaferStack.xlsx');

        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath1);
        await browser.sleep(10000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Wafer Stack")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");

        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
        sAlertMessage = "Demo Request submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        
        expect(await objHomePage.selectMenuOption("Requests", "My Demo Request")).toContain("Pass");
        expect(await objMyDemoRequestPage.verifyDemoPresentInTable(sDemoName)).toContain("Pass");
        expect(await objMyDemoRequestPage.verifyDemoApprovalStatus(sDemoName, objData.expDemoStatus)).toContain("Pass"); 

        done();
    });

    it('TC_43_1 - Verify that user shall be able to submit an external demo with Tamba disabled and Special Group demos toggle disabled - Approve demo using BU super user account', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_43");
        console.info(objData);
        
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameBUSuperUser)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordBUSuperUser)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain("Pass");
        await browser.sleep(5000);
        expect(await objCommonPage.clickInTableButton(sDemoName, "New Request")).toContain("Pass");
        
        expect(await objCommonPage.verifyAlertHeader("Approval View")).toContain("Pass");
        expect(await objApprovalsPage.selectDemoApproval(objData.demoApprovalStatus)).toContain("Pass");
        expect(await objApprovalsPage.selectPriority(objData.priority)).toContain("Pass");
        
        expect(await objApprovalsPage.setDemoOwner(sLoggedInUser)).toContain("Pass");
        expect(await objApprovalsPage.selectExecutionRisk("Medium")).toContain("Pass"); 
        await objApprovalsPage.clickOnSaveApprovalView();
        sAlertMessage = "Approval Saved Successfully"
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");

        // expect(await objHomePage.selectMenuOption("Approvals", "Approved Requests")).toContain("Pass");
        // expect(await objCommonPage.searchRequest(sDemoName)).toContain("Pass");
        // expect(await objCommonPage.goToColumn("Demo Approval")).toContain("Pass");
        // expect(await objApprovalsPage.verifyDemoApprovalStatus(sDemoName, "ACL-Approved")).toContain("Pass");
        done();
    });

    it('TC_43_2 - Verify that user shall be able to submit an external demo with Tamba disabled and Special Group demos toggle disabled - Submit demo details using Demo Owner account', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_43");
        console.info(objData);
        // sDemoName = "TestDemo_2787";
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');

        expect(await objAllViewPage.clickInTableCell(sDemoName, "Demo Number")).toContain("Pass");
        expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain("Pass");

        expect(await objDemoDetailsPage.setFieldValInDemoDtlsPage("Engineer", objData.engineer)).toContain("Pass");
        expect(await objDemoDetailsPage.selectDDOptionOnDemoDtlsPage("Resources", objData.resources)).toContain("Pass");
        expect(await objDemoDetailsPage.setFieldValInDemoDtlsPage("TEM(Sample/wk)", objData.temSampleWk)).toContain("Pass");
        expect(await objDemoDetailsPage.setFieldValInDemoDtlsPage("SEM(Sample/wk)", objData.semSampleWk)).toContain("Pass");
        expect(await objDemoDetailsPage.selectDDOptionOnDemoDtlsPage("Demo Development Stage", objData.demoDevStage)).toContain("Pass");
        expect(await objDemoDetailsPage.setFieldValInDemoDtlsPage("Chamber Usage(H/Day)", objData.chamberUsage)).toContain("Pass");
        expect(await objDemoDetailsPage.setFieldValInDemoDtlsPage("Duration(wk)", objData.duration)).toContain("Pass");
        
        expect(await objDemoDetailsPage.clickOnSubmitDemoDetails()).toContain("Pass");

        sAlertMessage = "Demo Details Submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");

        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
        expect(await objCommonPage.goToColumn("Eng.")).toContain("Pass");
        expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "Eng.", objData.engineer)).toContain("Pass");
        expect(await objCommonPage.goToColumn("Resources")).toContain("Pass");
        expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "Resources", objData.resourcesAllView)).toContain("Pass");
        expect(await objCommonPage.goToColumn("TEM Spls/wk")).toContain("Pass");
        expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "TEM Spls/wk", objData.temSampleWk)).toContain("Pass");
        expect(await objCommonPage.goToColumn("SEM Spls/wk")).toContain("Pass");
        expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "SEM Spls/wk", objData.semSampleWk)).toContain("Pass");
        expect(await objCommonPage.goToColumn("Demo Development Stage")).toContain("Pass");
        expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "Demo Development Stage", objData.demoDevStage)).toContain("Pass");
        expect(await objCommonPage.goToColumn("Chamber Usage (H/Day)")).toContain("Pass");
        expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "Chamber Usage (H/Day)", objData.chamberUsage)).toContain("Pass");
        expect(await objCommonPage.goToColumn("Duration (wk)")).toContain("Pass");
        expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "Duration (wk)", objData.duration)).toContain("Pass");
        done();
    });

    it('TC_44 - Verify that user shall be able to submit an external demo with Tamba enabled and Special Group demos toggle enabled with BM Owned selected', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_44");
        console.info(objData);

        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        expect(await objNewDemoRequest.toggleField("Special Group Demo", true)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRadioBtn("BU Owned")).toContain("Pass");
        // expect(await objNewDemoRequest.clickOnDropDown("Special Group to be Informed")).toContain("Pass");

        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_CreateDemo" + iRandomNum;

        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRadioBtn("BU Owned")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnDropDown("Special Group to be Informed")).toContain("Pass");
        expect(await objNewDemoRequest.selectOptionFromMultiSelectList("Special Group to be Informed", objData.specialGrpOptions)).toContain("Pass");
        // expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");

        expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
        expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
        // await objNewDemoRequest.verifyTambaDtlsOnNewDemoForm();  
        
        
        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        
        expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Customer Spec");
        const filePath = path.resolve('./autoItScripts/TestUpload_CustSpec.xlsx');
        const exePath = path.resolve('./autoItScripts/browseFile.exe')
        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath);
        await browser.sleep(10000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Customer Spec")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");

        expect(await objNewDemoRequest.clickWaferStackOption(objData.waferStackOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Wafer Stack");
        const filePath1 = path.resolve('./autoItScripts/TestUpload_WaferStack.xlsx');

        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath1);
        await browser.sleep(10000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Wafer Stack")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");

        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
        sAlertMessage = "Demo Request submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        
        
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain("Pass");
        await browser.sleep(5000);
        expect(await objCommonPage.clickInTableButton(sDemoName, "New Request")).toContain("Pass");
        
        expect(await objCommonPage.verifyAlertHeader("Approval View")).toContain("Pass");
        expect(await objApprovalsPage.selectDemoApproval(objData.demoApprovalStatus)).toContain("Pass");
        expect(await objApprovalsPage.selectPriority(objData.priority)).toContain("Pass");
        
        expect(await objApprovalsPage.setDemoOwner(sLoggedInUser)).toContain("Pass");
        expect(await objApprovalsPage.selectExecutionRisk("Medium")).toContain("Pass"); 
        await objApprovalsPage.clickOnSaveApprovalView();
        sAlertMessage = "Approval Saved Successfully"
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        
        // sDemoName = "TestDemo_6561";
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');

        expect(await objAllViewPage.clickInTableCell(sDemoName, "Demo Number")).toContain("Pass");
        expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain("Pass");

        expect(await objDemoDetailsPage.expandSection("Demo Issue")).toContain("Pass");
        expect(await objDemoDetailsPage.clickOnToggleField("Demo Issue")).toContain("Pass");
        expect(await objDemoDetailsPage.selectIssueType(objData.issueType)).toContain("Pass");
        expect(await objDemoDetailsPage.selectWaferSlotPosition(objData.waferSlotPosition)).toContain("Pass");
        expect(await objDemoDetailsPage.clickSaveToSaveTblChanges()).toContain("Pass");
        
        expect(await objDemoDetailsPage.clickOnSubmitDemoDetails()).toContain("Pass");

        sAlertMessage = "Demo Details Submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        // sDemoName = "TestDemo_6561";

        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
        expect(await objCommonPage.goToColumn("Demo Issue")).toContain("Pass");
        expect(await objAllViewPage.clickInTableCell(sDemoName, "Demo Issue")).toContain("Pass");
        expect(await objAllViewPage.clickCancelOnEditPopUp()).toContain("Pass");
        expect(await objAllViewPage.clickInTableCell(sDemoName, "Demo Issue")).toContain("Pass");
        // expect(await objAllViewPage.clickCancelOnEditPopUp()).toContain("Pass");
        await browser.sleep(5000);
        expect(await objCommonPage.verifyAlertHeader("Edit")).toContain("Pass");
        // expect(await objAllViewPage.verifyDemoIssueDtlsOnEditPopUp("Issue Type", objData.issueType)).toContain("Pass");
        // expect(await objAllViewPage.verifyDemoIssueDtlsOnEditPopUp("Wafer Slot Position", objData.waferSlotPosition)).toContain("Pass");
        expect(await objAllViewPage.clickCancelOnEditPopUp()).toContain("Pass");

        done();
    });
    it('TC_45 - Verify that user shall be able to submit an external demo with Tamba disabled and Special Group demos toggle enabled with BU Owner option selected', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_45");
        console.info(objData);

        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        expect(await objNewDemoRequest.toggleField("Special Group Demo", true)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRadioBtn("BU Owned")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnDropDown("Special Group to be Informed")).toContain("Pass");
        let sSpecialGrpOptions = (objData.specialGrpOptions).split("~");
        for(let iCount = 0; iCount < sSpecialGrpOptions.length; iCount++)
        {
            expect(await objNewDemoRequest.selectOptionFromMultiSelectList("Special Group to be Informed", sSpecialGrpOptions[iCount])).toContain("Pass");
        }

        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_CreateDemo" + iRandomNum;

        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");;
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");

        expect(await objNewDemoRequest.toggleField('TAMBA', false)).toContain("Pass");
        
        

        expect(await objNewDemoRequest.clickOnDropDownOption("Application Segment", objData.appSegment)).toContain("Pass");//DRAM: EUV
        expect(await objNewDemoRequest.clickOnDropDownOption("Device Type", objData.deviceType)).toContain("Pass");//FDSOI
        expect(await objNewDemoRequest.clickOnDropDownOption("AMAT Node", objData.amatNode)).toContain("Pass");//10nm
        
        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        
        expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Customer Spec");
        const filePath = path.resolve('./autoItScripts/TestUpload_CustSpec.xlsx');
        const exePath = path.resolve('./autoItScripts/browseFile.exe')
        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath);
        await browser.sleep(10000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Customer Spec")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");

        expect(await objNewDemoRequest.clickWaferStackOption(objData.waferStackOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Wafer Stack");
        const filePath1 = path.resolve('./autoItScripts/TestUpload_WaferStack.xlsx');

        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath1);
        await browser.sleep(10000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Wafer Stack")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");

        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
        sAlertMessage = "Demo Request submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        
        
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain("Pass");
        await browser.sleep(5000);
        expect(await objCommonPage.clickInTableButton(sDemoName, "New Request")).toContain("Pass");
        
        expect(await objCommonPage.verifyAlertHeader("Approval View")).toContain("Pass");
        expect(await objApprovalsPage.selectDemoApproval(objData.demoApprovalStatus)).toContain("Pass");
        expect(await objApprovalsPage.selectPriority(objData.priority)).toContain("Pass");
        
        expect(await objApprovalsPage.setDemoOwner(sLoggedInUser)).toContain("Pass");
        expect(await objApprovalsPage.selectExecutionRisk("Medium")).toContain("Pass"); 
        await objApprovalsPage.clickOnSaveApprovalView();
        sAlertMessage = "Approval Saved Successfully"
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        

        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');

        expect(await objAllViewPage.clickInTableCell(sDemoName, "Demo Number")).toContain("Pass");
        expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain("Pass");

        expect(await objCommonPage.selectPeoplePickerVal("Team Member", objData.teamMember)).toContain("Pass");
        expect(await objCommonPage.selectPeoplePickerVal("BM Owner", sLoggedInUser)).toContain("Pass");
        expect(await objCommonPage.selectPeoplePickerVal("CAT/RAT Manager", objData.catRatMngr)).toContain("Pass");
        expect(await objCommonPage.selectPeoplePickerVal("KPU Head/GPM", objData.kpuHeadGPM)).toContain("Pass");
        
        expect(await objDemoDetailsPage.clickOnSubmitDemoDetails()).toContain("Pass");

        sAlertMessage = "Demo Details Submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");

        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
        expect(await objCommonPage.goToColumn("Team Member")).toContain("Pass");
        expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "Team Member", objData.teamMember)).toContain("Pass");
        expect(await objCommonPage.goToColumn("BM Owner")).toContain("Pass");
        expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "BM Owner", sLoggedInUser)).toContain("Pass");
        expect(await objCommonPage.goToColumn("CAT/RAT Manager")).toContain("Pass");
        expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "CAT/RAT Manager", objData.catRatMngr)).toContain("Pass");
        expect(await objCommonPage.goToColumn("KPU Head/GPM")).toContain("Pass");
        expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "KPU Head/GPM", objData.kpuHeadGPM)).toContain("Pass");

        done();
    });

    it('TC_46 - Verify that user shall be able to submit an external demo with Tamba disabled and Special Group demos toggle enabled with Special Group Owned option selected', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_46");
        console.info(objData);

        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        expect(await objNewDemoRequest.toggleField("Special Group Demo", true)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRadioBtn("Special Group Owned")).toContain("Pass");
        // expect(await objNewDemoRequest.clickOnDropDown("Special Group to be Informed")).toContain("Pass");

        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_CreateDemo" + iRandomNum;

        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");;
        // expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");

        expect(await objNewDemoRequest.toggleField('TAMBA', false)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnDropDownOption("Special Group", objData.specialGroup)).toContain("Pass");        

        expect(await objNewDemoRequest.clickOnDropDownOption("Application Segment", objData.appSegment)).toContain("Pass");//DRAM: EUV
        expect(await objNewDemoRequest.clickOnDropDownOption("Device Type", objData.deviceType)).toContain("Pass");//FDSOI
        expect(await objNewDemoRequest.clickOnDropDownOption("AMAT Node", objData.amatNode)).toContain("Pass");//10nm
        
        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        
        expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Customer Spec");
        const filePath = path.resolve('./autoItScripts/TestUpload_CustSpec.xlsx');
        const exePath = path.resolve('./autoItScripts/browseFile.exe')
        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath);
        await browser.sleep(10000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Customer Spec")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");

        expect(await objNewDemoRequest.clickWaferStackOption(objData.waferStackOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Wafer Stack");
        const filePath1 = path.resolve('./autoItScripts/TestUpload_WaferStack.xlsx');

        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath1);
        await browser.sleep(10000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Wafer Stack")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");

        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
        sAlertMessage = "Demo Request submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        
        
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain("Pass");
        await browser.sleep(5000);
        expect(await objCommonPage.clickInTableButton(sDemoName, "New Request")).toContain("Pass");
        
        expect(await objCommonPage.verifyAlertHeader("Approval View")).toContain("Pass");
        expect(await objApprovalsPage.selectDemoApproval(objData.demoApprovalStatus)).toContain("Pass");
        expect(await objApprovalsPage.selectPriority(objData.priority)).toContain("Pass");
        
        expect(await objApprovalsPage.setDemoOwner(sLoggedInUser)).toContain("Pass");
        expect(await objApprovalsPage.selectExecutionRisk("Medium")).toContain("Pass"); 
        await objApprovalsPage.clickOnSaveApprovalView();
        sAlertMessage = "Approval Saved Successfully"
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        
        // sDemoName = "TestDemo_6761";
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');

        expect(await objAllViewPage.clickInTableCell(sDemoName, "Demo Number")).toContain("Pass");
        expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain("Pass");

        // expect(await objDemoDetailsPage.selectDDOptionOnDemoDtlsPage("Demo Location", objData.demoLoc)).toContain("Pass");
        expect(await objDemoDetailsPage.clickOnFieldDropDown("Demo Location")).toContain("Pass");
        expect(await objDemoDetailsPage.selectOptionFromDDList("Demo Location", objData.demoLoc)).toContain("Pass");
        // expect(await objDemoDetailsPage.selectDDOptionOnDemoDtlsPage("Tool Name", objData.toolName)).toContain("Pass");
        expect(await objDemoDetailsPage.clickOnFieldDropDown("Tool Name")).toContain("Pass");
        expect(await objDemoDetailsPage.selectOptionFromDDList("Tool Name", objData.toolName)).toContain("Pass");
        let sToolId = await objDemoDetailsPage.getToolId();
        expect(await objDemoDetailsPage.selectOptFromMultiSelectDDList("Chamber Position", objData.chamberPos)).toContain("Pass");
        // expect(await objDemoDetailsPage.clickOnFieldDropDown("Chamber Position")).toContain("Pass");
        // expect(await objDemoDetailsPage.selectOptionFromDDList("Chamber Position", objData.chamberPos)).toContain("Pass");
        expect(await objDemoDetailsPage.selectDDOptionOnDemoDtlsPage("Wafer location", objData.waferLoc)).toContain("Pass");
        // expect(await objDemoDetailsPage.clickOnFieldDropDown("Wafer Location")).toContain("Pass");
        // expect(await objDemoDetailsPage.selectOptionFromDDList("Wafer Location", objData.waferLoc)).toContain("Pass");
        expect(await objDemoDetailsPage.selectDDOptionOnDemoDtlsPage("Customer Wafer Destination", objData.custWaferDest)).toContain("Pass");
        // expect(await objDemoDetailsPage.clickOnFieldDropDown("Customer Wafer Destination")).toContain("Pass");
        // expect(await objDemoDetailsPage.selectOptionFromDDList("Customer Wafer Destination", objData.CustWaferDest)).toContain("Pass");
        
        expect(await objDemoDetailsPage.clickOnSubmitDemoDetails()).toContain("Pass");

        sAlertMessage = "Demo Details Submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");

        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
        expect(await objCommonPage.goToColumn("Demo Location")).toContain("Pass");
        expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "Demo Location", objData.demoLoc)).toContain("Pass");
        expect(await objCommonPage.goToColumn("Tool ID")).toContain("Pass");
        expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "Tool ID", sToolId)).toContain("Pass");
        expect(await objCommonPage.goToColumn("Chamber Position")).toContain("Pass");
        expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "Chamber Position", objData.chamberPos)).toContain("Pass");
        expect(await objCommonPage.goToColumn("Wafer Location")).toContain("Pass");
        expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "Wafer Location", objData.waferLoc)).toContain("Pass");
        expect(await objCommonPage.goToColumn("Customer Wafer Destination")).toContain("Pass");
        expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "Customer Wafer Destination", objData.custWaferDest)).toContain("Pass");

        done();
    });

    it('TC_47 - Verify that user shall be able to submit an external demo with Tamba enabled and Special Group demos toggle enabled with Special Group Owned option selected', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_47");
        console.info(objData);

        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        expect(await objNewDemoRequest.toggleField("Special Group Demo", true)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRadioBtn("Special Group Owned")).toContain("Pass");
        // expect(await objNewDemoRequest.clickOnDropDown("Special Group to be Informed")).toContain("Pass");

        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_CreateDemo" + iRandomNum;

        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");;
        // expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");

        expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnDropDownOption("Special Group", objData.specialGroup)).toContain("Pass"); 
        expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
        expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
        // await objNewDemoRequest.verifyTambaDtlsOnNewDemoForm();  
        
        expect(await objNewDemoRequest.clickOnAdditionalTAMBASearchBtn()).toContain("Pass");
        expect(await objNewDemoRequest.selectFromBUOnAdditionalBUTambaSearchPopUp(objData.additionaBu)).toContain("Pass");
        expect(await objNewDemoRequest.clickGoOnAdditionalBUTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.selectTambaRowOnAdditionalTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSubmitOnAdditionalTambaSearchPopUp()).toContain("Pass");

        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        
        expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Customer Spec");
        const filePath = path.resolve('./autoItScripts/TestUpload_CustSpec.xlsx');
        const exePath = path.resolve('./autoItScripts/browseFile.exe')
        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath);
        await browser.sleep(10000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Customer Spec")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");

        expect(await objNewDemoRequest.clickWaferStackOption(objData.waferStackOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Wafer Stack");
        const filePath1 = path.resolve('./autoItScripts/TestUpload_WaferStack.xlsx');

        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath1);
        await browser.sleep(10000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Wafer Stack")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");

        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
        sAlertMessage = "Demo Request submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        
        
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain("Pass");
        await browser.sleep(5000);
        expect(await objCommonPage.clickInTableButton(sDemoName, "New Request")).toContain("Pass");
        
        expect(await objCommonPage.verifyAlertHeader("Approval View")).toContain("Pass");
        expect(await objApprovalsPage.selectDemoApproval(objData.demoApprovalStatus)).toContain("Pass");
        expect(await objApprovalsPage.selectPriority(objData.priority)).toContain("Pass");
        
        expect(await objApprovalsPage.setDemoOwner(sLoggedInUser)).toContain("Pass");
        expect(await objApprovalsPage.selectExecutionRisk("Medium")).toContain("Pass"); 
        await objApprovalsPage.clickOnSaveApprovalView();
        sAlertMessage = "Approval Saved Successfully"
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        
        // sDemoName = "TestDemo_4025";
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');

        expect(await objAllViewPage.clickInTableCell(sDemoName, "Demo Number")).toContain("Pass");
        expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain("Pass");

        expect(await objDemoDetailsPage.clickonScheduleIcon("Lab Ready")).toContain("Pass");
        expect(await objDemoDetailsPage.clickOnCalendarIcon("Config Change Date")).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("12", "April", "2021")).toContain("Pass");
        expect(await objDemoDetailsPage.selectOptionFromFieldOnDemoDetails("Config Change Date Milestone Status", objData.confChngDtMilestoneStatus)).toContain("Pass");
        expect(await objDemoDetailsPage.setFieldValInDemoDtlsPage("Justification", objData.justification)).toContain("Pass");
        expect(await objCommonPage.takeActionOnAlert("Submit")).toContain("Pass");
        let sLabReadyDt = "04/12/2021";

        expect(await objDemoDetailsPage.clickonScheduleIcon("Demo Start")).toContain("Pass");
        expect(await objDemoDetailsPage.clickOnCalendarIcon("Schedule Start Date")).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("13", "April", "2021")).toContain("Pass");
        expect(await objDemoDetailsPage.selectOptionFromFieldOnDemoDetails("Schedule Start Date Milestone Status", objData.schStrtDtMilestoneStatus)).toContain("Pass");
        expect(await objDemoDetailsPage.setFieldValInDemoDtlsPage("Justification", objData.justification)).toContain("Pass");
        expect(await objCommonPage.takeActionOnAlert("Submit")).toContain("Pass");
        let sDemoStartDt = "04/13/2021";

        expect(await objDemoDetailsPage.clickonScheduleIcon("Demo Completion")).toContain("Pass");
        expect(await objDemoDetailsPage.clickOnCalendarIcon("Schedule Completion Date")).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("16", "April", "2021")).toContain("Pass");
        expect(await objDemoDetailsPage.selectOptionFromFieldOnDemoDetails("Schedule Completion Date Milestone Status", objData.schCompDtMilestoneStatus)).toContain("Pass");
        expect(await objDemoDetailsPage.setFieldValInDemoDtlsPage("Justification", objData.justification)).toContain("Pass");
        expect(await objCommonPage.takeActionOnAlert("Submit")).toContain("Pass");
        let sDemoCompletionDt = "04/16/2021";
        
        expect(await objDemoDetailsPage.clickOnSubmitDemoDetails()).toContain("Pass");

        sAlertMessage = "Demo Details Submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");

        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
        expect(await objCommonPage.goToColumn("Lab Ready")).toContain("Pass");
        expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "Lab Ready", sLabReadyDt)).toContain("Pass");
        expect(await objCommonPage.goToColumn("Demo Start")).toContain("Pass");
        expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "Demo Start", sDemoStartDt)).toContain("Pass");
        expect(await objCommonPage.goToColumn("Demo Completion")).toContain("Pass");
        expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "Demo Completion", sDemoCompletionDt)).toContain("Pass");

        done();
    });  
    it('TC_49 - Verify that user shall be able to submit an external multi BU  demo with Tamba enabled and Special Group demos toggle enabled with BU Owner option selected but special groups involved', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_49");
        console.info(objData);

        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        expect(await objNewDemoRequest.toggleField("Special Group Demo", true)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRadioBtn("BU Owned")).toContain("Pass");
        // expect(await objNewDemoRequest.clickOnDropDown("Special Group to be Informed")).toContain("Pass");

        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_CreateDemo" + iRandomNum;

        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        //expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");;
        // expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");

        expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
        //expect(await objNewDemoRequest.clickOnDropDownOption("Special Group", objData.specialGroup)).toContain("Pass"); 
        expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
        expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
        await objNewDemoRequest.verifyTambaDtlsOnNewDemoForm();  

        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnAddSecondaryBU()).toContain("Pass");
    
        expect(await objNewDemoRequest.selectSecondaryBUInTable(objData.secBU1)).toContain("Pass");
        expect(await objNewDemoRequest.selectRequestorInSecBUTbl(objData.requestor1)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSaveSecondaryBU()).toContain("Pass");
        
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.verifySubmitBtnIsEnabled()).not.toContain("Pass");
        expect(await objNewDemoRequest.getSubmitBtnTooltip()).toEqual(objData.submitBtnTooltip);//Please add special group in 'Special Group to be Informed' or add atleast one special gorup entry in multi bu demo table.
        
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Previous")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnAddSecondaryBU()).toContain("Pass");
        expect(await objNewDemoRequest.selectSecondaryBUInTable(objData.secBU2)).toContain("Pass");
        expect(await objNewDemoRequest.selectRequestorInSecBUTbl(objData.requestor1)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSaveSecondaryBU()).toContain("Pass");
        
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        
        expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Customer Spec");
        const filePath = path.resolve('./autoItScripts/TestUpload_CustSpec.xlsx');
        const exePath = path.resolve('./autoItScripts/browseFile.exe')
        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath);
        await browser.sleep(10000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Customer Spec")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");

        expect(await objNewDemoRequest.clickWaferStackOption(objData.waferStackOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Wafer Stack");
        const filePath1 = path.resolve('./autoItScripts/TestUpload_WaferStack.xlsx');

        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath1);
        await browser.sleep(10000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Wafer Stack")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");

        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
        sAlertMessage = "Demo Request submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        
        
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain("Pass");
        await browser.sleep(5000);
        expect(await objCommonPage.clickInTableButton(sDemoName, "New Request")).toContain("Pass");
        
        expect(await objCommonPage.verifyAlertHeader("Approval View")).toContain("Pass");
        expect(await objApprovalsPage.selectDemoApproval(objData.demoApprovalStatus)).toContain("Pass");
        expect(await objApprovalsPage.selectPriority(objData.priority)).toContain("Pass");
        
        expect(await objApprovalsPage.setDemoOwner(sLoggedInUser)).toContain("Pass");
        expect(await objApprovalsPage.selectExecutionRisk("Medium")).toContain("Pass"); 
        await objApprovalsPage.clickOnSaveApprovalView();
        sAlertMessage = "Approval Saved Successfully"
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');

        expect(await objAllViewPage.clickInTableCell(sDemoName, "Demo Number")).toContain("Pass");
        expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain("Pass");
        expect(await objDemoDetailsPage.expandSection("Tracker")).toContain("Pass");
        expect(await objDemoDetailsPage.selectDDOptionOnDemoDtlsPage("Customer Engagement", objData.custEngagement)).toContain("Pass");
        expect(await objDemoDetailsPage.selectRYGColourVal("Performance (Spec vs. Actual)", objData.perfRYGColour)).toContain("Pass");
        expect(await objDemoDetailsPage.selectRYGColourVal("CoO Gap (spec vs. Actual)", objData.cooGapRYGColour)).toContain("Pass");
        expect(await objDemoDetailsPage.clickOnToggleField("Onsite Chamber Readiness")).toContain("Pass");
        expect(await objDemoDetailsPage.clickOnToggleField("Additional CIP HW Requirement")).toContain("Pass");

        expect(await objDemoDetailsPage.clickOnCalendarIcon("CIP HW Shipment Target")).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("12", "April", "2021")).toContain("Pass");
        let sCIPHWShipmentTarget = "04/12/2021";
        expect(await objDemoDetailsPage.clickOnCalendarIcon("Schedule to close the DPY Gaps")).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("17", "April", "2021")).toContain("Pass");
        let sScheduleToCloseDYPGaps = "04/17/2021";
        expect(await objDemoDetailsPage.setFieldValInDemoDtlsPage("Risk/Gap Description", objData.riskGapDesc)).toContain("Pass");
        expect(await objDemoDetailsPage.setFieldValInDemoDtlsPage("Risk/Gap Closure Plan", objData.riskGapClosurePlan)).toContain("Pass");
        
        expect(await objDemoDetailsPage.clickOnSubmitDemoDetails()).toContain("Pass");

        sAlertMessage = "Demo Details Submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");

        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
        expect(await objCommonPage.goToColumn("Customer Engagement")).toContain("Pass");
        expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "Customer Engagement", objData.custEngagement)).toContain("Pass");
        expect(await objCommonPage.goToColumn("Performance (Spec vs. Actual)")).toContain("Pass");
        expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "Performance (Spec vs. Actual)", objData.perSpecAct)).toContain("Pass");
        expect(await objCommonPage.goToColumn("CoO Gap (spec vs. Actual)")).toContain("Pass");
        expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "CoO Gap (spec vs. Actual)", objData.cooGapSpecAct)).toContain("Pass");
        expect(await objCommonPage.goToColumn("Onsite Chamber Readiness")).toContain("Pass");
        expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "Onsite Chamber Readiness", "Yes")).toContain("Pass");
        expect(await objCommonPage.goToColumn("Additional CIP HW Requirement")).toContain("Pass");
        expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "Additional CIP HW Requirement", "Yes")).toContain("Pass");
        expect(await objCommonPage.goToColumn("CIP HW Shipment Target")).toContain("Pass");
        expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "CIP HW Shipment Target", sCIPHWShipmentTarget)).toContain("Pass");
        expect(await objCommonPage.goToColumn("Schedule to close the DPY Gaps")).toContain("Pass");
        expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "Schedule to close the DPY Gaps", sScheduleToCloseDYPGaps)).toContain("Pass");

        done();
    });

    it('TC_50 - Verify that user shall be able to submit an external multi BU  demo with Tamba disabled and Special Group demos toggle enabled with BU Owner option selected but special groups involved', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_50");
        console.info(objData);

        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        expect(await objNewDemoRequest.toggleField("Special Group Demo", true)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRadioBtn("BU Owned")).toContain("Pass");
        // expect(await objNewDemoRequest.clickOnDropDown("Special Group to be Informed")).toContain("Pass");

        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_CreateDemo" + iRandomNum;

        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");;
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");

        expect(await objNewDemoRequest.clickOnDropDownOption("Application Segment", objData.appSegment)).toContain("Pass");//DRAM: EUV
        expect(await objNewDemoRequest.clickOnDropDownOption("Device Type", objData.deviceType)).toContain("Pass");//FDSOI
        expect(await objNewDemoRequest.clickOnDropDownOption("AMAT Node", objData.amatNode)).toContain("Pass");

        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnAddSecondaryBU()).toContain("Pass");
    
        expect(await objNewDemoRequest.selectSecondaryBUInTable(objData.secBU1)).toContain("Pass");
        expect(await objNewDemoRequest.selectRequestorInSecBUTbl(objData.requestor1)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSaveSecondaryBU()).toContain("Pass");
        
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.verifySubmitBtnIsEnabled()).not.toContain("Pass");
        expect(await objNewDemoRequest.getSubmitBtnTooltip()).toEqual(objData.submitBtnTooltip);//Please add special group in 'Special Group to be Informed' or add atleast one special gorup entry in multi bu demo table.
        
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Previous")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnAddSecondaryBU()).toContain("Pass");
        expect(await objNewDemoRequest.selectSecondaryBUInTable(objData.secBU2)).toContain("Pass");
        expect(await objNewDemoRequest.selectRequestorInSecBUTbl(objData.requestor1)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSaveSecondaryBU()).toContain("Pass");
        
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        
        expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Customer Spec");
        const filePath = path.resolve('./autoItScripts/TestUpload_CustSpec.xlsx');
        const exePath = path.resolve('./autoItScripts/browseFile.exe')
        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath);
        await browser.sleep(7000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Customer Spec")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");

        expect(await objNewDemoRequest.clickWaferStackOption(objData.waferStackOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Wafer Stack");
        const filePath1 = path.resolve('./autoItScripts/TestUpload_WaferStack.xlsx');

        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath1);
        await browser.sleep(7000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Wafer Stack")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");

        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
        sAlertMessage = "Demo Request submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        
        
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain("Pass");
        await browser.sleep(5000);
        expect(await objCommonPage.clickInTableButton(sDemoName, "New Request")).toContain("Pass");
        
        expect(await objCommonPage.verifyAlertHeader("Approval View")).toContain("Pass");
        expect(await objApprovalsPage.selectDemoApproval(objData.demoApprovalStatus)).toContain("Pass");
        expect(await objApprovalsPage.selectPriority(objData.priority)).toContain("Pass");
        
        expect(await objApprovalsPage.setDemoOwner(sLoggedInUser)).toContain("Pass");
        expect(await objApprovalsPage.selectExecutionRisk("Medium")).toContain("Pass"); 
        await objApprovalsPage.clickOnSaveApprovalView();
        sAlertMessage = "Approval Saved Successfully"
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        
        // sDemoName = "TestDemo_2536";
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');

        expect(await objAllViewPage.clickInTableCell(sDemoName, "Demo Number")).toContain("Pass");
        expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain("Pass");
        expect(await objDemoDetailsPage.expandSection("Shipment Tracking Info")).toContain("Pass");
        expect(await objDemoDetailsPage.setFieldValInDemoDtlsPage("Shipping Information", objData.shippingInfo)).toContain("Pass");
        expect(await objDemoDetailsPage.clickOnAddShippingInfo()).toContain("Pass");
        let sShippingLink = "http://" + objData.shippingInfo;
        // await objDemoDetailsPage.getNewlyAddedShippingLink().then(function(sText){sShippingLink = sText});
        expect(await objDemoDetailsPage.clickOnToggleField("Shipping Details")).toContain("Pass");
        expect(await objDemoDetailsPage.setFreightFwdr(objData.freightFwdr)).toContain("Pass");
        expect(await objDemoDetailsPage.setTrackingNumber(objData.trackingNum)).toContain("Pass");
        expect(await objDemoDetailsPage.clickSaveToSaveTblChanges()).toContain("Pass");
        
        expect(await objDemoDetailsPage.clickOnSubmitDemoDetails()).toContain("Pass");

        sAlertMessage = "Demo Details Submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        

        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
        expect(await objCommonPage.goToColumn("Shipping Information")).toContain("Pass");
        expect(await objAllViewPage.clickInTableCell(sDemoName, "Shipping Information")).toContain("Pass");
        expect(await objAllViewPage.clickCancelOnEditPopUp()).toContain("Pass");
        expect(await objAllViewPage.clickInTableCell(sDemoName, "Shipping Information")).toContain("Pass");
        // expect(await objAllViewPage.clickCancelOnEditPopUp()).toContain("Pass");
        await browser.sleep(5000);
        expect(await objCommonPage.verifyAlertHeader("Edit")).toContain("Pass");
        expect(await objAllViewPage.verifyShippingLinkOnEditPopUp(sShippingLink)).toContain("Pass");
        expect(await objAllViewPage.verifyShippingDtlsOnEditPopUp("Freight Forwarder", objData.freightFwdr)).toContain("Pass");
        expect(await objAllViewPage.verifyShippingDtlsOnEditPopUp("Tracking Number", objData.trackingNum)).toContain("Pass");
        expect(await objAllViewPage.clickCancelOnEditPopUp()).toContain("Pass");

        done();
    });

    it('TC_51 - Verify that user shall be able to connect Internal demo with TAMBA', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_51");
        console.info(objData);

        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        
        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestInternalDemo_" + iRandomNum;

        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        
        

        expect(await objNewDemoRequest.toggleField('Internal Demo', true)).toContain("Pass");
        expect(await objNewDemoRequest.setInternalAccount(objData.internalAccount)).toContain("Pass");
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.setInternalAccountOwner(sLoggedInUser)).toContain("Pass");

        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustSpecFieldIsMandatory()).not.toContain("Pass");

        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
        sAlertMessage = "Demo Request submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");

        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain("Pass");
        await browser.sleep(5000);
        expect(await objCommonPage.clickInTableButton(sDemoName, "New Request")).toContain("Pass");
        
        expect(await objCommonPage.verifyAlertHeader("Approval View")).toContain("Pass");
        expect(await objApprovalsPage.selectDemoApproval(objData.demoApprovalStatus)).toContain("Pass");
        expect(await objApprovalsPage.selectPriority(objData.priority)).toContain("Pass");
        
        expect(await objApprovalsPage.setDemoOwner(sLoggedInUser)).toContain("Pass");
        expect(await objApprovalsPage.selectExecutionRisk("Medium")).toContain("Pass"); 
        await objApprovalsPage.clickOnSaveApprovalView();
        sAlertMessage = "Approval Saved Successfully"
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");

        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');

        expect(await objAllViewPage.clickInTableCell(sDemoName, "Demo Number")).toContain("Pass");
        expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain("Pass");
        expect(await objDemoDetailsPage.selectDDOptionOnDemoDtlsPage("Execution Risk", objData.execRisk)).toContain("Pass");

        expect(await objDemoDetailsPage.clickOnSubmitDemoDetails()).toContain("Pass");

        sAlertMessage = "Demo Details Submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        // sDemoName = "TestInternalDemo_1288";

        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
        expect(await objCommonPage.goToColumn("Current Execution Risk")).toContain("Pass");
        expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "Current Execution Risk", objData.expCurExeRisk)).toContain("Pass");
        let sDemoNumber = await objCommonPage.getTableCellValue("Demo Number", sDemoName);
        expect(await objCommonPage.goToColumn("Wafer Location")).toContain("Pass");
        
        expect(await objAllViewPage.clickInTableCell(sDemoName, "Wafer Location")).toContain("Pass");
        expect(await objAllViewPage.selectOptionFromDDInTableColumn("Wafer Location", objData.waferLoc)).toContain("Pass");
        await browser.waitForAngularEnabled(false);
        await browser.refresh();
        await browser.sleep(5000);
        await browser.waitForAngularEnabled(true);
        // expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
        // expect(await objCommonPage.goToColumn("Current Execution Risk")).toContain("Pass");
        // await objAllViewPage.clickInTableCell(sDemoName, "BU");
        // await objCommonPage.waitTillInvisibilityOfLoadingIcon();
        // expect(await objAllViewPage.clickInTableCell(sDemoName, "BU")).toContain("Pass");

        expect(await objCommonPage.clickInTableButton(sDemoName, "ACL-Approved")).toContain("Pass");
        
        expect(await objCommonPage.verifyAlertHeader("Approval View")).toContain("Pass");
        expect(await objApprovalsPage.selectDemoApproval(objData.demoApprovalStatus1)).toContain("Pass");
        // expect(await objApprovalsPage.selectPriority(objData.priority)).toContain("Pass");
        
        // expect(await objApprovalsPage.setDemoOwner(sLoggedInUser)).toContain("Pass");
        // expect(await objApprovalsPage.selectExecutionRisk("Medium")).toContain("Pass"); 
        await objApprovalsPage.clickOnSaveApprovalView();
        sAlertMessage = "Approval Saved Successfully"
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        // let sDemoNumber = "Etch-051506"
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_CreateDemo" + iRandomNum;

        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");

        expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
        expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
        await objNewDemoRequest.verifyTambaDtlsOnNewDemoForm();  

        expect(await objNewDemoRequest.toggleField("Repeat Demo", true)).toContain("Pass");
        expect(await objNewDemoRequest.setRepeatDemoID(sDemoNumber)).toContain("Pass");

        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        // expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        // expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
        // expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        // expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        
        expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Customer Spec");
        const filePath = path.resolve('./autoItScripts/TestUpload_CustSpec.xlsx');
        const exePath = path.resolve('./autoItScripts/browseFile.exe')
        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath);
        await browser.sleep(10000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Customer Spec")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");

        expect(await objNewDemoRequest.clickWaferStackOption(objData.waferStackOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Wafer Stack");
        const filePath1 = path.resolve('./autoItScripts/TestUpload_WaferStack.xlsx');

        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath1);
        await browser.sleep(10000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Wafer Stack")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Previous")).toContain("Pass");
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
        sAlertMessage = "Demo Request submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");

        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain("Pass");
        await browser.sleep(5000);
        expect(await objCommonPage.clickInTableButton(sDemoName, "New Request")).toContain("Pass");
        
        expect(await objCommonPage.verifyAlertHeader("Approval View")).toContain("Pass");
        expect(await objApprovalsPage.selectDemoApproval(objData.demoApprovalStatus)).toContain("Pass");
        expect(await objApprovalsPage.selectPriority(objData.priority)).toContain("Pass");
        
        expect(await objApprovalsPage.setDemoOwner(sLoggedInUser)).toContain("Pass");
        expect(await objApprovalsPage.selectExecutionRisk("Medium")).toContain("Pass"); 
        await objApprovalsPage.clickOnSaveApprovalView();
        sAlertMessage = "Approval Saved Successfully"
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");

        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');

        expect(await objAllViewPage.clickInTableCell(sDemoName, "Demo Number")).toContain("Pass");
        expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain("Pass");
        expect(await objDemoDetailsPage.selectDDOptionOnDemoDtlsPage("Execution Risk", objData.execRisk1)).toContain("Pass");

        expect(await objDemoDetailsPage.clickOnSubmitDemoDetails()).toContain("Pass");

        sAlertMessage = "Demo Details Submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");

        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
        expect(await objCommonPage.goToColumn("Current Execution Risk")).toContain("Pass");
        expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "Current Execution Risk", objData.expCurExeRisk1)).toContain("Pass");

        done();
    });

    it('TC_54 - Verify that an email notification sent to all the secondary BU user when an additional BU is added in secondary BU list after submitting the demo request', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_54");
        console.info(objData);
        
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        
        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_CreateDemo" + iRandomNum;

        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");;
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");

        expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
        
        expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
        expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
        await objNewDemoRequest.verifyTambaDtlsOnNewDemoForm();

        expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnAddSecondaryBU()).toContain("Pass");
    
        expect(await objNewDemoRequest.selectSecondaryBUInTable(objData.secBU1)).toContain("Pass");
        expect(await objNewDemoRequest.selectRequestorInSecBUTbl(objData.requestor1)).toContain("Pass");
    
        expect(await objNewDemoRequest.clickOnSaveSecondaryBU()).toContain("Pass");

        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        
        expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Customer Spec");
        const filePath = path.resolve('./autoItScripts/TestUpload_CustSpec.xlsx');
        const exePath = path.resolve('./autoItScripts/browseFile.exe')
        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath);
        await browser.sleep(10000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Customer Spec")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");

        expect(await objNewDemoRequest.clickWaferStackOption(objData.waferStackOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Wafer Stack");
        const filePath1 = path.resolve('./autoItScripts/TestUpload_WaferStack.xlsx');
        const exePath1 = path.resolve('./autoItScripts/browseFile.exe')
        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath1);
        await browser.sleep(10000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Wafer Stack")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
        
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
        sAlertMessage = "Demo Request submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        
        // sDemoName = "TestDemo_1013";

        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");
        expect(await objCommonPage.searchRequest(sDemoName)).toContain("Pass");
        // await browser.sleep(5000);
        expect(await objCommonPage.goToColumn("Demo Type")).toContain("Pass");
        expect(await objAllViewPage.clickInTableCell(sDemoName, "Demo Type")).toContain("Pass");
                
        expect(await objCommonPage.verifyAlertHeader("Edit")).toContain("Pass");

        expect(await objAllViewPage.clickAddNewBtnOnEditPopUp()).toContain("Pass");
        expect(await objAllViewPage.selectSecondaryBUInTableOnEditPopUp(objData.secBU2)).toContain("Pass");
        expect(await objNewDemoRequest.selectRequestorInSecBUTbl(objData.requestor1)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSaveSecondaryBU()).toContain("Pass");
        expect(await objAllViewPage.clickOnSave()).toContain("Pass");
        // await objAllViewPage.clickInTableCell(sDemoName, "BU");
        // await objCommonPage.waitTillInvisibilityOfLoadingIcon();
        expect(await objAllViewPage.clickInTableCell(sDemoName, "Demo Type")).toContain("Pass");
                
        expect(await objCommonPage.verifyAlertHeader("Edit")).toContain("Pass");
        expect(await objAllViewPage.verifySecondaryBUDtlsOnEditPopUp(objData.secBU2, objData.requestor1)).toContain("Pass");
        expect(await objAllViewPage.clickCancelOnEditPopUp()).toContain("Pass");

        done();
    });

    it('TC_55 - Verify that when primary demo gets approved then requester field of drafted secondary demo shall be editable', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_55");
        console.info(objData);
        
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();}); 
        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        
        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_CreateDemo" + iRandomNum;

        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");;
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");

        expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
        
        expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
        expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
        await objNewDemoRequest.verifyTambaDtlsOnNewDemoForm();

        expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnAddSecondaryBU()).toContain("Pass");
    
        expect(await objNewDemoRequest.selectSecondaryBUInTable(objData.secBU1)).toContain("Pass");
        expect(await objNewDemoRequest.selectRequestorInSecBUTbl(objData.requestor1)).toContain("Pass");
    
        expect(await objNewDemoRequest.clickOnSaveSecondaryBU()).toContain("Pass");

        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        
        expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Customer Spec");
        const filePath = path.resolve('./autoItScripts/TestUpload_CustSpec.xlsx');
        const exePath = path.resolve('./autoItScripts/browseFile.exe')
        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath);
        await browser.sleep(10000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Customer Spec")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");

        expect(await objNewDemoRequest.clickWaferStackOption(objData.waferStackOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Wafer Stack");
        const filePath1 = path.resolve('./autoItScripts/TestUpload_WaferStack.xlsx');
        const exePath1 = path.resolve('./autoItScripts/browseFile.exe')
        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath1);
        await browser.sleep(10000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Wafer Stack")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
        
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
        sAlertMessage = "Demo Request submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        
        
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain("Pass");
        await browser.sleep(5000);
        expect(await objCommonPage.clickInTableButton(sDemoName, "New Request")).toContain("Pass");
        
        expect(await objCommonPage.verifyAlertHeader("Approval View")).toContain("Pass");
        expect(await objApprovalsPage.selectDemoApproval(objData.demoApprovalStatus)).toContain("Pass");
        expect(await objApprovalsPage.selectPriority(objData.priority)).toContain("Pass");
        
        expect(await objApprovalsPage.setDemoOwner(sLoggedInUser)).toContain("Pass");
        // expect(await objApprovalsPage.selectExecutionRisk("Medium")).toContain("Pass"); 
        await objApprovalsPage.clickOnSaveApprovalView();
        sAlertMessage = "Approval Saved Successfully"
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        // sDemoName = "TestDemo_8890";
        await browser.waitForAngularEnabled(false);
        //Open application Url
        await objHomePage.openApplication('/');  
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameSecondaryBURequestor)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordSecondaryBURequestor)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass"); 
        expect(await objHomePage.selectMenuOption("Requests", "My Draft Request")).toContain("Pass");
        let sSearchDemo = objData.secBU1 + " " + sDemoName;
        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');  
        expect(await objCommonPage.clickInTheTableCell('Demo Number',sDemoName)).toContain('Pass');

        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectRequestor(objData.requestor2)).toContain("Pass");
        // expect(await objNewDemoRequest.clickOnDropDownOption("Application Segment", "Gate")).toContain("Pass");
        // expect(await objNewDemoRequest.clickOnDropDownOption("AMAT Node", "100-130p")).toContain("Pass");
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Save As Draft")).toContain("Pass");
        // await browser.sleep(10000);
        // // expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
        sAlertMessage = "Request is Saved Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");


        done();
    });
    it('TC_57 - Verify that Wafer type and Wafer Count fields are modified on customer spec page in mydemo application', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_57");
        console.info(objData);

        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_CreateDemo" + iRandomNum;

        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");;
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");

        expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
        
        expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
        expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
        await objNewDemoRequest.verifyTambaDtlsOnNewDemoForm();

        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");//Full wafer
        expect(await objNewDemoRequest.selectWaferSize(objData.waferSize)).toContain("Pass");
        expect(await objNewDemoRequest.setNoOfWafersForWaferType("Customer", "Blanket", objData.noOfCustomerBlanketWafer)).toContain("Pass");
        expect(await objNewDemoRequest.setNoOfWafersForWaferType("AMAT", "Blanket", objData.noOfAMATBlanketWafer)).toContain("Pass");
        expect(await objNewDemoRequest.setNoOfWafersForWaferType("Customer", "Pattern", objData.noOfCustomerPatternWafer)).toContain("Pass");
        expect(await objNewDemoRequest.setNoOfWafersForWaferType("AMAT", "Pattern", objData.noOfAMATPatternWafer)).toContain("Pass");
        
        expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Customer Spec");
        const filePath = path.resolve('./autoItScripts/TestUpload_CustSpec.xlsx');
        const exePath = path.resolve('./autoItScripts/browseFile.exe')
        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath);
        await browser.sleep(10000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Customer Spec")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
        //let sTodayDateCust = await objCommonPage.getCurrentDate("mm/dd/yyyy hh:mins");
        //console.log(sTodayDateCust);
        //expect(await objNewDemoRequest.getDateTimeAgainstDocInField("Customer Spec", "TestUpload_CustSpec.xlsx")).toEqual(sTodayDateCust);

        expect(await objNewDemoRequest.clickWaferStackOption(objData.waferStackOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Wafer Stack");
        const filePath1 = path.resolve('./autoItScripts/TestUpload_WaferStack.xlsx');

        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath1);
        await browser.sleep(10000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Wafer Stack")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
        //let sTodayDateWaferStack = await objCommonPage.getCurrentDate("mm/dd/yyyy hh:mins");
        //console.log(sTodayDateWaferStack);
        //expect(await objNewDemoRequest.getDateTimeAgainstDocInField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toEqual(sTodayDateWaferStack);

        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
        sAlertMessage = "Demo Request submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        // sDemoName = "TestDemo_9078"
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");
        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
        expect(await objCommonPage.goToColumn("Wafer Type")).toContain("Pass");
        expect(await objCommonPage.clickInTheTableCell("Wafer Type",sDemoName)).toContain("Pass");
        await browser.sleep(5000);
        expect(await objCommonPage.verifyAlertHeader("Edit")).toContain("Pass");
        expect(await objAllViewPage.verifyWaferTypeTableDtlsOnEditPopUp("Customer", "Blanket", objData.noOfCustomerBlanketWafer)).toContain("Pass");
        expect(await objAllViewPage.verifyWaferTypeTableDtlsOnEditPopUp("AMAT", "Blanket", objData.noOfAMATBlanketWafer)).toContain("Pass");
        expect(await objAllViewPage.verifyWaferTypeTableDtlsOnEditPopUp("Customer", "Pattern", objData.noOfCustomerPatternWafer)).toContain("Pass");
        expect(await objAllViewPage.verifyWaferTypeTableDtlsOnEditPopUp("AMAT", "Pattern", objData.noOfAMATPatternWafer)).toContain("Pass");
        expect(await objAllViewPage.clickCancelOnEditPopUp()).toContain("Pass");
        done();
    });
	
	it('TC_60 - Verify that Managed Account field shall be added as new field on Opportunity Info page and Demo Details page', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_60");
        console.info(objData);

        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.verifyFieldIsPresent("Managed Account")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnDropDownOption("Managed Account", objData.mngdAcc1)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnDropDownOption("Account", objData.account)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnDropDownOption("Managed Account", objData.mngdAcc2)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnDropDownOption("Account", objData.account)).not.toContain("Pass");
        expect(await objHomePage.clickOnMenuOption("Home")).toContain("Pass");
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_CreateDemo" + iRandomNum;

        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
        expect(await objNewDemoRequest.verifyValInField("Managed Account", objData.mngdAcc1)).toContain("Pass");
        // expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");

        expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
        
        expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
        expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
        await objNewDemoRequest.verifyTambaDtlsOnNewDemoForm();
        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
        
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Customer Spec");
        const filePath = path.resolve('./autoItScripts/TestUpload_CustSpec.xlsx');
        const exePath = path.resolve('./autoItScripts/browseFile.exe')
        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath);
        cp.execSync(exePath + ' ' + filePath);
        await browser.sleep(10000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Customer Spec")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");

        expect(await objNewDemoRequest.clickWaferStackOption(objData.waferStackOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Wafer Stack");
        const filePath1 = path.resolve('./autoItScripts/TestUpload_WaferStack.xlsx');

        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath1);
        cp.execSync(exePath + ' ' + filePath1);
        await browser.sleep(10000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Wafer Stack")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
        // expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Previous")).toContain("Pass");
        // expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
        // await browser.sleep(60000);
        sAlertMessage = "Demo Request submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
       
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");

        expect(await objCommonPage.searchRequest(sDemoName)).toContain("Pass");
        await browser.sleep(5000);
        expect(await objCommonPage.clickInTableButton(sDemoName, "New Request")).toContain("Pass");
        
        expect(await objCommonPage.verifyAlertHeader("Approval View")).toContain("Pass");
        expect(await objApprovalsPage.selectDemoApproval(objData.demoApprovalStatus)).toContain("Pass");
        expect(await objApprovalsPage.selectPriority(objData.priority)).toContain("Pass");
        
        expect(await objApprovalsPage.setDemoOwner(sLoggedInUser)).toContain("Pass");
        expect(await objApprovalsPage.selectExecutionRisk("Medium")).toContain("Pass"); 
        await objApprovalsPage.clickOnSaveApprovalView();
        sAlertMessage = "Approval Saved Successfully"
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        

        expect(await objHomePage.selectMenuOption("My Action", "My Demo Tasks")).toContain("Pass");
        expect(await objCommonPage.searchRequest(sDemoName)).toContain("Pass");
        expect(await objCommonPage.clickInTheTableCell("Demo Number", sDemoName)).toContain("Pass");
        expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain("Pass");
        expect(await objDemoDetailsPage.getFieldVal("Managed Account")).toEqual(objData.mngdAcc1);

        done();
    });

    it('TC_61 - Verify that After making TAMBA toggle button Yes the some of the field labels are renamed', async(done)=>{
        let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_61");
        console.info(objData);
        
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
        expect(await objNewDemoRequest.verifyFieldIsPresent("TAMBA Name")).toContain("Pass");
        expect(await objNewDemoRequest.verifyFieldNotPresent("TAMBA")).toContain("Pass");
        expect(await objNewDemoRequest.verifyFieldIsPresent("Application Segment")).toContain("Pass");
        expect(await objNewDemoRequest.verifyFieldNotPresent("Application Field")).toContain("Pass");
        expect(await objNewDemoRequest.verifyFieldIsPresent("AMAT Node")).toContain("Pass");
        expect(await objNewDemoRequest.verifyFieldNotPresent("Internal Tech Node")).toContain("Pass");
        expect(await objNewDemoRequest.verifyFieldIsPresent("Account")).toContain("Pass");
        expect(await objNewDemoRequest.verifyFieldNotPresent("Choose Customer")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
        expect(await objNewDemoRequest.verifyTAMBASearchPopUpDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.getTblHrdsOnTAMBASearchPopUp()).toEqual(objData.tambaSearchTblHdrs);
        expect(await objNewDemoRequest.clickCancelOnTAMBASearchPopUp()).toContain("Pass");

        done();
    });
});