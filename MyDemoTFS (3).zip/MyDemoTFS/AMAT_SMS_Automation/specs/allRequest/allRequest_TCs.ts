import {browser, element, ExpectedConditions, by} from 'protractor';
import {homePage} from '../../pages/homePage.po';
import { commonPage } from '../../pages/commonPage.po';
import { newDemoRequest } from '../../pages/newDemoRequest.po';
import { myDraftRequestPage } from '../../pages/myDraftRequestPage.po';
import { myDemoRequestPage } from '../../pages/myDemoRequestPage.po';
import { dataProvider} from "../../data/dataProvider";
import { loginPage } from '../../pages/loginPage.po';
import { allViewPage } from '../../pages/allViewPage.po';
import { allRequestPage } from '../../pages/allRequestPage.po';
import { win32 } from 'path';
import * as cp from 'child_process';
import { demoDetailsPage } from '../../pages/demoDetailsPage.po';



describe('All Request Test cases', () => {
    const path = win32;
    let objHomePage:homePage;
    let objNewDemoRequest:newDemoRequest;
    let objMyDraftRequest:myDraftRequestPage;
    let objCommonPage: commonPage;
    let objMyDemoRequest: myDemoRequestPage;
    let objLoginPage:loginPage;
    let objAllViewPage:allViewPage;
    let objAllRequestPage: allRequestPage;
    let objDemoDetailsPage: demoDetailsPage;
    
    let objLoginData = dataProvider.getJsonData("./data/login.json", "login");
    let sDemoName;
    let sAlertMessage = "";

    beforeEach(async () => {
        objHomePage = new homePage();
        objNewDemoRequest = new newDemoRequest();
        objMyDraftRequest = new myDraftRequestPage();
        objCommonPage = new commonPage();
        objMyDemoRequest = new myDemoRequestPage();
        objLoginPage = new loginPage();
        objAllViewPage = new allViewPage();
        objAllRequestPage = new allRequestPage();
        objDemoDetailsPage = new demoDetailsPage;
       
        await browser.waitForAngularEnabled(false);
        //Open application Url
        await objHomePage.openApplication('/');        
    });

    afterEach(() => {
        
    });
it('TC_Pre-Requisite.', async(done)=>{
        let objData = dataProvider.getJsonData("./data/allRequest.json", "TC_Pre-Requisite");
        console.log(objData);
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");
        await browser.waitForAngularEnabled(true);
        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
        //select menu option
        expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
       
        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_" + iRandomNum;
        console.log(sDemoName);
 
        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
       
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
        expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
        
        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        let sLoggedInUser;
        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
        
        //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
        expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
        expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
        expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
        expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");;
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
        expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');
        done();
});   
it('TC_02-"Verify that all the fields except Demo Approval & Justication are hidden while updating the status to reject, or on hold from New Request and those fields shall be made as non-mandatory.', async(done)=>{
    let objData = dataProvider.getJsonData("./data/allRequest.json", "TC_02");
    console.log(objData);
    //Login My Demo application as BU Super User
    expect(await objLoginPage.setUserName(objLoginData.userNameBUSuperUser)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordBUSuperUser)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")
    //User is on All Request Page
    expect(await objHomePage.selectMenuOption("Approvals", "All Requests")).toContain('Pass');
    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    //Search or the demo which is having status as new request and selecting it's status as "BCL - On Hold"
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.verifyDemoStatusInGrid(sDemoName,"New Request")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Name",sDemoName)).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Demo Approval")).not.toContain('Pass');
    expect(await objAllViewPage.clickFieldOnThePopUp("Demo Approval")).toContain('Pass');
    expect(await objAllViewPage.selectOptionsFromDDOnPopUp("Demo Approval","BCL - On Hold")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Justification")).not.toContain('Pass');
    expect(await objAllViewPage.setInputOnPopUp("Justification","Testing for BCL-hold")).toContain('Pass');
    //verifying field is mandate/disabled or not in the same method
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Demo Number")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Demo Name")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Wafer Status")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Priority")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Demo Owner")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Co-Owner")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("CAT/RAT Manager")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Execution Risk")).toContain('Pass');
    //selecting it's status as "Rejected"
    expect(await objAllViewPage.selectOptionsFromDDOnPopUp("Demo Approval","Rejected")).toContain('Pass');
    expect(await objAllViewPage.setInputOnPopUp("Justification","Testing for rejected")).toContain('Pass');
    //verifying field is mandate/disabled or not in the same method
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Demo Number")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Demo Name")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Wafer Status")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Priority")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Demo Owner")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Co-Owner")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("CAT/RAT Manager")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Execution Risk")).toContain('Pass');
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');
    done();
});
it('TC_06-"Verify that user shall not be able to submit the changes on approval screen without filling the mandatory fields.', async(done)=>{
    //Login My Demo application as BU Super User
    expect(await objLoginPage.setUserName(objLoginData.userNameBUSuperUser)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordBUSuperUser)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")
    //User is on All Request Page
    expect(await objHomePage.selectMenuOption("Approvals", "All Requests")).toContain('Pass');
    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    //Search or the demo which is having status as new request and change status to BCL-on hold
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.verifyDemoStatusInGrid(sDemoName,"New Request")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Name",sDemoName)).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","BCL - On Hold")).toContain('Pass');

    //verifying field is mandate/disabled or not
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Justification")).not.toContain('Pass');
    //checking Justification is empty or not
    expect(await objAllViewPage.verifyCommentIsEmptyOnApprovalPopUp()).toContain('Pass');
    //checking save btn is disabled or not
    expect(await objAllViewPage.verifySaveBtnIsDisabledOnPopUp()).toContain('Pass');
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');
    done();
});
it('TC_01-"Verify that user shall be able to approve the new submitted demo.', async(done)=>{
    let objData = dataProvider.getJsonData("./data/allRequest.json", "TC_01");
    console.log(objData);
    //Login My Demo application as BU Super User
    expect(await objLoginPage.setUserName(objLoginData.userNameBUSuperUser)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordBUSuperUser)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")
    //User is on All Request Page
    expect(await objHomePage.selectMenuOption("Approvals", "All Requests")).toContain('Pass');
    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    //Search or the demo which is having status as new request and make it approved 
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.verifyDemoStatusInGrid(sDemoName,"New Request")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Name",sDemoName)).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
    expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objData.demoOwner)).toContain('Pass');
    expect(await objAllRequestPage.selectRATCATManager("CAT/RAT Manager",objData.catRatManager)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    done();
});
it('TC_03-"Verify that all the fields except Demo Approval & Justication are hidden while updating the status to Cancel, or on hold from Approved Request and those fields shal be made as non-mandatory.', async(done)=>{
    //Login My Demo application as BU Super User
    expect(await objLoginPage.setUserName(objLoginData.userNameBUSuperUser)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordBUSuperUser)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")
    //User is on All Request Page
    expect(await objHomePage.selectMenuOption("Approvals", "All Requests")).toContain('Pass');
    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    //Search or the demo which is having status approved 
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.verifyDemoStatusInGrid(sDemoName,"ACL-Approved")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Name",sDemoName)).toContain('Pass');
     //checking for cancel status
   console.log("checking for cancelled status")
   expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","Cancelled")).toContain('Pass');
   expect(await objAllViewPage.clickFieldOnThePopUp("Priority")).toContain("Pass");
   //verifying field is mandate/disabled or not 
   expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Demo Number")).toContain('Pass');
   expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Demo Name")).toContain('Pass');
   expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Wafer Status")).toContain('Pass');
   expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Demo Approval")).not.toContain('Pass');
   expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Priority")).toContain('Pass');
   expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Demo Owner")).toContain('Pass');
   expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Co-Owner")).toContain('Pass');
   expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("CAT/RAT Manager")).toContain('Pass');
   expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Execution Risk")).toContain('Pass');
   expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("IO/Cost Center")).toContain('Pass');
   expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Justification")).not.toContain('Pass');
   //checking for BCL-on Hold status
   console.log("checking for BCL-on Hold status")
   expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","BCL - On Hold")).toContain('Pass');
   //verifying field is mandate/disabled or not 
   expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Demo Number")).toContain('Pass');
   expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Demo Name")).toContain('Pass');
   expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Wafer Status")).toContain('Pass');
   expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Demo Approval")).not.toContain('Pass');
   expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Priority")).toContain('Pass');
   expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Demo Owner")).toContain('Pass');
   expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Co-Owner")).toContain('Pass');
   expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("CAT/RAT Manager")).toContain('Pass');
   expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Execution Risk")).toContain('Pass');
   expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("IO/Cost Center")).toContain('Pass');
   expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Justification")).not.toContain('Pass');
   expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');
   done();
});
it('TC_07-"Wafer status is added to Approval pop up for approved requests',async(done)=>{
    let objData = dataProvider.getJsonData("./data/allRequest.json", "TC_07");
    console.log(objData);
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameBUSuperUser)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordBUSuperUser)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

    //Go to All view and select the wafer location
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objCommonPage.goToColumn("Wafer Location")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Wafer Location",sDemoName)).toContain('Pass');
    expect(await objCommonPage.selectOptionFromDDInTableColumn("Wafer Location",objData.waferLocation)).toContain('Pass');


    //click on approval and verify submenu header's
    expect(await objHomePage.clickOnMenuOption("Approvals")).toContain('Pass');
    expect(await objHomePage.getSubMenuList("Approvals")).toContain(objData.headerLabelList);

   //go to all requset page and verify wafer status is present on the approval pop up or not
    expect(await objHomePage.clickOnSubMenuOption("All Requests")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.verifyDemoStatusInGrid(sDemoName,"ACL-Approved")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Name",sDemoName)).toContain('Pass');
    expect(await objAllRequestPage.verifyLabelIsPresent("Wafer Status")).toContain('Pass');
    expect(await objAllViewPage.verifyFieldIsDisabledOnPopUp("Wafer Status")).toContain('Pass');
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');
    done();
});
it('TC_08-"Verify that All Requests screen will have status dropdown and search feautures added to it',async(done)=>{
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameBUSuperUser)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordBUSuperUser)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

    //Go to All Request and verify Status DD 
    expect(await objHomePage.selectMenuOption("Approvals", "All Requests")).toContain('Pass');
    expect(await objCommonPage.verifyStatusDDIsPresentWithDefVal("")).toContain('Pass');

    console.log("Default Grid View before entering Search text");
    await objCommonPage.getTheLatestDemoNm();
    //Search Entred
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.getSearchResults(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.clearSearchText()).toContain('Pass');
    expect(await objCommonPage.clickOnSearch()).toContain('Pass');
    console.log("Default Grid View After Clearing Entered Search Text");
    await objCommonPage.getTheLatestDemoNm(); 
    done();
});
it('TC_Pre-Requisite-Create Demo Uploading Documents',async(done)=>{
    let objData = dataProvider.getJsonData("./data/allRequest.json", "TC_Pre-Requisite_1");
    console.log(objData);
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    //Create a new demo by uploading wafer stack and CustSpec Documents
    expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
    expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
   
    var iRandomNum = Math.floor(1000 + Math.random() * 9000);
    sDemoName = "TestDemo_" + iRandomNum;
    console.log(sDemoName);

    expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
    expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
   
    expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
    expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
    
    expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
    expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
    expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
    expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
    expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
    await objNewDemoRequest.clickOnBrowseButtonAgainstField("Customer Spec");
    const filePath = path.resolve('./autoItScripts/TestUpload_CustSpec.xlsx');
    const exePath = path.resolve('./autoItScripts/browseFile.exe')
    //await browser.sleep(5000);
    cp.execSync(exePath + ' ' + filePath);
    await browser.sleep(5000);
    expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
    expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Customer Spec")).toContain("Pass");
    expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
    expect(await objNewDemoRequest.verifyChkboxStatusAgainstField("Customer Spec", "Upload", "true")).toContain("Pass");
    let sTodayDateCust = await objCommonPage.getCurrentDate("mm/dd/yyyy hh:mins");
    console.log(sTodayDateCust);
    expect(await objNewDemoRequest.verifyDateTimeAgainstField("Customer Spec")).toContain(sTodayDateCust);

    expect(await objNewDemoRequest.clickWaferStackOption(objData.waferStackOption)).toContain("Pass");
    await objNewDemoRequest.clickOnBrowseButtonAgainstField("Wafer Stack");
    const filePath1 = path.resolve('./autoItScripts/TestUpload_WaferStack.xlsx');
    //await browser.sleep(5000);
    cp.execSync(exePath + ' ' + filePath1);
    await browser.sleep(5000);
    expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
    expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Wafer Stack")).toContain("Pass");
    expect(await objNewDemoRequest.verifyChkboxStatusAgainstField("Wafer Stack", "Upload", "true")).toContain("Pass");
    expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
    let sTodayDateWafer = await objCommonPage.getCurrentDate("mm/dd/yyyy hh:mins");
    console.log(sTodayDateWafer);
    expect(await objNewDemoRequest.verifyDateTimeAgainstField("Wafer Stack")).toContain(sTodayDateWafer);
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
    expect(await objCommonPage.clickOnOkBtnOnPopUp()).toContain('Pass');
    done();
});
it('TC_05-"Verify that If Risk is completed and wafer location is not updated to either “In Transit to Account” , “In Transit to Customer”, "No Customer Wafer" or "Customer Hand Carried" then approval screen shall be freezed with the message (System will not allow to edit any field until the Wafers location is In Transit to Account or customer  or Customer Hand Carried or No customer wafer and Risk is updated to completed) in the top.',async(done)=>{
    let objData = dataProvider.getJsonData("./data/allRequest.json", "TC_05");
    console.log(objData);
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameBUSuperUser)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordBUSuperUser)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    //Go to All Request Page and Approve the Newly created Demo
    expect(await objHomePage.selectMenuOption("Approvals", "All Requests")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass')  
    expect(await objAllViewPage.verifyDemoStatusInGrid(sDemoName,"New Request")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Name",sDemoName)).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
    expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objData.demoOwner)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

    //Go to All view Page and  Change the Exceution Risk to complete and update wafer location “In Transit to Account” , “In Transit to Customer”, "No Customer Wafer" or "Customer Hand Carried"
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objCommonPage.goToColumn("Current Execution Risk")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Current Execution Risk",sDemoName)).toContain('Pass');
    expect(await objCommonPage.selectOptionFromDDInTableColumn("Current Execution Risk","Complete")).toContain('Pass');

    expect(await objCommonPage.goToColumn("Wafer Location")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Wafer Location",sDemoName)).toContain('Pass');
    expect(await objCommonPage.selectOptionFromDDInTableColumn("Wafer Location",objData.waferLocation)).toContain('Pass');

    //Go to all request page and clicked on the demo and verify fresszed message which will only display for wafer loctaion other then.
    expect(await objHomePage.selectMenuOption("Approvals", "All Requests")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.verifyDemoStatusInGrid(sDemoName,"ACL-Approved")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCellUsingJavaScript("Demo Name",sDemoName)).toContain('Pass');
    expect(await objAllRequestPage.verifyFreezedMsgOnPopUp()).toContain('Pass');
    expect(await objAllRequestPage.verifyAllFieldIsNotClickable()).toContain('Pass');
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');
    done();
});
it('TC_11-"Verify that demo created in Mydemos shall not be closed untill a demo report is attached to it.'+
   'TC_14-Verify that customer spec table get displayed on view details page for user in mydemo application.', async(done)=>{
        let objData = dataProvider.getJsonData("./data/allRequest.json", "TC_11");
        console.log(objData);
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");
        await browser.waitForAngularEnabled(true);
        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
        //Create a new demo by uploading wafer stack and CustSpec Documents
        expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
       
        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        let sDemoName1 = "TestDemo_" + iRandomNum;
        console.log(sDemoName1);
 
        expect(await objNewDemoRequest.enterDemoName(sDemoName1)).toContain("Pass");
        expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
       
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
        expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
        
        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        let sLoggedInUser;
        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Customer Spec");
        const filePath = path.resolve('./autoItScripts/TestUpload_CustSpec.xlsx');
        const exePath = path.resolve('./autoItScripts/browseFile.exe')
        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath);
        await browser.sleep(5000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Customer Spec")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.verifyChkboxStatusAgainstField("Customer Spec", "Upload", "true")).toContain("Pass");
        let sTodayDateCust = await objCommonPage.getCurrentDate("mm/dd/yyyy hh:mins");
        console.log(sTodayDateCust);
        expect(await objNewDemoRequest.verifyDateTimeAgainstField("Customer Spec")).toContain(sTodayDateCust);

        expect(await objNewDemoRequest.clickWaferStackOption(objData.waferStackOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Wafer Stack");
        const filePath1 = path.resolve('./autoItScripts/TestUpload_WaferStack.xlsx');
        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath1);
        await browser.sleep(5000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Wafer Stack")).toContain("Pass");
        expect(await objNewDemoRequest.verifyChkboxStatusAgainstField("Wafer Stack", "Upload", "true")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
        let sTodayDateWafer = await objCommonPage.getCurrentDate("mm/dd/yyyy hh:mins");
        console.log(sTodayDateWafer);
        expect(await objNewDemoRequest.verifyDateTimeAgainstField("Wafer Stack")).toContain(sTodayDateWafer);
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
        expect(await objCommonPage.clickOnOkBtnOnPopUp()).toContain('Pass');

        //Go to All Request Page and click on the eye icon of newly created demo
        expect(await objHomePage.selectMenuOption("Approvals", "All Requests")).toContain('Pass');
        expect(await objCommonPage.searchRequest(sDemoName1)).toContain('Pass');
        expect(await objAllRequestPage.clickOnTheEyeIcon()).toContain('Pass');
        let sAlert0="Demo Detail"
        expect(await objCommonPage.verifyAlertHeader(sAlert0)).toContain('Pass');
        expect(await objAllRequestPage.verifySectionDisplayedOnPopUp("Customer Spec information")).toContain('Pass');
        expect(await objCommonPage.takeActionOnAlert("Close")).toContain('Pass');
    
        //Approve the Newly created Demo
        expect(await objAllViewPage.verifyDemoStatusInGrid(sDemoName1,"New Request")).toContain('Pass');
        expect(await objCommonPage.clickInTheTableCell("Demo Name",sDemoName1)).toContain('Pass');
        expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
        expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","High")).toContain('Pass');
        expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objData.demoOwner)).toContain('Pass');
        expect(await objAllViewPage.clickOnSave()).toContain('Pass');
        let sAlert="Approval Saved Successfully"
        expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
        expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

        //Go to All view Page and  Change the Exceution Risk to complete and update wafer location 
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
        expect(await objCommonPage.searchRequest(sDemoName1)).toContain('Pass');
        expect(await objCommonPage.goToColumn("Current Execution Risk")).toContain('Pass');
        expect(await objCommonPage.clickInTheTableCell("Current Execution Risk",sDemoName1)).toContain('Pass');
        expect(await objCommonPage.selectOptionFromDDInTableColumn("Current Execution Risk","Complete")).toContain('Pass');
        expect(await objCommonPage.goToColumn("Wafer Location")).toContain('Pass');
        expect(await objCommonPage.clickInTheTableCell("Wafer Location",sDemoName1)).toContain('Pass');
        expect(await objCommonPage.selectOptionFromDDInTableColumn("Wafer Location","In transit to account")).toContain('Pass');

        //Go to all request page and try to change the status to the close
        expect(await objHomePage.selectMenuOption("Approvals", "All Requests")).toContain('Pass');
        expect(await objCommonPage.searchRequest(sDemoName1)).toContain('Pass');

        //changing status of the demo to close user should be able to close as demo report needs to attach
        expect(await objAllViewPage.verifyDemoStatusInGrid(sDemoName1,"ACL-Approved")).toContain('Pass');
        expect(await objCommonPage.clickInTheTableCell("Demo Name",sDemoName1)).toContain('Pass');
        expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","Closed")).toContain('Pass');
        expect(await objAllViewPage.clickOnSave()).toContain('Pass');
        let sAlert1="Please upload demo report"
        expect(await objCommonPage.verifyAlertMessage(sAlert1)).toContain('Pass');
        expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
        expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');
        expect(await objAllRequestPage.clickOnTheAttachmentIcon()).toContain('Pass');

        // Attach the demo report by clicking on the attachement icon
        expect(await objAllRequestPage.clickOnBrowseButtonOnViewAttachment()).toContain("Pass");
        const filePath2 = path.resolve('./autoItScripts/Data_Report.xlsx');
        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath2);
        await browser.sleep(5000);
        expect(await objAllViewPage.selectValueFromDDOnPopUp("Security", objData.ddSecurityVal)).toContain("Pass");
        expect(await objAllViewPage.selectValueFromDDOnPopUp("Category", "Demo Report")).toContain("Pass");
        expect(await objAllRequestPage.clickOnUploadButtonOnViewAttachment()).toContain("Pass");
        expect(await objCommonPage.takeActionOnAlert("Cancel")).toContain('Pass');

        // After attaching the demo report chainging status of demo to close
        expect(await objCommonPage.clickInTheTableCell("Demo Name",sDemoName1)).toContain('Pass');
        expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","Closed")).toContain('Pass');
        expect(await objAllViewPage.clickOnSave()).toContain('Pass');
        let sAlert3="Approval Saved Successfully"
        expect(await objCommonPage.verifyAlertMessage(sAlert3)).toContain('Pass');
        expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
        done();
});
it('TC_12-"Verify if the demo is closed with demo report and is re-opened then verify that the closure shall be done without a new report attached that means the existing demo report will validate this logic.', async(done)=>{
   //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    //Go to All Request Page and Approve the closed demo.
    expect(await objHomePage.selectMenuOption("Approvals", "All Requests")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.verifyDemoStatusInGrid(sDemoName,"Closed")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Name",sDemoName)).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

    //changing status of the demo to close user should be able to close as demo report needs to attach
    expect(await objAllViewPage.verifyDemoStatusInGrid(sDemoName,"ACL-Approved")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Name",sDemoName)).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","Closed")).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert3="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert3)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    done();
});
it('TC_13-Verify that secondary demos shall be closed without attaching any demo report to them in Mydemo Application.+ Creating New Demo Request', async(done)=>{
        let objData = dataProvider.getJsonData("./data/allRequest.json", "TC_13");
        console.log(objData);
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");
        await browser.waitForAngularEnabled(true);
        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
        //select menu option
        expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
       
        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_" + iRandomNum;
        console.log(sDemoName);
 
        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
       
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
        expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
        
        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        let sLoggedInUser;
        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnAddSecondaryBU()).toContain("Pass");
        expect(await objNewDemoRequest.openBUDDListInSecondaryBUTable()).toContain("Pass");
        expect(await objNewDemoRequest.selectSecondaryBUInTable(objData.secBU1)).toContain("Pass");
        expect(await objNewDemoRequest.selectRequestorInSecBUTbl(objData.requestor1)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSaveSecondaryBU()).toContain("Pass");

        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
        expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
        expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
        expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
        expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");;
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
        sAlertMessage = "Demo Request submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
        done();
});
//Approve the created Multi BU Demo As a Bu Super User  
it('TC_13_1-Verify that secondary demos shall be closed without attaching any demo report to them in Mydemo Application. + Approve the created Multi BU Demo As a BU Super User ', async(done)=>{
    let objData = dataProvider.getJsonData("./data/allRequest.json", "TC_13_1");
    console.log(objData);
    //Login My Demo as Bu Super User application
    expect(await objLoginPage.setUserName(objLoginData.userNameBUSuperUser)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordBUSuperUser)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    //Go to All Request Page and Approve the Newly created Demo
    expect(await objHomePage.selectMenuOption("Approvals", "All Requests")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.verifyDemoStatusInGrid(sDemoName,"New Request")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Name",sDemoName)).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","High")).toContain('Pass');
    expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objData.demoOwner)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    done();
});
//Check the Status of secondary Demo by taking login as Requestor
it('TC_13_2-Verify that secondary demos shall be closed without attaching any demo report to them in Mydemo Application. + Check the Status of secondary Demo by taking login as Requestor', async(done)=>{
    let objData = dataProvider.getJsonData("./data/allRequest.json", "TC_13_2");
    console.log(objData);
    //Login My Demo as a Requestor
    expect(await objLoginPage.setUserName(objLoginData.userNameEstimator)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordEstimator)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    //Go to My Draft Request and look for secondary Demo
    expect(await objHomePage.selectMenuOption('Requests', 'My Draft Request')).toContain('Pass');
    expect(await objCommonPage.setSearchText(sDemoName)).toContain('Pass');
    expect(await objCommonPage.getTableCellValue("Demo Number",sDemoName)).toContain(objData.demoNumBu);

    //Go back to opprtunity Info screen by clicking on the demo number and update Field
    expect(await objCommonPage.clickInTheTableCell("Demo Number",sDemoName)).toContain('Pass');
    expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.clickOnDropDownOption("Application Segment", objData.appSeg)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnDropDownOption("AMAT Node", objData.amatNode)).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");

    //Upload document for cusSpec section.
    expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
    await objNewDemoRequest.clickOnBrowseButtonAgainstField("Customer Spec");
    const filePath = path.resolve('./autoItScripts/TestUpload_CustSpec.xlsx');
    const exePath = path.resolve('./autoItScripts/browseFile.exe')
    //await browser.sleep(5000);
    cp.execSync(exePath + ' ' + filePath);
    await browser.sleep(5000);
    expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
    expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Customer Spec")).toContain("Pass");
    expect(await objNewDemoRequest.verifyChkboxStatusAgainstField("Customer Spec", "Upload", "true")).toContain("Pass");
    expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
    let sTodayDateCust = await objCommonPage.getCurrentDate("mm/dd/yyyy hh:mins");
    console.log(sTodayDateCust);
    expect(await objNewDemoRequest.verifyDateTimeAgainstField("Customer Spec")).toContain(sTodayDateCust);
     
    //Upload document for wafer section.
    expect(await objNewDemoRequest.clickWaferStackOption(objData.waferStackOption)).toContain("Pass");
    await objNewDemoRequest.clickOnBrowseButtonAgainstField("Wafer Stack");
    const filePath1 = path.resolve('./autoItScripts/TestUpload_WaferStack.xlsx');
    //await browser.sleep(5000);
    cp.execSync(exePath + ' ' + filePath1);
    await browser.sleep(5000);
    expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
    expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Wafer Stack")).toContain("Pass");
    expect(await objNewDemoRequest.verifyChkboxStatusAgainstField("Wafer Stack", "Upload", "true")).toContain("Pass");
    expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
    
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
    sAlertMessage = "Demo Request submitted Successfully.";
    expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
    done();
}); 
//Approve the secondary demo by taking login as BU Super User
it('TC_13_3-Verify that secondary demos shall be closed without attaching any demo report to them in Mydemo Application. + Approve the secondary demo by taking login as BU Super User', async(done)=>{
    let objData = dataProvider.getJsonData("./data/allRequest.json", "TC_13_3");
    console.log(objData);
    //Login My Demo as Bu Super User application
    expect(await objLoginPage.setUserName(objLoginData.userNameBUSuperUser)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordBUSuperUser)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    //Go to All Request Page and Approve the secondary  created Demo
    expect(await objHomePage.selectMenuOption("Approvals", "All Requests")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.verifyDemoStatusInGrid(sDemoName,"New Request")).toContain('Pass');
    expect(await objAllRequestPage.clickInTableCellDemoRequestor(sDemoName, objData.requestor)).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority",objData.ddPriority)).toContain('Pass');
    expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objData.demoOwner)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    // Go to All view Page and  Change the Exceution Risk to complete and update wafer location 
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objCommonPage.goToColumn("Current Execution Risk")).toContain('Pass');
    expect(await objAllViewPage.clickInTheTableCellAgainstDemoNumber("Current Execution Risk",objData.buName)).toContain('Pass');
    expect(await objCommonPage.selectOptionFromDDInTableColumn("Current Execution Risk","Complete")).toContain('Pass');
    expect(await objCommonPage.goToColumn("Wafer Location")).toContain('Pass');
    expect(await objAllViewPage.clickInTheTableCellAgainstDemoNumber("Wafer Location",objData.buName)).toContain('Pass');
    expect(await objCommonPage.selectOptionFromDDInTableColumn("Wafer Location","In transit to account")).toContain('Pass');
   
    //Changing status of the demo to the close without attaching any demo report
    expect(await objHomePage.selectMenuOption("Approvals", "All Requests")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllRequestPage.clickInTableCellDemoRequestor(sDemoName, objData.requestor)).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","Closed")).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert3="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert3)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    done();
});
it('TC_10 -Verify that internal demos can be closed without attaching any demo report in Mydemo Application-Creating Internal Demo', async(done)=>{
        let objData = dataProvider.getJsonData("./data/allRequest.json", "TC_10");
        console.info(objData);

        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");
        await browser.waitForAngularEnabled(true);
        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass")
        
        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestInternalDemo_" + iRandomNum;

        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.toggleField('Internal Demo', true)).toContain("Pass");
        expect(await objNewDemoRequest.setInternalAccount(objData.internalAccount)).toContain("Pass");
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
        let sLoggedInUser;
        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        expect(await objNewDemoRequest.setInternalAccountOwner(sLoggedInUser)).toContain("Pass");

        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Customer Spec");
        const filePath = path.resolve('./autoItScripts/TestUpload_CustSpec.xlsx');
        const exePath = path.resolve('./autoItScripts/browseFile.exe')
        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath);
        await browser.sleep(5000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Customer Spec")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");

        expect(await objNewDemoRequest.clickWaferStackOption(objData.waferStackOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Wafer Stack");
        const filePath1 = path.resolve('./autoItScripts/TestUpload_WaferStack.xlsx');

        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath1);
        await browser.sleep(5000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Wafer Stack")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");

        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
        sAlertMessage = "Demo Request submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");

        //Approve the Newly created Internal Demo
        expect(await objHomePage.selectMenuOption("Approvals", "All Requests")).toContain('Pass');
        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
        expect(await objAllViewPage.verifyDemoStatusInGrid(sDemoName,"New Request")).toContain('Pass');
        expect(await objCommonPage.clickInTheTableCell("Demo Name",sDemoName)).toContain('Pass');
        expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
        expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
        expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objData.demoOwner)).toContain('Pass');
        expect(await objAllViewPage.clickOnSave()).toContain('Pass');
        let sAlert="Approval Saved Successfully"
        expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
        expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

        //Go to All view Page and  Change the Exceution Risk to complete and update wafer location 
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
        expect(await objCommonPage.goToColumn("Current Execution Risk")).toContain('Pass');
        expect(await objCommonPage.clickInTheTableCell("Current Execution Risk",sDemoName)).toContain('Pass');
        expect(await objCommonPage.selectOptionFromDDInTableColumn("Current Execution Risk","Complete")).toContain('Pass');
        expect(await objCommonPage.goToColumn("Wafer Location")).toContain('Pass');
        expect(await objCommonPage.clickInTheTableCell("Wafer Location",sDemoName)).toContain('Pass');
        expect(await objCommonPage.selectOptionFromDDInTableColumn("Wafer Location","In transit to customer")).toContain('Pass');

        //Go to all request page and change the status to the close on the approval pop up
        expect(await objHomePage.selectMenuOption("Approvals", "All Requests")).toContain('Pass');
        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
        expect(await objCommonPage.clickInTheTableCell("Demo Name",sDemoName)).toContain('Pass');
        expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","Closed")).toContain('Pass');
        expect(await objAllViewPage.clickOnSave()).toContain('Pass');
        let sAlert1="Approval Saved Successfully"
        expect(await objCommonPage.verifyAlertMessage(sAlert1)).toContain('Pass');
        expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
        done();
});
});