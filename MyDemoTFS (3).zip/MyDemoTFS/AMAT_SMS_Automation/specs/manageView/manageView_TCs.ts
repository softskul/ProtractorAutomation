import {browser, element, ExpectedConditions, by} from 'protractor';
import {homePage} from '../../pages/homePage.po';
import { commonPage } from '../../pages/commonPage.po';
import { newDemoRequest } from '../../pages/newDemoRequest.po';
import { myDraftRequestPage } from '../../pages/myDraftRequestPage.po';
import { myDemoRequestPage } from '../../pages/myDemoRequestPage.po';
import { dataProvider} from "../../data/dataProvider";
import { loginPage } from '../../pages/loginPage.po';
import { allViewPage } from '../../pages/allViewPage.po';
import { manageViewPage } from '../../pages/manageView.po';


describe('Manage View Test cases', () => {
    
    let objHomePage:homePage;
    let objNewDemoRequest:newDemoRequest;
    let objMyDraftRequest:myDraftRequestPage;
    let objCommonPage: commonPage;
    let objMyDemoRequest: myDemoRequestPage;
    let objAllViewPage: allViewPage;
    let objLoginPage:loginPage;
    let objManageViewPage:manageViewPage;
    let objLoginData = dataProvider.getJsonData("./data/login.json", "login");
    let sDemoName;
    let sAlertMessage = "";

    beforeEach(async () => {
        objHomePage = new homePage();
        objNewDemoRequest = new newDemoRequest();
        objMyDraftRequest = new myDraftRequestPage();
        objCommonPage = new commonPage();
        objAllViewPage = new allViewPage();
        objMyDemoRequest = new myDemoRequestPage();
        objManageViewPage = new manageViewPage();
        objLoginPage = new loginPage();
        await browser.waitForAngularEnabled(false);
        //Open application Url
        await objHomePage.openApplication('/');        
    });

    afterEach(() => {
        
    });
it('TC_01-Verify that Global Admin Feature have been added to View screens which will allow user to change columns and publish for all users.', async(done)=>{
        let objData = dataProvider.getJsonData("./data/manageView.json", "TC_01");
        console.log(objData);
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
        expect(await objLoginPage.clickLogin()).toContain('Pass')
        await browser.waitForAngularEnabled(true);
        expect(await objHomePage.verifyHomePageDisplayed()).toContain('Pass');
        expect(await objHomePage.selectMenuOption('Admin', 'Manage View')).toContain('Pass');
        expect(await objManageViewPage.selectViewFromDD('All View')).toContain('Pass');
        let sColList = (objData.availableColsSelection).split("~");
        for(var iCount = 0; iCount < sColList.length; iCount++)
        {
            expect(await objAllViewPage.selectFromSelectedAvailableColList("Available Columns", sColList[iCount])).toContain('Pass');
            expect(await objAllViewPage.addColInSelectedColumnList()).toContain('Pass');
        }
        expect(await objManageViewPage.clickOnPublishButtonManageView()).toContain('Pass');
        let sAlert="Published Global View"
        expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
        expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
        let sSelectedColList = await objAllViewPage.getSelectedColList();
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
        
        expect(await objAllViewPage.getUnpingedColHeaders()).toEqual(sSelectedColList);
        expect(await objHomePage.selectMenuOption('Admin', 'Manage View')).toContain('Pass');
        expect(await objManageViewPage.selectViewFromDD('All View')).toContain('Pass');
    
        let sColList1 = (objData.selectedColsSelection).split("~");
        for(var iCount = 0; iCount < sColList1.length; iCount++)
        {
            expect(await objAllViewPage.selectFromSelectedAvailableColList("Selected Columns", sColList1[iCount])).toContain('Pass');
            expect(await objAllViewPage.removeColFromSelectedColumnList()).toContain('Pass');
            expect(await objAllViewPage.verifyColPresentInSelectedAvailableColList("Available Columns", sColList1[iCount])).toContain('Pass');
        }
        expect(await objManageViewPage.clickOnPublishButtonManageView()).toContain('Pass');
        let sAlert1="Published Global View"
        expect(await objCommonPage.verifyAlertMessage(sAlert1)).toContain('Pass');
        expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
        done();
   
});
});