import {browser, element, ExpectedConditions, by} from 'protractor';
import {homePage} from '../../pages/homePage.po';
import { commonPage } from '../../pages/commonPage.po';
import { newDemoRequest } from '../../pages/newDemoRequest.po';
import { myDraftRequestPage } from '../../pages/myDraftRequestPage.po';
import { myDemoRequestPage } from '../../pages/myDemoRequestPage.po';
import { dataProvider} from "../../data/dataProvider";
import { loginPage } from '../../pages/loginPage.po';


describe('My Draft Request Test cases', () => {
    
    let objHomePage:homePage;
    let objNewDemoRequest:newDemoRequest;
    let objMyDraftRequest:myDraftRequestPage;
    let objCommonPage: commonPage;
    let objMyDemoRequest: myDemoRequestPage;
    let objLoginPage:loginPage;
    let objLoginData = dataProvider.getJsonData("./data/login.json", "login");
    let sDemoName;
    let sAlertMessage = "";

    beforeEach(async () => {
        objHomePage = new homePage();
        objNewDemoRequest = new newDemoRequest();
        objMyDraftRequest = new myDraftRequestPage();
        objCommonPage = new commonPage();
        objMyDemoRequest = new myDemoRequestPage();
        objLoginPage = new loginPage();
        await browser.waitForAngularEnabled(false);
        //Open application Url
        await objHomePage.openApplication('/');        
    });

    afterEach(() => {
		objHomePage = null;
        objCommonPage = null;
        
    });
    it('TC_02-Verify that Draft section is working as expected when user tries to access the drafted demo from My Draft Request section.', async(done)=>{
        let objData = dataProvider.getJsonData("./data/myDraftRequest.json", "TC_02");
        console.log(objData);
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");
        browser.waitForAngularEnabled(true);
        
        //select menu option
        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
        expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
       
        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_MyDemoDraftRequest" + iRandomNum;
        console.log(sDemoName);
 
        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
       
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).not.toContain("Pass");
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).not.toContain("Pass");
        expect(await objNewDemoRequest.clickOnSaveAsDraft()).toContain("Pass");
        expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');
        expect(await objHomePage.selectMenuOption('Requests', 'My Draft Request')).toContain('Pass');
        
        await objCommonPage.getTheLatestDemoNm();  
        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');  
        expect(await objCommonPage.clickInTheTableCell('Demo Number',sDemoName)).toContain('Pass');
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain('Pass');     
        expect(await objNewDemoRequest.verifyPrimaryBUDDIsEnabled()).toContain('Pass');      
        done();
});
   

    it('TC_01-Verify that My Draft Request page is loading fine and user shall be able to check whether recently drafted demo is displaying in the top of demos list.', async(done)=>{
        let objData = dataProvider.getJsonData("./data/myDraftRequest.json", "TC_01");
        console.log(objData);
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
        expect(await objLoginPage.clickLogin()).toContain('Pass')
        browser.waitForAngularEnabled(true);
        expect(await objHomePage.verifyHomePageDisplayed()).toContain('Pass');
        expect(await objHomePage.selectMenuOption('Requests', 'My Draft Request')).toContain('Pass');
        //let sLoggedInUser;
        await objHomePage.getLoggedInUser();
        expect(await objCommonPage.getTableHeaders()).toEqual(objData.headerLabelList);
        await objCommonPage.getTheLatestDemoNm();
        expect(await objCommonPage.verifyHyperLink('Demo Number', sDemoName)).toContain('Pass');
        expect(await objCommonPage.verifySorting('Demo Number')).not.toContain('Pass'); 
        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');  
        expect(await objCommonPage.clickInTheTableCell('Demo Number',sDemoName)).toContain('Pass');
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain('Pass');
        done();
});
});