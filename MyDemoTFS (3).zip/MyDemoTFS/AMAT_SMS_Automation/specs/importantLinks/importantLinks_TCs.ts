import {browser, element, ExpectedConditions, by} from 'protractor';
import {homePage} from '../../pages/homePage.po';
import { commonPage } from '../../pages/commonPage.po';
import { newDemoRequest } from '../../pages/newDemoRequest.po';
import { myDraftRequestPage } from '../../pages/myDraftRequestPage.po';
import { myDemoRequestPage } from '../../pages/myDemoRequestPage.po';
import { dataProvider} from "../../data/dataProvider";
import { loginPage } from '../../pages/loginPage.po';
import { allViewPage } from '../../pages/allViewPage.po';
import { manageViewPage } from '../../pages/manageView.po';


describe('Important Links Test cases', () => {
    
    let objHomePage:homePage;
    let objNewDemoRequest:newDemoRequest;
    let objMyDraftRequest:myDraftRequestPage;
    let objCommonPage: commonPage;
    let objMyDemoRequest: myDemoRequestPage;
    let objAllViewPage: allViewPage;
    let objLoginPage:loginPage;
    let objManageViewPage:manageViewPage;
    let objLoginData = dataProvider.getJsonData("./data/login.json", "login");
    let sDemoName;
    let sAlertMessage = "";

    beforeEach(async () => {
        objHomePage = new homePage();
        objNewDemoRequest = new newDemoRequest();
        objMyDraftRequest = new myDraftRequestPage();
        objCommonPage = new commonPage();
        objAllViewPage = new allViewPage();
        objMyDemoRequest = new myDemoRequestPage();
        objManageViewPage = new manageViewPage();
        objLoginPage = new loginPage();
        await browser.waitForAngularEnabled(false);
        //Open application Url
        await objHomePage.openApplication('/');        
    });

    afterEach(() => {
        
    });
	it('TC_01-Verify that Tableau link is added in important links section within mydemo application.', async(done)=>{
		
			expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
			expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
			expect(await objLoginPage.clickLogin()).toContain('Pass')
			await browser.waitForAngularEnabled(true);
			expect(await objHomePage.verifyHomePageDisplayed()).toContain('Pass');
			expect(await objHomePage.clickOnMenuOption('Important Links')).toContain('Pass');
			expect(await objHomePage.getSubMenuList('Important Links')).toContain('Tableau Dashboards');
			
			done();
	   
	});
	
	it('TC_03 - Verify that required links are updated under important links section', async(done)=>{
        
        let objData = dataProvider.getJsonData("./data/importantLinks.json", "TC_03");
        console.info(objData);
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
        expect(await objLoginPage.clickLogin()).toContain('Pass')
        await browser.waitForAngularEnabled(true);
        expect(await objHomePage.verifyHomePageDisplayed()).toContain('Pass');
        // expect(await objHomePage.clickOnMenuOption('Important Links')).toContain('Pass');

        let sImpLnkSubMenuLst = await objHomePage.getSubMenuList('Important Links').then(function(sLinks){console.log(sLinks); return sLinks;});
        let sExpLnks = (objData.expLinks).split("~");
        let sExpUrls = (objData.expUrls).split("~");
        for(let iCount = 0; iCount < sExpLnks.length; iCount++)
        {
            expect(await objHomePage.clickOnMenuOption('Important Links')).toContain('Pass');
            // expect(sImpLnkSubMenuLst).toContain(sExpLnks[iCount]);
            expect(await objHomePage.clickOnSubMenuOption(sExpLnks[iCount])).toContain("Pass");
            
            await browser.sleep(100000);
            
            await objCommonPage.switchtoNewTab();
            await browser.waitForAngularEnabled(false);
            console.log(await browser.getCurrentUrl())
            expect(await browser.getCurrentUrl()).toEqual(sExpUrls[iCount]);
            // await browser.waitForAngularEnabled(true);
            await objCommonPage.closeTab();
            await objCommonPage.switchtoParentTab();
            // 
            
        }
        let sNotExpLnks = (objData.notExpLinks).split("~");
        for(let iCount = 0; iCount <= sExpLnks.length; iCount++)
        {
            expect(sImpLnkSubMenuLst).not.toContain(sNotExpLnks[iCount]);
        }
        
        done();

    });
});