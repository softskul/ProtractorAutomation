import {browser, element, ExpectedConditions, by} from 'protractor';
import {homePage} from '../../pages/homePage.po';
import { commonPage } from '../../pages/commonPage.po';
import { newDemoRequest } from '../../pages/newDemoRequest.po';
import { myDraftRequestPage } from '../../pages/myDraftRequestPage.po';
import { myDemoRequestPage } from '../../pages/myDemoRequestPage.po';
import { approvalsPage } from '../../pages/approvalsPage.po';
import { allViewPage } from '../../pages/allViewPage.po';
import { dataProvider} from "../../data/dataProvider";

describe('Sprint 7 test cases', () => {
    const sprint7_TC_Data = require('../../../data/sprint7_TCs.json');
    let objHomePage:homePage;
    let objNewDemoRequest:newDemoRequest;
    let objMyDraftRequest:myDraftRequestPage;
    let objCommonPage: commonPage;
    let objMyDemoRequest: myDemoRequestPage;
    let objApprovalsPage: approvalsPage;
    let objAllViewPage: allViewPage;
    let sDemoName = "";
    let sAlertMessage = "";

    beforeEach(async () => {
        objHomePage = new homePage();
        objNewDemoRequest = new newDemoRequest();
        objMyDraftRequest = new myDraftRequestPage();
        objCommonPage = new commonPage();
        objMyDemoRequest = new myDemoRequestPage();
        objApprovalsPage = new approvalsPage();
        objAllViewPage = new allViewPage();

        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_" + iRandomNum;
        console.info(sDemoName);

        await browser.waitForAngularEnabled(false);
        //Open application Url
        await objHomePage.openApplication('/');        
    });

    afterEach(() => {

    });

    it('MyDemo_TC_01 - Verify that when Internal Demo toggle button is made as Yes, then following changes are appear on Opportunity Information section of opportunity Info page while creating New Demo Request. 1.Except Primary BU field, Rest all the field in opportunity information section should be made as non-mandatory', async()=>{
        expect(await objHomePage.verifyHomePageDisplayed()).toBe(true);
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toBe(true);
        browser.waitForAngularEnabled(true);
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toBe(true);
        expect(await objNewDemoRequest.verifyToggleForFieldIsPresent('Internal Demo')).toBe(true);
        expect(await objNewDemoRequest.toggleField('TAMBA', false)).toBe(true);
        expect(await objNewDemoRequest.toggleField('Internal Demo', true)).toBe(true);
        expect(await objNewDemoRequest.verifyPrimaryBUIsMandatoryWhenInternalDemo()).toBeTruthy();
    });

});