import {browser, element, ExpectedConditions, by} from 'protractor';
import {homePage} from '../../pages/homePage.po';
import { commonPage } from '../../pages/commonPage.po';
import { newDemoRequest } from '../../pages/newDemoRequest.po';
import { myDraftRequestPage } from '../../pages/myDraftRequestPage.po';
import { myDemoRequestPage } from '../../pages/myDemoRequestPage.po';
import { approvalsPage } from '../../pages/approvalsPage.po';
import { allViewPage } from '../../pages/allViewPage.po';
import { dataProvider} from "../../data/dataProvider";

describe('Sprint 8 test cases', () => {
    const sprint8_TC_Data = require('../../../data/sprint8_TCs.json');
    let objHomePage:homePage;
    let objNewDemoRequest:newDemoRequest;
    let objMyDraftRequest:myDraftRequestPage;
    let objCommonPage: commonPage;
    let objMyDemoRequest: myDemoRequestPage;
    let objApprovalsPage: approvalsPage;
    let objAllViewPage: allViewPage;
    let sDemoName = "";
    let sAlertMessage = "";

    beforeEach(async () => {
        objHomePage = new homePage();
        objNewDemoRequest = new newDemoRequest();
        objMyDraftRequest = new myDraftRequestPage();
        objCommonPage = new commonPage();
        objMyDemoRequest = new myDemoRequestPage();
        objApprovalsPage = new approvalsPage();
        objAllViewPage = new allViewPage();

        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_" + iRandomNum;
        console.info(sDemoName);

        await browser.waitForAngularEnabled(false);
        //Open application Url
        await objHomePage.openApplication('/');        
    });

    afterEach(() => {

    });

    it('MyDemo_TC_01 - Verify that following types are added to the selection list for Demo Type on the New Request page. 1.DYP 2.PME 3.Engineering 4.Tool Selection 5.Other', async()=>{
        let objData = dataProvider.getJsonData("./data/sprint8_TCs.json", "MyDemo_TC_01");
        console.info(objData);
        expect(await objHomePage.verifyHomePageDisplayed()).toBe(true);
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toBe(true);
        browser.waitForAngularEnabled(true);
        expect(await objNewDemoRequest.clickOnDemoTypeDD()).toBe(true);
        let sDemoTypes = (sprint8_TC_Data.MyDemo_TC_01.demoTypes).split("~");
        for(var iCount = 0; iCount < sDemoTypes.length; iCount++)
        {
            expect(await objNewDemoRequest.verifyDemoTypeListItemExists(sDemoTypes[iCount])).toBe(true);
        }
    });

});