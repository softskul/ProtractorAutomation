// import {browser, element, ExpectedConditions, by} from 'protractor';
// import {homePage} from '../../pages/homePage.po';
// import { commonPage } from '../../pages/commonPage.po';
// import { newDemoRequest } from '../../pages/newDemoRequest.po';
// import { myDraftRequestPage } from '../../pages/myDraftRequestPage.po';
// import { myDemoRequestPage } from '../../pages/myDemoRequestPage.po';
// import { approvalsPage } from '../../pages/approvalsPage.po';
// import { allViewPage } from '../../pages/allViewPage.po';
// import { dataProvider} from "../../data/dataProvider";

// describe('Create new project', () => {
//     const coreTestData = require('../../../data/coreTests.json');
//     let objHomePage:homePage;
//     let objNewDemoRequest:newDemoRequest;
//     let objMyDraftRequest:myDraftRequestPage;
//     let objCommonPage: commonPage;
//     let objMyDemoRequest: myDemoRequestPage;
//     let objApprovalsPage: approvalsPage;
//     let objAllViewPage: allViewPage;
//     let sDemoName = "";
//     let sAlertMessage = "";

//     beforeEach(async () => {
//         objHomePage = new homePage();
//         objNewDemoRequest = new newDemoRequest();
//         objMyDraftRequest = new myDraftRequestPage();
//         objCommonPage = new commonPage();
//         objMyDemoRequest = new myDemoRequestPage();
//         objApprovalsPage = new approvalsPage();
//         objAllViewPage = new allViewPage();

//         await browser.waitForAngularEnabled(false);
//         //Open application Url
//         await objHomePage.openApplication('/');        
//     });

//     afterEach(() => {

//     });

//     it('Core_Test_1 - Verify that user is able to launch MyDemo homepage successfully and Homepage should load as per requirement', async()=>{
//         let objData = dataProvider.getJsonData("./data/coreTests.json", "coreTest01");
//         console.info(objData);
//         expect(await objHomePage.verifyMyDemoLogo()).toBe(true);
//         expect(await objHomePage.verifyMenuItemPresent("Home")).toBe(true);
//         expect(await objHomePage.verifyMenuItemPresent("Requests")).toBe(true);
//         expect(await objHomePage.verifyMenuItemPresent("All Demo's")).toBe(true);
//         expect(await objHomePage.verifyMenuItemPresent("Approvals")).toBe(true);
//         expect(await objHomePage.verifyMenuItemPresent("Admin")).toBe(true);
//         expect(await objHomePage.verifyMenuItemPresent("My Action")).toBe(true);
//         expect(await objHomePage.verifyMenuItemPresent("Important Links")).toBe(true);
//         expect(await objHomePage.selectBU(coreTestData.coreTest01.bu)).toBe(true);
//         expect(await objHomePage.verifyRowCountAfterBUSelection(coreTestData.coreTest01.bu, coreTestData.coreTest01.homePageDataCount)).toBe(true);
//         browser.sleep(5000);
//         expect(await objHomePage.verifyAccountTAMValInDescOrder()).toBe(true);
//     });

//     it('Verify that user shall be able to create a new demo request successfully using MyDemo Application', async()=>{
//         let objData = dataProvider.getJsonData("./data/coreTests.json", "coreTest02");
//         console.info(objData);
//         var iRandomNum = Math.floor(1000 + Math.random() * 9000);
//         sDemoName = "TestDemo_" + iRandomNum;
//         console.info(sDemoName);
//         let sLoggedInUser;
//         await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
//         //let sDemoName = "TestDemo_1436";
//         expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toBe(true);
//         browser.waitForAngularEnabled(true);
//         expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toBe(true);
//         expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toBe(true);
//         expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toBe(true);
//         expect(await objNewDemoRequest.enterDemoName(sDemoName)).toBe(true);
//         expect(await objNewDemoRequest.selectAccount(coreTestData.coreTest02.account)).toBe(true);
//         expect(await objNewDemoRequest.selectPrimaryBU(coreTestData.coreTest02.primaryBu)).toBe(true);
//         expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toBe(false);
//         expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toBe(false);
//         expect(await objNewDemoRequest.clickOnSaveAsDraft()).toBe(true);
//         expect(await objCommonPage.verifyAlertAndTakeAction("", "Request is Saved Successfully.", "OK")).toBe(true);
//         expect(await objHomePage.selectMenuOption("Requests", "My Draft Request")).toBe(true);
//         expect(await objMyDraftRequest.verifyDraftRequestPresentInTable(sDemoName)).toBe(true); 
//         expect(await objMyDraftRequest.getDraftedDemoNumber(sDemoName)).not.toBeNull();
//         expect(await objMyDraftRequest.clickOnDraftedDemo(sDemoName)).toBe(true);
//         expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toBe(true);
//         expect(await objNewDemoRequest.verifyPrimaryBUDDIsEnabled()).toBe(false);
//         expect(await objNewDemoRequest.verifyToggleForFieldIsPresent('TAMBA')).toBe(true);

//         expect(await objNewDemoRequest.verifyToggleForFieldIsPresent('Internal Demo')).toBe(true);
//         expect(await objNewDemoRequest.toggleField('TAMBA', false)).toBe(true);
//         expect(await objNewDemoRequest.toggleField('Internal Demo', true)).toBe(true);
//         expect(await objNewDemoRequest.verifyPrimaryBUIsMandatoryWhenInternalDemo()).toBeTruthy();
//         expect(await objNewDemoRequest.toggleField('Internal Demo', false)).toBe(true);

//         expect(await objNewDemoRequest.toggleField('TAMBA', true)).toBe(true);
        
//         expect(await objNewDemoRequest.clickOnTAMBASearch()).toBe(true);
//         expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(coreTestData.coreTest02.account)).toBe(true);
//         expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toBe(true);
//         expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toBe(true);
//         expect(await objNewDemoRequest.clickOnSubmit()).toBe(true);
//         await objNewDemoRequest.verifyTambaDtlsOnNewDemoForm();
//         expect(await objNewDemoRequest.enterHVP(coreTestData.coreTest02.hvp)).toBeTruthy();
//         expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toBeTruthy();
//         expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toBeTruthy();
//         expect(await objNewDemoRequest.selectDemoType(coreTestData.coreTest02.demoType)).toBeTruthy();
//         expect(await objNewDemoRequest.setSuccessCriteria(coreTestData.coreTest02.successCriteria)).toBeTruthy();
//         expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toBeTruthy();
//         expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toBeTruthy();
//         expect(await objNewDemoRequest.selectSubstrateType(coreTestData.coreTest02.substrateType)).toBeTruthy();
//         expect(await objNewDemoRequest.clickCustomerSpecOption(coreTestData.coreTest02.customerSpecOption)).toBeTruthy();
        
//         //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
//         expect(await objNewDemoRequest.setAttributeCategory(coreTestData.coreTest02.attributeCategory)).toBeTruthy();
//         expect(await objNewDemoRequest.setAttribute(coreTestData.coreTest02.attribute)).toBeTruthy();
//         expect(await objNewDemoRequest.setMarketSegmentReq(coreTestData.coreTest02.marketSegReq)).toBeTruthy();
//         expect(await objNewDemoRequest.selectWeighPriority(coreTestData.coreTest02.weightProperty)).toBeTruthy();
//         expect(await objNewDemoRequest.clickOnAttributeSave());
//         expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toBeTruthy();
//         sAlertMessage = "Demo Request submitted Successfully.";
//         expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toBeTruthy();
//         expect(await objHomePage.selectMenuOption("Requests", "My Demo Request")).toBe(true);
//         expect(await objMyDemoRequest.verifyDemoPresentInTable(sDemoName)).toBeTruthy();
//         expect(await objMyDemoRequest.verifyDemoApprovalStatus(sDemoName, "Pending Review")).toBeTruthy();
        
//     });

//     it("Verify that user shall be able to approve the new submitted demo", async()=>{
//         let objData = dataProvider.getJsonData("./data/coreTests.json", "coreTest03");
//         console.info(objData);
//         let sLoggedInUser;
//         await objHomePage.getLoggedInUser().then(function(sUser){
//             sLoggedInUser = sUser.trim();
//         });
//         await browser.waitForAngularEnabled(true);
//         expect(await objHomePage.selectMenuOption("Approvals", "New Requests")).toBeTruthy();
//         expect(await objCommonPage.searchRequest(sDemoName)).toBeTruthy();
//         expect(await objApprovalsPage.clickOnDemoRequestRow(sDemoName)).toBeTruthy();
//         expect(await objCommonPage.verifyAlertHeader("Approval View")).toBeTruthy();
//         expect(await objApprovalsPage.selectDemoApproval(coreTestData.coreTest03.demoApprovalStatus)).toBeTruthy();
//         expect(await objApprovalsPage.selectPriority(coreTestData.coreTest03.priority)).toBeTruthy();
//         expect(await objApprovalsPage.setDemoOwner(coreTestData.coreTest03.demoOwner)).toBeTruthy();
//         expect(await objApprovalsPage.setCATRATManager(sLoggedInUser)).toBeTruthy();
//         expect(await objApprovalsPage.selectExecutionRisk("Medium")).toBeTruthy(); 
//         await objApprovalsPage.clickOnSaveApprovalView();
//         sAlertMessage = "Approval Saved Successfully."
//         expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK"));
//         expect(await objHomePage.selectMenuOption("Approvals", "All Requests")).toBeTruthy();
//         expect(await objApprovalsPage.selectRequestStatus(coreTestData.coreTest03.demoApprovalStatus)).toBeTruthy();
//         expect(await objCommonPage.searchRequest(sDemoName)).toBeTruthy();
//         expect(await objApprovalsPage.verifyDemoNumberPresentInTable(sDemoName));
//         expect(await objHomePage.selectMenuOption("Approvals", "Approved Requests")).toBeTruthy();
//         expect(await objCommonPage.searchRequest(sDemoName)).toBeTruthy();
//         expect(await objCommonPage.goToColumn("Demo Approval"));
//         expect(await objApprovalsPage.verifyDemoApprovalStatus(sDemoName, "ACL-Approved"));
//     });

//     it("Verify that user shall be able to perform various operations on All View screen", async()=>{
//         //sDemoName = "TestDemo_1473";
//         let objData = dataProvider.getJsonData("./data/coreTests.json", "coreTest04");
//         console.info(objData);
//         await browser.waitForAngularEnabled(true);
//         expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toBeTruthy();
//         //expect(await objCommonPage.searchRequest(sDemoName)).toBeTruthy();//Remove
//         expect(await objAllViewPage.verifyPubliPersonalViewDDIsPresent()).toBeTruthy();
//         expect(await objAllViewPage.verifyStatusDDIsPresentWithDefVal("Active")).toBeTruthy();
//         expect(await objCommonPage.verifyGoToDDIsPresent()).toBeTruthy();
//         expect(await objCommonPage.verifySearchTextBoxIsPresent()).toBeTruthy();
//         expect(await objCommonPage.verifySearchBtnIsPresent()).toBeTruthy();
//         expect(await objCommonPage.searchRequest(sDemoName)).toBeTruthy();
//         expect(await objCommonPage.goToColumn("Demo Approval")).toBeTruthy();
//         expect(await objAllViewPage.verifyDemoApprovalStatus(sDemoName, coreTestData.coreTest04.expDemoApprovalStatus)).toBeTruthy();
//         expect(await objAllViewPage.clickOnDemoNumber(sDemoName)).toBeTruthy();
//         expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toBeTruthy();
//         expect(await objCommonPage.searchRequest(sDemoName)).toBeTruthy();
//         expect(await objAllViewPage.clickOnACLApprovalInTableCell(sDemoName)).toBeTruthy();
//         expect(await objCommonPage.verifyAlertHeader("Approval View")).toBeTruthy();
//         expect(await objApprovalsPage.selectDemoApproval(coreTestData.coreTest04.demoApprovalStatus)).toBeTruthy();
//         expect(await objApprovalsPage.setJustificationInApprovalViewPopUp(coreTestData.coreTest04.justification)).toBeTruthy();
//         await objApprovalsPage.clickOnSaveApprovalView();
//         sAlertMessage = "Approval Saved Successfully"
//         expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toBeTruthy();
//         expect(await objCommonPage.goToColumn("Demo Approval")).toBeTruthy();
//         expect(await objAllViewPage.verifyDemoApprovalStatus(sDemoName, coreTestData.coreTest04.expDemoApprovalStatus1)).toBeTruthy();
//         expect(await objCommonPage.searchRequest(sDemoName)).toBeTruthy();
//         expect(await objCommonPage.goToColumn("ROI/ Purpose")).toBeTruthy();
//         expect(await objAllViewPage.clickInTableCell(sDemoName, "ROI/ Purpose")).toBeTruthy();
//         await objAllViewPage.setValInTableInputField(coreTestData.coreTest04.ROIPurpose);
//         expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "ROI/ Purpose", coreTestData.coreTest04.ROIPurpose));
//         expect(await objCommonPage.goToColumn("Customer Fab")).toBeTruthy();
//         expect(await objAllViewPage.clickInTableCell(sDemoName, "Customer Fab")).toBeTruthy();
//         await objAllViewPage.setValInTableInputField(coreTestData.coreTest04.custFab);
//         expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "Customer Fab", coreTestData.coreTest04.custFab));
//         expect(await objCommonPage.goToColumn("Performance (Spec vs. Actual)")).toBeTruthy();
//         expect(await objAllViewPage.clickInTableCell(sDemoName, "Performance (Spec vs. Actual)")).toBeTruthy();
//         expect(await objAllViewPage.selectOptionFromDDInTableColumn("Performance (Spec vs. Actual)", coreTestData.coreTest04.perfSpecVsAct)).toBeTruthy();
//         expect(await objAllViewPage.verifyAttributeValueInTableCell(sDemoName, "Performance (Spec vs. Actual)", "data-original-title", coreTestData.coreTest04.expPerfSpecVsAct)).toBeTruthy();   
//     });

//     it("Verify that user shall be able to perform various operations on All View screen - Part 2", async()=>{
//         let objData = dataProvider.getJsonData("./data/coreTests.json", "coreTest04");
//         console.info(objData);
//         await browser.waitForAngularEnabled(true);
//         expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toBeTruthy();
//         expect(await objCommonPage.searchRequest(sDemoName)).toBeTruthy();
//        //await objCommonPage.waitTillInvisibilityOfLoadingIcon();
//         expect(await objCommonPage.goToColumn("Current Execution Risk")).toBeTruthy();
//         expect(await objAllViewPage.clickInTableCell(sDemoName, "Current Execution Risk")).toBeTruthy();
//         expect(await objAllViewPage.selectOptionFromDDInTableColumn("Current Execution Risk", coreTestData.coreTest04.curExecRisk)).toBeTruthy();
//         expect(await objAllViewPage.verifyAttributeValueInTableCell(sDemoName, "Current Execution Risk", "data-original-title", coreTestData.coreTest04.expCurExecRisk)).toBeTruthy();
//         //await objCommonPage.waitTillInvisibilityOfLoadingIcon();
//         //Need to add below three lines as it is taking time for loading icon to disappear
//         await browser.waitForAngularEnabled(false);
//         await objHomePage.refreshAppPage();
//         await browser.waitForAngularEnabled(true);
//         expect(await objCommonPage.searchRequest(sDemoName)).toBeTruthy();
//         expect(await objCommonPage.goToColumn("CoO Gap (spec vs. Actual)")).toBeTruthy();
//         expect(await objAllViewPage.clickInTableCell(sDemoName, "CoO Gap (spec vs. Actual)")).toBeTruthy();
//         expect(await objAllViewPage.selectOptionFromDDInTableColumn("CoO Gap (spec vs. Actual)", coreTestData.coreTest04.cooGapSpecVsAct)).toBeTruthy();
//         expect(await objAllViewPage.verifyAttributeValueInTableCell(sDemoName, "CoO Gap (spec vs. Actual)", "data-original-title", coreTestData.coreTest04.expCooGapSpecVsAct)).toBeTruthy();
//         //Need to add below three lines as it is taking time for loading icon to disappear
//         await browser.waitForAngularEnabled(false);
//         await objHomePage.refreshAppPage();
//         await browser.waitForAngularEnabled(true);
//         expect(await objCommonPage.searchRequest(sDemoName)).toBeTruthy();
//         expect(await objCommonPage.goToColumn("Onsite Chamber Readiness")).toBeTruthy();
//         expect(await objAllViewPage.clickInTableCell(sDemoName, "Onsite Chamber Readiness")).toBeTruthy();
//         expect(await objAllViewPage.selectOptionFromDDInTableColumn("Onsite Chamber Readiness", coreTestData.coreTest04.onsiteChamberReady)).toBeTruthy();
//         expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "Onsite Chamber Readiness", coreTestData.coreTest04.onsiteChamberReady)).toBeTruthy();
//         //await objCommonPage.waitTillInvisibilityOfLoadingIcon();
//         //Need to add below three lines as it is taking time for loading icon to disappear
//         await browser.waitForAngularEnabled(false);
//         await objHomePage.refreshAppPage();
//         await browser.waitForAngularEnabled(true);
//         expect(await objCommonPage.searchRequest(sDemoName)).toBeTruthy();
//         expect(await objCommonPage.goToColumn("Additional CIP HW Requirement")).toBeTruthy();
//         expect(await objAllViewPage.clickInTableCell(sDemoName, "Additional CIP HW Requirement")).toBeTruthy();
//         expect(await objAllViewPage.selectOptionFromDDInTableColumn("Additional CIP HW Requirement", coreTestData.coreTest04.addCIPHWReq)).toBeTruthy();
//         expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "Additional CIP HW Requirement", coreTestData.coreTest04.addCIPHWReq)).toBeTruthy();
//         //await objCommonPage.waitTillInvisibilityOfLoadingIcon();
//         //Need to add below three lines as it is taking time for loading icon to disappear
//         await browser.waitForAngularEnabled(false);
//         await objHomePage.refreshAppPage();
//         await browser.waitForAngularEnabled(true);
//         expect(await objCommonPage.searchRequest(sDemoName)).toBeTruthy();
//         expect(await objCommonPage.goToColumn("Risk/Gap Description")).toBeTruthy();
//         expect(await objAllViewPage.clickInTableCell(sDemoName, "Risk/Gap Description")).toBeTruthy();
//         await objAllViewPage.setValInTableInputField(coreTestData.coreTest04.riskGapDesc);
//         await objCommonPage.waitTillInvisibilityOfLoadingIcon();
//         expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "Risk/Gap Description", coreTestData.coreTest04.riskGapDesc));
//         expect(await objCommonPage.goToColumn("Risk/Gap Closure Plan")).toBeTruthy();
//         expect(await objAllViewPage.clickInTableCell(sDemoName, "Risk/Gap Closure Plan")).toBeTruthy();
//         await objAllViewPage.setValInTableInputField(coreTestData.coreTest04.riskGapClosurePlan);
//         await objCommonPage.waitTillInvisibilityOfLoadingIcon();
//         expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "Risk/Gap Closure Plan", coreTestData.coreTest04.riskGapClosurePlan));
//         expect(await objCommonPage.goToColumn("HVP")).toBeTruthy();
//         expect(await objAllViewPage.clickInTableCell(sDemoName, "HVP")).toBeTruthy();
//         await objAllViewPage.setValInTableInputField(coreTestData.coreTest04.hvp);
//         await objCommonPage.waitTillInvisibilityOfLoadingIcon();
//         expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "HVP", coreTestData.coreTest04.hvp));
//     });

//     it("Verify that user shall be able to perform various operations on All View screen - Part 3", async()=>{
//         let objData = dataProvider.getJsonData("./data/coreTests.json", "coreTest04");
//         console.info(objData);
//         await browser.waitForAngularEnabled(true);
//         expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toBeTruthy();
//         expect(await objCommonPage.searchRequest(sDemoName)).toBeTruthy();
//         expect(await objCommonPage.goToColumn("HtH")).toBeTruthy();
//         expect(await objAllViewPage.clickInTableCell(sDemoName, "HtH")).toBeTruthy();
//         expect(await objCommonPage.verifyAlertHeader("RAT Detail")).toBeTruthy();
//         expect(await objAllViewPage.selectDDOptionOnRATDtlsPopUp("HtH", "Yes")).toBeTruthy();
//         expect(await objAllViewPage.selectDDOptionOnRATDtlsPopUp("Tech Prob of Win", ">75")).toBeTruthy();
//         expect(await objAllViewPage.selectDDOptionOnRATDtlsPopUp("Strategic Importance", "High")).toBeTruthy();
//         expect(await objAllViewPage.selectDDOptionOnRATDtlsPopUp("Customer Commit", "Medium")).toBeTruthy();
//         expect(await objAllViewPage.clickBtnOnPopUp("RAT Detail", "Submit")).toBeTruthy();
//         sAlertMessage = "The RATP3 Project has a TAMBA ID associated. Do you want the Demo to be updated with the RATP3 TAMBA information?";
//         expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "No")).toBeTruthy();
//         await objCommonPage.waitTillInvisibilityOfLoadingIcon();
//         expect(await objCommonPage.goToColumn("Strategic Importance")).toBeTruthy();
//         expect(await objAllViewPage.verifyAttributeValueInTableCell(sDemoName, "Strategic Importance", "data-original-title", "High Risk"));
//         expect(await objCommonPage.goToColumn("HtH")).toBeTruthy();
//         expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "HtH", "Yes")).toBeTruthy();
//         expect(await objCommonPage.goToColumn("Tech Prob")).toBeTruthy();
//         expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "Tech Prob", ">75")).toBeTruthy();
//         expect(await objCommonPage.goToColumn("Customer Commit")).toBeTruthy();
//         expect(await objAllViewPage.verifyAttributeValueInTableCell(sDemoName, "Customer Commit", "data-original-title", "Medium Risk"));
//         expect(await objCommonPage.goToColumn("Customer Owner")).toBeTruthy();
//         expect(await objAllViewPage.clickInTableCell(sDemoName, "Customer Owner")).toBeTruthy();
//         await objAllViewPage.setValInTableInputField("Test_Customer_Owner");
//         await objCommonPage.waitTillInvisibilityOfLoadingIcon();
//         expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "Customer Owner", "Test_Customer_Owner")).toBe(true);
//         expect(await objCommonPage.goToColumn("Customer title")).toBeTruthy();
//         expect(await objAllViewPage.clickInTableCell(sDemoName, "Customer title")).toBeTruthy();
//         await objAllViewPage.setValInTableInputField("Test_Customer_Title");
//         await objCommonPage.waitTillInvisibilityOfLoadingIcon();
//         expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "Customer title", "Test_Customer_Title")).toBe(true);
//         expect(await objCommonPage.goToColumn("Customer e-mail")).toBeTruthy();
//         expect(await objAllViewPage.clickInTableCell(sDemoName, "Customer e-mail")).toBeTruthy();
//         await objAllViewPage.setValInTableInputField("Test@customeremail.com");
//         await objCommonPage.waitTillInvisibilityOfLoadingIcon();
//         expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "Customer e-mail", "Test@customeremail.com")).toBe(true);
//         expect(await objCommonPage.goToColumn("Customer Phone")).toBeTruthy();
//         expect(await objAllViewPage.clickInTableCell(sDemoName, "Customer Phone")).toBeTruthy();
//         await objAllViewPage.setValInTableInputField("8712407094");
//         await objCommonPage.waitTillInvisibilityOfLoadingIcon();
//         expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "Customer Phone", "8712407094")).toBe(true);
//         expect(await objCommonPage.goToColumn("Customer Mailing address")).toBeTruthy();
//         expect(await objAllViewPage.clickInTableCell(sDemoName, "Customer Mailing address")).toBeTruthy();
//         await objAllViewPage.setValInTableInputField("Test_Customer_Mailing_Address");
//         await objCommonPage.waitTillInvisibilityOfLoadingIcon();
//         expect(await objAllViewPage.verifyValueInTableCell(sDemoName, "Customer Mailing address", "Test_Customer_Mailing_Address")).toBe(true);
//     });

// });