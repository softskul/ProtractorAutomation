import {browser, element, ExpectedConditions, by} from 'protractor';
import {homePage} from '../../pages/homePage.po';
import { commonPage } from '../../pages/commonPage.po';
import { newDemoRequest } from '../../pages/newDemoRequest.po';
import { myDraftRequestPage } from '../../pages/myDraftRequestPage.po';
import { myDemoRequestPage } from '../../pages/myDemoRequestPage.po';
import { dataProvider} from "../../data/dataProvider";
import { loginPage } from '../../pages/loginPage.po';
import { allViewPage } from '../../pages/allViewPage.po';
import { manageViewPage } from '../../pages/manageView.po';
import { grantDemoAccessPage } from '../../pages/grantDemoAccessPage.po';
import { allRequestPage } from '../../pages/allRequestPage.po';


describe('Grant Demo Access Test cases', () => {
    
    let objHomePage:homePage;
    let objNewDemoRequest:newDemoRequest;
    let objMyDraftRequest:myDraftRequestPage;
    let objCommonPage: commonPage;
    let objMyDemoRequest: myDemoRequestPage;
    let objAllViewPage: allViewPage;
    let objLoginPage:loginPage;
    let objManageViewPage:manageViewPage;
    let objGrantDemoAccessPage : grantDemoAccessPage;
    let objAllRequestPage : allRequestPage;
    let objLoginData = dataProvider.getJsonData("./data/login.json", "login");
    let sDemoName;
    let sAlertMessage = "";

    beforeEach(async () => {
        objHomePage = new homePage();
        objNewDemoRequest = new newDemoRequest();
        objMyDraftRequest = new myDraftRequestPage();
        objCommonPage = new commonPage();
        objAllViewPage = new allViewPage();
        objMyDemoRequest = new myDemoRequestPage();
        objManageViewPage = new manageViewPage();
        objLoginPage = new loginPage();
        objGrantDemoAccessPage = new grantDemoAccessPage();
        objAllRequestPage = new allRequestPage();
        
        await browser.waitForAngularEnabled(false);
        //Open application Url
        await objHomePage.openApplication('/');        
    });

    afterEach(() => {
        
    });
it('TC_Pre-Requisite.', async(done)=>{
        let objData = dataProvider.getJsonData("./data/grantDemoAccess.json", "TC_Pre-Requisite");
        console.log(objData);
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");
        await browser.waitForAngularEnabled(true);
        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
        //select menu option
        expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
       
        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_GrantDemoAccess" + iRandomNum;
        console.log(sDemoName);
 
        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
       
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
        expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
        
        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        let sLoggedInUser;
        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
        
        //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
        expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
        expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
        expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
        expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");;
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
        expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');

            //Approve the Newly created Demo on All view Page
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
        expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"New Request")).toContain('Pass');
        expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
        expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
        expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objData.demoOwner)).toContain('Pass');
        expect(await objAllViewPage.clickOnSave()).toContain('Pass');
        let sAlert="Approval Saved Successfully"
        expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
        expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
        done();
}); 
it('TC_01-"Verify that when user logs in as Global Admin then he/she shall be able to assign/update following roles on Grant Demo Access Page.', async (done)=>
{
/*
1.Demo Owner
2.Team Member
3.Account Owner
4.RAT/CAT Account Manager
5.KPU Head/GPM
6.Productivity Owner
7.Other Groups
*/
   let objData = dataProvider.getJsonData("./data/grantDemoAccess.json", "TC_01");
   console.log(objData);

   // Login as Global Admin User
   expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass"); 
   expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
   expect(await objLoginPage.clickLogin()).toContain("Pass");
   await browser.waitForAngularEnabled(true);
   expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
   
   //Search or the demo and update the owner's name
   expect(await objHomePage.selectMenuOption("All Demo's", "Grant Demo Access")).toContain('Pass');
   expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
   expect(await objAllViewPage.getUnpingedColHeaders()).toEqual(objData.headerLabelListUnpinged);
   expect(await objAllViewPage.getPingedColHeaders()).toEqual(objData.headerLabelListPinged);

   expect(await objCommonPage.clickInTheTableCell("Demo Name",sDemoName)).toContain('Pass');
   let sAlert="Security Access View"
   expect(await objCommonPage.verifyAlertHeader(sAlert)).toContain('Pass');

   expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objData.demoOwner)).toContain('Pass');
   expect(await objGrantDemoAccessPage.selectOwnerFromDD("Account Owner",objData.accountOwner)).toContain('Pass');
   expect(await objGrantDemoAccessPage.selectOwnerFromDD("Team Member",objData.teamMember)).toContain('Pass');
   expect(await objGrantDemoAccessPage.selectOwnerFromDD("CAT/RAT Manager",objData.catRatManager)).toContain('Pass');
   expect(await objGrantDemoAccessPage.selectOwnerFromDD("KPU Head/GPM",objData.kpuHeadGpm)).toContain('Pass');
   expect(await objGrantDemoAccessPage.selectOwnerFromDD("Productivity Owner",objData.productivityOwner)).toContain('Pass');
   expect(await objAllViewPage.setInputOnPopUp("Other Group",objData.otherGroup)).toContain('Pass');
   expect(await objAllViewPage.clickOnSave()).toContain('Pass');
   let sAlert1="Approval Saved Successfully"
   expect(await objCommonPage.verifyAlertMessage(sAlert1)).toContain('Pass');
   expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
   done();
});
it('TC_Pre-Requisite.', async(done)=>{
    let objData = dataProvider.getJsonData("./data/grantDemoAccess.json", "TC_Pre-Requisite");
    console.log(objData);
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    //select menu option
    expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
    expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
   
    var iRandomNum = Math.floor(1000 + Math.random() * 9000);
    sDemoName = "TestDemo_GrantDemoAccess" + iRandomNum;
    console.log(sDemoName);

    expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
    expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
   
    expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
    expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
    
    expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
    expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
    expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
    expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
    expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
    
    //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
    expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
    expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
    expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
    expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");;
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
    expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');

        //Approve the Newly created Demo on All view Page
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"New Request")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
    expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objData.demoOwner)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    done();
});
it('TC_01_1-"Verify that when user logs in as BU Super User then he/she shall be able to assign/update following roles on Grant Demo Access Page.', async (done)=>
{
/*
1.Demo Owner
2.Team Member
3.Account Owner
4.RAT/CAT Account Manager
5.KPU Head/GPM
6.Productivity Owner
7.Other Groups
*/
   let objData = dataProvider.getJsonData("./data/grantDemoAccess.json", "TC_01");
   console.log(objData);

   // Login as Global Admin User
   expect(await objLoginPage.setUserName(objLoginData.userNameBUSuperUser)).toContain("Pass"); 
   expect(await objLoginPage.setPassword(objLoginData.passwordBUSuperUser)).toContain("Pass");
   expect(await objLoginPage.clickLogin()).toContain("Pass");
   await browser.waitForAngularEnabled(true);
   expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
   
   //Search or the demo and update the owner's name
   expect(await objHomePage.selectMenuOption("All Demo's", "Grant Demo Access")).toContain('Pass');
   expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
   expect(await objAllViewPage.getUnpingedColHeaders()).toEqual(objData.headerLabelListUnpinged);
   expect(await objAllViewPage.getPingedColHeaders()).toEqual(objData.headerLabelListPinged);

   expect(await objCommonPage.clickInTheTableCell("Demo Name",sDemoName)).toContain('Pass');
   let sAlert="Security Access View"
   expect(await objCommonPage.verifyAlertHeader(sAlert)).toContain('Pass');


   //expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objData.demoOwner)).toContain('Pass');
   expect(await objGrantDemoAccessPage.selectOwnerFromDD("Account Owner",objData.accountOwner)).toContain('Pass');
   expect(await objGrantDemoAccessPage.selectOwnerFromDD("Team Member",objData.teamMember)).toContain('Pass');
   expect(await objGrantDemoAccessPage.selectOwnerFromDD("CAT/RAT Manager",objData.catRatManager)).toContain('Pass');
   expect(await objGrantDemoAccessPage.selectOwnerFromDD("KPU Head/GPM",objData.kpuHeadGpm)).toContain('Pass');
   expect(await objAllRequestPage.selectOwnerOnPopUp("Productivity Owner",objData.productivityOwner)).toContain('Pass');
   expect(await objAllViewPage.setInputOnPopUp("Other Group",objData.otherGroup)).toContain('Pass');
   expect(await objAllViewPage.clickOnSave()).toContain('Pass');
   let sAlert1="Approval Saved Successfully"
   expect(await objCommonPage.verifyAlertMessage(sAlert1)).toContain('Pass');
   expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
   done();
});
it('TC_Pre-Requisite.', async(done)=>{
    let objData = dataProvider.getJsonData("./data/grantDemoAccess.json", "TC_Pre-Requisite");
    console.log(objData);
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    //select menu option
    expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
    expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
   
    var iRandomNum = Math.floor(1000 + Math.random() * 9000);
    sDemoName = "TestDemo_GrantDemoAccess" + iRandomNum;
    console.log(sDemoName);

    expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
    expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
   
    expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
    expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
    
    expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
    expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
    expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
    expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
    expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
    
    //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
    expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
    expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
    expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
    expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");;
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
    expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');

        //Approve the Newly created Demo on All view Page
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"New Request")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
    expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objData.demoOwner)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    done();
});
it('TC_01_2-"Verify that when user logs in as KPU Head User then he/she shall be able to assign/update following roles on Grant Demo Access Page.', async (done)=>
{
/*
1.Demo Owner
2.Team Member
3.Account Owner
4.RAT/CAT Account Manager
5.KPU Head/GPM
6.Productivity Owner
7.Other Groups
*/
   let objData = dataProvider.getJsonData("./data/grantDemoAccess.json", "TC_01");
   console.log(objData);

   // Login as Global Admin User
   expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass"); 
   expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
   expect(await objLoginPage.clickLogin()).toContain("Pass");
   await browser.waitForAngularEnabled(true);
   expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
   
   //Search or the demo and update the owner's name
   expect(await objHomePage.selectMenuOption("All Demo's", "Grant Demo Access")).toContain('Pass');
   expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
   expect(await objAllViewPage.getUnpingedColHeaders()).toEqual(objData.headerLabelListUnpinged);
   expect(await objAllViewPage.getPingedColHeaders()).toEqual(objData.headerLabelListPinged);

   expect(await objCommonPage.clickInTheTableCell("Demo Name",sDemoName)).toContain('Pass');
   let sAlert="Security Access View"
   expect(await objCommonPage.verifyAlertHeader(sAlert)).toContain('Pass');
   expect(await objGrantDemoAccessPage.selectOwnerFromDD("KPU Head/GPM",objData.kpuHeadGpmUser)).toContain('Pass');
   expect(await objAllViewPage.clickOnSave()).toContain('Pass');
   let sAlert1="Approval Saved Successfully"
   expect(await objCommonPage.verifyAlertMessage(sAlert1)).toContain('Pass');
   expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');


    // Take Login as KPU Head User
    await browser.waitForAngularEnabled(false)
    await objHomePage.openApplication('/');      
    expect(await objLoginPage.setUserName(objData.kpuHeadGpmUser)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordCATRATManager)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    expect(await objHomePage.selectMenuOption("All Demo's", "Grant Demo Access")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Name",sDemoName)).toContain('Pass');
    expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objData.demoOwner)).toContain('Pass');
    expect(await objGrantDemoAccessPage.selectOwnerFromDD("Account Owner",objData.accountOwner)).toContain('Pass');
    expect(await objGrantDemoAccessPage.selectOwnerFromDD("Team Member",objData.teamMember)).toContain('Pass');
    expect(await objGrantDemoAccessPage.selectOwnerFromDD("CAT/RAT Manager",objData.catRatManager)).toContain('Pass');
    expect(await objGrantDemoAccessPage.selectOwnerFromDD("KPU Head/GPM",objData.kpuHeadGpm)).toContain('Pass');
    expect(await objAllRequestPage.selectOwnerOnPopUp("Productivity Owner",objData.productivityOwner)).toContain('Pass');
    expect(await objAllViewPage.setInputOnPopUp("Other Group",objData.otherGroup)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');

    expect(await objCommonPage.verifyAlertMessage(sAlert1)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    done();
});
it('TC_Pre-Requisite.', async(done)=>{
    let objData = dataProvider.getJsonData("./data/grantDemoAccess.json", "TC_Pre-Requisite");
    console.log(objData);
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    //select menu option
    expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
    expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
   
    var iRandomNum = Math.floor(1000 + Math.random() * 9000);
    sDemoName = "TestDemo_GrantDemoAccess" + iRandomNum;
    console.log(sDemoName);

    expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
    expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
   
    expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
    expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
    
    expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
    expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
    expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
    expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
    expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
    
    //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
    expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
    expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
    expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
    expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");;
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
    expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');

        //Approve the Newly created Demo on All view Page
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"New Request")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
    expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objData.demoOwner)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    done();
});
it('TC_01_3-"Verify that when user logs in as Demo Owner User then he/she shall be able to assign/update following roles on Grant Demo Access Page.', async (done)=>
{
/*
1.Demo Owner
2.Team Member
3.Account Owner
4.RAT/CAT Account Manager
5.KPU Head/GPM
6.Productivity Owner
7.Other Groups
*/
   let objData = dataProvider.getJsonData("./data/grantDemoAccess.json", "TC_01");
   console.log(objData);

   // Login as Global Admin User
   expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass"); 
   expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
   expect(await objLoginPage.clickLogin()).toContain("Pass");
   await browser.waitForAngularEnabled(true);
   expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
   
   //Search or the demo and update the owner's name
   expect(await objHomePage.selectMenuOption("All Demo's", "Grant Demo Access")).toContain('Pass');
   expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
   expect(await objAllViewPage.getUnpingedColHeaders()).toEqual(objData.headerLabelListUnpinged);
   expect(await objAllViewPage.getPingedColHeaders()).toEqual(objData.headerLabelListPinged);

   expect(await objCommonPage.clickInTheTableCell("Demo Name",sDemoName)).toContain('Pass');
   let sAlert="Security Access View"
   expect(await objCommonPage.verifyAlertHeader(sAlert)).toContain('Pass');
   expect(await objGrantDemoAccessPage.selectOwnerFromDD("Demo Owner",objData.demoOwnerUser)).toContain('Pass');
   expect(await objAllViewPage.clickOnSave()).toContain('Pass');
   let sAlert1="Approval Saved Successfully"
   expect(await objCommonPage.verifyAlertMessage(sAlert1)).toContain('Pass');
   expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');


    // Take Login as KPU Head User
    await browser.waitForAngularEnabled(false)
    await objHomePage.openApplication('/');      
    expect(await objLoginPage.setUserName(objData.demoOwnerUser)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordCATRATManager)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    expect(await objHomePage.selectMenuOption("All Demo's", "Grant Demo Access")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Demo Name",sDemoName)).toContain('Pass');
    expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objData.demoOwner)).toContain('Pass');
    expect(await objGrantDemoAccessPage.selectOwnerFromDD("Account Owner",objData.accountOwner)).toContain('Pass');
    expect(await objGrantDemoAccessPage.selectOwnerFromDD("Team Member",objData.teamMember)).toContain('Pass');
    expect(await objGrantDemoAccessPage.selectOwnerFromDD("CAT/RAT Manager",objData.catRatManager)).toContain('Pass');
    expect(await objGrantDemoAccessPage.selectOwnerFromDD("KPU Head/GPM",objData.kpuHeadGpm)).toContain('Pass');
    expect(await objAllRequestPage.selectOwnerOnPopUp("Productivity Owner",objData.productivityOwner)).toContain('Pass');
    expect(await objAllViewPage.setInputOnPopUp("Other Group",objData.otherGroup)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');

    expect(await objCommonPage.verifyAlertMessage(sAlert1)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    done();
});
it('TC_Pre-Requisite.', async(done)=>{
    let objData = dataProvider.getJsonData("./data/grantDemoAccess.json", "TC_Pre-Requisite");
    console.log(objData);
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    //select menu option
    expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
    expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
   
    var iRandomNum = Math.floor(1000 + Math.random() * 9000);
    sDemoName = "TestDemo_GrantDemoAccess" + iRandomNum;
    console.log(sDemoName);

    expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
    expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
   
    expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
    expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
    
    expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
    expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
    expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
    expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
    expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
    
    //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
    expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
    expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
    expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
    expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");;
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
    expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');

        //Approve the Newly created Demo on All view Page
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"New Request")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
    expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objData.demoOwner)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    done();
});
it('TC_02-"Verify that when user logs in as Team Member User the he/she shall not be able to assign/update following roles on Grant Demo Access Page.', async (done)=>
{

    /*
    1.Team Member
    2.Account Owner
    3.RAT/CAT Account Manager
    4.KPU Head/GPM
    5.Productivity Owner
    6.Other Groups
    */
   let objData = dataProvider.getJsonData("./data/grantDemoAccess.json", "TC_02");
   console.log(objData);

   // Login as Global Admin User
   expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass"); 
   expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
   expect(await objLoginPage.clickLogin()).toContain("Pass");
   await browser.waitForAngularEnabled(true);
   expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
   
   //Search or the demo and update the Team Member
   expect(await objHomePage.selectMenuOption("All Demo's", "Grant Demo Access")).toContain('Pass');
   expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');

   expect(await objCommonPage.clickInTheTableCell("Demo Name",sDemoName)).toContain('Pass');
   let sAlert="Security Access View"
   expect(await objCommonPage.verifyAlertHeader(sAlert)).toContain('Pass');
   expect(await objGrantDemoAccessPage.selectOwnerFromDD("Team Member",objData.teamMember)).toContain('Pass');
   expect(await objAllViewPage.clickOnSave()).toContain('Pass');
   let sAlert1="Approval Saved Successfully"
   expect(await objCommonPage.verifyAlertMessage(sAlert1)).toContain('Pass');
   expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');


    // Take Login as Team Member
    await browser.waitForAngularEnabled(false)
    await objHomePage.openApplication('/');      
    expect(await objLoginPage.setUserName(objLoginData.userNameTeamMember)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordTeamMember)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

    expect(await objHomePage.selectMenuOption("All Demo's", "Grant Demo Access")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.getSearchResults(sDemoName)).not.toContain('Pass');
    done();
})
it('TC_Pre-Requisite.', async(done)=>{
    let objData = dataProvider.getJsonData("./data/grantDemoAccess.json", "TC_Pre-Requisite");
    console.log(objData);
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    //select menu option
    expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
    expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
   
    var iRandomNum = Math.floor(1000 + Math.random() * 9000);
    sDemoName = "TestDemo_GrantDemoAccess" + iRandomNum;
    console.log(sDemoName);

    expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
    expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
   
    expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
    expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
    
    expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
    expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
    expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
    expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
    expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
    
    //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
    expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
    expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
    expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
    expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");;
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
    expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');

        //Approve the Newly created Demo on All view Page
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"New Request")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
    expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objData.demoOwner)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    done();
});
it('TC_02_1-"Verify that when user logs in as Productivity Owner User the he/she shall not be able to assign/update following roles on Grant Demo Access Page.', async (done)=>
{

    /*
    1.Team Member
    2.Account Owner
    3.RAT/CAT Account Manager
    4.KPU Head/GPM
    5.Productivity Owner
    6.Other Groups
    */
   let objData = dataProvider.getJsonData("./data/grantDemoAccess.json", "TC_02");
   console.log(objData);

   // Login as Global Admin User
   expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass"); 
   expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
   expect(await objLoginPage.clickLogin()).toContain("Pass");
   await browser.waitForAngularEnabled(true);
   expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
   
   //Search or the demo and update the Productivity Owner
   expect(await objHomePage.selectMenuOption("All Demo's", "Grant Demo Access")).toContain('Pass');
   expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');

   expect(await objCommonPage.clickInTheTableCell("Demo Name",sDemoName)).toContain('Pass');
   let sAlert="Security Access View"
   expect(await objCommonPage.verifyAlertHeader(sAlert)).toContain('Pass');
   expect(await objGrantDemoAccessPage.selectOwnerFromDD("Productivity Owner",objData.productivityOwner)).toContain('Pass');
   expect(await objAllViewPage.clickOnSave()).toContain('Pass');
   let sAlert1="Approval Saved Successfully"
   expect(await objCommonPage.verifyAlertMessage(sAlert1)).toContain('Pass');
   expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');


    // Take Login as productivity owner
    await browser.waitForAngularEnabled(false)
    await objHomePage.openApplication('/');      
    expect(await objLoginPage.setUserName(objLoginData.userNameProductivityOwner)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordProductivityOwner)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

    expect(await objHomePage.selectMenuOption("All Demo's", "Grant Demo Access")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.getSearchResults(sDemoName)).not.toContain('Pass');
    
   
    done();
})
it('TC_Pre-Requisite.', async(done)=>{
    let objData = dataProvider.getJsonData("./data/grantDemoAccess.json", "TC_Pre-Requisite");
    console.log(objData);
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    //select menu option
    expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
    expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
   
    var iRandomNum = Math.floor(1000 + Math.random() * 9000);
    sDemoName = "TestDemo_GrantDemoAccess" + iRandomNum;
    console.log(sDemoName);

    expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
    expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
   
    expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
    expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
    
    expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
    expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
    expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
    expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
    expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
    
    //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
    expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
    expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
    expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
    expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");;
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
    expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');

        //Approve the Newly created Demo on All view Page
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"New Request")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
    expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objData.demoOwner)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    done();
});
it('TC_03-"Verify that whenver user logs in as Account Owner of a particular demo in MyDemo QA  then he/she shall not be able to access Grant Demo Access Page. If he/she is able to Grant Demo Access page because of his/her roles in other demos then when user serach the demo in Grant Demo Access page then there should not be any result.', async (done)=>
{
   let objData = dataProvider.getJsonData("./data/grantDemoAccess.json", "TC_03");
   console.log(objData);

   // Login as Global Admin User
   expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass"); 
   expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
   expect(await objLoginPage.clickLogin()).toContain("Pass");
   await browser.waitForAngularEnabled(true);
   expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
   
   //Search or the demo and update the Account Owner Name
   expect(await objHomePage.selectMenuOption("All Demo's", "Grant Demo Access")).toContain('Pass');
   expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');

   expect(await objCommonPage.clickInTheTableCell("Demo Name",sDemoName)).toContain('Pass');
   let sAlert="Security Access View"
   expect(await objCommonPage.verifyAlertHeader(sAlert)).toContain('Pass');
   expect(await objGrantDemoAccessPage.selectOwnerFromDD("Account Owner",objData.accountOwner)).toContain('Pass');
   expect(await objAllViewPage.clickOnSave()).toContain('Pass');
   let sAlert1="Approval Saved Successfully"
   expect(await objCommonPage.verifyAlertMessage(sAlert1)).toContain('Pass');
   expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');


    // Take Login as Account Owner
    await browser.waitForAngularEnabled(false)
    await objHomePage.openApplication('/');      
    expect(await objLoginPage.setUserName(objLoginData.userNameAccountOwner)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordAccountOwner)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

    expect(await objHomePage.selectMenuOption("All Demo's", "Grant Demo Access")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.getSearchResults(sDemoName)).not.toContain('Pass');
    
   
    done();
})
it('TC_Pre-Requisite.', async(done)=>{
    let objData = dataProvider.getJsonData("./data/grantDemoAccess.json", "TC_Pre-Requisite");
    console.log(objData);
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    //select menu option
    expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
    expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
   
    var iRandomNum = Math.floor(1000 + Math.random() * 9000);
    sDemoName = "TestDemo_GrantDemoAccess" + iRandomNum;
    console.log(sDemoName);

    expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
    expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
   
    expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
    expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
    
    expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
    expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
    expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
    expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
    expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
    
    //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
    expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
    expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
    expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
    expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");;
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
    expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');

        //Approve the Newly created Demo on All view Page
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"New Request")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
    expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objData.demoOwner)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    done();
});
it('TC_03_1-"Verify that whenver user logs in as CATRAT Account Manager/Other Group of a particular demo in MyDemo QA  then he/she shall not be able to access Grant Demo Access Page. If he/she is able to Grant Demo Access page because of his/her roles in other demos then when user serach the demo in Grant Demo Access page then there should not be any result.', async (done)=>
{
   let objData = dataProvider.getJsonData("./data/grantDemoAccess.json", "TC_03");
   console.log(objData);

   // Login as Global Admin User
   expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass"); 
   expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
   expect(await objLoginPage.clickLogin()).toContain("Pass");
   await browser.waitForAngularEnabled(true);
   expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
   
   //Search or the demo and update the CAT RAT Manager
   expect(await objHomePage.selectMenuOption("All Demo's", "Grant Demo Access")).toContain('Pass');
   expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');

   expect(await objCommonPage.clickInTheTableCell("Demo Name",sDemoName)).toContain('Pass');
   let sAlert="Security Access View"
   expect(await objCommonPage.verifyAlertHeader(sAlert)).toContain('Pass');
   expect(await objGrantDemoAccessPage.selectOwnerFromDD("CAT/RAT Manager",objData.catRatManager)).toContain('Pass');
   expect(await objAllViewPage.clickOnSave()).toContain('Pass');
   let sAlert1="Approval Saved Successfully"
   expect(await objCommonPage.verifyAlertMessage(sAlert1)).toContain('Pass');
   expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');


    // Take Login as CAT RAT Manager
    await browser.waitForAngularEnabled(false)
    await objHomePage.openApplication('/');      
    expect(await objLoginPage.setUserName(objLoginData.userNameCATRATManager)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordCATRATManager)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

    expect(await objHomePage.selectMenuOption("All Demo's", "Grant Demo Access")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.getSearchResults(sDemoName)).not.toContain('Pass');
    
   
    done();
})
it('TC_Pre-Requisite.', async(done)=>{
    let objData = dataProvider.getJsonData("./data/grantDemoAccess.json", "TC_Pre-Requisite");
    console.log(objData);
    //Login My Demo application
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    //select menu option
    expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
    expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
   
    var iRandomNum = Math.floor(1000 + Math.random() * 9000);
    sDemoName = "TestDemo_GrantDemoAccess" + iRandomNum;
    console.log(sDemoName);

    expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
    expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
   
    expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
    expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
    expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
    expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
    
    expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
    expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

    let sLoggedInUser;
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
    expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
    expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
    expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
    expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
    expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
    expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
    
    //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
    expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
    expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
    expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
    expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
    expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");;
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
    expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');

        //Approve the Newly created Demo on All view Page
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"New Request")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
    expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objData.demoOwner)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    let sAlert="Approval Saved Successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    done();
});
it('TC_03_2-"Verify that whenver user logs in as Other Group of a particular demo in MyDemo QA  then he/she shall not be able to access Grant Demo Access Page. If he/she is able to Grant Demo Access page because of his/her roles in other demos then when user serach the demo in Grant Demo Access page then there should not be any result.', async (done)=>
{
   let objData = dataProvider.getJsonData("./data/grantDemoAccess.json", "TC_03");
   console.log(objData);

   // Login as Global Admin User
   expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass"); 
   expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
   expect(await objLoginPage.clickLogin()).toContain("Pass");
   await browser.waitForAngularEnabled(true);
   expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
   
   //Search or the demo and update the Other Group User
   expect(await objHomePage.selectMenuOption("All Demo's", "Grant Demo Access")).toContain('Pass');
   expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');

   expect(await objCommonPage.clickInTheTableCell("Demo Name",sDemoName)).toContain('Pass');
   let sAlert="Security Access View"
   expect(await objCommonPage.verifyAlertHeader(sAlert)).toContain('Pass');
   expect(await objAllViewPage.setInputOnPopUp("Other Group",objData.otherGroup)).toContain('Pass');
   expect(await objAllViewPage.clickOnSave()).toContain('Pass');
   let sAlert1="Approval Saved Successfully"
   expect(await objCommonPage.verifyAlertMessage(sAlert1)).toContain('Pass');
   expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

    // Take Login as Other Group User
    await browser.waitForAngularEnabled(false)
    await objHomePage.openApplication('/');      
    expect(await objLoginPage.setUserName(objLoginData.userNameOtherGroupUser)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordOtherGroupUser)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

    expect(await objHomePage.selectMenuOption("All Demo's", "Grant Demo Access")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.getSearchResults(sDemoName)).not.toContain('Pass');
    done();
})
});