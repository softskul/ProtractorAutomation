import {browser, element, ExpectedConditions, by} from 'protractor';
import {homePage} from '../../pages/homePage.po';
import { commonPage } from '../../pages/commonPage.po';
import { newDemoRequest } from '../../pages/newDemoRequest.po';
import { myDraftRequestPage } from '../../pages/myDraftRequestPage.po';
import { myDemoRequestPage } from '../../pages/myDemoRequestPage.po';
import { dataProvider} from "../../data/dataProvider";
import { loginPage } from '../../pages/loginPage.po';
import { allViewPage } from '../../pages/allViewPage.po';
import { manageViewPage } from '../../pages/manageView.po';
import { adminAccessViewPage } from '../../pages/adminAccessViewPage.po';
import { allRequestPage } from '../../pages/allRequestPage.po';
import { win32 } from 'path';
import * as cp from 'child_process';
import { grantDemoAccessPage } from '../../pages/grantDemoAccessPage.po';


describe('Home Page Test cases', () => {
    const path = win32;
    let objHomePage:homePage;
    let objNewDemoRequest:newDemoRequest;
    let objMyDraftRequest:myDraftRequestPage;
    let objCommonPage: commonPage;
    let objMyDemoRequest: myDemoRequestPage;
    let objAllViewPage: allViewPage;
    let objLoginPage:loginPage;
    let objManageViewPage:manageViewPage;
    let objAdminAccessView:adminAccessViewPage;
    let objLoginData = dataProvider.getJsonData("./data/login.json", "login");
    let objAllRequestPage : allRequestPage
    let objGrantDemoAccessPage : grantDemoAccessPage
    let sDemoName ;
    let sAlertMessage = "";

    beforeEach(async () => {
        objHomePage = new homePage();
        objNewDemoRequest = new newDemoRequest();
        objMyDraftRequest = new myDraftRequestPage();
        objCommonPage = new commonPage();
        objAllViewPage = new allViewPage();
        objMyDemoRequest = new myDemoRequestPage();
        objManageViewPage = new manageViewPage();
        objLoginPage = new loginPage();
        objAdminAccessView = new adminAccessViewPage();
        objAllRequestPage = new allRequestPage
        objGrantDemoAccessPage = new grantDemoAccessPage
        await browser.waitForAngularEnabled(false);
        //Open application Url
        await objHomePage.openApplication('/');        
    });

    afterEach(() => {
        
    });


	it('TC_Pre-Requisite.', async(done)=>{
			let objData = dataProvider.getJsonData("./data/homePage.json", "TC_Pre-Requisite");
			console.log(objData);
			//Login My Demo application
			expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
			expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
			expect(await objLoginPage.clickLogin()).toContain("Pass");
			await browser.waitForAngularEnabled(true);
			expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
			//select menu option
			expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
			expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
			expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
			expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
		  
			var iRandomNum = Math.floor(1000 + Math.random() * 9000);
			sDemoName = "TestDemo_Home" + iRandomNum;
			console.log(sDemoName);
		
			expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
			expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
		  
			expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");

			expect(await objNewDemoRequest.clickOnDropDownOption("Application Segment", objData.appSegment)).toContain("Pass");
			expect(await objNewDemoRequest.clickOnDropDownOption("Device Type", objData.deviceType)).toContain("Pass");
			expect(await objNewDemoRequest.clickOnDropDownOption("AMAT Node", objData.amatNode)).toContain("Pass");

			expect(await objNewDemoRequest.setNumberInRangeField("Account TAM($M)", objData.accountTam)).toContain("Pass");
			expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
			expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
			expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");
		
			let sLoggedInUser;
			await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
			expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
			expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
			expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
			expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
			expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
			expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
			expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
		 
			//expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
			expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
			expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
			expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
			expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
			expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");
			expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
			expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');
		
			//Approve the Newly created Demo on All view Page
			expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
			expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
			expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"New Request")).toContain('Pass');
			expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
			expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
			expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objData.demoOwner)).toContain('Pass');
			expect(await objAllViewPage.clickOnSave()).toContain('Pass');
			let sAlert="Approval Saved Successfully"
			expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
			expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
			done();
		   
	}); 
	it('TC_01-Verify that User is able to launch MyDemo Homepage Successfully and Homepage should load as per the requirements.', async(done)=>{
			let objData = dataProvider.getJsonData("./data/homePage.json", "TC_01");
			console.log(objData);
			// Take Login As Global admin User
			expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
			expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
			expect(await objLoginPage.clickLogin()).toContain('Pass')
			await browser.waitForAngularEnabled(true);

			expect(await objHomePage.getMenuList()).toContain(objData.menuList);

			let sBannerText1 = await objHomePage.getBannerTextPart1();
			let sBannerText2 = await objHomePage.getBannerTextPart2();

			let sBannerText =  sBannerText1 +" "+sBannerText2
			expect(sBannerText).toContain(objData.bannerText);
			expect(await objHomePage.getDemoEntriesInTable("Demo Number")).toContain('Pass');
			expect(await objHomePage.verifyBuDDIsPresent()).toContain('Pass');
			expect(await objHomePage.verifyLegendPresent("Actions:")).toContain(objData.actionLegends);
			expect(await objHomePage.verifyLegendPresent("Milestones:")).toContain(objData.milestoneLegends);
			expect(await objCommonPage.getTableHeaders()).toContain(objData.headerTable);


			//Verify TAM Value is in Dec Order
			expect(await objHomePage.verifyAccountTAMValInDescOrder()).toContain("Pass");



			// Go to all view and check demo should not have priority as HIGH
			expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
			expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
			expect(await objCommonPage.verifyTextValueInTableCell("Priority", sDemoName, "H")).not.toContain('Pass');

			//Going on Home demo should not be present in the Table
			expect(await objHomePage.clickOnMenuOption("Home")).toContain('Pass');
			expect(await objCommonPage.verifyTextValueInTableCell("Demo Name", sDemoName, sDemoName)).not.toContain('Pass');

			//performed sorting
			let firstDemoNameInGrid = await objCommonPage.verifySorting("Demo Name");
			expect(await objCommonPage.getTheLatestDemoNm()).toContain(firstDemoNameInGrid);
		

			//Select BU and see the table result
			expect(await objHomePage.selectBU(objData.bU)).toContain('Pass');
			expect(await objCommonPage.geColDataList("Demo Number")).toContain(objData.bU);

		   

			// Go to all view and get the details of newly created demo having TAM Value high and Priority as HIGH
			expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
			expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
			expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"ACL-Approved")).toContain('Pass');
			expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","High")).toContain('Pass');
			expect(await objAllViewPage.clickOnSave()).toContain('Pass');
			let sAlert="Approval Saved Successfully"
			expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
			expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
			expect(await objCommonPage.verifyTextValueInTableCell("Priority", sDemoName, "H")).toContain('Pass');

			//Going on all view and checking same demo should be present on the Home Page.
			expect(await objHomePage.clickOnMenuOption("Home")).toContain('Pass');
			expect(await objCommonPage.verifyTextValueInTableCell("Demo Name", sDemoName, sDemoName)).toContain('Pass');


			// Take Login As Demo owner admin User to check home page as per access level
			await browser.waitForAngularEnabled(false);
			await objHomePage.openApplication('/');    
			expect(await objLoginPage.setUserName(objLoginData.userNameDemoOwner)).toContain('Pass');
			expect(await objLoginPage.setPassword(objLoginData.passwordDemoOwner)).toContain('Pass');
			expect(await objLoginPage.clickLogin()).toContain('Pass')
			await browser.waitForAngularEnabled(true);

			//Check User should be able to see demo on homepage

			expect(await objCommonPage.verifyTextValueInTableCell("Demo Name", sDemoName, sDemoName)).toContain('Pass');


			//Check User should be able to see demo on All view
			expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
			expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
			expect(await objCommonPage.verifyTextValueInTableCell("Demo Name", sDemoName, sDemoName)).toContain('Pass');


		   
			done();
	   
	});
	it('TC_02-Verify that user shall be able to Add comment for the required demo on home page of My Demo QA.', async(done)=>{
		let objData = dataProvider.getJsonData("./data/homePage.json", "TC_02");
		console.log(objData);
		// Take Login As Global admin User
		expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
		expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
		expect(await objLoginPage.clickLogin()).toContain('Pass');
		await browser.waitForAngularEnabled(true);
		expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")

		//Click on the Add Comment Button.
		expect(await objHomePage.clickOnTheIcon("Add Comment",sDemoName)).toContain('Pass');
		expect(await objAllViewPage.verifySaveBtnIsDisabledOnPopUp()).toContain('Pass');
		expect(await objHomePage.setCommentOnPopUp(objData.comment)).toContain('Pass');
		expect(await objHomePage.clickOnBtnOnPopUpIcon("Save")).toContain('Pass');
		expect(await objHomePage.clickOnBtnOnPopUpIcon("Cancel")).toContain('Pass');
		expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")
		

		done();

	});
	it('TC_03-Verify that user shall be able to Add Action for the required demo on home page of My Demo QA.', async(done)=>{
		let objData = dataProvider.getJsonData("./data/homePage.json", "TC_03");
		console.log(objData);
		// Take Login As BU Super User
		expect(await objLoginPage.setUserName(objLoginData.userNameBUSuperUser)).toContain('Pass');
		expect(await objLoginPage.setPassword(objLoginData.passwordBUSuperUser)).toContain('Pass');
		expect(await objLoginPage.clickLogin()).toContain('Pass');
		await browser.waitForAngularEnabled(true);
		expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
		let sDemoNumber = await objCommonPage.getTableCellValue("Demo Number",sDemoName);
		console.log(sDemoNumber);
		//Click on the Add Action Button.

		let actionCountBefore  = await objHomePage.getTheCountOnTheIcon(sDemoName,"Add Action");
		
		expect(await objHomePage.clickOnTheIcon("Add Action",sDemoName)).toContain('Pass');
		expect(await objCommonPage.verifyAlertHeader("Add Action: "+sDemoNumber+"")).toContain('Pass');
		expect(await objHomePage.verifyBtnIsDisabledOnPopUp("Save")).toContain('Pass');
		expect(await objHomePage.verifyBtnIsDisabledOnPopUp("Delete")).toContain('Pass');
		//verifying Col Header on the pop up
		expect(await objHomePage.getTableHeadersOnPopUp()).toContain(objData.headerTable);
		expect(await objHomePage.clickOnBtnOnPopUpIcon("Add New Item")).toContain('Pass');
		let sTodayDate = await objCommonPage.getCurrentDate("mm/dd/yyyy");
		console.log(sTodayDate);

		let sDate = await objHomePage.getTableCellValue("Created Date");
		let sCreateDate ="0"+sDate
		expect(sCreateDate).toContain(sTodayDate);

		expect(await objHomePage.getTableCellValue("Status")).toContain("Not Started");
		expect(await objHomePage.verifyViewButtonIsPresentOnPopUp()).toContain("Pass");
		expect(await objHomePage.clickInTheTableCellOnPopUp("Action Item")).toContain("Pass");
		expect(await objHomePage.setTextAreaInTableCellOnPopUp("Action Item",objData.actionItemText)).toContain('Pass');

		expect(await objHomePage.clickInTheTableCellOnPopUpJavascript("ECD")).toContain("Pass");
		expect(await objHomePage.selectDateFromdd("1", "Mar", "2021")).toContain("Pass");

		expect(await objHomePage.clickInTheTableCellOnPopUp("Owner")).toContain("Pass");
		expect(await objHomePage.selectOwnerOnActionPopUp("Owner",objData.ownerText,)).toContain('Pass');

		expect(await objHomePage.clickInTheTableCellOnPopUp("Comments")).toContain("Pass");
		expect(await objHomePage.setTextAreaInTableCellOnPopUp("Comments",objData.commentText)).toContain('Pass');

		expect(await objHomePage.clickOnBtnOnPopUpIcon("Save")).toContain('Pass');
		expect(await objHomePage.clickOnCancelBtnOnPopUpIcon()).toContain('Pass');
		expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
		expect(await objHomePage.clickOnMenuOption("Home")).toContain('Pass');


		let actionCountAfter  = await objHomePage.getTheCountOnTheIcon(sDemoName,"Add Action");

		expect(actionCountAfter).not.toContain(actionCountBefore);

		

		done();

	});
	it('TC_04-Verify that user shall be able to Delete Action for the required demo on home page of My Demo QA.', async(done)=>{
		let objData = dataProvider.getJsonData("./data/homePage.json", "TC_04");
		console.log(objData);
		// Take Login As BU Super User
		expect(await objLoginPage.setUserName(objLoginData.userNameBUSuperUser)).toContain('Pass');
		expect(await objLoginPage.setPassword(objLoginData.passwordBUSuperUser)).toContain('Pass');
		expect(await objLoginPage.clickLogin()).toContain('Pass');
		await browser.waitForAngularEnabled(true);
		expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

		let sDemoNumber = await objCommonPage.getTableCellValue("Demo Number",sDemoName);
		console.log(sDemoNumber);


		//Click on the Add Action Button.

		let actionCountBefore  = await objHomePage.getTheCountOnTheIcon(sDemoName,"Add Action");
		
		expect(await objHomePage.clickOnTheIcon("Add Action",sDemoName)).toContain('Pass');
		expect(await objCommonPage.verifyAlertHeader("Add Action: "+sDemoNumber+"")).toContain('Pass');
		expect(await objHomePage.verifyBtnIsDisabledOnPopUp("Save")).toContain('Pass');
		expect(await objHomePage.verifyBtnIsDisabledOnPopUp("Delete")).toContain('Pass');
		//verifying Col Header on the pop up
		expect(await objHomePage.getTableHeadersOnPopUp()).toContain(objData.headerTable);
		expect(await objHomePage.clickInTheCheckbox("Checkbox",objData.actionItemText)).toContain("Pass");
		expect(await objHomePage.clickOnBtnOnPopUpIcon("Delete")).toContain('Pass');

		expect(await objHomePage.clickOnCancelBtnOnPopUpIcon()).toContain('Pass');
		expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
		expect(await objHomePage.clickOnMenuOption("Home")).toContain('Pass');
		let actionCountAfter  = await objHomePage.getTheCountOnTheIcon(sDemoName,"Add Action");

		expect(actionCountAfter).not.toContain(actionCountBefore);

		done();

	});
	it('TC_05-Verify that user shall be able to Add Documents & Links using Attachment & External Link for the required demo on home page of My Demo QA.', async(done)=>{
		let objData = dataProvider.getJsonData("./data/homePage.json", "TC_05");
		console.log(objData);
		// Take Login As BU Super User
		expect(await objLoginPage.setUserName(objLoginData.userNameBUSuperUser)).toContain('Pass');
		expect(await objLoginPage.setPassword(objLoginData.passwordBUSuperUser)).toContain('Pass');
		expect(await objLoginPage.clickLogin()).toContain('Pass');
		await browser.waitForAngularEnabled(true);
		expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")


		let attachmentCountBefore  = await objHomePage.getTheCountOnTheIcon(sDemoName,"Attachment and External Link");

		// Attach the demo report by clicking on the attachement icon
		expect(await objHomePage.clickOnTheIcon("Attachment and External Link",sDemoName)).toContain('Pass');
		expect(await objAllRequestPage.clickOnBrowseButtonOnViewAttachment()).toContain("Pass");
		const filePath = path.resolve('./autoItScripts/Data_Report.xlsx');
		const exePath = path.resolve('./autoItScripts/browseFile.exe')
		cp.execSync(exePath + ' ' + filePath);
	   
		expect(await objAllViewPage.selectValueFromDDOnAttachmentPopUp("Security", objData.ddSecurityVal)).toContain("Pass");
		expect(await objAllViewPage.selectValueFromDDOnAttachmentPopUp("Category", "Demo Report")).toContain("Pass");
		
		expect(await objAllRequestPage.clickOnUploadButtonOnViewAttachment()).toContain("Pass");
		

		//Adding external Link
		expect(await objHomePage.clickOnExternalLinkLabelOnPopUp()).toContain('Pass');
		expect(await objHomePage.setExternalLinkPopUp(objData.link)).toContain('Pass');
		expect(await objHomePage.clickOnBtnOnPopUpIcon("Add")).toContain('Pass');
		expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');

		expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
		expect(await objHomePage.clickOnMenuOption("Home")).toContain('Pass');
		let attachmentCountAfter  = await objHomePage.getTheCountOnTheIcon(sDemoName,"Attachment and External Link");

		expect(attachmentCountAfter).not.toContain(attachmentCountBefore);

		done();

	});
	it('TC_06-Verify that user shall be able to view the details of the required demo on home page of My Demo QA using eye icon.', async(done)=>{
		let objData = dataProvider.getJsonData("./data/homePage.json", "TC_05");
		console.log(objData);
		// Take Login As BU Super User
		expect(await objLoginPage.setUserName(objLoginData.userNameBUSuperUser)).toContain('Pass');
		expect(await objLoginPage.setPassword(objLoginData.passwordBUSuperUser)).toContain('Pass');
		expect(await objLoginPage.clickLogin()).toContain('Pass');
		await browser.waitForAngularEnabled(true);
		expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")

		// Attach the demo report by clicking on the view icon

		let sDemoNumber = await objCommonPage.getTableCellValue("Demo Number",sDemoName);
		console.log(sDemoNumber);
		expect(await objHomePage.clickOnTheIcon("View Details",sDemoName)).toContain('Pass');
		let sAlert="Demo Detail: "+sDemoNumber+""
		expect(await objCommonPage.verifyAlertHeader(sAlert)).toContain('Pass');
		expect(await objAllRequestPage.verifySectionDisplayedOnPopUp("Customer Spec information")).toContain('Pass');
		expect(await objCommonPage.takeActionOnAlert("Close")).toContain('Pass');
		done();

	});
	it('TC_07-Verify that user shall not be able to edit/update any of the data on the Homepage.', async(done)=>{
		let objData = dataProvider.getJsonData("./data/homePage.json", "TC_07");
		console.log(objData);
		// Take Login As BU Super User
		expect(await objLoginPage.setUserName(objLoginData.userNameBUSuperUser)).toContain('Pass');
		expect(await objLoginPage.setPassword(objLoginData.passwordBUSuperUser)).toContain('Pass');
		expect(await objLoginPage.clickLogin()).toContain('Pass');
		await browser.waitForAngularEnabled(true);
		expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")

		// Click on the each Tble celll value
		expect(await objCommonPage.clickInTheTableCell("Priority",sDemoName)).toContain("Pass");
		expect(await objCommonPage.clickOnDDInTableCellUsingJavaScript("Priority")).not.toContain("Pass");

		expect(await objCommonPage.clickInTheTableCell("Execution Risk",sDemoName)).toContain("Pass");
		expect(await objCommonPage.clickOnDDInTableCellUsingJavaScript("Execution Risk")).not.toContain("Pass");
		done();

	});

	it('TC_Post-Requisite - Set project status to low', async(done)=>{
       
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");
        await browser.waitForAngularEnabled(true);

        //Approve the Newly created Demo on All view Page
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
        expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"ACL-Approved")).toContain('Pass');
        expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
        expect(await objAllViewPage.clickOnSave()).toContain('Pass');
        let sAlert="Approval Saved Successfully"
        expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
        expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
        done();
    
    });
});