import {browser, element, ExpectedConditions, by} from 'protractor';
import {homePage} from '../../pages/homePage.po';
import { commonPage } from '../../pages/commonPage.po';
import { newDemoRequest } from '../../pages/newDemoRequest.po';
import { myDraftRequestPage } from '../../pages/myDraftRequestPage.po';
import { myDemoRequestPage } from '../../pages/myDemoRequestPage.po';
import { dataProvider} from "../../data/dataProvider";
import { loginPage } from '../../pages/loginPage.po';
import { allViewPage } from '../../pages/allViewPage.po';
import { manageViewPage } from '../../pages/manageView.po';
import { adminAccessViewPage } from '../../pages/adminAccessViewPage.po';
import { allRequestPage } from '../../pages/allRequestPage.po';


describe('Admin Access View Test cases', () => {
    
    let objHomePage:homePage;
    let objNewDemoRequest:newDemoRequest;
    let objMyDraftRequest:myDraftRequestPage;
    let objCommonPage: commonPage;
    let objMyDemoRequest: myDemoRequestPage;
    let objAllViewPage: allViewPage;
    let objLoginPage:loginPage;
    let objManageViewPage:manageViewPage;
    let objAdminAccessView:adminAccessViewPage;
    let objLoginData = dataProvider.getJsonData("./data/login.json", "login");
    let objAllRequestPage : allRequestPage
    let sDemoName;
    let sAlertMessage = "";

    beforeEach(async () => {
        objHomePage = new homePage();
        objNewDemoRequest = new newDemoRequest();
        objMyDraftRequest = new myDraftRequestPage();
        objCommonPage = new commonPage();
        objAllViewPage = new allViewPage();
        objMyDemoRequest = new myDemoRequestPage();
        objManageViewPage = new manageViewPage();
        objLoginPage = new loginPage();
        objAdminAccessView = new adminAccessViewPage();
        objAllRequestPage = new allRequestPage
        await browser.waitForAngularEnabled(false);
        //Open application Url
        await objHomePage.openApplication('/');        
    });

    afterEach(() => {
        
    });
it('TC_Pre-Requisite.', async(done)=>{
        let objData = dataProvider.getJsonData("./data/grantDemoAccess.json", "TC_Pre-Requisite");
        console.log(objData);
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");
        await browser.waitForAngularEnabled(true);
        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
        //select menu option
        expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
       
        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_AdminView" + iRandomNum;
        console.log(sDemoName);
 
        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
       
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
        expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
        
        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        let sLoggedInUser;
        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
        
        //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
        expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
        expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
        expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
        expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");;
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
        expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');

            //Approve the Newly created Demo on All view Page
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
        expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"New Request")).toContain('Pass');
        expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
        expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
        expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objData.demoOwner)).toContain('Pass');
        expect(await objAllViewPage.clickOnSave()).toContain('Pass');
        let sAlert="Approval Saved Successfully"
        expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
        expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
        done();
}); 
it('TC_01-Verify that there will be a admin screen to assign user with different roles(Account Executive User) in MyDemo Application.', async(done)=>{
        let objData = dataProvider.getJsonData("./data/adminAccessView.json", "TC_01");
        console.log(objData);
        // Take Login As Global admin User
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
        expect(await objLoginPage.clickLogin()).toContain('Pass')
        await browser.waitForAngularEnabled(true);
        expect(await objHomePage.verifyHomePageDisplayed()).toContain('Pass');
        expect(await objHomePage.selectMenuOption('Admin', 'Admin Access View')).toContain('Pass');
        //Click on Add User Button and add Access level as "Account Executive User"
        expect(await objAdminAccessView.clickOnAddUserButton()).toContain('Pass');
        expect(await objAdminAccessView.selectOwnerOnPopUp("Display Name",objData.displayName)).toContain('Pass');
        expect(await objAdminAccessView.clickInTheTableCellWhileAddingUser("Access Level")).toContain('Pass');
        expect(await objCommonPage.selectOptionFromDDInTableColumn("Access Level","Account Executive User")).toContain('Pass');
        expect(await objAdminAccessView.doubleclickInTheTableCell("Account")).toContain('Pass');
        expect(await objAdminAccessView.clickOnMultiSelectDD()).toContain('Pass');
        expect(await objAdminAccessView.selectItemFromMutiSelectDDInTableCell(objData.account)).toContain("Pass");
        expect(await objAdminAccessView.clickInTheTableCellWhileAddingUser("BU")).toContain('Pass');
        let sAlert="Record added successfully"
        expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
        expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

        //Take Login as Newly Created Account Executive User & check edit access on all view page
        await browser.waitForAngularEnabled(false)
        await objHomePage.openApplication('/');      
        expect(await objLoginPage.setUserName(objData.displayName)).toContain("Pass");
        expect(await objLoginPage.setPassword(objData.passwordDisplayName)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");
        await browser.waitForAngularEnabled(true);
        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');

        expect(await objCommonPage.goToColumn("Current Execution Risk")).toContain('Pass');
        expect(await objCommonPage.clickInTheTableCell("Current Execution Risk",sDemoName)).toContain('Pass');
        expect(await objCommonPage.clickOnDDInTableCellUsingJavaScript("Current Execution Risk")).not.toContain('Pass');
        done();
   
});
it('TC_02-Verify that a user access can be removed from admin access screen.', async(done)=>{
    let objData = dataProvider.getJsonData("./data/adminAccessView.json", "TC_02");
    console.log(objData);
    // Take Login As Global admin User
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain('Pass')
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain('Pass');
    expect(await objHomePage.selectMenuOption('Admin', 'Admin Access View')).toContain('Pass');
    //Select the checkbox and remove the user.
    expect(await objAdminAccessView.clickInTheTableCell('Checkbox', objData.displayUser)).toContain('Pass');
    expect(await objAdminAccessView.clickOnRemoveUserButton()).toContain('Pass');
    let sAlert="Record deleted successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    
   done();

});
it('TC_03-Verify that added user (Global Admin) from the admin will have defined access in MyDemo application.', async(done)=>{
    let objData = dataProvider.getJsonData("./data/adminAccessView.json", "TC_03");
        console.log(objData);
        // Take Login As Global admin User
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
        expect(await objLoginPage.clickLogin()).toContain('Pass')
        await browser.waitForAngularEnabled(true);
        expect(await objHomePage.verifyHomePageDisplayed()).toContain('Pass');
        expect(await objHomePage.selectMenuOption('Admin', 'Admin Access View')).toContain('Pass');
        //Click on Add User Button and add Access level as "Global Admin User"
        expect(await objAdminAccessView.clickOnAddUserButton()).toContain('Pass');
        expect(await objAdminAccessView.selectOwnerOnPopUp("Display Name",objData.displayName)).toContain('Pass');
        expect(await objAdminAccessView.clickInTheTableCellWhileAddingUser("Access Level")).toContain('Pass');
        expect(await objCommonPage.selectOptionFromDDInTableColumn("Access Level","Global Admin")).toContain('Pass');
        let sAlert="Record added successfully"
        expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
        expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

        //Take Login as Newly Created Global Admin & check edit access on all view page
        await browser.waitForAngularEnabled(false)
        await objHomePage.openApplication('/');      
        expect(await objLoginPage.setUserName(objData.displayName)).toContain("Pass");
        expect(await objLoginPage.setPassword(objData.passwordDisplayName)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");
        await browser.waitForAngularEnabled(true);
        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');

        expect(await objCommonPage.goToColumn("Current Execution Risk")).toContain('Pass');
        expect(await objCommonPage.clickInTheTableCell("Current Execution Risk",sDemoName)).toContain('Pass');
        expect(await objCommonPage.selectOptionFromDDInTableColumn("Current Execution Risk","High")).toContain('Pass');




       // Take Login As Global admin User and remove newly created Global admin User
        await browser.waitForAngularEnabled(false)
        await objHomePage.openApplication('/');     
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
        expect(await objLoginPage.clickLogin()).toContain('Pass')
        await browser.waitForAngularEnabled(true);
        expect(await objHomePage.verifyHomePageDisplayed()).toContain('Pass');
        expect(await objHomePage.selectMenuOption('Admin', 'Admin Access View')).toContain('Pass');
       //Select the checkbox and remove the user.

        expect(await objAdminAccessView.clickInTheTableCell('Checkbox', objData.displayName)).toContain('Pass');
        expect(await objAdminAccessView.clickOnRemoveUserButton()).toContain('Pass');
        let sAlert1="Record deleted successfully"
        expect(await objCommonPage.verifyAlertMessage(sAlert1)).toContain('Pass');
        expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    
        done();

});
it('TC_03_1-Verify that added user (Account Super User) from the admin will have defined access in MyDemo application.', async(done)=>{
    let objData = dataProvider.getJsonData("./data/adminAccessView.json", "TC_03");
        console.log(objData);
        // Take Login As Global admin User
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
        expect(await objLoginPage.clickLogin()).toContain('Pass')
        await browser.waitForAngularEnabled(true);
        expect(await objHomePage.verifyHomePageDisplayed()).toContain('Pass');
        expect(await objHomePage.selectMenuOption('Admin', 'Admin Access View')).toContain('Pass');
        //Click on Add User Button and add Access level as "Account Super User User"
        expect(await objAdminAccessView.clickOnAddUserButton()).toContain('Pass');
        expect(await objAdminAccessView.selectOwnerOnPopUp("Display Name",objData.displayName)).toContain('Pass');
        expect(await objAdminAccessView.clickInTheTableCellWhileAddingUser("Access Level")).toContain('Pass');
        expect(await objCommonPage.selectOptionFromDDInTableColumn("Access Level","Account Super User")).toContain('Pass');
        expect(await objAdminAccessView.doubleclickInTheTableCell("Account")).toContain('Pass');
        expect(await objAdminAccessView.clickOnMultiSelectDD()).toContain('Pass');
        expect(await objAdminAccessView.selectItemFromMutiSelectDDInTableCell(objData.account)).toContain("Pass");
        expect(await objAdminAccessView.clickInTheTableCellWhileAddingUser("BU")).toContain('Pass');
        let sAlert="Record added successfully"
        expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
        expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

        //Take Login as Newly Created Account Super User & check edit access on all view page
        await browser.waitForAngularEnabled(false)
        await objHomePage.openApplication('/');      
        expect(await objLoginPage.setUserName(objData.displayName)).toContain("Pass");
        expect(await objLoginPage.setPassword(objData.passwordDisplayName)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");
        await browser.waitForAngularEnabled(true);
        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');

        expect(await objCommonPage.goToColumn("Current Execution Risk")).toContain('Pass');
        expect(await objCommonPage.clickInTheTableCell("Current Execution Risk",sDemoName)).toContain('Pass');
        expect(await objCommonPage.selectOptionFromDDInTableColumn("Current Execution Risk","Low")).toContain('Pass');
        
       // Take Login As Global admin User and remove newly created Account Super User
        await browser.waitForAngularEnabled(false)
        await objHomePage.openApplication('/');     
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
        expect(await objLoginPage.clickLogin()).toContain('Pass')
        await browser.waitForAngularEnabled(true);
        expect(await objHomePage.verifyHomePageDisplayed()).toContain('Pass');
        expect(await objHomePage.selectMenuOption('Admin', 'Admin Access View')).toContain('Pass');
       //Select the checkbox and remove the user.

        expect(await objAdminAccessView.clickInTheTableCell('Checkbox', objData.displayName)).toContain('Pass');
        expect(await objAdminAccessView.clickOnRemoveUserButton()).toContain('Pass');
        let sAlert1="Record deleted successfully"
        expect(await objCommonPage.verifyAlertMessage(sAlert1)).toContain('Pass');
        expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    
        done();

});
it('TC_03_2-Verify that added user (BU Super User ) from the admin will have defined access in MyDemo application.', async(done)=>{
    let objData = dataProvider.getJsonData("./data/adminAccessView.json", "TC_03");
        console.log(objData);
        // Take Login As Global admin User
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
        expect(await objLoginPage.clickLogin()).toContain('Pass')
        await browser.waitForAngularEnabled(true);
        expect(await objHomePage.verifyHomePageDisplayed()).toContain('Pass');
        expect(await objHomePage.selectMenuOption('Admin', 'Admin Access View')).toContain('Pass');
        //Click on Add User Button and add Access level as "BU Super User"
        expect(await objAdminAccessView.clickOnAddUserButton()).toContain('Pass');
        expect(await objAdminAccessView.selectOwnerOnPopUp("Display Name",objData.displayName)).toContain('Pass');
        expect(await objAdminAccessView.clickInTheTableCellWhileAddingUser("Access Level")).toContain('Pass');
        expect(await objCommonPage.selectOptionFromDDInTableColumn("Access Level","BU Super User")).toContain('Pass');
        expect(await objAdminAccessView.clickInTheTableCellWhileAddingUser("BU")).toContain('Pass');
        expect(await objAdminAccessView.clickOnMultiSelectDD()).toContain('Pass');
        expect(await objAdminAccessView.selectItemFromMutiSelectDDInTableCell(objData.bU)).toContain("Pass");
        expect(await objAdminAccessView.clickInTheTableCellWhileAddingUser("Created By")).toContain('Pass');
       
        let sAlert="Record added successfully"
        expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
        expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

        //Take Login as Newly Created BU Super User & check edit access on all view page
        await browser.waitForAngularEnabled(false)
        await objHomePage.openApplication('/');      
        expect(await objLoginPage.setUserName(objData.displayName)).toContain("Pass");
        expect(await objLoginPage.setPassword(objData.passwordDisplayName)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");
        await browser.waitForAngularEnabled(true);
        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');

        expect(await objCommonPage.goToColumn("Current Execution Risk")).toContain('Pass');
        expect(await objCommonPage.clickInTheTableCell("Current Execution Risk",sDemoName)).toContain('Pass');
        expect(await objCommonPage.selectOptionFromDDInTableColumn("Current Execution Risk","Low")).toContain('Pass');
        

       // Take Login As Global admin User and remove newly created BU Super User
        await browser.waitForAngularEnabled(false)
        await objHomePage.openApplication('/');     
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
        expect(await objLoginPage.clickLogin()).toContain('Pass')
        await browser.waitForAngularEnabled(true);
        expect(await objHomePage.verifyHomePageDisplayed()).toContain('Pass');
        expect(await objHomePage.selectMenuOption('Admin', 'Admin Access View')).toContain('Pass');
       //Select the checkbox and remove the user.

        expect(await objAdminAccessView.clickInTheTableCell('Checkbox', objData.displayName)).toContain('Pass');
        expect(await objAdminAccessView.clickOnRemoveUserButton()).toContain('Pass');
        let sAlert1="Record deleted successfully"
        expect(await objCommonPage.verifyAlertMessage(sAlert1)).toContain('Pass');
        expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    
        done();

});
it('TC_03_3-Verify that added user (BU Executive User ) from the admin will have defined access in MyDemo application.', async(done)=>{
    let objData = dataProvider.getJsonData("./data/adminAccessView.json", "TC_03");
    console.log(objData);
    // Take Login As Global admin User
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain('Pass')
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain('Pass');
    expect(await objHomePage.selectMenuOption('Admin', 'Admin Access View')).toContain('Pass');
    //Click on Add User Button and add Access level as "BU Super User"
    expect(await objAdminAccessView.clickOnAddUserButton()).toContain('Pass');
    expect(await objAdminAccessView.selectOwnerOnPopUp("Display Name",objData.displayName)).toContain('Pass');
    expect(await objAdminAccessView.clickInTheTableCellWhileAddingUser("Access Level")).toContain('Pass');
    expect(await objCommonPage.selectOptionFromDDInTableColumn("Access Level","BU Executive User")).toContain('Pass');
    expect(await objAdminAccessView.clickInTheTableCellWhileAddingUser("BU")).toContain('Pass');
    expect(await objAdminAccessView.clickOnMultiSelectDD()).toContain('Pass');
    expect(await objAdminAccessView.selectItemFromMutiSelectDDInTableCell(objData.bU)).toContain("Pass");
    expect(await objAdminAccessView.clickInTheTableCellWhileAddingUser("Created By")).toContain('Pass');
   
    let sAlert="Record added successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

    //Take Login as Newly Created BU Executive User & check edit access on all view page
    await browser.waitForAngularEnabled(false)
    await objHomePage.openApplication('/');      
    expect(await objLoginPage.setUserName(objData.displayName)).toContain("Pass");
    expect(await objLoginPage.setPassword(objData.passwordDisplayName)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');

    expect(await objCommonPage.goToColumn("Current Execution Risk")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Current Execution Risk",sDemoName)).toContain('Pass');
    expect(await objCommonPage.clickOnDDInTableCellUsingJavaScript("Current Execution Risk")).not.toContain('Pass');

   // Take Login As Global admin User and remove newly created BU Executive User
    await browser.waitForAngularEnabled(false)
    await objHomePage.openApplication('/');     
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain('Pass')
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain('Pass');
    expect(await objHomePage.selectMenuOption('Admin', 'Admin Access View')).toContain('Pass');
   //Select the checkbox and remove the user.

    expect(await objAdminAccessView.clickInTheTableCell('Checkbox', objData.displayName)).toContain('Pass');
    expect(await objAdminAccessView.clickOnRemoveUserButton()).toContain('Pass');
    let sAlert1="Record deleted successfully"
    expect(await objCommonPage.verifyAlertMessage(sAlert1)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

    done();
});
it('TC_04-Verify that filters shall be applied to the column in Admin access view.', async(done)=>{
    let objData = dataProvider.getJsonData("./data/adminAccessView.json", "TC_04");
    console.log(objData);
    // Take Login As Global admin User
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain('Pass')
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain('Pass');
    expect(await objHomePage.selectMenuOption('Admin', 'Admin Access View')).toContain('Pass');
    // Select Any col (Display User) and Apply Filter Icon
    expect(await objCommonPage.clickOnTableHdrMenuIcon("Display Name")).toContain("Pass");
    expect(await objCommonPage.clickOnTableHdrFilterIcon()).toContain("Pass");
    expect(await objCommonPage.selectItemFromMutiSelectDD("(Select All)")).toContain("Pass");
    expect(await objAdminAccessView.setSearchInFilter(objData.displayName)).toContain("Pass");
    expect(await objCommonPage.selectItemFromMutiSelectDD(objData.displayName)).toContain("Pass");

    expect(await objCommonPage.clickOnTableHdrFilterIcon()).toContain("Pass");
    let sDisplayNameList = await objAdminAccessView.geColDataListOnAdminView("Display Name")
    let sDisplayName = sDisplayNameList.split("~");
    expect(sDisplayName).toContain(objData.displayName);
    done();

});
it('TC_05-Verify that whenever user tries to edit the value in Admin screen the he/she shall not be able to do the same.', async(done)=>{
    let objData = dataProvider.getJsonData("./data/adminAccessView.json", "TC_05");
    console.log(objData);
    // Take Login As Global admin User
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain('Pass')
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain('Pass');
    expect(await objHomePage.selectMenuOption('Admin', 'Admin Access View')).toContain('Pass');
    //Try to Edit Access Level of the existing user
    expect(await objAdminAccessView.doubleclickInTheTableCell("Access Level")).toContain('Pass');
    
    let sAlert='For assigning new role please remove the exisiting role by clicking "Remove User" Button.'
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    
   done();

});
});