import {browser, element, ExpectedConditions, by} from 'protractor';
import {homePage} from '../../pages/homePage.po';
import { commonPage } from '../../pages/commonPage.po';
import { newDemoRequest } from '../../pages/newDemoRequest.po';
import { myDraftRequestPage } from '../../pages/myDraftRequestPage.po';
import { myDemoRequestPage } from '../../pages/myDemoRequestPage.po';
import { approvalsPage } from '../../pages/approvalsPage.po';
import { allViewPage } from '../../pages/allViewPage.po';
import { dataProvider} from "../../data/dataProvider";
import {excelWrapper} from '../../utils/excel.util';
import { win32 } from 'path';

describe('Sprint 14 test cases', () => {
    const sprint14_TC_Data = require('../../../data/sprint14_TCs.json');
    const path = win32;
    let objHomePage:homePage;
    let objNewDemoRequest:newDemoRequest;
    let objMyDraftRequest:myDraftRequestPage;
    let objCommonPage: commonPage;
    let objMyDemoRequest: myDemoRequestPage;
    let objApprovalsPage: approvalsPage;
    let objAllViewPage: allViewPage;
	let objExcelWrapper: excelWrapper;
    let sDemoName = "";
    let sAlertMessage = "";
    

    beforeEach(async () => {
        objHomePage = new homePage();
        objNewDemoRequest = new newDemoRequest();
        objMyDraftRequest = new myDraftRequestPage();
        objCommonPage = new commonPage();
        objMyDemoRequest = new myDemoRequestPage();
        objApprovalsPage = new approvalsPage();
        objAllViewPage = new allViewPage();
		objExcelWrapper = new excelWrapper();
        await browser.waitForAngularEnabled(false);
        //Open application Url
        await objHomePage.openApplication('/');        
    });

    afterEach(() => {
		objHomePage = null;
        objCommonPage = null;
        objExcelWrapper = null;
    });

   /*it('Pre-requisite test to create demo with Pending Review status', async()=>{
        let objData = dataProvider.getJsonData("./data/sprint14_TCs.json", "MyDemo_TC_02");
        console.info(objData);
        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_" + iRandomNum;
        console.info(sDemoName);
        let sLoggedInUser;
        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toBe(true);
        browser.waitForAngularEnabled(true);
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toBe(true);
        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toBe(true);
        expect(await objNewDemoRequest.toggleField('TAMBA', true)).toBe(true);
        
        expect(await objNewDemoRequest.clickOnTAMBASearch()).toBe(true);
        expect(await objNewDemoRequest.selectFromBUONTAMBASearchPopUp(sprint14_TC_Data.MyDemo_TC_02.bu)).toBe(true);
        expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(sprint14_TC_Data.MyDemo_TC_02.account)).toBe(true);
        expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toBe(true);
        expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toBe(true);
        expect(await objNewDemoRequest.clickOnSubmit()).toBe(true);
        await objNewDemoRequest.verifyTambaDtlsOnNewDemoForm();
        expect(await objNewDemoRequest.enterHVP(sprint14_TC_Data.MyDemo_TC_02.hvp)).toBe(true);
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toBe(true);
        expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toBe(true);
        expect(await objNewDemoRequest.selectDemoType(sprint14_TC_Data.MyDemo_TC_02.demoType)).toBe(true);
        expect(await objNewDemoRequest.setSuccessCriteria(sprint14_TC_Data.MyDemo_TC_02.successCriteria)).toBe(true);
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toBe(true);
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toBe(true);
        expect(await objNewDemoRequest.selectSubstrateType(sprint14_TC_Data.MyDemo_TC_02.substrateType)).toBe(true);
        expect(await objNewDemoRequest.clickCustomerSpecOption(sprint14_TC_Data.MyDemo_TC_02.customerSpecOption)).toBe(true);
        
        expect(await objNewDemoRequest.setAttributeCategory(sprint14_TC_Data.MyDemo_TC_02.attributeCategory)).toBe(true);
        expect(await objNewDemoRequest.setAttribute(sprint14_TC_Data.MyDemo_TC_02.attribute)).toBe(true);
        expect(await objNewDemoRequest.setMarketSegmentReq(sprint14_TC_Data.MyDemo_TC_02.marketSegReq)).toBe(true);
        expect(await objNewDemoRequest.selectWeighPriority(sprint14_TC_Data.MyDemo_TC_02.weightProperty)).toBe(true);
        expect(await objNewDemoRequest.clickOnAttributeSave());
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toBe(true);
        sAlertMessage = "Demo Request submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toBe(true);
     
    });

    
    it('Verify that user shall be able to see Approved by column in exported excel from the grid so that he/she will get to know that who approved the demo', async()=>{

        //Did not validate On Hold Request Page as Approved By column is not displayed
        const os = require('os');     
        const sDownloadPath = os.homedir()+"/Downloads/";
        
        let objData = dataProvider.getJsonData("./data/sprint14_TCs.json", "MyDemo_TC_02");
        console.info("Sprint 14 - MyDemo_TC_02 =>" + objData);
        let sLoggedInUser;
        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});

        expect(await objHomePage.verifyHomePageDisplayed()).toBe(true);
        await browser.waitForAngularEnabled(true);
        await objCommonPage.getCurrentDate("mm/dd/yyyy");
    
        //New Request
        expect(await objHomePage.selectMenuOption("Approvals", objData.new_request)).toBeTruthy();
        await objCommonPage.deleteFileFromDownloadsDir(sDownloadPath+objData.newRequest_excel+".xlsx"); 
        expect(await objCommonPage.goToColumn(objData.column_Name)); 
        expect(await objCommonPage.clickExportButton(objData.new_request)).toBe(true);
        expect(await objCommonPage.searchRequest(sDemoName)).toBe(true);
        expect(await objApprovalsPage.verifyApprovedByUserName(sDemoName, "")).toBe(true);//Approver name is null coz request is not yet approved
        expect(await objExcelWrapper.verifyExcelCellValuesofSingleRowForSpecifiedColumn(sDownloadPath + objData.newRequest_excel+".xlsx",objData.newRequest_excel,objData.excel_columns,sDemoName+"~")).toBe(true); //Approver is not present as status is 'Penidng Review'
               
   
        //Change demo request status from Pending to Approve 
        expect(await objHomePage.selectMenuOption("Approvals", objData.new_request)).toBe(true);
        expect(await objCommonPage.searchRequest(sDemoName)).toBe(true);
        expect(await objApprovalsPage.clickOnDemoRequestRow(sDemoName)).toBe(true);
        expect(await objCommonPage.verifyAlertHeader("Approval View")).toBe(true);
        expect(await objApprovalsPage.selectDemoApproval(objData.demoApprovalStatus)).toBe(true);
        expect(await objApprovalsPage.selectPriority(objData.priority)).toBe(true);
        expect(await objApprovalsPage.setDemoOwner(objData.demoOwner)).toBe(true);
        expect(await objApprovalsPage.setCATRATManager(sLoggedInUser)).toBe(true);
        expect(await objApprovalsPage.selectExecutionRisk("Medium")).toBe(true); 
        await objApprovalsPage.clickOnSaveApprovalView();
        sAlertMessage = "Approval Saved Successfully."
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK"));


        //Approve Request
        expect(await objHomePage.selectMenuOption("Approvals", objData.approved_request)).toBeTruthy();
        await objCommonPage.deleteFileFromDownloadsDir(sDownloadPath+objData.approvedRequest_excel+".xlsx"); 
        expect(await objCommonPage.goToColumn(objData.column_Name)); 
        expect(await objCommonPage.clickExportButton(objData.approved_request)).toBe(true);
        expect(await objCommonPage.searchRequest(sDemoName)).toBe(true);
        expect(await objApprovalsPage.verifyApprovedByUserName(sDemoName, sLoggedInUser)).toBe(true);
        expect(await objExcelWrapper.verifyExcelCellValuesofSingleRowForSpecifiedColumn(sDownloadPath + objData.approvedRequest_excel+".xlsx",objData.approvedRequest_excel,objData.excel_columns,sDemoName+"~"+sLoggedInUser)).toBe(true);


        //Account view
        expect(await objHomePage.selectMenuOption("All Demo's", objData.acc_view)).toBeTruthy();  
        await objCommonPage.deleteFileFromDownloadsDir(sDownloadPath + objData.acc_view+".xlsx"); 
        expect(await objCommonPage.goToColumn(objData.column_Name));     
        expect(await objCommonPage.clickExportButton(objData.acc_view)).toBe(true);
        expect(await objCommonPage.searchRequest(sDemoName)).toBe(true);
        expect(await objApprovalsPage.verifyApprovedByUserName(sDemoName, sLoggedInUser)).toBe(true);
        
        //BU view
        expect(await objHomePage.selectMenuOption("All Demo's", objData.bu_view)).toBeTruthy();
        await objCommonPage.deleteFileFromDownloadsDir(sDownloadPath+objData.bu_excel+".xlsx"); 
        expect(await objCommonPage.goToColumn(objData.column_Name));    
        expect(await objCommonPage.clickExportButton(objData.bu_view)).toBe(true);
        expect(await objCommonPage.searchRequest(sDemoName)).toBe(true);
        expect(await objApprovalsPage.verifyApprovedByUserName(sDemoName, sLoggedInUser)).toBe(true);
        //Demo Team view
        expect(await objHomePage.selectMenuOption("All Demo's", objData.demo_view)).toBeTruthy();
        await objCommonPage.deleteFileFromDownloadsDir(sDownloadPath+objData.demo_view+".xlsx"); 
        expect(await objCommonPage.goToColumn(objData.column_Name));   
        expect(await objCommonPage.clickExportButton(objData.demo_view)).toBe(true);
        expect(await objCommonPage.searchRequest(sDemoName)).toBe(true);
        expect(await objApprovalsPage.verifyApprovedByUserName(sDemoName, sLoggedInUser)).toBe(true);
        //ALL view
        expect(await objHomePage.selectMenuOption("All Demo's", objData.all_view)).toBeTruthy();
        await objCommonPage.deleteFileFromDownloadsDir(sDownloadPath+objData.all_view+".xlsx");
        expect(await objCommonPage.goToColumn(objData.column_Name)); 
        expect(await objCommonPage.clickExportButton(objData.all_view)).toBe(true);
        expect(await objCommonPage.searchRequest(sDemoName)).toBe(true);
        expect(await objApprovalsPage.verifyApprovedByUserName(sDemoName, sLoggedInUser)).toBe(true);


        //Account view               
        expect(await objExcelWrapper.verifyExcelCellValuesofSingleRowForSpecifiedColumn(sDownloadPath + objData.acc_view+".xlsx",objData.acc_view,objData.excel_columns,sDemoName+"~"+sLoggedInUser)).toBe(true);
        //BU view               
        expect(await objExcelWrapper.verifyExcelCellValuesofSingleRowForSpecifiedColumn(sDownloadPath + objData.bu_excel+".xlsx",objData.bu_excel,objData.excel_columns,sDemoName+"~"+sLoggedInUser)).toBe(true);
        //Demo Team view               
        expect(await objExcelWrapper.verifyExcelCellValuesofSingleRowForSpecifiedColumn(sDownloadPath + objData.demo_view+".xlsx",objData.demo_view,objData.excel_columns,sDemoName+"~"+sLoggedInUser)).toBe(true);
        //ALL view               
        expect(await objExcelWrapper.verifyExcelCellValuesofSingleRowForSpecifiedColumn(sDownloadPath + objData.all_view+".xlsx",objData.all_view,objData.excel_columns,sDemoName+"~"+sLoggedInUser)).toBe(true);
        
    });*/

    it('MyDemo_TC_10 - Verify that user shall be able to submit an internal demo with special group disabled', async()=>{
        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "InternalTestDemo_" + iRandomNum;
        console.info(sDemoName);
        let objData = dataProvider.getJsonData("./data/sprint14_TCs.json", "MyDemo_TC_10");
        console.info(objData);
        let sLoggedInUser;
        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        expect(await objHomePage.verifyHomePageDisplayed()).toBe(true);
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toBe(true);
        browser.waitForAngularEnabled(true);
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toBe(true);
        expect(await objNewDemoRequest.toggleField('Internal Demo', true)).toBe(true);
        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toBe(true);
        
        expect(await objNewDemoRequest.setInternalAccount(objData.internalAccount)).toBe(true);
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBU)).toBe(true);
        expect(await objNewDemoRequest.enterHVP(objData.hvp)).toBe(true);
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toBe(true);
        expect(await objNewDemoRequest.setInternalAccountOwner(sLoggedInUser)).toBe(true);
        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toBe(true);
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toBe(true);
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toBe(true);
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toBe(true);
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toBe(true);
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toBe(true);
        sAlertMessage = "Demo Request submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toBe(true);
        expect(await objHomePage.selectMenuOption("Requests", "My Demo Request")).toBe(true);
        expect(await objMyDemoRequest.verifyDemoPresentInTable(sDemoName)).toBe(true);
        expect(await objMyDemoRequest.verifyDemoApprovalStatus(sDemoName, "Pending Review")).toBe(true);

        //approve request
       
        expect(await objHomePage.selectMenuOption("Approvals", "New Requests")).toBe(true);
        
        expect(await objCommonPage.searchRequest(sDemoName)).toBe(true);
        expect(await objApprovalsPage.clickOnDemoRequestRow(sDemoName)).toBe(true);
        
        expect(await objCommonPage.verifyAlertHeader("Approval View")).toBe(true);
        
        expect(await objApprovalsPage.selectDemoApproval(objData.demoApprovalStatus)).toBe(true);
        expect(await objApprovalsPage.selectPriority(objData.priority)).toBe(true);
        expect(await objApprovalsPage.setDemoOwner(objData.demoOwner)).toBe(true);
        expect(await objApprovalsPage.setCATRATManager(sLoggedInUser)).toBe(true);
        expect(await objApprovalsPage.selectExecutionRisk("Medium")).toBe(true); 
        await objApprovalsPage.clickOnSaveApprovalView();
        sAlertMessage = "Approval Saved Successfully."
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK"));
    });
});