import {browser, element, ExpectedConditions, by} from 'protractor';
import {homePage} from '../../pages/homePage.po';
import { commonPage } from '../../pages/commonPage.po';
import { newDemoRequest } from '../../pages/newDemoRequest.po';
import { myDraftRequestPage } from '../../pages/myDraftRequestPage.po';
import { myDemoRequestPage } from '../../pages/myDemoRequestPage.po';
import { approvalsPage } from '../../pages/approvalsPage.po';
import { allViewPage } from '../../pages/allViewPage.po';
import { dataProvider} from "../../data/dataProvider";
import {excelWrapper} from '../../utils/excel.util';

describe('Sprint 11 test cases', () => {
    const sprint11_TC_Data = require('../../../data/sprint11_TCs.json');
    let objHomePage:homePage;
    let objNewDemoRequest:newDemoRequest;
    let objMyDraftRequest:myDraftRequestPage;
    let objCommonPage: commonPage;
    let objMyDemoRequest: myDemoRequestPage;
    let objApprovalsPage: approvalsPage;
    let objAllViewPage: allViewPage;
	let objExcelWrapper: excelWrapper;
    let sDemoName = "";
    let sAlertMessage = "";

    beforeEach(async () => {
        objHomePage = new homePage();
        objNewDemoRequest = new newDemoRequest();
        objMyDraftRequest = new myDraftRequestPage();
        objCommonPage = new commonPage();
        objMyDemoRequest = new myDemoRequestPage();
        objApprovalsPage = new approvalsPage();
        objAllViewPage = new allViewPage();
		objExcelWrapper = new excelWrapper();
        await browser.waitForAngularEnabled(false);
        //Open application Url
        await objHomePage.openApplication('/');        
    });

    afterEach(() => {
		objHomePage = null;
        objCommonPage = null;
        objExcelWrapper = null;
    });

   it('Pre-requisite test to create demo with status ACL approved status', async()=>{
        
        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_" + iRandomNum;
        console.info(sDemoName);
        let sLoggedInUser;
        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toBe(true);
        browser.waitForAngularEnabled(true);
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toBe(true);
        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toBe(true);
        expect(await objNewDemoRequest.toggleField('TAMBA', true)).toBe(true);
        
        expect(await objNewDemoRequest.clickOnTAMBASearch()).toBe(true);
        expect(await objNewDemoRequest.selectFromBUONTAMBASearchPopUp(sprint11_TC_Data.MyDemo_TC_01.bu)).toBe(true);
        expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(sprint11_TC_Data.MyDemo_TC_01.account)).toBe(true);
        expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toBe(true);
        expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toBe(true);
        expect(await objNewDemoRequest.clickOnSubmit()).toBe(true);
        await objNewDemoRequest.verifyTambaDtlsOnNewDemoForm();
        expect(await objNewDemoRequest.enterHVP(sprint11_TC_Data.MyDemo_TC_01.hvp)).toBe(true);
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toBe(true);
        expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toBe(true);
        expect(await objNewDemoRequest.selectDemoType(sprint11_TC_Data.MyDemo_TC_01.demoType)).toBe(true);
        expect(await objNewDemoRequest.setSuccessCriteria(sprint11_TC_Data.MyDemo_TC_01.successCriteria)).toBe(true);
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toBe(true);
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toBe(true);
        expect(await objNewDemoRequest.selectSubstrateType(sprint11_TC_Data.MyDemo_TC_01.substrateType)).toBe(true);
        expect(await objNewDemoRequest.clickCustomerSpecOption(sprint11_TC_Data.MyDemo_TC_01.customerSpecOption)).toBe(true);
        
        expect(await objNewDemoRequest.setAttributeCategory(sprint11_TC_Data.MyDemo_TC_01.attributeCategory)).toBe(true);
        expect(await objNewDemoRequest.setAttribute(sprint11_TC_Data.MyDemo_TC_01.attribute)).toBe(true);
        expect(await objNewDemoRequest.setMarketSegmentReq(sprint11_TC_Data.MyDemo_TC_01.marketSegReq)).toBe(true);
        expect(await objNewDemoRequest.selectWeighPriority(sprint11_TC_Data.MyDemo_TC_01.weightProperty)).toBe(true);
        expect(await objNewDemoRequest.clickOnAttributeSave());
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toBe(true);
        sAlertMessage = "Demo Request submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toBe(true);
        expect(await objHomePage.selectMenuOption("Requests", "My Demo Request")).toBe(true);
        expect(await objMyDemoRequest.verifyDemoPresentInTable(sDemoName)).toBe(true);
        expect(await objMyDemoRequest.verifyDemoApprovalStatus(sDemoName, "Pending Review")).toBe(true);
        
        //approve request
        expect(await objHomePage.selectMenuOption("Approvals", "New Requests")).toBe(true);
        expect(await objCommonPage.searchRequest(sDemoName)).toBe(true);
        expect(await objApprovalsPage.clickOnDemoRequestRow(sDemoName)).toBe(true);
        expect(await objCommonPage.verifyAlertHeader("Approval View")).toBe(true);
        expect(await objApprovalsPage.selectDemoApproval(sprint11_TC_Data.MyDemo_TC_01.demoApprovalStatus)).toBe(true);
        expect(await objApprovalsPage.selectPriority(sprint11_TC_Data.MyDemo_TC_01.priority)).toBe(true);
        expect(await objApprovalsPage.setDemoOwner(sprint11_TC_Data.MyDemo_TC_01.demoOwner)).toBe(true);
        expect(await objApprovalsPage.setCATRATManager(sLoggedInUser)).toBe(true);
        expect(await objApprovalsPage.selectExecutionRisk("Medium")).toBe(true); 
        await objApprovalsPage.clickOnSaveApprovalView();
        sAlertMessage = "Approval Saved Successfully."
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK"));
    });

   

    it('Verify that there is column called Demo Submission Date is added in the exported excel sheet.', async()=>{

        const os = require('os');     
        const sDownloadPath = os.homedir()+"/Downloads/";
        
        let objData = dataProvider.getJsonData("./data/sprint11_TCs.json", "MyDemo_TC_01");
        console.info("Sprint 11 - MyDemo_TC_01 =>" + objData);
     
        expect(await objHomePage.verifyHomePageDisplayed()).toBe(true);
        await browser.waitForAngularEnabled(true);
        await objCommonPage.getCurrentDate("mm/dd/yyyy");
        //Account view
        expect(await objHomePage.selectMenuOption("All Demo's", objData.acc_view)).toBeTruthy();  
        await objCommonPage.deleteFileFromDownloadsDir(sDownloadPath + objData.acc_view+".xlsx");      
        expect(await objCommonPage.clickExportButton(objData.acc_view)).toBe(true);
        expect(await objCommonPage.verifyColumnNameNotPresentInGoToDD(objData.column_Name,objData.acc_view)).toBe(true);
        //BU view
        expect(await objHomePage.selectMenuOption("All Demo's", objData.bu_view)).toBeTruthy();
        await objCommonPage.deleteFileFromDownloadsDir(sDownloadPath+objData.bu_excel+".xlsx");  
        expect(await objCommonPage.clickExportButton(objData.bu_view)).toBe(true);
        expect(await objCommonPage.verifyColumnNameNotPresentInGoToDD(objData.column_Name,objData.bu_view)).toBe(true);
        //Demo Team view
        expect(await objHomePage.selectMenuOption("All Demo's", objData.demo_view)).toBeTruthy();
        await objCommonPage.deleteFileFromDownloadsDir(sDownloadPath+objData.demo_view+".xlsx"); 
        expect(await objCommonPage.clickExportButton(objData.demo_view)).toBe(true);
        expect(await objCommonPage.verifyColumnNameNotPresentInGoToDD(objData.column_Name,objData.demo_view)).toBe(true);
        //ALL view
        expect(await objHomePage.selectMenuOption("All Demo's", objData.all_view)).toBeTruthy();
        await objCommonPage.deleteFileFromDownloadsDir(sDownloadPath+objData.all_view+".xlsx"); 
        expect(await objCommonPage.clickExportButton(objData.all_view)).toBe(true);
        expect(await objCommonPage.verifyColumnNameNotPresentInGoToDD(objData.column_Name,objData.all_view)).toBe(true);

        let currentDate = await objCommonPage.getCurrentDate("mm/dd/yyyy");    

        //Account view               
        expect(await objExcelWrapper.verifyExcelCellValuesofSingleRowForSpecifiedColumn(sDownloadPath + objData.acc_view+".xlsx",objData.acc_view,objData.excel_columns,sDemoName+"~"+currentDate)).toBe(true);
        //BU view 
        expect(await objExcelWrapper.verifyExcelCellValuesofSingleRowForSpecifiedColumn(sDownloadPath + objData.bu_excel+".xlsx",objData.bu_excel,objData.excel_columns,sDemoName+"~"+currentDate)).toBe(true);
        //Demo Team view
        expect(await objExcelWrapper.verifyExcelCellValuesofSingleRowForSpecifiedColumn(sDownloadPath + objData.demo_view+".xlsx",objData.demo_view,objData.excel_columns,sDemoName+"~"+currentDate)).toBe(true);
        //ALL view
        expect(await objExcelWrapper.verifyExcelCellValuesofSingleRowForSpecifiedColumn(sDownloadPath + objData.all_view+".xlsx",objData.all_view,objData.excel_columns,sDemoName+"~"+currentDate)).toBe(true);
        
    });

   
});