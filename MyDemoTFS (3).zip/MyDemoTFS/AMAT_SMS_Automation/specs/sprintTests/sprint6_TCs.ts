import {browser, element, ExpectedConditions, by} from 'protractor';
import {homePage} from '../../pages/homePage.po';
import { commonPage } from '../../pages/commonPage.po';
import { newDemoRequest } from '../../pages/newDemoRequest.po';
import { myDraftRequestPage } from '../../pages/myDraftRequestPage.po';
import { myDemoRequestPage } from '../../pages/myDemoRequestPage.po';
import { approvalsPage } from '../../pages/approvalsPage.po';
import { allViewPage } from '../../pages/allViewPage.po';
import { dataProvider} from "../../data/dataProvider";
import {excelWrapper} from '../../utils/excel.util';

describe('Sprint 6 test cases', () => {
    const sprint6_TC_Data = require('../../../data/sprint6_TCs.json');
    let objHomePage:homePage;
    let objNewDemoRequest:newDemoRequest;
    let objMyDraftRequest:myDraftRequestPage;
    let objCommonPage: commonPage;
    let objMyDemoRequest: myDemoRequestPage;
    let objApprovalsPage: approvalsPage;
    let objAllViewPage: allViewPage;
	let objExcelWrapper: excelWrapper;
    let sDemoName = "";
    let sAlertMessage = "";

    beforeEach(async () => {
        objHomePage = new homePage();
        objNewDemoRequest = new newDemoRequest();
        objMyDraftRequest = new myDraftRequestPage();
        objCommonPage = new commonPage();
        objMyDemoRequest = new myDemoRequestPage();
        objApprovalsPage = new approvalsPage();
        objAllViewPage = new allViewPage();
		objExcelWrapper = new excelWrapper();
        await browser.waitForAngularEnabled(false);
        //Open application Url
        await objHomePage.openApplication('/');        
    });

    afterEach(() => {
		objHomePage = null;
        objCommonPage = null;
        objExcelWrapper = null;
    });

    /*it('Pre-requisite test to create demo with status ACL approved status', async()=>{
        let objData = dataProvider.getJsonData("./data/sprint6_TCs.json", "MyDemo_TC_04");
        console.info(objData);
        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_" + iRandomNum;
        console.info(sDemoName);
        let sLoggedInUser;
        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toBe(true);
        browser.waitForAngularEnabled(true);
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toBe(true);
        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toBe(true);
        expect(await objNewDemoRequest.toggleField('TAMBA', true)).toBe(true);
        
        expect(await objNewDemoRequest.clickOnTAMBASearch()).toBe(true);
        expect(await objNewDemoRequest.selectFromBUONTAMBASearchPopUp(sprint6_TC_Data.MyDemo_TC_04.bu)).toBe(true);
        expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(sprint6_TC_Data.MyDemo_TC_04.account)).toBe(true);
        expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toBe(true);
        expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toBe(true);
        expect(await objNewDemoRequest.clickOnSubmit()).toBe(true);
        await objNewDemoRequest.verifyTambaDtlsOnNewDemoForm();
        expect(await objNewDemoRequest.enterHVP(sprint6_TC_Data.MyDemo_TC_04.hvp)).toBe(true);
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toBe(true);
        expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toBe(true);
        expect(await objNewDemoRequest.selectDemoType(sprint6_TC_Data.MyDemo_TC_04.demoType)).toBe(true);
        expect(await objNewDemoRequest.setSuccessCriteria(sprint6_TC_Data.MyDemo_TC_04.successCriteria)).toBe(true);
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toBe(true);
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toBe(true);
        expect(await objNewDemoRequest.selectSubstrateType(sprint6_TC_Data.MyDemo_TC_04.substrateType)).toBe(true);
        expect(await objNewDemoRequest.clickCustomerSpecOption(sprint6_TC_Data.MyDemo_TC_04.customerSpecOption)).toBe(true);
        
        expect(await objNewDemoRequest.setAttributeCategory(sprint6_TC_Data.MyDemo_TC_04.attributeCategory)).toBe(true);
        expect(await objNewDemoRequest.setAttribute(sprint6_TC_Data.MyDemo_TC_04.attribute)).toBe(true);
        expect(await objNewDemoRequest.setMarketSegmentReq(sprint6_TC_Data.MyDemo_TC_04.marketSegReq)).toBe(true);
        expect(await objNewDemoRequest.selectWeighPriority(sprint6_TC_Data.MyDemo_TC_04.weightProperty)).toBe(true);
        expect(await objNewDemoRequest.clickOnAttributeSave());
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toBe(true);
        sAlertMessage = "Demo Request submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toBe(true);
        expect(await objHomePage.selectMenuOption("Requests", "My Demo Request")).toBe(true);
        expect(await objMyDemoRequest.verifyDemoNumberPresentInTable(sDemoName)).toBe(true);
        expect(await objMyDemoRequest.verifyDemoApprovalStatus(sDemoName, "Pending Review")).toBe(true);
        
        //approve request
        expect(await objHomePage.selectMenuOption("Approvals", "New Requests")).toBe(true);
        expect(await objCommonPage.searchRequest(sDemoName)).toBe(true);
        expect(await objApprovalsPage.clickOnDemoRequestRow(sDemoName)).toBe(true);
        expect(await objCommonPage.verifyAlertHeader("Approval View")).toBe(true);
        expect(await objApprovalsPage.selectDemoApproval(sprint6_TC_Data.MyDemo_TC_04.demoApprovalStatus)).toBe(true);
        expect(await objApprovalsPage.selectPriority(sprint6_TC_Data.MyDemo_TC_04.priority)).toBe(true);
        expect(await objApprovalsPage.setDemoOwner(sprint6_TC_Data.MyDemo_TC_04.demoOwner)).toBe(true);
        expect(await objApprovalsPage.setCATRATManager(sLoggedInUser)).toBe(true);
        expect(await objApprovalsPage.selectExecutionRisk("Medium")).toBe(true); 
        await objApprovalsPage.clickOnSaveApprovalView();
        sAlertMessage = "Approval Saved Successfully."
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK"));
    });

    it("MyDemo_TC_04 - Verify that when a demo is in a status of ACL the demo number should become a hyperlink that would allow any user with access to the demo to be able to open the plan and execute. Note : Security should be the same as the view edit.", async()=>{
        browser.waitForAngularEnabled(true);
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toBe(true);
        expect(await objCommonPage.searchRequest(sDemoName)).toBe(true);
        expect(await objCommonPage.goToColumn("Demo Approval")).toBe(true);
        expect(await objAllViewPage.verifyDemoApprovalStatus(sDemoName, sprint6_TC_Data.MyDemo_TC_04.expDemoApprovalStatus)).toBe(true);
        expect(await objAllViewPage.verifyDemoNumberHyperlinkPresent(sDemoName)).toBe(true);
    });*/
	
	it('MyDemo_TC_06 - Verify that Approved date field is visible in exported excel sheet from All the views in MyDemo Application.', async()=>{
        const os = require('os');     
        const sDownloadPath = os.homedir()+"/Downloads/";
        
        let objData = dataProvider.getJsonData("./data/sprint6_TCs.json", "MyDemoTest_06");
        console.info("Sprint 6 - MyDemoTest_06 =>" + objData);
     
        expect(await objHomePage.verifyHomePageDisplayed()).toBe(true);
        await browser.waitForAngularEnabled(true);
        
        //Account view
        expect(await objHomePage.selectMenuOption("All Demo's", objData.acc_view)).toBeTruthy();  
        await objCommonPage.deleteFileFromDownloadsDir(sDownloadPath + objData.acc_view+".xlsx");      
        expect(await objCommonPage.clickExportButton(objData.acc_view)).toBe(true);
        //BU view
        expect(await objHomePage.selectMenuOption("All Demo's", objData.bu_view)).toBeTruthy();
        await objCommonPage.deleteFileFromDownloadsDir(sDownloadPath+objData.bu_excel+".xlsx");  
        expect(await objCommonPage.clickExportButton(objData.bu_view)).toBe(true);
        //Demo Team view
        expect(await objHomePage.selectMenuOption("All Demo's", objData.demo_view)).toBeTruthy();
        await objCommonPage.deleteFileFromDownloadsDir(sDownloadPath+objData.demo_view+".xlsx"); 
        expect(await objCommonPage.clickExportButton(objData.demo_view)).toBe(true);
        //ALL view
        expect(await objHomePage.selectMenuOption("All Demo's", objData.all_view)).toBeTruthy();
        await objCommonPage.deleteFileFromDownloadsDir(sDownloadPath+objData.all_view+".xlsx"); 
        expect(await objCommonPage.clickExportButton(objData.all_view)).toBe(true);

        //Account view
        
        let excelColumnHeaders = await objExcelWrapper.readExcelHeader(sDownloadPath + objData.acc_view+".xlsx",objData.acc_view);
        let expectedheadersList = objData.column_Name.split("~");
        
        for(var iCount = 0; iCount < expectedheadersList.length; iCount++)
        { 
            expect(await objCommonPage.verifyColumnPresentInExcelHeader(expectedheadersList[iCount],excelColumnHeaders)).toBe(true);
        }

        //BU view
        
        excelColumnHeaders = await objExcelWrapper.readExcelHeader(sDownloadPath+objData.bu_excel+".xlsx",objData.bu_excel);
        expectedheadersList = objData.column_Name.split("~");
        
        for(var iCount = 0; iCount < expectedheadersList.length; iCount++)
        { 
            expect(await objCommonPage.verifyColumnPresentInExcelHeader(expectedheadersList[iCount],excelColumnHeaders)).toBe(true);
        }

        //Demo Team view

        excelColumnHeaders = await objExcelWrapper.readExcelHeader(sDownloadPath+objData.demo_view+".xlsx",objData.demo_view);
        expectedheadersList = objData.column_Name.split("~");
        
        for(var iCount = 0; iCount < expectedheadersList.length; iCount++)
        { 
            expect(await objCommonPage.verifyColumnPresentInExcelHeader(expectedheadersList[iCount],excelColumnHeaders)).toBe(true);
        }

        //ALL view

        excelColumnHeaders = await objExcelWrapper.readExcelHeader(sDownloadPath+objData.all_view+".xlsx",objData.all_view);
        expectedheadersList = objData.column_Name.split("~");
       
        for(var iCount = 0; iCount < expectedheadersList.length; iCount++)
        { 
            expect(await objCommonPage.verifyColumnPresentInExcelHeader(expectedheadersList[iCount],excelColumnHeaders)).toBe(true);
        }

      
    });
});