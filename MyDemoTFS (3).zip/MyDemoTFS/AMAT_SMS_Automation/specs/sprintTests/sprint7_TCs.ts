import {browser, element, ExpectedConditions, by} from 'protractor';
import {homePage} from '../../pages/homePage.po';
import { commonPage } from '../../pages/commonPage.po';
import { newDemoRequest } from '../../pages/newDemoRequest.po';
import { myDraftRequestPage } from '../../pages/myDraftRequestPage.po';
import { myDemoRequestPage } from '../../pages/myDemoRequestPage.po';
import { approvalsPage } from '../../pages/approvalsPage.po';
import { allViewPage } from '../../pages/allViewPage.po';
import { dataProvider} from "../../data/dataProvider";
import * as cp from 'child_process';
import { win32 } from 'path';

describe('Sprint 7 test cases', () => {
    const objData = require('../../../data/sprint7_TCs.json');
    const path = win32;
    let objHomePage:homePage;
    let objNewDemoRequest:newDemoRequest;
    let objMyDraftRequest:myDraftRequestPage;
    let objCommonPage: commonPage;
    let objMyDemoRequest: myDemoRequestPage;
    let objApprovalsPage: approvalsPage;
    let objAllViewPage: allViewPage;
    let sDemoName = "";
    let sAlertMessage = "";
    //const shell = require('shelljs');

    beforeEach(async () => {
        objHomePage = new homePage();
        objNewDemoRequest = new newDemoRequest();
        objMyDraftRequest = new myDraftRequestPage();
        objCommonPage = new commonPage();
        objMyDemoRequest = new myDemoRequestPage();
        objApprovalsPage = new approvalsPage();
        objAllViewPage = new allViewPage();

        // var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        // sDemoName = "TestDemo_" + iRandomNum;
        // console.info(sDemoName);

        await browser.waitForAngularEnabled(false);
        //Open application Url
        await objHomePage.openApplication('/');        
    });

    afterEach(() => {

    });

    it('MyDemo_TC_01 - Verify that when Internal Demo toggle button is made as Yes, then following changes are appear on Opportunity Information section of opportunity Info page while creating New Demo Request. 1.Except Primary BU field, Rest all the field in opportunity information section should be made as non-mandatory', async()=>{
        expect(await objHomePage.verifyHomePageDisplayed()).toBe(true);
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toBe(true);
        browser.waitForAngularEnabled(true);
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toBe(true);
        expect(await objNewDemoRequest.verifyToggleForFieldIsPresent('Internal Demo')).toBe(true);
        expect(await objNewDemoRequest.toggleField('TAMBA', false)).toBe(true);
        expect(await objNewDemoRequest.toggleField('Internal Demo', true)).toBe(true);
        expect(await objNewDemoRequest.verifyPrimaryBUIsMandatoryWhenInternalDemo()).toBeTruthy();
    });

    it('MyDemo_TC_04 - Verify that user shall have ability to make a demo as internal so that projects for engineering are tracked in tool (VSE).', async()=>{
        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "InternalTestDemo_" + iRandomNum;
        console.info(sDemoName);
        let objData = dataProvider.getJsonData("./data/sprint7_TCs.json", "MyDemo_TC_04");
        console.info(objData);
        let sLoggedInUser;
        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        expect(await objHomePage.verifyHomePageDisplayed()).toBe(true);
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toBe(true);
        browser.waitForAngularEnabled(true);
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toBe(true);
        expect(await objNewDemoRequest.toggleField('Internal Demo', true)).toBe(true);
        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toBe(true);
        
        expect(await objNewDemoRequest.setInternalAccount(objData.internalAccount)).toBe(true);
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBU)).toBe(true);
        expect(await objNewDemoRequest.enterHVP(objData.hvp)).toBe(true);
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toBe(true);
        expect(await objNewDemoRequest.setInternalAccountOwner(sLoggedInUser)).toBe(true);
        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toBe(true);
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toBe(true);
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toBe(true);
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toBe(true);
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toBe(true);
        await objNewDemoRequest.clickOnAdditionalDocumentBrowseButton();
        const filePath = path.resolve('./autoItScripts/TestUpload.xlsx');
        const exePath = path.resolve('./autoItScripts/browseFile.exe')
        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath);
        await browser.sleep(5000);
        expect(await objNewDemoRequest.verifyAdditionalDocumentBrowsed("TestUpload.xlsx")).toBe(true);
        expect(await objNewDemoRequest.clickOnAdditionalDocumentUploadButton()).toBe(true);
        expect(await objNewDemoRequest.verifyAdditionalDocumentUploaded("TestUpload.xlsx")).toBe(true);
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toBe(true);
        sAlertMessage = "Demo Request submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toBe(true);
        expect(await objHomePage.selectMenuOption("Requests", "My Demo Request")).toBe(true);
        expect(await objMyDemoRequest.verifyDemoPresentInTable(sDemoName)).toBe(true);
        expect(await objMyDemoRequest.verifyDemoApprovalStatus(sDemoName, "Pending Review")).toBe(true);
    });

});