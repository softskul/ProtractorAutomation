import {browser, element, ExpectedConditions, by} from 'protractor';
import {homePage} from '../../pages/homePage.po';
import { commonPage } from '../../pages/commonPage.po';
import { newDemoRequest } from '../../pages/newDemoRequest.po';
import { myDraftRequestPage } from '../../pages/myDraftRequestPage.po';
import { myDemoRequestPage } from '../../pages/myDemoRequestPage.po';
import { approvalsPage } from '../../pages/approvalsPage.po';
import { allViewPage } from '../../pages/allViewPage.po';
import { dataProvider} from "../../data/dataProvider";
import { exec } from 'child_process';

describe('Sprint 9 test cases', () => {
    const sprint9_TC_Data = require('../../../data/sprint9_TCs.json');
    let objHomePage:homePage;
    let objNewDemoRequest:newDemoRequest;
    let objMyDraftRequest:myDraftRequestPage;
    let objCommonPage: commonPage;
    let objMyDemoRequest: myDemoRequestPage;
    let objApprovalsPage: approvalsPage;
    let objAllViewPage: allViewPage;
    let sDemoName = "";
    let sAlertMessage = "";

    beforeEach(async () => {
        objHomePage = new homePage();
        objNewDemoRequest = new newDemoRequest();
        objMyDraftRequest = new myDraftRequestPage();
        objCommonPage = new commonPage();
        objMyDemoRequest = new myDemoRequestPage();
        objApprovalsPage = new approvalsPage();
        objAllViewPage = new allViewPage();

        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_" + iRandomNum;
        console.info(sDemoName);

        await browser.waitForAngularEnabled(false);
        //Open application Url
        await objHomePage.openApplication('/');        
    });

    afterEach(() => {

    });

    /*it('MyDemo_TC_01 - Verify that in MyDemo Application,After migrating PPC data from database following customers are added to database.1.CHIPMORE TECHNOLOGY CORPORATION LIMITED 2.LB SEMICON, INC. 3.Qualcomm, Inc. 4.SEAGATE TECHNOLOGY LLC 5.Skyworks 6.UNISEM ADVANCED TECHNOLOGIES 7.Winbond Electronics Corp. 8.WINSTEK SEMICONDUCTOR TECHNOLOGY CO., LTD 9.Wuhan Xinxin Semiconductor Manufacturing Corporation (XMC) 10.Laytron AG 11.Sumco', async()=>{
        let objData = dataProvider.getJsonData("./data/sprint9_TCs.json", "MyDemo_TC_01");
        console.info(objData);
        expect(await objHomePage.verifyHomePageDisplayed()).toBe(true);
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toBe(true);
        browser.waitForAngularEnabled(true);
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toBe(true);
        //expect(await objNewDemoRequest.clickOnAccountDD()).toBe(true);
        let sAcc = (sprint9_TC_Data.MyDemo_TC_01.accounts).split("~");
        for(var iCount = 0; iCount < sAcc.length; iCount++)
        {
            expect(await objNewDemoRequest.verifyAccountListItemExists(sAcc[iCount])).toBe(true);
        }
    });*/

    /* it('MyDemo_TC_13 - Verify that all the substrate type changes made in MyDemo application as per ppt provided.', async()=>{
        let objData = dataProvider.getJsonData("./data/sprint9_TCs.json", "MyDemo_TC_13");
        console.info(objData);
        expect(await objHomePage.verifyHomePageDisplayed()).toBe(true);
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toBe(true);
        browser.waitForAngularEnabled(true);
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toBe(true);
        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toBe(true);
        expect(await objNewDemoRequest.selectAccount(sprint9_TC_Data.MyDemo_TC_13.account)).toBe(true);
        expect(await objNewDemoRequest.selectPrimaryBU(sprint9_TC_Data.MyDemo_TC_13.primaryBU)).toBe(true);
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toBe(true);
        expect(await objNewDemoRequest.verifySubstrateTypeDDExists()).toBe(true);
    }); */

    /* it('MyDemo_TC_14 - Verify that when substrate type is selected full wafer then certain changes should be applied in MyDemo.', async()=>{
        let objData = dataProvider.getJsonData("./data/sprint9_TCs.json", "MyDemo_TC_14");
        console.info(objData);
        expect(await objHomePage.verifyHomePageDisplayed()).toBe(true);
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toBe(true);
        browser.waitForAngularEnabled(true);
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toBe(true);
        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toBe(true);
        expect(await objNewDemoRequest.selectAccount(sprint9_TC_Data.MyDemo_TC_14.account)).toBe(true);
        expect(await objNewDemoRequest.selectPrimaryBU(sprint9_TC_Data.MyDemo_TC_14.primaryBU)).toBe(true);
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toBe(true);
        expect(await objNewDemoRequest.selectSubstrateType(sprint9_TC_Data.MyDemo_TC_14.substrateType)).toBe(true);
        expect(await objNewDemoRequest.verifySubstrateMaterialDDExists()).toBe(true);
    }); 

    it('MyDemo_TC_15 - Verify that substrate material have feautures which are applied in MyDemo.', async()=>{
        let objData = dataProvider.getJsonData("./data/sprint9_TCs.json", "MyDemo_TC_15");
        console.info(objData);
        expect(await objHomePage.verifyHomePageDisplayed()).toBe(true);
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toBe(true);
        browser.waitForAngularEnabled(true);
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toBe(true);
        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toBe(true);
        expect(await objNewDemoRequest.selectAccount(objData.account)).toBe(true);
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBU)).toBe(true);
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toBe(true);
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toBe(true);
        expect(await objNewDemoRequest.verifySubstrateMaterialDDIsNotMandatory()).toBe(true);
        expect(await objNewDemoRequest.verifyDefValInSubstrateMaterialDD(objData.defSubstrateMaterialVal)).toBe(true);
        expect(await objNewDemoRequest.selectSubstrateMaterial(objData.substrateMaterial)).toBe(true); //place "" value
        expect(await objNewDemoRequest.selectSubstrateMaterial(objData.substrateMaterial1)).toBe(true); //place Other value
        expect(await objNewDemoRequest.verifyTextFieldDisplayedForOtherSubstrateMaterial()).toBe(true);
    });

    it('MyDemo_TC_16 - Verify that when user selects Thin Flat as substrate material value then mandatory conditions will be applied on the particular field', async()=>{
        let objData = dataProvider.getJsonData("./data/sprint9_TCs.json", "MyDemo_TC_16");
        console.info(objData);
        expect(await objHomePage.verifyHomePageDisplayed()).toBe(true);
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toBe(true);
        browser.waitForAngularEnabled(true);
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toBe(true);
        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toBe(true);
        expect(await objNewDemoRequest.selectAccount(objData.account)).toBe(true);
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBU)).toBe(true);
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toBe(true);
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toBe(true);
        expect(await objNewDemoRequest.selectSubstrateMaterial(objData.substrateMaterial)).toBe(true);
        expect(await objNewDemoRequest.verifyWaferThicknessIsMandatory()).toBe(true);
        expect(await objNewDemoRequest.setWaferThickness(objData.waferThickness)).toBe(true);
        expect(await objNewDemoRequest.verifyFrontsideProtectionOrCarrierTypeDDIsMandatory()).toBe(true);
    });

    it('MyDemo_TC_17 - Verify that when user selects Thin Taiko as substrate material value then mandatory conditions will be applied on the particular field', async()=>{
        let objData = dataProvider.getJsonData("./data/sprint9_TCs.json", "MyDemo_TC_17");
        console.info(objData);
        expect(await objHomePage.verifyHomePageDisplayed()).toBe(true);
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toBe(true);
        browser.waitForAngularEnabled(true);
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toBe(true);
        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toBe(true);
        expect(await objNewDemoRequest.selectAccount(objData.account)).toBe(true);
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBU)).toBe(true);
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toBe(true);
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toBe(true);
        expect(await objNewDemoRequest.selectSubstrateMaterial(objData.substrateMaterial)).toBe(true);
        expect(await objNewDemoRequest.verifyWaferThicknessIsMandatory()).toBe(true);
        expect(await objNewDemoRequest.setWaferThickness(objData.waferThickness)).toBe(true);
        expect(await objNewDemoRequest.verifyFrontsideProtectionOrCarrierTypeDDIsMandatory()).toBe(true);
    });*/ 

    it('MyDemo_TC_18 - Verify that when user selects Coupon as substrate type value then dimensions field should be displayed.', async()=>{
        let objData = dataProvider.getJsonData("./data/sprint9_TCs.json", "MyDemo_TC_18");
        console.info(objData);
        expect(await objHomePage.verifyHomePageDisplayed()).toBe(true);
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toBe(true);
        browser.waitForAngularEnabled(true);
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toBe(true);
        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toBe(true);
        expect(await objNewDemoRequest.selectAccount(objData.account)).toBe(true);
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBU)).toBe(true);
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toBe(true);
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toBe(true);
        expect(await objNewDemoRequest.setDimensions(objData.dimension)).toBe(true);
    }); 
});