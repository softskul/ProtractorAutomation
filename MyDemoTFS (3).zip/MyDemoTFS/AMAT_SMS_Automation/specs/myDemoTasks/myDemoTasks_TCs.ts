import {browser, element, ExpectedConditions, by} from 'protractor';
import {homePage} from '../../pages/homePage.po';
import { commonPage } from '../../pages/commonPage.po';
import { newDemoRequest } from '../../pages/newDemoRequest.po';
import { myDraftRequestPage } from '../../pages/myDraftRequestPage.po';
import { myDemoRequestPage } from '../../pages/myDemoRequestPage.po';
import { demoDetailsPage } from '../../pages/demoDetailsPage.po';
import { dataProvider} from "../../data/dataProvider";
import { loginPage } from '../../pages/loginPage.po';
import { allViewPage } from '../../pages/allViewPage.po';
import { myDemoTasksPage } from '../../pages/myDemoTasksPage.po';
import{ adminAccessViewPage } from '../../pages/adminAccessViewPage.po';
import { allRequestPage } from '../../pages/allRequestPage.po';
import { Console } from 'console';
import { win32 } from 'path';
import * as cp from 'child_process';
import { approvalsPage } from '../../pages/approvalsPage.po';															 
import { outlookPage } from '../../pages/outlookPage.po';
import { myLabPage } from '../../pages/myLabPage.po';

describe('My Demo Tasks Module Test cases', () => {
    const path = win32;
    let objHomePage:homePage;
    let objNewDemoRequest:newDemoRequest;
    let objMyDraftRequest:myDraftRequestPage;
    let objCommonPage: commonPage;
    let objMyDemoRequest: myDemoRequestPage;
    let objDemoDetailsPage: demoDetailsPage;
    let objLoginPage:loginPage;
    let objAllViewPage:allViewPage;
    let objMyDemoTasksPage:myDemoTasksPage;
    let objadminAccessViewPage:adminAccessViewPage;
    let objAllRequestPage: allRequestPage;
	  let objApprovalsPage:approvalsPage;	
    let objOutlookPage: outlookPage							   
    let objLoginData = dataProvider.getJsonData("./data/login.json", "login");
    let sDemoName,sLoggedInUser;
    let sAlertMessage = "", sViewNm;
	  let sDemoNumber;
	  let objMyLabPage:myLabPage;
  
    

    beforeEach(async () => {
       
        objHomePage = new homePage();
        objNewDemoRequest = new newDemoRequest();
        objMyDraftRequest = new myDraftRequestPage();
        objCommonPage = new commonPage();
        objMyDemoRequest = new myDemoRequestPage();
        objLoginPage = new loginPage();
        objAllViewPage = new allViewPage();
        objMyDemoTasksPage = new myDemoTasksPage();
        objAllRequestPage = new allRequestPage();
        objadminAccessViewPage= new adminAccessViewPage();
        objDemoDetailsPage = new demoDetailsPage();
		    objApprovalsPage = new approvalsPage();	
        objOutlookPage = new outlookPage();	
		    objMyLabPage=new myLabPage();
        
        await browser.waitForAngularEnabled(false);
        //Open application Url
        await objHomePage.openApplication('/');        
    });

    afterEach(() => {
        
    });

it('TC_Pre-Requisite.', async(done)=>{
         let objData = dataProvider.getJsonData("./data/myDemoTasks.json", "TC_Pre-Requisite");
         console.log(objData);
         //Login My Demo application
         expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
         expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
         expect(await objLoginPage.clickLogin()).toContain("Pass");
         await browser.waitForAngularEnabled(true);
         expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
         //select menu option
        expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
         expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
         expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
         expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
	
      var iRandomNum = Math.floor(1000 + Math.random() * 9000);
      sDemoName = "TestDemo_MyDemoTask" + iRandomNum;
      console.log(sDemoName);

      expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
      expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
    
      expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
      expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
      expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
      expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
      expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
      expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
      expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
      expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
   
      await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
      expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
      expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
      expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");         
    
                                              
      expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
      expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
      
      expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
      expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
      expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
      expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
      expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
  
      
      expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
      expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
      expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
      expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
      expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");
  
      expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
      expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');
    
      //Search or the demo which is having status as new request and make it approved 
      expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain("Pass");													   
    
      expect(await objCommonPage.searchRequest(sDemoName)).toContain("Pass");
      expect(await objCommonPage.clickInTableButton(sDemoName, "New Request")).toContain("Pass");        
      expect(await objCommonPage.verifyAlertHeader("Approval View")).toContain("Pass");
      expect(await objApprovalsPage.selectDemoApproval(objData.demoApprovalStatus)).toContain("Pass");
      expect(await objApprovalsPage.selectPriority(objData.priority)).toContain("Pass");    
      expect(await objApprovalsPage.setDemoOwner(sLoggedInUser)).toContain("Pass");

      await objApprovalsPage.clickOnSaveApprovalView();
      sAlertMessage = "Approval Saved Successfully"
      expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
      done();
}); 
it('TC_02-Verify that Demo Owner should be able to submit demo details successfully', async (done)=>
{
       
   //Login My Demo application as global admin user
  expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
   expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
   expect(await objLoginPage.clickLogin()).toContain("Pass");
  await browser.waitForAngularEnabled(true);
   expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")
   
   expect(await objHomePage.selectMenuOption("My Action", "My Demo Tasks")).toContain('Pass');
 
   //Search for the demo Name
   expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
   expect(await objMyDemoTasksPage.verifyDemoisDisplayed(sDemoName)).toContain('Pass');
   //click on the hyperlink
   expect(await objCommonPage.clickOnDemoNumberHyperLink("Demo Number",sDemoName)).toContain('Pass');  
   expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain('Pass'); 
  expect(await objAllViewPage.verifyFieldIsMandatory("Execution Risk")).toContain('Pass');
   expect(await objDemoDetailsPage.getFieldValue("Execution Risk")).toBeNull();
   expect(await objDemoDetailsPage.clickOnBtn("Submit")).toContain("Pass");
    sAlertMessage="Risk is mandatory."
    expect(await objCommonPage.verifyAlertMessage(sAlertMessage)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('');
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
  //Update Execution risk
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Execution Risk","Medium")).toContain('Pass');
    expect(await objDemoDetailsPage.selectDDOptionOnDemoDtlsPage("Resources","Low")).toContain('Pass');
    expect(await objDemoDetailsPage.setFieldValInDemoDtlsPage("Engineer","2")).toContain('Pass');
    expect(await objDemoDetailsPage.clickOnBtn("Submit")).toContain("Pass");
    sAlertMessage="Demo Details Submitted Successfully."
    expect(await objCommonPage.verifyAlertMessage(sAlertMessage)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
     
    expect(await objHomePage.selectMenuOption("My Action", "My Demo Tasks")).toContain('Pass');
 
   //Search for the demo Name
   expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
   
    expect(await objMyDemoTasksPage.verifyDemoisDisplayed(sDemoName)).toContain('Pass');
     //click on the hyperlink
     expect(await objCommonPage.clickOnDemoNumberHyperLink("Demo Number",sDemoName)).toContain('Pass');  
     expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain('Pass');

     expect(await objDemoDetailsPage.getFieldValue("Execution Risk")).toEqual('M');
     expect(await objDemoDetailsPage.getFieldValue("Resources")).toEqual('L');
     expect(await objDemoDetailsPage.getFieldValue("Engineer")).toEqual('2');
    done();
});
it('TC_18-In MyDemo Verify that Demo Complete value is removed from the Wafer Status field and   In demos where the value is Demo Complete should be updated to Wafer Ready to Ship Back', async (done)=>
{
    let objData = dataProvider.getJsonData("./data/myDemoTasks.json", "TC_19");
    console.log(objData);
   
   //Login My Demo application as global admin user
   expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
   expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
   expect(await objLoginPage.clickLogin()).toContain("Pass");
   await browser.waitForAngularEnabled(true);
   expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
   
   expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
         
 
   //Search for the demo Name
   expect(await objCommonPage.searchRequest(sDemoName)).toContain("Pass");
   expect(await objMyDemoTasksPage.verifyDemoisDisplayed(sDemoName)).toContain('Pass');

   expect(await objCommonPage.clickOnDemoNumberHyperLink("Demo Number",sDemoName)).toContain('Pass');  
   expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain('Pass');
  
   expect(await objDemoDetailsPage.verifyOptionFromFieldDDOnDemoDetails("Wafer Location","Demo Complete")).toContain('not present');
   expect(await objDemoDetailsPage.verifyOptionFromFieldDDOnDemoDetails("Wafer Location","Wafer ready to ship back")).toContain('Pass');

    done();
})
it('TC_32 - Verify that user shall be able to update Wafer Available in Lab date on demo details screen', async(done)=>{

  expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
  expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
  expect(await objLoginPage.clickLogin()).toContain("Pass");
  await browser.waitForAngularEnabled(true);
  expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
  expect(await objHomePage.selectMenuOption("My Action", "My Demo Tasks")).toContain('Pass');

  //Search for the demo Name
  expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
  expect(await objMyDemoTasksPage.verifyDemoisDisplayed(sDemoName)).toContain('Pass');
  //click on the hyperlink
  expect(await objCommonPage.clickOnDemoNumberHyperLink("Demo Number",sDemoName)).toContain('Pass');  

  //select todays date in Wafer Avalaible in lab date
  expect(await objDemoDetailsPage.clickOnWaferAvailableInLabDate("Wafers Available in Lab")).toContain('Pass');  
  await objCommonPage.selectDateFromCalendar("Today");

  expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
  let sAlert="Demo Details Submitted Successfully."
  expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
  expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

  //verify the updated date is dispayed in All view
  expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
  let sDate;
  objCommonPage.getCurrentDate("mm/dd/yyyy").then(function(currDate){ sDate=currDate;});
  expect(await objCommonPage.searchRequest(sDemoName));
  expect(await objCommonPage.goToColumn("Wafer Available in Lab")).toContain('Pass');
  expect(await objCommonPage.verifyTextValueInTableCell("Wafer Available in Lab",sDemoName,sDate)).toContain('Verified');
 
  done();
});
it('TC_06-Verify that Demo type should be multi select field in Mydemo Application.', async (done)=>
{
    let objData = dataProvider.getJsonData("./data/myDemoTasks.json", "TC_06");
    console.log(objData);
   
   //Login My Demo application as global admin user
   expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
   expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
   expect(await objLoginPage.clickLogin()).toContain("Pass");
   await browser.waitForAngularEnabled(true);
   expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
   
   expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
         
 
   //Search for the demo Name
   expect(await objCommonPage.searchRequest(sDemoName)).toContain("Pass");
   expect(await objMyDemoTasksPage.verifyDemoisDisplayed(sDemoName)).toContain('Pass');
   
   expect(await objCommonPage.goToColumn("Demo Approval")).toContain('Pass');
   expect(await objCommonPage.getTableCellValue( "Demo Approval",sDemoName)).toContain("ACL-With Demo Owner");

   expect(await objCommonPage.goToColumn("Demo Type")).toContain('Pass');
   let demoval;
   await objCommonPage.getTableCellValue( "Demo Type",sDemoName).then(function(sText){demoval=sText;});
   expect(await objCommonPage.goToColumn("Demo Type")).toContain('Pass');
   expect(await objCommonPage.clickInTheTableCell("Demo Type",sDemoName)).toContain('Pass');
   expect(await objDemoDetailsPage.clickOnMultipleSelectFieldDropDown("Demo Type")).toContain('Pass');
   demoval=demoval+objData.demoType;
   let sOptionList = (demoval).split(";");
   for(var iCount = 0; iCount < sOptionList.length; iCount++)
    {
        expect(await objDemoDetailsPage.selectMultipleOptionFromDDList("Demo Type", sOptionList[iCount])).toContain('Pass');    
    }
    expect(await objDemoDetailsPage.clickOnMultipleSelectFieldDropDown("Demo Type")).toContain('Pass'); 
    expect(await objCommonPage.clickOnBtnOnPopup("Save")).toContain("Pass");
    
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');    
    expect(await objCommonPage.searchRequest(sDemoName)).toContain("Pass");
    expect(await objCommonPage.goToColumn("Demo Type")).toContain('Pass');  
    expect(await objCommonPage.verifyTextValueInTableCell( "Demo Type",sDemoName, objData.demoType)).toContain("Verified");
  
    done();
});
it('TC_04 - Verify that BM Owner, CAT/RAT Manager, KPU Head/GPM (Non Mandatory) fields are added to the Demo Details page.', async(done)=>{
  let objData = dataProvider.getJsonData("./data/myDemoTasks.json", "TC_04");
  console.log(objData);
   
  //Login My Demo application as global admin user
  expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
  expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
  expect(await objLoginPage.clickLogin()).toContain("Pass");
  await browser.waitForAngularEnabled(true);
  expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

  expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
 
  expect(await objCommonPage.searchRequest(sDemoName)).toContain("Pass");
  expect(await objCommonPage.goToColumn("BM Owner")).toContain('Pass');
  let bmOwnerName ;
  await objCommonPage.getTableCellValue("BM Owner",sDemoName).then(function(sText){bmOwnerName=sText;});

  expect(await objHomePage.selectMenuOption("My Action", "My Demo Tasks")).toContain('Pass');

  //Search for the demo Name
  expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
  expect(await objMyDemoTasksPage.verifyDemoisDisplayed(sDemoName)).toContain('Pass');
  //click on the hyperlink
  expect(await objCommonPage.clickOnDemoNumberHyperLink("Demo Number",sDemoName)).toContain('Pass');  
 // Verify BM Owner, CAT/RAT Manager, KPU Head/GPM  are Non Mandatory fields
  expect(await objAllViewPage.verifyFieldIsMandatory("BM Owner")).toContain('not Mandate');  
  expect(await objAllViewPage.verifyFieldIsMandatory("CAT/RAT Manager")).toContain('not Mandate'); 
  expect(await objAllViewPage.verifyFieldIsMandatory("KPU Head/GPM")).toContain('not Mandate'); 
  expect(objDemoDetailsPage.getFieldValue("BM Owner")).toEqual(bmOwnerName);
  //verify CAT/RAT Manager, KPU Head/GPM fields are mulitple people picker
  let userList =(objData.peopleList).split(";");
  for(var iCount = 0; iCount < userList.length; iCount++)
  {
    expect(await objCommonPage.selectPeoplePickerVal("CAT/RAT Manager",userList[iCount])).toContain('Pass');
  }

  for(var iCount = 0; iCount < userList.length; iCount++)
  {
    expect(await objCommonPage.selectPeoplePickerVal("KPU Head/GPM",userList[iCount])).toContain('Pass');
  }

  expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
  let sAlert="Demo Details Submitted Successfully."
  expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
  expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

  //verify the values are save and dislayed in All view
  expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');

  expect(await objCommonPage.searchRequest(sDemoName));
  expect(await objCommonPage.goToColumn("CAT/RAT Manager")).toContain('Pass');
  expect(await objCommonPage.verifyTextValueInTableCell("CAT/RAT Manager",sDemoName,objData.peopleList)).toContain('Verified');

  expect(await objCommonPage.goToColumn("KPU Head/GPM")).toContain('Pass');
  expect(await objCommonPage.verifyTextValueInTableCell("KPU Head/GPM",sDemoName,objData.peopleList)).toContain('Verified');
 
  done();
}); 
it('TC_9 - Verify that user shall be able to attach document by clicking on paperclip icon present in mydemo application'+
'TC_14-Verify that whenever user is uploading file using attachment section then he/she should be able to select Security and Category as follows'+
'Security:'+
'1.External - BU & Account'+
'2.Internal - BU Only'+
'Category : '+
'1.Customer Feedback'+
'2.Customer Specs'+
'3.Demo Plan'+
'4.Demo Report'+
'5.Others'+
'6.Split Table'+
'7.Traveler'+
'8.Wafer Stack', async (done)=>
{
    let objData = dataProvider.getJsonData("./data/myDemoTasks.json", "TC_14");
    console.log(objData);
   
   //Login My Demo application as global admin user
   expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
   expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
   expect(await objLoginPage.clickLogin()).toContain("Pass");
   await browser.waitForAngularEnabled(true);
   expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
   
   expect(await objHomePage.selectMenuOption("My Action", "My Demo Tasks")).toContain('Pass');
         
 
   //Search for the demo Name
   expect(await objCommonPage.searchRequest(sDemoName)).toContain("Pass");
   expect(await objMyDemoTasksPage.verifyDemoisDisplayed(sDemoName)).toContain('Pass');
   //click on the hyperlink
   expect(await objCommonPage.clickOnDemoNumberHyperLink("Demo Number",sDemoName)).toContain('Pass');  
   expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain('Pass'); 

   expect(await objDemoDetailsPage.verifyAttachmentIconIsDisplayed()).toContain("Pass");
   expect(await objDemoDetailsPage.clickOnAttachmentsBtn()).toContain("Pass");
   expect(await objDemoDetailsPage.verifyAttachmentsPopUpDisplayed()).toContain("Pass");

  //Verify the dropdown values on attachment pop up
     let sOptionList = (objData.securityDDList).split("~");
     for(var i =0; i<sOptionList.length; i++){
      expect(await objDemoDetailsPage.verifyOptionFromFieldDDOnDemoDetails("Security", sOptionList[i])).toContain('Pass');    
     }
    
     sOptionList = (objData.categoryList).split("~");
     for(var i =0; i<sOptionList.length; i++){
      expect(await objDemoDetailsPage.verifyOptionFromFieldDDOnDemoDetails("Category", sOptionList[i])).toContain('Pass');    
     }       

    expect(await objDemoDetailsPage.clickBrowseOnAttachmentsPopUp()).toContain("Pass");
    
    const filePath = path.resolve('./autoItScripts/TestUpload_CustSpec.xlsx');
    const exePath = path.resolve('./autoItScripts/browseFile.exe')
  
    cp.exec(exePath + ' ' + filePath);
    await browser.sleep(5000);
    
    expect(await objDemoDetailsPage.verifyFileBrowsedOnAttachmentsPopUp("TestUpload_CustSpec.xlsx")).toContain("Pass");
    expect(await objDemoDetailsPage.selectDDValOnAttachmentsPopUp("Security", objData.security)).toContain("Pass");//External - BU And Account
    expect(await objDemoDetailsPage.selectDDValOnAttachmentsPopUp("Category", objData.category)).toContain("Pass");//Customer Spec
    expect(await objDemoDetailsPage.clickUploadBtnOnAttachmentsPopUp()).toContain("Pass");
    expect(await objDemoDetailsPage.verifyDocUploadedOnAttachmentsPopUp("TestUpload_CustSpec.xlsx")).not.toContain("Pass");
    expect(await objAllViewPage.clickCancelOnAttachmentsPopUp()).toContain('Pass');
    expect(await objDemoDetailsPage.clickOnBtn("Submit")).toContain("Pass");
    let sAlert="Demo Details Submitted Successfully."
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

    //verify the file uploaded on attchments pop up from All view page
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    //Search for the demo Name
    expect(await objCommonPage.searchRequest(sDemoName)).toContain("Pass");
    expect(await objMyDemoTasksPage.verifyDemoisDisplayed(sDemoName)).toContain('Pass');
    expect(await objAllViewPage.clickOnAddAttachmentExtLinkInTableCell(sDemoName)).toBe(true);

    expect(await objDemoDetailsPage.verifyAttachmentsPopUpDisplayed()).toContain("Pass");
    expect(await objDemoDetailsPage.verifyDocUploadedOnAttachmentsPopUp("TestUpload_CustSpec.xlsx")).not.toContain("Pass");
      
    expect(await objAllViewPage.clickCancelOnAttachmentsPopUp()).toContain('Pass');

    done();
});
it('TC_15 - Verify that user shall be able to add and delete and edit a link in Demo Details screen and paper clip', async (done)=>
{
    let objData = dataProvider.getJsonData("./data/myDemoTasks.json", "TC_14");
    console.log(objData);
   
   //Login My Demo application as global admin user
   expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
   expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
   expect(await objLoginPage.clickLogin()).toContain("Pass");
   await browser.waitForAngularEnabled(true);
   expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
   
   expect(await objHomePage.selectMenuOption("My Action", "My Demo Tasks")).toContain('Pass');
         
 
   //Search for the demo Name
   expect(await objCommonPage.searchRequest(sDemoName)).toContain("Pass");
   expect(await objMyDemoTasksPage.verifyDemoisDisplayed(sDemoName)).toContain('Pass');

   //click on the hyperlink
   expect(await objCommonPage.clickOnDemoNumberHyperLink("Demo Number",sDemoName)).toContain('Pass');  
   expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain('Pass'); 
   expect(await objHomePage.getCurrentUrl("request_demo")).toContain("Pass");
   expect(await objDemoDetailsPage.verifyAttachmentIconIsDisplayed()).toContain("Pass");
   expect(await objDemoDetailsPage.clickOnAttachmentsBtn()).toContain("Pass");
   expect(await objDemoDetailsPage.verifyAttachmentsPopUpDisplayed()).toContain("Pass");
  
    
    expect(await objDemoDetailsPage.expandExternalLinkOnAttachmentsPopUp()).toContain("Pass");
    let linkURL = (browser.params.baseUrl);
    let linkURL_noHttp = (browser.params.baseUrl).replace("https://","");
    expect(await objDemoDetailsPage.setLinkValInAttachmentsPopup("Link", linkURL_noHttp)).toContain("Pass");
    expect(await objDemoDetailsPage.clickAddOnAttachmentsPopUp()).toContain("Pass");
    
    expect(await objDemoDetailsPage.getExternalLinkValueOnAttachmentsPopup()).toEqual(linkURL.replace("https","http"));
    expect(await objDemoDetailsPage.clickOnLinkOnAttachmentsPopUp(linkURL.replace("https","http"))).toContain('Pass');
    await browser.sleep(5000);
    await objCommonPage.switchtoNewTab();
    await browser.sleep(5000);
    expect(await objHomePage.getCurrentUrl(linkURL)).toContain("Pass");
    await browser.sleep(5000);
    await objCommonPage.closeTab();
    await objCommonPage.switchtoParentTab();
    await browser.sleep(15000);
    expect(await objDemoDetailsPage.deleteLinkOnAttachmentsPopUp(linkURL.replace("https","http"))).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');


    expect(await objDemoDetailsPage.setLinkValInAttachmentsPopup("Link", linkURL)).toContain("Pass");
    expect(await objDemoDetailsPage.clickAddOnAttachmentsPopUp()).toContain("Pass");
    
    expect(await objDemoDetailsPage.getExternalLinkValueOnAttachmentsPopup()).toEqual(linkURL);
    expect(await objDemoDetailsPage.clickOnLinkOnAttachmentsPopUp(linkURL)).toContain('Pass');
    await browser.sleep(15000);
    await objCommonPage.switchtoNewTab();
    expect(await objHomePage.getCurrentUrl(linkURL)).toContain("Pass");
    await browser.sleep(15000);
    await objCommonPage.closeTab(); 
    await objCommonPage.switchtoParentTab();
    await browser.sleep(15000);
    expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');

    done();
});
it('TC_07-Verify that when user updates Milestone Status then following changes should be implemented'+
'1.When status changed as On Track then Green color should be the background color'+
'2.When status changed as Complete then Blue color should be the background color'+
'3.When status changed as At risk then Red color should be the background color', async (done)=>
{  
    let objData = dataProvider.getJsonData("./data/myDemoTasks.json", "TC_07");
    console.log(objData);

   //Login My Demo application as global admin user
  expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
   expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
   expect(await objLoginPage.clickLogin()).toContain("Pass");
  await browser.waitForAngularEnabled(true);
   expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")
   
   let sList= (objData.milestoneStatus_Color).split("~");
    for(var i =0; i<sList.length; i++){ 
   expect(await objHomePage.selectMenuOption("My Action", "My Demo Tasks")).toContain('Pass');
 
   //Search for the demo Name
   expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
   expect(await objMyDemoTasksPage.verifyDemoStatusInTableGrid(sDemoName,"ACL-With Demo Owner")).toContain('Pass');
   //click on the hyperlink
   expect(await objCommonPage.clickOnDemoNumberHyperLink("Demo Number",sDemoName)).toContain('Pass');  
   expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain('Pass');
    //select date for Demo start field and sumbmit request 
   let status_color = sList[i].split(";");
   expect(await objDemoDetailsPage.clickonScheduleIcon(objData.demoStartCol)).toContain("Pass");
   expect(await objDemoDetailsPage.clickOnCalendarIcon("Schedule Start Date")).toContain("Pass");
    await objCommonPage.selectDateFromCalendar("Today");
   expect(await objDemoDetailsPage.clickFieldOnDemoDetails("Milestone Status")).toContain("Pass");
   expect(await objDemoDetailsPage.selectOptionFromFieldOnDemoDetails("Milestone Status",status_color[0])).toContain("Pass");
   expect(await objDemoDetailsPage.setValInField("Justification",status_color[0]+" comment ")).toContain("Pass");
   expect(await objCommonPage.clickOnBtnOnPopup("Submit")).toContain("Pass");
   //Verify the color after date selection
   expect(await objDemoDetailsPage.verifyBackgroudColour(objData.demoStartCol,status_color[1])).toContain("Pass");
   expect(await objDemoDetailsPage.clickOnBtn("Submit")).toContain("Pass");
   let sAlert="Demo Details Submitted Successfully."
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
   

    //Search request in All view and verify the color
     expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objCommonPage.goToColumn(objData.demoStartCol)).toBeTruthy();
    expect(objAllViewPage.getTableCellColor(objData.demoStartCol,sDemoName)).toContain(status_color[1]);
   
    } 
   done();
});
it('TC_08-Verify that user shall be able to select multiple values in chamber field on Demo Details page', async (done)=>
{
    let objData = dataProvider.getJsonData("./data/myDemoTasks.json", "TC_08");
    console.log(objData);
   
   //Login My Demo application as global admin user
  expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
   expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
   expect(await objLoginPage.clickLogin()).toContain("Pass");
  await browser.waitForAngularEnabled(true);
   expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")
   
   expect(await objHomePage.selectMenuOption("My Action", "My Demo Tasks")).toContain('Pass');
 
   //Search for the demo Name
   expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
   
   //click on the hyperlink
   expect(await objCommonPage.clickOnDemoNumberHyperLink("Demo Number",sDemoName)).toContain('Pass');  
   expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain('Pass'); 
    //Update the Demo location, Tool Name 
    expect(await objDemoDetailsPage.clickOnFieldDropDown(objData.demoLocationCol)).toContain("Pass");
   expect(await objDemoDetailsPage.selectOptionFromDDList(objData.demoLocationCol,objData.demoLocationVal)).toContain("Pass");
   expect(await objDemoDetailsPage.clickOnFieldDropDown(objData.toolNameCol)).toContain("Pass");
   expect(await objDemoDetailsPage.selectOptionFromDDList(objData.toolNameCol,objData.toolNameValue)).toContain("Pass");
   //Select multiple values from Chanmber Position Dropdown
   expect(await objDemoDetailsPage.clickOnMultipleSelectFieldDropDown(objData.chamberPositionCol)).toContain('Pass');
   //Select multiple values from Chanmber Position Dropdown
   let sOptionList = (objData.chamberPositionVal).split(";");
   for(var iCount = 0; iCount < sOptionList.length; iCount++)
    {
        expect(await objDemoDetailsPage.selectMultipleOptionFromDDList(objData.chamberPositionCol, sOptionList[iCount])).toContain('Pass');    
    }
    expect(await objDemoDetailsPage.clickOnBtn("Submit")).toContain("Pass");
    let sAlert="Demo Details Submitted Successfully."
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
     
   //Search request in All view and verify the update values
   expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
   expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
   expect(await objCommonPage.goToColumn(objData.demoLocationCol)).toBeTruthy();
   expect(await objCommonPage.getTableCellValue(objData.demoLocationCol,sDemoName)).toEqual(objData.demoLocationVal);
   expect(await objCommonPage.goToColumn(objData.toolIDCol)).toBeTruthy();
   expect(await objCommonPage.getTableCellValue(objData.toolIDCol,sDemoName)).toEqual(objData.toolIDVal);
   expect(await objCommonPage.goToColumn(objData.chamberPositionCol)).toBeTruthy();
   expect(await objCommonPage.getTableCellValue(objData.chamberPositionCol,sDemoName)).toEqual((objData.chamberPositionVal)+";");

    done();
});
it('TC_10-Verify that there will be Demo Development Stage field with following values '+
'1.Coupon '+
'2.Full Wafer'+ 
'3.On Site '+
'4.Electrical'+
'5.Productivity'+
'6.Production', async (done)=>
{
    let objData = dataProvider.getJsonData("./data/myDemoTasks.json", "TC_10");
    console.log(objData);
   //Login My Demo application as global admin user
   expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
   expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
   expect(await objLoginPage.clickLogin()).toContain("Pass");
  await browser.waitForAngularEnabled(true);
   expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")
   
   expect(await objHomePage.selectMenuOption("My Action", "My Demo Tasks")).toContain('Pass');
 
   //Search for the demo Name
   expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
  
   //click on the hyperlink
   expect(await objCommonPage.clickOnDemoNumberHyperLink("Demo Number",sDemoName)).toContain('Pass');  
   expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain('Pass'); 
   //verify dropdown values in Demo Development Stage
   expect(await objDemoDetailsPage.clickFieldOnDemoDetails(objData.demoDevelopmentStageCol)).toContain("Pass");
   let optionList =(objData.dropDownValues).split("~");
   for(var i =0; i<optionList.length; i++){
    expect(await objDemoDetailsPage.verifyOptionFromFieldDDOnDemoDetails(objData.demoDevelopmentStageCol,optionList[i])).toContain("Pass");
   }
   //select any value in Demo Development Stage
   expect(await objDemoDetailsPage.selectOptionFromFieldOnDemoDetails(objData.demoDevelopmentStageCol,objData.sOption)).toContain("Pass");
   expect(await objDemoDetailsPage.clickOnBtn("Submit")).toContain("Pass");
   
   let sAlert="Demo Details Submitted Successfully."
   expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
   expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    
  //Search request in All view and verify the update values
   expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
   expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
   expect(await objCommonPage.goToColumn(objData.demoDevelopmentStageCol)).toBeTruthy();
   expect(await objCommonPage.getTableCellValue(objData.demoDevelopmentStageCol,sDemoName)).toEqual(objData.sOption);
   done();
    
});   
it('TC_03 - Verify that there is a new field added by name Team Member in Demo Details Screen which will be a multiple people picker field.', async(done)=>{
    let objData = dataProvider.getJsonData("./data/myDemoTasks.json", "TC_03");
  
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
    expect(await objLoginPage.clickLogin()).toContain("Pass");
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
    expect(await objHomePage.selectMenuOption("My Action", "My Demo Tasks")).toContain('Pass');
  
    //Search for the demo Name
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objMyDemoTasksPage.verifyDemoisDisplayed(sDemoName)).toContain('Pass');
    //click on the hyperlink
    expect(await objCommonPage.clickOnDemoNumberHyperLink("Demo Number",sDemoName)).toContain('Pass');  
    expect(await objNewDemoRequest.verifyFieldIsMandatory("Demo Number")).toContain('non mandatory');  
    let teamMember =(objData.teamMember).split(";");
    for(var iCount = 0; iCount < teamMember.length; iCount++)
    {
      expect(await objCommonPage.selectPeoplePickerVal("Team Member",teamMember[iCount])).toContain('Pass');
    }
	  
																							 
														 
																				 
																			  
    
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
    let sAlert="Demo Details Submitted Successfully."
    expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objCommonPage.goToColumn("Team Member")).toContain('Pass');
    expect(await objCommonPage.verifyTextValueInTableCell("Team Member",sDemoName,objData.teamMember)).toContain('Verified');
    done();
});
it('TC_Pre-RequisiteforTC_1 - Create Test demo for TC_01', async(done)=>{
  let objData = dataProvider.getJsonData("./data/myDemoTasks.json", "TC_01");
  console.log(objData);
  //Login My Demo application
  expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
  expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
  expect(await objLoginPage.clickLogin()).toContain("Pass");
  await browser.waitForAngularEnabled(true);
  expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
  //select menu option
 expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
  expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
  expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
  expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");

  var iRandomNum = Math.floor(1000 + Math.random() * 9000);
  sDemoName = "TestDemo_MyDemoTask" + iRandomNum;
  console.log(sDemoName);

  expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
  expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");

  expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnDropDownOption("Primary BU", objData.primaryBu)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnDropDownOption("Application Segment", objData.appSeg)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnDropDownOption("Device Type", objData.deviceType)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnDropDownOption("AMAT Node", objData.amatNode)).toContain("Pass");
 
  expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
  expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

  let sLoggedInUser;
  await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
  expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
  expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
  expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
  expect(await objNewDemoRequest.toggleField("Resource Estimation to Execute Demo (Optional)", true)).toContain("Pass");
  
  expect(await objNewDemoRequest.selectPeoplePickerVal("Estimator Name", objData.estimatorNm)).toContain("Pass");
  expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
  expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
  expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
  expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");

  
  expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
  expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
  expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
  expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");
  browser.sleep(50000);
  expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
  expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');
  done();
});
it('TC_01 - Verify that user shall be able to submit estimation for the required demo using estimation screen in mydemo application', async(done)=>{
    let objData = dataProvider.getJsonData("./data/myDemoTasks.json", "TC_01");
 
  expect(await objLoginPage.setUserName(objLoginData.userNameBUSuperUser)).toContain("Pass");
  expect(await objLoginPage.setPassword(objLoginData.passwordBUSuperUser)).toContain("Pass");
  expect(await objLoginPage.clickLogin()).toContain("Pass");
  await browser.waitForAngularEnabled(true);
  expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
  expect(await objHomePage.selectMenuOption("My Action", "My Demo Tasks")).toContain('Pass');
 
   //Search for the demo Name
   expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
   expect(await objMyDemoTasksPage.verifyDemoisDisplayed(sDemoName)).toContain('Pass');
   //click on the hyperlink
  expect(await objCommonPage.clickOnDemoNumberHyperLink("Demo Number",sDemoName)).toContain('Pass');  
   expect(await objMyDemoTasksPage.verifyAssementsAndEstimationsPageIsDisplayed()).toContain('Pass');

   expect(await objDemoDetailsPage.selectDDOptionOnDemoDtlsPage("Resources","Low")).toContain('Pass');
   expect(await objDemoDetailsPage.setFieldValInDemoDtlsPage("TEM(Samples/wk)","3")).toContain('Pass');
   expect(await objDemoDetailsPage.setFieldValInDemoDtlsPage("SEM(Samples/wk)","1")).toContain('Pass');
   expect(await objDemoDetailsPage.setFieldValInDemoDtlsPage("Engineer/Head Count","2")).toContain('Pass');
   expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Save As Draft")).toContain("Pass");

   sAlertMessage ="Estimation is Saved Successfully."
   expect(await objCommonPage.verifyAlertMessage(sAlertMessage)).toContain('Pass');
							
																										
   expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
   
    expect(await objDemoDetailsPage.getFieldValue("Resources")).toEqual('L');
    expect(await objDemoDetailsPage.getFieldValue("TEM(Samples/wk)")).toEqual('3');
    expect(await objDemoDetailsPage.getFieldValue("SEM(Samples/wk)")).toEqual('1');
    expect(await objDemoDetailsPage.getFieldValue("Engineer/Head Count")).toEqual('2');
    expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
    sAlertMessage ="Demo Request Estimation is Submitted Successfully."   
    expect(await objCommonPage.verifyAlertMessage(sAlertMessage)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

    expect(await objHomePage.selectMenuOption("My Action", "My Demo Tasks")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objMyDemoTasksPage.verifyDemoisDisplayed(sDemoName)).toContain('Fail');
  done();	   
});		
it('TC_Pre-RequisiteforTC_13 - Create Test demo for TC_13', async(done)=>{
  
  let objData = dataProvider.getJsonData("./data/myDemoTasks.json", "TC_01");
  console.log(objData);
  //Login My Demo application
  expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
  expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
  expect(await objLoginPage.clickLogin()).toContain("Pass");
  await browser.waitForAngularEnabled(true);
  expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
  //select menu option
 expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
  expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
  expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
  expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");

  var iRandomNum = Math.floor(1000 + Math.random() * 9000);
  sDemoName = "TestDemo_MyDemoTask" + iRandomNum;
  console.log(sDemoName);

  expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
  expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");

  expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnDropDownOption("Primary BU", objData.primaryBu)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnDropDownOption("Application Segment", objData.appSeg)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnDropDownOption("Device Type", objData.deviceType)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnDropDownOption("AMAT Node", objData.amatNode)).toContain("Pass");
 
  expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
  expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

 
  await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
  expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
  expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
  expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
  expect(await objNewDemoRequest.toggleField("Resource Estimation to Execute Demo (Optional)", true)).toContain("Pass");
  
  expect(await objNewDemoRequest.selectPeoplePickerVal("Estimator Name", objLoginData.userNameEstimator)).toContain("Pass");
  expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
  expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
  expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
  expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");

  
  expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
  expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
  expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
  expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");

  expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
  expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');
 done();
});
it('TC_13 - Verify that Tracker section is added to Estimation Screen and Demo Details Screen.', async(done)=>{
  
//login with the estimator
expect(await objLoginPage.setUserName(objLoginData.userNameEstimator)).toContain("Pass");
expect(await objLoginPage.setPassword(objLoginData.passwordEstimator)).toContain("Pass");
expect(await objLoginPage.clickLogin()).toContain("Pass");
await browser.waitForAngularEnabled(true);
expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
expect(await objHomePage.selectMenuOption("My Action", "My Demo Tasks")).toContain('Pass');

 //Search for the demo Name
 expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
 expect(await objMyDemoTasksPage.verifyDemoisDisplayed(sDemoName)).toContain('Pass');
 //click on the hyperlink
expect(await objCommonPage.clickOnDemoNumberHyperLink("Demo Number",sDemoName)).toContain('Pass');  
 expect(await objMyDemoTasksPage.verifyAssementsAndEstimationsPageIsDisplayed()).toContain('Pass');

 //verify section and its fields are displayed
expect(await objDemoDetailsPage.expandSection("Tracker")).toContain('Pass');
expect(await objMyDemoTasksPage.verifyFieldIsDisplayed("Customer Engagement")).toContain('Pass');
expect(await objMyDemoTasksPage.verifyFieldIsDisplayed("Performance (Spec vs. Actual)")).toContain('Pass');
expect(await objMyDemoTasksPage.verifyFieldIsDisplayed("CoO Gap (spec vs. Actual)")).toContain('Pass');
expect(await objMyDemoTasksPage.verifyFieldIsDisplayed("Onsite Chamber Readiness")).toContain('Pass');
expect(await objMyDemoTasksPage.verifyFieldIsDisplayed("Additional CIP HW Requirement")).toContain('Pass');
expect(await objMyDemoTasksPage.verifyFieldIsDisplayed("CIP HW Shipment Target")).toContain('Pass');
expect(await objMyDemoTasksPage.verifyFieldIsDisplayed("Schedule to close the DPY Gaps")).toContain('Pass');
expect(await objMyDemoTasksPage.verifyFieldIsDisplayed("Risk/Gap Description")).toContain('Pass');
expect(await objMyDemoTasksPage.verifyFieldIsDisplayed("Risk/Gap Closure Plan")).toContain('Pass');

await browser.waitForAngularEnabled(false);
await objHomePage.openApplication('/');   

//login with the requestor
expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
expect(await objLoginPage.clickLogin()).toContain("Pass");
await browser.waitForAngularEnabled(true);
//Search or the demo make it approved 
expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
expect(await objCommonPage.searchRequest(sDemoName));

await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"New Request")).toContain('Pass');
expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objLoginData.userNameSecondaryBURequestor)).toContain('Pass');
expect(await objAllViewPage.selectValueFromDDOnPopUp("Execution Risk","Medium")).toContain('Pass');
expect(await objAllViewPage.clickOnSave()).toContain('Pass');
sAlertMessage="Approval Saved Successfully";
expect(await objCommonPage.verifyAlertMessage(sAlertMessage)).toContain('Pass');
expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

await browser.waitForAngularEnabled(false);
await objHomePage.openApplication('/');   

//login with the Demo Owner
expect(await objLoginPage.setUserName(objLoginData.userNameSecondaryBURequestor)).toContain("Pass");
expect(await objLoginPage.setPassword(objLoginData.passwordSecondaryBURequestor)).toContain("Pass");
expect(await objLoginPage.clickLogin()).toContain("Pass");
await browser.waitForAngularEnabled(true);
expect(await objHomePage.selectMenuOption("My Action", "My Demo Tasks")).toContain('Pass');

 //Search for the demo Name
 expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
 expect(await objMyDemoTasksPage.verifyDemoisDisplayed(sDemoName)).toContain('Pass');
 expect(await objAllViewPage.verifyDemoStatusInGrid(sDemoName,"ACL-Approved")).toContain('Verified');
 
 //click on the hyperlink
expect(await objCommonPage.clickOnDemoNumberHyperLink("Demo Number",sDemoName)).toContain('Pass');  
 

 //verify section and its fields are displayed
expect(await objDemoDetailsPage.expandSection("Tracker")).toContain('Pass');
expect(await objMyDemoTasksPage.verifyFieldIsDisplayed("Customer Engagement")).toContain('Pass');
expect(await objMyDemoTasksPage.verifyFieldIsDisplayed("Performance (Spec vs. Actual)")).toContain('Pass');
expect(await objMyDemoTasksPage.verifyFieldIsDisplayed("CoO Gap (spec vs. Actual)")).toContain('Pass');
expect(await objMyDemoTasksPage.verifyFieldIsDisplayed("Onsite Chamber Readiness")).toContain('Pass');
expect(await objMyDemoTasksPage.verifyFieldIsDisplayed("Additional CIP HW Requirement")).toContain('Pass');
expect(await objMyDemoTasksPage.verifyFieldIsDisplayed("CIP HW Shipment Target")).toContain('Pass');
expect(await objMyDemoTasksPage.verifyFieldIsDisplayed("Schedule to close the DPY Gaps")).toContain('Pass');
expect(await objMyDemoTasksPage.verifyFieldIsDisplayed("Risk/Gap Description")).toContain('Pass');
expect(await objMyDemoTasksPage.verifyFieldIsDisplayed("Risk/Gap Closure Plan")).toContain('Pass');

//update all the values 
expect(await objDemoDetailsPage.selectDDOptionOnDemoDtlsPage("Customer Engagement","Defense")).toContain('Pass');
expect(await objDemoDetailsPage.selectColorRadioBtn("Performance (Spec vs. Actual)","Green")).toContain('Pass');
expect(await objDemoDetailsPage.selectColorRadioBtn("CoO Gap (spec vs. Actual)","Yellow")).toContain('Pass');
expect(await objDemoDetailsPage.clickOnToggleField("Onsite Chamber Readiness")).toContain('Pass');
expect(await objDemoDetailsPage.clickOnToggleField("Additional CIP HW Requirement")).toContain('Pass');
expect(await objDemoDetailsPage.clickOnCalendarIcon("CIP HW Shipment Target")).toContain("Pass");
await objCommonPage.selectDateFromCalendar("Today");

expect(await objDemoDetailsPage.clickOnCalendarIcon("Schedule to close the DPY Gaps")).toContain("Pass");
await objCommonPage.selectDateFromCalendar("Today");

expect(await objDemoDetailsPage.setFieldValInDemoDtlsPage("Risk/Gap Description","Gap Description")).toContain("Pass");
expect(await objDemoDetailsPage.setFieldValInDemoDtlsPage("Risk/Gap Closure Plan","Gap Closure Plan Desc")).toContain("Pass");


expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
let sAlert="Demo Details Submitted Successfully."
expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');


//verify the values are updated
expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
expect(await objCommonPage.searchRequest(sDemoName));
expect(await objCommonPage.goToColumn("Customer Engagement"));
expect(await objCommonPage.verifyTextValueInTableCell("Customer Engagement",sDemoName,"Defense")).toContain('Verified');
expect(await objCommonPage.goToColumn("Performance (Spec vs. Actual)"));
expect(await objCommonPage.verifySpecificAttributeValueInTableCell("Performance (Spec vs. Actual)",sDemoName,"data-original-title","Low Risk")).toContain('Verified');
expect(await objCommonPage.goToColumn("CoO Gap (spec vs. Actual)"));
expect(await objCommonPage.verifySpecificAttributeValueInTableCell("CoO Gap (spec vs. Actual)",sDemoName,"data-original-title","Medium Risk")).toContain('Verified');
expect(await objCommonPage.goToColumn("Onsite Chamber Readiness"));
expect(await objCommonPage.verifyTextValueInTableCell("Onsite Chamber Readiness",sDemoName,"Yes")).toContain('Verified');
expect(await objCommonPage.goToColumn("Additional CIP HW Requirement"));
expect(await objCommonPage.verifyTextValueInTableCell("Additional CIP HW Requirement",sDemoName,"Yes")).toContain('Verified');

let sDate;
objCommonPage.getCurrentDate("mm/dd/yyyy").then(function(currDate){ sDate=currDate;});
expect(await objCommonPage.goToColumn("CIP HW Shipment Target"));
expect(await objCommonPage.verifyTextValueInTableCell("CIP HW Shipment Target",sDemoName,sDate)).toContain('Verified');

expect(await objCommonPage.goToColumn("Schedule to close the DPY Gaps"));
expect(await objCommonPage.verifyTextValueInTableCell("Schedule to close the DPY Gaps",sDemoName,sDate)).toContain('Verified');


expect(await objCommonPage.goToColumn("Risk/Gap Description"));
expect(await objCommonPage.verifyTextValueInTableCell("Risk/Gap Description",sDemoName,"Gap Description")).toContain('Verified');

expect(await objCommonPage.goToColumn("Risk/Gap Closure Plan"));
expect(await objCommonPage.verifyTextValueInTableCell("Risk/Gap Closure Plan",sDemoName,"Gap Closure Plan Desc")).toContain('Verified');



//Update the values from All view screen
expect(await objCommonPage.goToColumn("Customer Engagement"));
expect(await objCommonPage.clickInTheTableCell("Customer Engagement",sDemoName)).toContain('Pass');
expect(await objDemoDetailsPage.clickOnApplicationFieldDropDown()).toContain("Pass");
expect(await objDemoDetailsPage.selectOptionFromApplicationDDList("Application","FCVD Cure")).toContain("Pass");
expect(await objAllViewPage.selectOptionsFromDDOnPopUp("Customer Engagement","Recovery")).toContain('Pass');

expect(await objAllViewPage.clickOnSave()).toContain('Pass');

expect(await objCommonPage.goToColumn("Performance (Spec vs. Actual)"));
expect(await objCommonPage.clickInTheTableCell("Performance (Spec vs. Actual)",sDemoName)).toContain('Pass');
expect(await objCommonPage.selectOptionFromDDInTableColumn("Performance (Spec vs. Actual)","Red")).toContain('Pass');
expect(await objCommonPage.goToColumn("CoO Gap (spec vs. Actual)"));
expect(await objCommonPage.clickInTheTableCell("CoO Gap (spec vs. Actual)",sDemoName)).toContain('Pass');
expect(await objCommonPage.selectOptionFromDDInTableColumn("CoO Gap (spec vs. Actual)","Red")).toContain('Pass');

expect(await objCommonPage.goToColumn("Onsite Chamber Readiness"));
expect(await objCommonPage.clickInTheTableCell("Onsite Chamber Readiness",sDemoName)).toContain('Pass');
expect(await objCommonPage.selectOptionFromDDInTableColumn("Onsite Chamber Readiness","No")).toContain('Pass');
expect(await objCommonPage.goToColumn("Additional CIP HW Requirement"));
expect(await objCommonPage.clickInTheTableCell("Additional CIP HW Requirement",sDemoName)).toContain('Pass');
expect(await objCommonPage.selectOptionFromDDInTableColumn("Additional CIP HW Requirement","No")).toContain('Pass');

expect(await objCommonPage.goToColumn("CIP HW Shipment Target"));
expect(await objCommonPage.clickInTheTableCell("CIP HW Shipment Target",sDemoName)).toContain('Pass');
expect(await objCommonPage.selectDateFromCalendarInTable("Today"));
expect(await objCommonPage.sendKeysInDateTypeTableCell("CIP HW Shipment Target",sDemoName,"Enter~Enter")).toContain('Pass');


expect(await objCommonPage.goToColumn("Schedule to close the DPY Gaps"));
expect(await objCommonPage.clickInTheTableCell("Schedule to close the DPY Gaps",sDemoName)).toContain('Pass');
expect(await objCommonPage.selectDateFromCalendarInTable("Today"));
expect(await objCommonPage.sendKeysInDateTypeTableCell("Schedule to close the DPY Gaps",sDemoName,"Enter~Enter")).toContain('Pass');


expect(await objCommonPage.goToColumn("Risk/Gap Description"));
expect(await objCommonPage.clickInTheTableCell("Risk/Gap Description",sDemoName)).toContain('Pass');
expect(await objCommonPage.setTextInTableCellTextarea("Gap Description comments")).toContain('Pass');

expect(await objCommonPage.goToColumn("Risk/Gap Closure Plan"));
expect(await objCommonPage.clickInTheTableCell("Risk/Gap Closure Plan",sDemoName)).toContain('Pass');
expect(await objCommonPage.setTextInTableCellTextarea("Gap Closure Plan Desc comments")).toContain('Pass');


//verify the updated values are displayed in All view screen
expect(await objCommonPage.goToColumn("Customer Engagement"));
expect(await objCommonPage.verifyTextValueInTableCell("Customer Engagement",sDemoName,"Recovery")).toContain('Verified');
expect(await objCommonPage.goToColumn("Performance (Spec vs. Actual)"));
expect(await objCommonPage.verifySpecificAttributeValueInTableCell("Performance (Spec vs. Actual)",sDemoName,"data-original-title","High Risk")).toContain('Verified');
expect(await objCommonPage.goToColumn("CoO Gap (spec vs. Actual)"));
expect(await objCommonPage.verifySpecificAttributeValueInTableCell("CoO Gap (spec vs. Actual)",sDemoName,"data-original-title","High Risk")).toContain('Verified');
expect(await objCommonPage.goToColumn("Onsite Chamber Readiness"));
expect(await objCommonPage.verifyTextValueInTableCell("Onsite Chamber Readiness",sDemoName,"No")).toContain('Verified');
expect(await objCommonPage.goToColumn("Additional CIP HW Requirement"));
expect(await objCommonPage.verifyTextValueInTableCell("Additional CIP HW Requirement",sDemoName,"No")).toContain('Verified');

let sTodayDate;
objCommonPage.getCurrentDate("mm/dd/yyyy").then(function(currDate){ sTodayDate=currDate;});
expect(await objCommonPage.goToColumn("CIP HW Shipment Target"));
expect(await objCommonPage.verifyTextValueInTableCell("CIP HW Shipment Target",sDemoName,sTodayDate)).toContain('Pass');

expect(await objCommonPage.goToColumn("Schedule to close the DPY Gaps"));
expect(await objCommonPage.verifyTextValueInTableCell("Schedule to close the DPY Gaps",sDemoName,sTodayDate)).toContain('Pass');

expect(await objCommonPage.goToColumn("Risk/Gap Description"));
expect(await objCommonPage.verifyTextValueInTableCell("Risk/Gap Description",sDemoName,"Gap Description comments")).toContain('Pass');

expect(await objCommonPage.goToColumn("Risk/Gap Closure Plan"));
expect(await objCommonPage.verifyTextValueInTableCell("Risk/Gap Closure Plan",sDemoName,"Gap Closure Plan Desc comments")).toContain('Pass');


done();
});
it('TC_17 - Verify in MyDemo Application that there is a Demo Issue field dropdown  is added in Demo Details screen and also in the view screen editable for Demo Owner and Demo Requestor and Super User for Approved and Completed demos', async(done)=>{
  let objData = dataProvider.getJsonData("./data/myDemoTasks.json", "TC_17");
  console.log(objData);
    
  //login with the Requestor
  expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
  expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
  expect(await objLoginPage.clickLogin()).toContain("Pass");
  await browser.waitForAngularEnabled(true);
    
  expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
  
   //Search for the demo Name
   expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
   expect(await objMyDemoTasksPage.verifyDemoisDisplayed(sDemoName)).toContain('Pass');
 
   //click on the hyperlink
  expect(await objCommonPage.clickOnDemoNumberHyperLink("Demo Number",sDemoName)).toContain('Pass');  
   
  
   //verify section and its fields are displayed
  expect(await objDemoDetailsPage.expandSection("Demo Issue")).toContain('Pass');
  expect(await objDemoDetailsPage.clickOnToggleField("Demo Issue")).toContain('Pass');
  let issueList = (objData.issueTypeDDList).split("~");
  let wspList = (objData.wspvalueList).split("~");
  for(var iCount =0; iCount<issueList.length; iCount++)
  {
      expect(await objDemoDetailsPage.verifyIssueTypeDDValue(issueList[iCount])).toContain('Pass');
  }
  
  //update all the values 
  expect(await objDemoDetailsPage.selectIssueType(issueList[0])).toContain('Pass');
  expect(await objDemoDetailsPage.selectWaferSlotPosition(wspList[0])).toContain('Pass');
  expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");
  expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
 
  sAlertMessage="Demo Details Submitted Successfully."
  expect(await objCommonPage.verifyAlertMessage(sAlertMessage)).toContain('Pass');
  expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
  
  
  //verify the values are updated
  expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
  expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
  expect(await objCommonPage.goToColumn("Demo Issue")).toContain("Pass");
  expect(await objCommonPage.clickInTheTableCellUsingJavaScript("Demo Issue",sDemoName)).toContain('Pass');
  expect(await objAllViewPage.verifyDemoIssueValuesinTable(objData.issuesCount_Req)).toContain('Pass');
  expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');

  //login with the Demo Owner
  await browser.waitForAngularEnabled(false);
  await objHomePage.openApplication('/');   
  expect(await objLoginPage.setUserName(objLoginData.userNameSecondaryBURequestor)).toContain("Pass");
  expect(await objLoginPage.setPassword(objLoginData.passwordSecondaryBURequestor)).toContain("Pass");
  expect(await objLoginPage.clickLogin()).toContain("Pass");
  await browser.waitForAngularEnabled(true);
    
  expect(await objHomePage.selectMenuOption("My Action", "My Demo Tasks")).toContain('Pass');

  //Search for the demo Name
  expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
  expect(await objMyDemoTasksPage.verifyDemoisDisplayed(sDemoName)).toContain('Pass');

  //click on the hyperlink
  expect(await objCommonPage.clickOnDemoNumberHyperLink("Demo Number",sDemoName)).toContain('Pass');  
  

  //verify section and its fields are displayed
  expect(await objDemoDetailsPage.expandSection("Demo Issue")).toContain('Pass');
  
  //update all the values 
  expect(await objNewDemoRequest.clickOnAddSecondaryBU()).toContain('Pass');
  expect(await objDemoDetailsPage.selectIssueType(issueList[1])).toContain('Pass');
  expect(await objDemoDetailsPage.selectWaferSlotPosition(wspList[1])).toContain('Pass');
  expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");
  expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");

  sAlertMessage="Demo Details Submitted Successfully."
  expect(await objCommonPage.verifyAlertMessage(sAlertMessage)).toContain('Pass');
  expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');


  //verify the values are updated
  expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
  expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
  expect(await objCommonPage.goToColumn("Demo Issue")).toContain("Pass");
  expect(await objCommonPage.clickInTheTableCellUsingJavaScript("Demo Issue",sDemoName)).toContain('Pass');
  expect(await objAllViewPage.verifyDemoIssueValuesinTable(objData.issuesCount_DO));
  expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');

  //login with the Super user
  await browser.waitForAngularEnabled(false);
  await objHomePage.openApplication('/');   
  expect(await objLoginPage.setUserName(objLoginData.userNameBUSuperUser)).toContain("Pass");
  expect(await objLoginPage.setPassword(objLoginData.passwordBUSuperUser)).toContain("Pass");
  expect(await objLoginPage.clickLogin()).toContain("Pass");
  await browser.waitForAngularEnabled(true);
    
  expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');

  //Search for the demo Name
  expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
  expect(await objMyDemoTasksPage.verifyDemoisDisplayed(sDemoName)).toContain('Pass');

  //click on the hyperlink
  expect(await objCommonPage.clickOnDemoNumberHyperLink("Demo Number",sDemoName)).toContain('Pass');  
  

  //verify section and its fields are displayed
  expect(await objDemoDetailsPage.expandSection("Demo Issue")).toContain('Pass');
  
  //update all the values 
  expect(await objNewDemoRequest.clickOnAddSecondaryBU()).toContain('Pass');
  expect(await objDemoDetailsPage.selectIssueType(issueList[2])).toContain('Pass');
  expect(await objDemoDetailsPage.selectWaferSlotPosition(wspList[2])).toContain('Pass');
  expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");
  expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");

  sAlertMessage="Demo Details Submitted Successfully."
  expect(await objCommonPage.verifyAlertMessage(sAlertMessage)).toContain('Pass');
  expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');


  //verify the values are updated
  expect(await objCommonPage.goToColumn("Demo Issue")).toContain("Pass");
  expect(await objCommonPage.clickInTheTableCellUsingJavaScript("Demo Issue",sDemoName)).toContain('Pass');
  expect(await objAllViewPage.verifyDemoIssueValuesinTable(objData.issuesCount_SU)).toContain('Pass');
  expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');

  //Change the Exceution Risk to complete and update wafer location “In Transit to Account” , “In Transit to Customer”, "No Customer Wafer" or "Customer Hand Carried"
   expect(await objCommonPage.goToColumn("Current Execution Risk")).toContain('Pass');
  expect(await objCommonPage.clickInTheTableCell("Current Execution Risk",sDemoName)).toContain('Pass');
  expect(await objCommonPage.selectOptionFromDDInTableColumn("Current Execution Risk","Complete")).toContain('Pass');

  //verify Demo issue is editable by Super user
  expect(await objCommonPage.goToColumn("Demo Issue")).toContain("Pass");
  expect(await objCommonPage.clickInTheTableCellUsingJavaScript("Demo Issue",sDemoName)).toContain('Pass');
  expect(await objCommonPage.verifyAlertHeader("Edit")).toContain('Pass');
  expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');

  //login with the Demo Owner and verify Demo issue is editable
  await browser.waitForAngularEnabled(false);
  await objHomePage.openApplication('/');   
  expect(await objLoginPage.setUserName(objLoginData.userNameSecondaryBURequestor)).toContain("Pass");
  expect(await objLoginPage.setPassword(objLoginData.passwordSecondaryBURequestor)).toContain("Pass");
  expect(await objLoginPage.clickLogin()).toContain("Pass");
  await browser.waitForAngularEnabled(true);
  expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
  expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
  expect(await objCommonPage.goToColumn("Demo Issue")).toContain("Pass");
  expect(await objCommonPage.clickInTheTableCellUsingJavaScript("Demo Issue",sDemoName)).toContain('Pass');
  expect(await objCommonPage.verifyAlertHeader("Edit")).toContain('Pass');
  expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');

  //login with the Requestor and verify Demo issue is editable
  await browser.waitForAngularEnabled(false);
  await objHomePage.openApplication('/'); 
  expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
  expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
  expect(await objLoginPage.clickLogin()).toContain("Pass");
  await browser.waitForAngularEnabled(true);
  expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
  expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
  expect(await objCommonPage.goToColumn("Demo Issue")).toContain("Pass");
  expect(await objCommonPage.clickInTheTableCellUsingJavaScript("Demo Issue",sDemoName)).toContain('Pass');
  expect(await objCommonPage.verifyAlertHeader("Edit")).toContain('Pass');
  expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');

  done();
});
it('TC_Pre-Requisite_27 - Create Demo for TC_27 ', async(done)=>{
  
  let objData = dataProvider.getJsonData("./data/myDemoTasks.json", "TC_27");
  console.log(objData);
  //Login My Demo application
  expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
  expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
  expect(await objLoginPage.clickLogin()).toContain("Pass");
  await browser.waitForAngularEnabled(true);
  expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
  //select menu option
 expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
  expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
  expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
  expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");

  var iRandomNum = Math.floor(1000 + Math.random() * 9000);
  sDemoName = "TestDemo_MyDemoTask" + iRandomNum;
  console.log(sDemoName);

  expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
  expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");

  expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnDropDownOption("Primary BU", objData.primaryBu)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnDropDownOption("Application Segment", objData.appSeg)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnDropDownOption("Device Type", objData.deviceType)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnDropDownOption("AMAT Node", objData.amatNode)).toContain("Pass");
 
  expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
  expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

 
  await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
  expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
  expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
  expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass"); expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
  expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
  expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
  expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
  await objNewDemoRequest.clickOnBrowseButtonAgainstField("Customer Spec");
  const filePath = path.resolve('./autoItScripts/TestUpload_CustSpec.xlsx');
  const exePath = path.resolve('./autoItScripts/browseFile.exe')

  cp.execSync(exePath + ' ' + filePath);
  await browser.sleep(5000);
  expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
  expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Customer Spec")).toContain("Pass");
  expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");

  expect(await objNewDemoRequest.clickWaferStackOption(objData.waferStackOption)).toContain("Pass");
  await objNewDemoRequest.clickOnBrowseButtonAgainstField("Wafer Stack");
  const filePath1 = path.resolve('./autoItScripts/TestUpload_WaferStack.xlsx');


  cp.execSync(exePath + ' ' + filePath1);
  await browser.sleep(5000);
  expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
  expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Wafer Stack")).toContain("Pass");
  expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
  expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
 
  expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');


  expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');

await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"New Request")).toContain('Pass');
expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objLoginData.userNameOtherGroupUser)).toContain('Pass');
expect(await objAllViewPage.clickOnSave()).toContain('Pass');
sAlertMessage="Approval Saved Successfully";
expect(await objCommonPage.verifyAlertMessage(sAlertMessage)).toContain('Pass');
expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
 done();
});;
it('TC_27 - Verify that Other Groups user shall be added as an internal user like a Demo owner in MyDemo Application ', async (done)=>
{
  let objData = dataProvider.getJsonData("./data/myDemoTasks.json", "TC_27");
  console.log(objData);
   //Login My Demo application as Demo Owner
  expect(await objLoginPage.setUserName(objLoginData.userNameOtherGroupUser)).toContain('Pass');
   expect(await objLoginPage.setPassword(objLoginData.passwordOtherGroupUser)).toContain('Pass');
   expect(await objLoginPage.clickLogin()).toContain("Pass");
  await browser.waitForAngularEnabled(true);
   expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")
   
   expect(await objHomePage.selectMenuOption("My Action", "My Demo Tasks")).toContain('Pass');
 
   //Search for the demo Name
   expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
   expect(await objMyDemoTasksPage.verifyDemoisDisplayed(sDemoName)).toContain('Pass');
   //click on the hyperlink
   expect(await objCommonPage.clickOnDemoNumberHyperLink("Demo Number",sDemoName)).toContain('Pass');  
   expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain('Pass'); 
 
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
  
    //edit some fields
    
    expect(await objDemoDetailsPage.clickOnFieldDropDown(objData.demoLocationCol)).toContain("Pass");
    expect(await objDemoDetailsPage.selectOptionFromDDList(objData.demoLocationCol,objData.demoLocationVal)).toContain("Pass");
    expect(await objAllViewPage.selectValueFromDDOnPopUp("Execution Risk","Medium")).toContain('Pass');

    expect(await objDemoDetailsPage.clickOnBtn("Submit")).toContain("Pass");
    sAlertMessage="Demo Details Submitted Successfully."
    expect(await objCommonPage.verifyAlertMessage(sAlertMessage)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
     
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
 
   //Search for the demo Name
   expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
   
    expect(await objMyDemoTasksPage.verifyDemoisDisplayed(sDemoName)).toContain('Pass');
    
     expect(await objCommonPage.goToColumn("Current Execution Risk")).toContain('Pass');
     expect(await objCommonPage.verifyTextValueInTableCell("Current Execution Risk", sDemoName, "M")).toContain("Verified");
     expect(await objCommonPage.goToColumn(objData.demoLocationCol)).toContain('Pass');
     expect(await objCommonPage.getTableCellValue(objData.demoLocationCol,sDemoName)).toEqual(objData.demoLocationVal);
    
    
     expect(await objCommonPage.goToColumn("Risk/Gap Description"));
    expect(await objCommonPage.clickInTheTableCell("Risk/Gap Description",sDemoName)).toContain('Pass');
    expect(await objCommonPage.setTextInTableCellTextarea("Gap Description comments")).toContain('Pass');

    expect(await objCommonPage.goToColumn("Risk/Gap Closure Plan"));
    expect(await objCommonPage.clickInTheTableCell("Risk/Gap Closure Plan",sDemoName)).toContain('Pass');
    expect(await objCommonPage.setTextInTableCellTextarea("Gap Closure Plan Desc comments")).toContain('Pass');

     expect(await objCommonPage.goToColumn("Risk/Gap Description"));
    expect(await objCommonPage.verifyTextValueInTableCell("Risk/Gap Description",sDemoName,"Gap Description comments")).toContain('Verified');

    expect(await objCommonPage.goToColumn("Risk/Gap Closure Plan"));
    expect(await objCommonPage.verifyTextValueInTableCell("Risk/Gap Closure Plan",sDemoName,"Gap Closure Plan Desc comments")).toContain('Verified');     
    done();
});
it('TC_28 - Verify that Other Groups user shall be added as an internal user like a Team Member in MyDemo Application  ', async (done)=>
{
  let objData = dataProvider.getJsonData("./data/myDemoTasks.json", "TC_27");
  console.log(objData);
   //Login My Demo application as global admin user  
  expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
   expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
   expect(await objLoginPage.clickLogin()).toContain("Pass");
  await browser.waitForAngularEnabled(true);
   expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")
   
   expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
   await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
   //Search for the demo Name
   expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
   
    expect(await objMyDemoTasksPage.verifyDemoisDisplayed(sDemoName)).toContain('Pass');
   
     expect(await objCommonPage.clickInTheTableCell("Demo Owner",sDemoName)).toContain('Pass');     
     expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",sLoggedInUser)).toContain('Pass');
     expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    expect(await objCommonPage.getTableCellValue("Demo Owner",sDemoName)).toEqual(sLoggedInUser);

    expect(await objCommonPage.goToColumn("Team Member")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Team Member",sDemoName)).toContain('Pass');     
    expect(await objCommonPage.selectPeoplePickerVal("Team Member",objLoginData.userNameOtherGroupUser)).toContain('Pass');
     expect(await objAllViewPage.clickOnSave()).toContain('Pass');
     browser.sleep(2000);
     expect(await objCommonPage.getTableCellValue("Team Member",sDemoName)).toEqual(objLoginData.userNameOtherGroupUser);
    
    
   await browser.waitForAngularEnabled(false);
   await objHomePage.openApplication('/'); 
   expect(await objLoginPage.setUserName(objLoginData.userNameOtherGroupUser)).toContain('Pass');
   expect(await objLoginPage.setPassword(objLoginData.passwordOtherGroupUser)).toContain('Pass');
   expect(await objLoginPage.clickLogin()).toContain("Pass");
   await browser.waitForAngularEnabled(true);

   //Search for the demo Name
   expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
   expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
   expect(await objMyDemoTasksPage.verifyDemoisDisplayed(sDemoName)).toContain('Pass');
   //click on the hyperlink
   expect(await objCommonPage.clickOnDemoNumberHyperLink("Demo Number",sDemoName)).toContain('Pass');  
   expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain('Pass'); 
 
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
  
    //edit some fields    
    expect(await objDemoDetailsPage.clickOnFieldDropDown(objData.toolNameCol)).toContain("Pass");
    expect(await objDemoDetailsPage.selectOptionFromDDList(objData.toolNameCol,objData.toolNameValue)).toContain("Pass");
    
    expect(await objDemoDetailsPage.clickOnBtn("Submit")).toContain("Pass");
    sAlertMessage="Demo Details Submitted Successfully."
    expect(await objCommonPage.verifyAlertMessage(sAlertMessage)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    
    expect(await objHomePage.clickOnMenuOption("Home")).toContain('Pass');
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
   expect(await objMyDemoTasksPage.verifyDemoisDisplayed(sDemoName)).toContain('Pass');
    //verify value is added
    expect(await objCommonPage.goToColumn(objData.toolIDCol)).toContain('Pass');
    expect(await objCommonPage.getTableCellValue(objData.toolIDCol,sDemoName)).toEqual(objData.toolIDVal);

     expect(await objCommonPage.goToColumn("Risk/Gap Description"));
    expect(await objCommonPage.clickInTheTableCell("Risk/Gap Description",sDemoName)).toContain('Pass');
    expect(await objCommonPage.setTextInTableCellTextarea("Gap Description comments")).toContain('Pass');

    expect(await objCommonPage.goToColumn("Risk/Gap Closure Plan"));
    expect(await objCommonPage.clickInTheTableCell("Risk/Gap Closure Plan",sDemoName)).toContain('Pass');
    expect(await objCommonPage.setTextInTableCellTextarea("Gap Closure Plan Desc comments")).toContain('Pass');

    //verify edited value is updated
     expect(await objCommonPage.goToColumn("Risk/Gap Description"));
    expect(await objCommonPage.verifyTextValueInTableCell("Risk/Gap Description",sDemoName,"Gap Description comments")).toContain('Verified');

    expect(await objCommonPage.goToColumn("Risk/Gap Closure Plan"));
    expect(await objCommonPage.verifyTextValueInTableCell("Risk/Gap Closure Plan",sDemoName,"Gap Closure Plan Desc comments")).toContain('Verified');     
     
    done();
});														 
it('TC_29 - Verify that Other Groups user shall be added as an internal user like a RATorCAT Account Manager in MyDemo Application  ', async (done)=>
{  
  let objData = dataProvider.getJsonData("./data/myDemoTasks.json", "TC_27");
  console.log(objData);
   //Login My Demo application as global admin user  
  expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
   expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
   expect(await objLoginPage.clickLogin()).toContain("Pass");
  await browser.waitForAngularEnabled(true);
   expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")
   
   expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
   await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
   //Search for the demo Name
   expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
   
    expect(await objMyDemoTasksPage.verifyDemoisDisplayed(sDemoName)).toContain('Pass');
   
    expect(await objCommonPage.goToColumn("Team Member")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Team Member",sDemoName)).toContain('Pass');     
    expect(await objCommonPage.removeSelectedPeople("Team Member",objLoginData.userNameOtherGroupUser)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');

    expect(await objCommonPage.goToColumn("CAT/RAT Manager")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("CAT/RAT Manager",sDemoName)).toContain('Pass');     
    expect(await objCommonPage.selectPeoplePickerVal("CAT/RAT Manager",objLoginData.userNameOtherGroupUser)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    browser.sleep(3000);
    expect(await objCommonPage.getTableCellValue("CAT/RAT Manager",sDemoName)).toEqual(objLoginData.userNameOtherGroupUser);
    
    //login with CAT/RAT manager
   await browser.waitForAngularEnabled(false);
   await objHomePage.openApplication('/'); 
   expect(await objLoginPage.setUserName(objLoginData.userNameOtherGroupUser)).toContain('Pass');
   expect(await objLoginPage.setPassword(objLoginData.passwordOtherGroupUser)).toContain('Pass');
   expect(await objLoginPage.clickLogin()).toContain("Pass");
   await browser.waitForAngularEnabled(true);

   //Search for the demo Name
   expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
   expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
   expect(await objMyDemoTasksPage.verifyDemoisDisplayed(sDemoName)).toContain('Pass');
   //click on the hyperlink
   expect(await objCommonPage.clickOnDemoNumberHyperLink("Demo Number",sDemoName)).toContain('Pass');  
   expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain('Pass'); 
 
    await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
  
    //edit some fields    
   expect(await objDemoDetailsPage.selectDDOptionOnDemoDtlsPage("Customer Wafer Destination",objData.customerWaferDes)).toContain("Pass");
    expect(await objDemoDetailsPage.clickOnBtn("Submit")).toContain("Pass");
    sAlertMessage="Demo Details Submitted Successfully."
    expect(await objCommonPage.verifyAlertMessage(sAlertMessage)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    
    expect(await objHomePage.clickOnMenuOption("Home")).toContain('Pass');
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
   expect(await objMyDemoTasksPage.verifyDemoisDisplayed(sDemoName)).toContain('Pass');
    //verify value is added
    expect(await objCommonPage.goToColumn("Customer Wafer Destination")).toContain('Pass');
    expect(await objCommonPage.verifyTextValueInTableCell("Customer Wafer Destination", sDemoName,objData.customerWaferDes)).toContain("Verified");
    
  
     expect(await objCommonPage.goToColumn("Risk/Gap Description"));
    expect(await objCommonPage.clickInTheTableCell("Risk/Gap Description",sDemoName)).toContain('Pass');
    expect(await objCommonPage.setTextInTableCellTextarea("Gap Description Cat/RAT comments")).toContain('Pass');

    expect(await objCommonPage.goToColumn("Risk/Gap Closure Plan"));
    expect(await objCommonPage.clickInTheTableCell("Risk/Gap Closure Plan",sDemoName)).toContain('Pass');
    expect(await objCommonPage.setTextInTableCellTextarea("Gap Closure Plan Desc Cat/RAT comments")).toContain('Pass');

    //verify edited value is updated
     expect(await objCommonPage.goToColumn("Risk/Gap Description"));
    expect(await objCommonPage.verifyTextValueInTableCell("Risk/Gap Description",sDemoName,"Gap Description Cat/RAT comments")).toContain('Verified');

    expect(await objCommonPage.goToColumn("Risk/Gap Closure Plan"));
    expect(await objCommonPage.verifyTextValueInTableCell("Risk/Gap Closure Plan",sDemoName,"Gap Closure Plan Desc Cat/RAT comments")).toContain('Verified');     
     
    done();
});
it('TC_30 - Verify that Other Groups user shall be added as an internal user like a KPU HeadorGPM in MyDemo Application ', async (done)=>
{  
   //Login My Demo application as global admin user  
  expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
   expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
   expect(await objLoginPage.clickLogin()).toContain("Pass");
  await browser.waitForAngularEnabled(true);
   expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")
   
   expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
   await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
   //Search for the demo Name
   expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
   
    expect(await objMyDemoTasksPage.verifyDemoisDisplayed(sDemoName)).toContain('Pass');
    expect(await objCommonPage.clickOnDemoNumberHyperLink("Demo Number",sDemoName)).toContain('Pass');  
    expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain('Pass'); 
    expect(await objCommonPage.removeSelectedPeople("CAT/RAT Manager",objLoginData.userNameOtherGroupUser)).toContain('Pass');
    expect(await objCommonPage.selectPeoplePickerVal("KPU Head/GPM",objLoginData.userNameOtherGroupUser)).toContain('Pass');
   
    expect(await objDemoDetailsPage.clickOnBtn("Submit")).toContain("Pass");
    sAlertMessage="Demo Details Submitted Successfully."
    expect(await objCommonPage.verifyAlertMessage(sAlertMessage)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

    //login with KPU GPM 
   await browser.waitForAngularEnabled(false);
   await objHomePage.openApplication('/'); 
   expect(await objLoginPage.setUserName(objLoginData.userNameOtherGroupUser)).toContain('Pass');
   expect(await objLoginPage.setPassword(objLoginData.passwordOtherGroupUser)).toContain('Pass');
   expect(await objLoginPage.clickLogin()).toContain("Pass");
   await browser.waitForAngularEnabled(true);

   //Search for the demo Name
   expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
   expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
   expect(await objMyDemoTasksPage.verifyDemoisDisplayed(sDemoName)).toContain('Pass');
   //click on the hyperlink
   expect(await objCommonPage.clickOnDemoNumberHyperLink("Demo Number",sDemoName)).toContain('Pass');  
   expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain('Pass'); 
 
    //edit some fields    
    expect(await objDemoDetailsPage.clickOnMultipleSelectFieldDropDown("Chamber Position")).toContain('Pass');
    expect(await objDemoDetailsPage.selectMultipleOptionFromDDList("Chamber Position", "2")).toContain('Pass');    
    expect(await objDemoDetailsPage.clickOnBtn("Submit")).toContain("Pass");
    sAlertMessage="Demo Details Submitted Successfully."
    expect(await objCommonPage.verifyAlertMessage(sAlertMessage)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    
    expect(await objHomePage.clickOnMenuOption("Home")).toContain('Pass');
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
   expect(await objMyDemoTasksPage.verifyDemoisDisplayed(sDemoName)).toContain('Pass');
    //verify value is added
    expect(await objCommonPage.goToColumn("Chamber Position")).toBeTruthy();
    expect(await objCommonPage.getTableCellValue("Chamber Position",sDemoName)).toEqual("2;");
  
     expect(await objCommonPage.goToColumn("Risk/Gap Description"));
    expect(await objCommonPage.clickInTheTableCell("Risk/Gap Description",sDemoName)).toContain('Pass');
    expect(await objCommonPage.setTextInTableCellTextarea("Gap Description KPU GPM comments")).toContain('Pass');

    expect(await objCommonPage.goToColumn("Risk/Gap Closure Plan"));
    expect(await objCommonPage.clickInTheTableCell("Risk/Gap Closure Plan",sDemoName)).toContain('Pass');
    expect(await objCommonPage.setTextInTableCellTextarea("Gap Closure Plan Desc KPU GPM comments")).toContain('Pass');

    //verify edited value is updated
     expect(await objCommonPage.goToColumn("Risk/Gap Description"));
    expect(await objCommonPage.verifyTextValueInTableCell("Risk/Gap Description",sDemoName,"Gap Description KPU GPM comments")).toContain('Verified');

    expect(await objCommonPage.goToColumn("Risk/Gap Closure Plan"));
    expect(await objCommonPage.verifyTextValueInTableCell("Risk/Gap Closure Plan",sDemoName,"Gap Closure Plan Desc KPU GPM comments")).toContain('Verified');     
     
    done();
});
it('TC_31 - Verify that Other Groups user shall be added as an internal user like Productivity Owner in MyDemo Application ', async (done)=>
{  
   //Login My Demo application as global admin user  
  expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
   expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
   expect(await objLoginPage.clickLogin()).toContain("Pass");
  await browser.waitForAngularEnabled(true);
   expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")
   
   
   expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
   await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
   //Search for the demo Name
   expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
   
    expect(await objMyDemoTasksPage.verifyDemoisDisplayed(sDemoName)).toContain('Pass');
   
    expect(await objMyDemoTasksPage.verifyDemoisDisplayed(sDemoName)).toContain('Pass');
    expect(await objCommonPage.clickOnDemoNumberHyperLink("Demo Number",sDemoName)).toContain('Pass');  
    expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain('Pass'); 
    expect(await objCommonPage.removeSelectedPeople("KPU Head/GPM",objLoginData.userNameOtherGroupUser)).toContain('Pass');
    
    expect(await objDemoDetailsPage.clickOnBtn("Submit")).toContain("Pass");
    sAlertMessage="Demo Details Submitted Successfully."
    expect(await objCommonPage.verifyAlertMessage(sAlertMessage)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

        expect(await objCommonPage.goToColumn("Productivity Owner")).toContain('Pass');
    expect(await objCommonPage.clickInTheTableCell("Productivity Owner",sDemoName)).toContain('Pass');     
    expect(await objCommonPage.selectPeoplePickerVal("Productivity Owner",objLoginData.userNameOtherGroupUser)).toContain('Pass');
    expect(await objAllViewPage.clickOnSave()).toContain('Pass');
    browser.sleep(3000);
    expect(await objCommonPage.getTableCellValue("Productivity Owner",sDemoName)).toEqual(objLoginData.userNameOtherGroupUser);
    

    //login with KPU GPM 
   await browser.waitForAngularEnabled(false);
   await objHomePage.openApplication('/'); 
   expect(await objLoginPage.setUserName(objLoginData.userNameOtherGroupUser)).toContain('Pass');
   expect(await objLoginPage.setPassword(objLoginData.passwordOtherGroupUser)).toContain('Pass');
   expect(await objLoginPage.clickLogin()).toContain("Pass");
   await browser.waitForAngularEnabled(true);

   //Search for the demo Name
   expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
   expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
   expect(await objMyDemoTasksPage.verifyDemoisDisplayed(sDemoName)).toContain('Pass');
   //click on the hyperlink
   expect(await objCommonPage.clickOnDemoNumberHyperLink("Demo Number",sDemoName)).toContain('Pass');  
   expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain('Pass'); 
 
    //edit some fields   
    expect(await objNewDemoRequest.setDimensions('12.3cm')).toContain("Pass"); 
    expect(await objDemoDetailsPage.clickOnBtn("Submit")).toContain("Pass");
    sAlertMessage="Demo Details Submitted Successfully."
    expect(await objCommonPage.verifyAlertMessage(sAlertMessage)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    
    expect(await objHomePage.clickOnMenuOption("Home")).toContain('Pass');
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
   expect(await objMyDemoTasksPage.verifyDemoisDisplayed(sDemoName)).toContain('Pass');
    //verify value is added
    expect(await objCommonPage.goToColumn("Dimension")).toBeTruthy();
    expect(await objCommonPage.getTableCellValue("Dimension",sDemoName)).toEqual('12.3cm');
  
     expect(await objCommonPage.goToColumn("Risk/Gap Description"));
    expect(await objCommonPage.clickInTheTableCell("Risk/Gap Description",sDemoName)).toContain('Pass');
    expect(await objCommonPage.setTextInTableCellTextarea("Gap Description PO comments")).toContain('Pass');

    expect(await objCommonPage.goToColumn("Risk/Gap Closure Plan"));
    expect(await objCommonPage.clickInTheTableCell("Risk/Gap Closure Plan",sDemoName)).toContain('Pass');
    expect(await objCommonPage.setTextInTableCellTextarea("Gap Closure Plan Desc PO comments")).toContain('Pass');

    //verify edited value is updated
     expect(await objCommonPage.goToColumn("Risk/Gap Description"));
    expect(await objCommonPage.verifyTextValueInTableCell("Risk/Gap Description",sDemoName,"Gap Description PO comments")).toContain('Verified');

    expect(await objCommonPage.goToColumn("Risk/Gap Closure Plan"));
    expect(await objCommonPage.verifyTextValueInTableCell("Risk/Gap Closure Plan",sDemoName,"Gap Closure Plan Desc PO comments")).toContain('Verified');     
     
    done();
});
it('TC_23 - Verify that whenever scheduled completion date is marked as complete then there will be expected changes in execution risk and all demo milestones status', async(done)=>{
  let objData = dataProvider.getJsonData("./data/myDemoTasks.json", "TC_23");
  console.log(objData);
  //Login My Demo application
  expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
  expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
  expect(await objLoginPage.clickLogin()).toContain("Pass");
  await browser.waitForAngularEnabled(true);
  expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
  //select menu option
 expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
  expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
  expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
  expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");

  var iRandomNum = Math.floor(1000 + Math.random() * 9000);
  sDemoName = "TestDemo_MyDemoTask" + iRandomNum;
  console.log(sDemoName);

  expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
  expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");

  expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnDropDownOption("Primary BU", objData.primaryBu)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnDropDownOption("Application Segment", objData.appSeg)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnDropDownOption("Device Type", objData.deviceType)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnDropDownOption("AMAT Node", objData.amatNode)).toContain("Pass");
 
  expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
  expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

  await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
  expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
  expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
  expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
  expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
  expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
  expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
  expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
  
  expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
  expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
  expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
  expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");
  browser.sleep(5000);
  expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
  expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');

  //Search or the demo which is having status as new request and make it approved 
  expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
  expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
 
  expect(await objAllViewPage.clickOnACLApprovalInTableCell(sDemoName)).toContain('Pass');
  expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
  expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
  expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",sLoggedInUser)).toContain('Pass');
  expect(await objAllViewPage.clickOnSave()).toContain('Pass');
  sAlertMessage="Approval Saved Successfully";
  expect(await objCommonPage.verifyAlertMessage(sAlertMessage)).toContain('Pass');
  expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

  //update execution risk and milestones
  expect(await objHomePage.selectMenuOption("My Action", "My Demo Tasks")).toContain('Pass');
  expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
  expect(await objMyDemoTasksPage.verifyDemoStatusInTableGrid(sDemoName,"ACL-With Demo Owner")).toContain('Pass');
  //click on the hyperlink
  expect(await objCommonPage.clickOnDemoNumberHyperLink("Demo Number",sDemoName)).toContain('Pass');  
  expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain('Pass');

  expect(await objAllViewPage.selectValueFromDDOnPopUp("Execution Risk","Medium")).toContain('Pass');
   //select date for Demo start field 
  let sDemoStart_status_color = (objData.demoStartMilestoneStatus_Color).split("~");
  expect(await objDemoDetailsPage.clickonScheduleIcon(objData.demoStartCol)).toContain("Pass");
  expect(await objDemoDetailsPage.clickOnCalendarIcon("Schedule Start Date")).toContain("Pass");
 await objCommonPage.selectDateFromCalendar("Today");
 expect(await objDemoDetailsPage.clickFieldOnDemoDetails("Milestone Status")).toContain("Pass");
 expect(await objDemoDetailsPage.selectOptionFromFieldOnDemoDetails("Milestone Status",sDemoStart_status_color[0])).toContain("Pass");
 expect(await objDemoDetailsPage.setValInField("Justification",sDemoStart_status_color[0]+" comment ")).toContain("Pass");
 expect(await objCommonPage.clickOnBtnOnPopup("Submit")).toContain("Pass");

 let sLabReady_status_color = (objData.labReadyMilestoneStatus_Color).split("~");
 expect(await objDemoDetailsPage.clickonScheduleIcon(objData.labReadyCol)).toContain("Pass");
  expect(await objDemoDetailsPage.clickOnCalendarIcon("Config Change Date")).toContain("Pass");
 await objCommonPage.selectDateFromCalendar("Today");
 expect(await objDemoDetailsPage.clickFieldOnDemoDetails("Config Change Date Milestone Status")).toContain("Pass");
 expect(await objDemoDetailsPage.selectOptionFromFieldOnDemoDetails("Config Change Date Milestone Status",sLabReady_status_color[0])).toContain("Pass");
 expect(await objDemoDetailsPage.setValInField("Justification",sLabReady_status_color[0]+" comment ")).toContain("Pass");
 expect(await objCommonPage.clickOnBtnOnPopup("Submit")).toContain("Pass");
 expect(await objDemoDetailsPage.clickOnBtn("Submit")).toContain("Pass");
 sAlertMessage="Demo Details Submitted Successfully."
    expect(await objCommonPage.verifyAlertMessage(sAlertMessage)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

 //Search request in All view and verify the color
 expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
 expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
 expect(await objCommonPage.goToColumn("Current Execution Risk")).toContain('Pass');
 expect(await objCommonPage.verifyTextValueInTableCell("Current Execution Risk", sDemoName, "M")).toContain("Verified");
 expect(await objCommonPage.goToColumn(objData.demoStartCol)).toContain('Pass');
 expect(await objAllViewPage.getTableCellColor(objData.demoStartCol,sDemoName)).toContain(sDemoStart_status_color[1]);

 expect(await objCommonPage.goToColumn(objData.labReadyCol)).toContain('Pass');
 expect(await objAllViewPage.getTableCellColor(objData.labReadyCol,sDemoName)).toContain(sLabReady_status_color[1]);

expect(await objHomePage.selectMenuOption("My Action", "My Demo Tasks")).toContain('Pass');
expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
expect(await objCommonPage.clickOnDemoNumberHyperLink("Demo Number",sDemoName)).toContain('Pass');  
expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain('Pass');

 //select date for Demo Completion field 
let sDemoCompletion_status_color = (objData.demoCompletionMilestoneStatus_Color).split("~");
expect(await objDemoDetailsPage.clickonScheduleIcon(objData.demoCompletionCol)).toContain("Pass");
expect(await objDemoDetailsPage.clickOnCalendarIcon("Schedule Completion Date")).toContain("Pass");
await objCommonPage.selectDateFromCalendar("Today");
expect(await objDemoDetailsPage.clickFieldOnDemoDetails("Schedule Completion Date Milestone Status")).toContain("Pass");
expect(await objDemoDetailsPage.selectOptionFromFieldOnDemoDetails("Schedule Completion Date Milestone Status",sDemoCompletion_status_color[0])).toContain("Pass");
expect(await objDemoDetailsPage.setValInField("Justification",sDemoCompletion_status_color[0]+" comment ")).toContain("Pass");
expect(await objCommonPage.clickOnBtnOnPopup("Submit")).toContain("Pass");

expect(await objDemoDetailsPage.verifyBackgroudColour(objData.demoStartCol,sDemoCompletion_status_color[1])).toContain("Pass");
expect(await objDemoDetailsPage.verifyBackgroudColour(objData.labReadyCol,sDemoCompletion_status_color[1])).toContain("Pass");
expect(await objDemoDetailsPage.verifyBackgroudColour(objData.demoCompletionCol,sDemoCompletion_status_color[1])).toContain("Pass");

expect(await objDemoDetailsPage.clickOnBtn("Submit")).toContain("Pass");
sAlertMessage="Demo Details Submitted Successfully."
  expect(await objCommonPage.verifyAlertMessage(sAlertMessage)).toContain('Pass');
  expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

//Search request in All view and verify the color
expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
expect(await objCommonPage.goToColumn("Current Execution Risk")).toContain('Pass');
expect(await objCommonPage.verifyTextValueInTableCell("Current Execution Risk", sDemoName, "C")).toContain("Verified");
expect(await objCommonPage.goToColumn(objData.demoStartCol)).toContain('Pass');
expect(await objAllViewPage.getTableCellColor(objData.demoStartCol,sDemoName)).toContain(sDemoCompletion_status_color[1]);

expect(await objCommonPage.goToColumn(objData.labReadyCol)).toContain('Pass');
expect(await objAllViewPage.getTableCellColor(objData.labReadyCol,sDemoName)).toContain(sDemoCompletion_status_color[1]);

expect(await objCommonPage.goToColumn(objData.demoCompletionCol)).toContain('Pass');
expect(await objAllViewPage.getTableCellColor(objData.demoCompletionCol,sDemoName)).toContain(sDemoCompletion_status_color[1]);
done();
});
it('TC_Pre-Requisite_22 - Create Demo Request for Test case 22', async(done)=>{
  let objData = dataProvider.getJsonData("./data/myDemoTasks.json", "TC_Pre-Requisite");
  console.log(objData);
  //Login My Demo application
  expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
  expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
  expect(await objLoginPage.clickLogin()).toContain("Pass");
  await browser.waitForAngularEnabled(true);
  expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
  //select menu option
 expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
  expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
  expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
  expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");

  var iRandomNum = Math.floor(1000 + Math.random() * 9000);
  sDemoName = "TestDemo_MyDemoTask" + iRandomNum;
  console.log(sDemoName);

  expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
  expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");

  expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
  expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
  expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
  expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
  expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
  expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
  await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
  expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
  expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
  expect(await objDemoDetailsPage.selectDDOptionOnDemoDtlsPage("Customer Wafer Destination",objData.customerWaferDes)).toContain("Pass");

  expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
  expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
  expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");
  expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
  expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
  expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
  expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");

  expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
  expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
  expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
  expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");
  browser.sleep(5000);
  expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
  expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');
 //appprove using BU user
  await browser.waitForAngularEnabled(false);
  console.log("Logged in as a Account Super User")
  await objHomePage.openApplication('/'); 
  expect(await objLoginPage.setUserName(objLoginData.userNameBUSuperUser)).toContain('Pass');
  expect(await objLoginPage.setPassword(objLoginData.passwordBUSuperUser)).toContain('Pass');
  expect(await objLoginPage.clickLogin()).toContain("Pass");
  await browser.waitForAngularEnabled(true);

 //Search or the demo which is having status as new request and make it approved 
 expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
 expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');

 expect(await objAllViewPage.clickOnACLApprovalInTableCell(sDemoName)).toContain('Pass');
 expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
 expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
 expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",sLoggedInUser)).toContain('Pass');
 expect(await objAllViewPage.selectValueFromDDOnPopUp("Execution Risk","Medium")).toContain('Pass');
 expect(await objAllViewPage.clickOnSave()).toContain('Pass');
 let sAlert="Approval Saved Successfully"
 expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
 expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
  done();
});
it('TC_22-Verify that value provided in customer wafer room field on opportunity info screen will be populated in demo details page as well', async (done)=>
{
  let objData = dataProvider.getJsonData("./data/myDemoTasks.json", "TC_Pre-Requisite");
    console.log(objData);
   
   //Login My Demo application as global admin user
   expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
   expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
   expect(await objLoginPage.clickLogin()).toContain("Pass");
   await browser.waitForAngularEnabled(true);
   expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");     
         
 
   //Search for the demo Name   
   expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
   expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
   expect(await objMyDemoTasksPage.verifyDemoisDisplayed(sDemoName)).toContain('Pass');
   expect(await objCommonPage.goToColumn("Customer Wafer Destination")).toContain('Pass');
 //verify the value is same as opportunity info section
   expect(await objCommonPage.verifyTextValueInTableCell("Customer Wafer Destination", sDemoName,objData.customerWaferDes)).toContain("Verified");
   
   expect(await objHomePage.selectMenuOption("My Action", "My Demo Tasks")).toContain('Pass');
   expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass'); 
   expect(await objCommonPage.clickOnDemoNumberHyperLink("Demo Number",sDemoName)).toContain('Pass');  
   expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain('Pass');
  //verify the value is same as opportunity info section
   expect(await objDemoDetailsPage.getFieldValue("Customer Wafer Destination")).toEqual('5');// DRP_SPG Bowers Customer Wafer Room 
  
   //update customer wafer destination value
   expect(await objDemoDetailsPage.selectDDOptionOnDemoDtlsPage("Customer Wafer Destination","B1-SRP")).toContain('Pass');
   expect(await objDemoDetailsPage.clickOnBtn("Submit")).toContain("Pass");
   sAlertMessage="Demo Details Submitted Successfully."
   expect(await objCommonPage.verifyAlertMessage(sAlertMessage)).toContain('Pass');
   expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
   
   expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');    
   expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
   expect(await objCommonPage.goToColumn("Customer Wafer Destination")).toContain('Pass');
 //verify the value is updated
   expect(await objCommonPage.verifyTextValueInTableCell("Customer Wafer Destination", sDemoName,"B1-SRP")).toContain("Verified");
    done();
});
it('TC_18-In MyDemo Verify that Demo Complete value is removed from the Wafer Status field and In demos where the value is Demo Complete should be updated to Wafer Ready to Ship Back', async (done)=>
{
    let objData = dataProvider.getJsonData("./data/myDemoTasks.json", "TC_19");
    console.log(objData);
   
   //Login My Demo application as global admin user
   expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
   expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
   expect(await objLoginPage.clickLogin()).toContain("Pass");
   await browser.waitForAngularEnabled(true);
   expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")
   
   expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
         
 
   //Search for the demo Name
   expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
   expect(await objMyDemoTasksPage.verifyDemoisDisplayed(sDemoName)).toContain('Pass');

   expect(await objCommonPage.clickOnDemoNumberHyperLink("Demo Number",sDemoName)).toContain('Pass');  
   expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain('Pass');
  
   expect(await objDemoDetailsPage.verifyOptionFromFieldDDOnDemoDetails("Wafer Location","Demo Complete")).toContain('not present');
   expect(await objDemoDetailsPage.verifyOptionFromFieldDDOnDemoDetails("Wafer Location","Wafer ready to ship back")).toContain('Pass');

    done();
});
it('TC_19-Verify that there shall be a manual shipping tracking table with 2 cloumns Freight Forwarder and Tracking number added on Plan or Run page and Both columns should be manditory', async (done)=>
{
    let objData = dataProvider.getJsonData("./data/myDemoTasks.json", "TC_19");
    console.log(objData);
   
   //Login My Demo application as global admin user
   expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
   expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
   expect(await objLoginPage.clickLogin()).toContain("Pass");
   await browser.waitForAngularEnabled(true);
   expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass")
   
   expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
         
 
   //Search for the demo Name
   expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
   expect(await objMyDemoTasksPage.verifyDemoisDisplayed(sDemoName)).toContain('Pass');

   expect(await objCommonPage.clickOnDemoNumberHyperLink("Demo Number",sDemoName)).toContain('Pass');  
   expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain('Pass');
  
   expect(await objDemoDetailsPage.verifySectionIsDisplayed("Shipment Tracking Info")).toContain('Pass');
   expect(await objDemoDetailsPage.expandSection("Shipment Tracking Info")).toContain('Pass');
   expect(await objDemoDetailsPage.clickOnToggleField("Shipping Details")).toContain('Pass');
  
   let trackingList = (objData.trackingDetails).split("~");
    let trackData= trackingList[0].split(";");
    expect(await objDemoDetailsPage.setFreightForwarder(trackData[0])).toContain('Pass');
    expect(await objDemoDetailsPage.setTrackingNumber(trackData[1])).toContain('Pass');
    expect(await objNewDemoRequest.clickOnAttributeSave()).toContain('Pass'); 

    expect(await objNewDemoRequest.clickOnAddSecondaryBU()).toContain('Pass'); 

     trackData= trackingList[1].split(";");
    expect(await objDemoDetailsPage.setFreightForwarder(trackData[0])).toContain('Pass');
    expect(await objDemoDetailsPage.setTrackingNumber(trackData[1])).toContain('Pass');
    expect(await objNewDemoRequest.clickOnAttributeSave()).toContain('Pass'); 
   
    
    expect(await objDemoDetailsPage.clickOnBtn("Submit")).toContain("Pass");
    sAlertMessage="Demo Details Submitted Successfully."
    expect(await objCommonPage.verifyAlertMessage(sAlertMessage)).toContain('Pass');
    expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
    
    expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');    
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(await objCommonPage.goToColumn("Shipping Information")).toContain('Pass');
  
    expect(await objCommonPage.getShippingInfoCountfromTableCell( sDemoName)).toEqual('2');
  
    done();
});
it('TC_20-"Verify that if customer selects No Customer Wafer value in Wafer Location dropdown then the demo should be able to be placed into a closed status exactly the same as Customer Hand Carried.', async(done)=>{
        let objData = dataProvider.getJsonData("./data/myDemoTasks.json", "TC_20");
        console.log(objData);
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");
        await browser.waitForAngularEnabled(true);
        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
        //Create a new demo by uploading wafer stack and CustSpec Documents
        expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
       
        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        let sDemoName = "TestDemo_MyDemoTask" + iRandomNum;
        console.log(sDemoName);
 
        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
       
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
        expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
        
        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        let sLoggedInUser;
        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Customer Spec");
        const filePath = path.resolve('./autoItScripts/TestUpload_CustSpec.xlsx');
        const exePath = path.resolve('./autoItScripts/browseFile.exe')
        // //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath);
        await browser.sleep(5000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Customer Spec")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.verifyChkboxStatusAgainstField("Customer Spec", "Upload", "true")).toContain("Pass");

        expect(await objNewDemoRequest.clickWaferStackOption(objData.waferStackOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Wafer Stack");
        const filePath1 = path.resolve('./autoItScripts/TestUpload_WaferStack.xlsx');
        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath1);
        await browser.sleep(5000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Wafer Stack")).toContain("Pass");
        expect(await objNewDemoRequest.verifyChkboxStatusAgainstField("Wafer Stack", "Upload", "true")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
        expect(await objCommonPage.clickOnOkBtnOnPopUp()).toContain('Pass');



        //Taking Login as BU super User and approve the demo
        await browser.waitForAngularEnabled(false);
        await objHomePage.openApplication('/');   
        expect(await objLoginPage.setUserName(objLoginData.userNameBUSuperUser)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordBUSuperUser)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");
        await browser.waitForAngularEnabled(true);
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');

        //Approve the Newly created Demo
    
        expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"New Request")).toContain('Pass');
        expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
        expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
        expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objData.demoOwner)).toContain('Pass');
        expect(await objAllViewPage.clickOnSave()).toContain('Pass');
        let sAlert0="Approval Saved Successfully"
        expect(await objCommonPage.verifyAlertMessage(sAlert0)).toContain('Pass');
        expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
        
        //Go to All view Page click on the hyper link demo humber and reach on the demo details page,Change the Exceution Risk to complete and update wafer location 
        //Taking Login as demo owner 
        await browser.waitForAngularEnabled(false);
        await objHomePage.openApplication('/');   
        expect(await objLoginPage.setUserName(objLoginData.userNameDemoOwner)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordDemoOwner)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");
        await browser.waitForAngularEnabled(true);

        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
        expect(await objAllViewPage.clickOnHyperLinkInDemoNumber(sDemoName)).toContain('Pass');
        expect(await objHomePage.getCurrentUrl("request_demo")).toContain("Pass");

        expect(await objDemoDetailsPage.clickFieldOnDemoDetails("Wafer location")).toContain("Pass");
        expect(await objDemoDetailsPage.selectOptionFromFieldOnDemoDetails("Wafer location",objData.waferLocation)).toContain("Pass");

        expect(await objDemoDetailsPage.clickFieldOnDemoDetails("Execution Risk")).toContain("Pass");
        expect(await objDemoDetailsPage.selectOptionFromFieldOnDemoDetails("Execution Risk",objData.exeRisk)).toContain("Pass");
        expect(await objDemoDetailsPage.clickOnSubmitDemoDetails()).toContain("Pass");

        let sAlert="Demo Details Submitted Successfully."
        expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
        expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
 
        // Attach the demo report by clicking on the attachement icon
        expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
        expect(await objAllRequestPage.clickOnTheAttachmentIcon()).toContain('Pass');
        expect(await objAllRequestPage.clickOnBrowseButtonOnViewAttachment()).toContain("Pass");
        const filePath2 = path.resolve('./autoItScripts/Data_Report.xlsx');
        cp.execSync(exePath + ' ' + filePath2);
        await browser.sleep(5000);
        expect(await objAllViewPage.selectValueFromDDOnAttachmentPopUp("Security", objData.ddSecurityVal)).toContain("Pass");
        expect(await objAllViewPage.selectValueFromDDOnAttachmentPopUp("Category", "Demo Report")).toContain("Pass");
        expect(await objAllRequestPage.clickOnUploadButtonOnViewAttachment()).toContain("Pass");
        expect(await objAllViewPage.clickOnCloseIcon()).toContain('Pass');

        // After attaching the demo report chainging status of demo to close
        expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"ACL-Approved")).toContain('Pass');
        expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","Closed")).toContain('Pass');
        expect(await objAllViewPage.clickOnSave()).toContain('Pass');
        expect(await objCommonPage.verifyAlertMessage(sAlert0)).toContain('Pass');
        expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
        done();
});
it('TC_21-"verify that when the user gets a notification for a specific demo and After clicking the hyperlink in the notification user shall be redirected to the Demo details view of that specific Demo.', async(done)=>{
  let objData = dataProvider.getJsonData("./data/myDemoTasks.json", "TC_21");
  console.log(objData);
  //Login My Demo application
  expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
  expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
  expect(await objLoginPage.clickLogin()).toContain("Pass");
  await browser.waitForAngularEnabled(true);
  expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
  //select menu option
  expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
  expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
  expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
  expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");

  var iRandomNum = Math.floor(1000 + Math.random() * 9000);
  sDemoName = "TestDemo_MyDemoTask" + iRandomNum;
  console.log(sDemoName);

  expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
  expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");

  expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
  expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
  expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
  expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
  expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
  expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
 
  expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
  expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

  let sLoggedInUser;
  await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
  expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
  expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
  expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
  expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
  expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
  expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
  expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");

  //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
  expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
  expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
  expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
  expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");
  expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
  expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');

  //Approve the Newly created Demo on All view Page
  expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
  expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
  let sDemoNumber = await objCommonPage.getTableCellValue("Demo Number",sDemoName);
  console.log(sDemoNumber);

  expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"New Request")).toContain('Pass');
  expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
  expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
  expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",sLoggedInUser)).toContain('Pass');
  expect(await objAllViewPage.clickOnSave()).toContain('Pass');
  let sAlert="Approval Saved Successfully"
  expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
  expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');


  // Checking Email Notification for status change and link should redirect on the demo page.
  let sMailHeader = "Status change for Demo Request "+sDemoNumber+"";
  await browser.waitForAngularEnabled(false);
  await browser.sleep(15000);
  await objHomePage.openWebmail(objLoginData.outlookUrl);
  expect(await objOutlookPage.verifyOutllookEmailExists(objLoginData.outlookUserName, "", sMailHeader)).toContain("Pass");
  //expect(await objOutlookPage.verifyOutllookEmailExistsSecondTime(sMailHeader)).toContain("Pass");
  await browser.sleep(5000);
  expect(await objOutlookPage.verifyMailBodyWithDemoNumNmInBold(sDemoName, sDemoNumber)).toContain("Pass");
  expect(await objOutlookPage.clickOnTheWebLinkToVisitDemo()).toContain("Pass");
  await browser.waitForAngularEnabled(true);
 
  await objCommonPage.switchtoNewTab();
  await browser.sleep(5000);
  expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain("Pass");
  expect(await objDemoDetailsPage.verifyTextOnDemoDetails("Demo #", sDemoNumber)).toContain("Pass");

  done();
 
});
it('TC_24 -"Verify that For all secondary demos where IMS is Primary then secondary demo information should be hidden and  Only the Primary demo information shall be visible in the Multi BU card on the demo details page', async(done)=>{
  let objData = dataProvider.getJsonData("./data/myDemoTasks.json", "TC_24");
        console.info(objData);

        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");

        browser.waitForAngularEnabled(true);

        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});

        //select menu option
        expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

        expect(await objNewDemoRequest.toggleField("Special Group Demo", true)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRadioBtn("Special Group Owned")).toContain("Pass");
  

        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_MyDemoTask" + iRandomNum;

        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");;
        

        expect(await objNewDemoRequest.toggleField('TAMBA', false)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnDropDownOption("Special Group", objData.specialGroup)).toContain("Pass");        

        expect(await objNewDemoRequest.clickOnDropDownOption("Application Segment", objData.appSegment)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnDropDownOption("Device Type", objData.deviceType)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnDropDownOption("AMAT Node", objData.amatNode)).toContain("Pass");
        
        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");


        expect(await objNewDemoRequest.clickOnAddSecondaryBU()).toContain("Pass");
        expect(await objNewDemoRequest.selectSecondaryBUInTable(objData.secBU1)).toContain("Pass");
        expect(await objNewDemoRequest.selectRequestorInSecBUTbl(objData.requestor)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSaveSecondaryBU()).toContain("Pass");

        
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
    
        
        expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Customer Spec");
        const filePath = path.resolve('./autoItScripts/TestUpload_CustSpec.xlsx');
        const exePath = path.resolve('./autoItScripts/browseFile.exe')
  
        cp.execSync(exePath + ' ' + filePath);
        await browser.sleep(6000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Customer Spec")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Customer Spec", "TestUpload_CustSpec.xlsx")).toContain("Pass");

        expect(await objNewDemoRequest.clickWaferStackOption(objData.waferStackOption)).toContain("Pass");
        await objNewDemoRequest.clickOnBrowseButtonAgainstField("Wafer Stack");
        const filePath1 = path.resolve('./autoItScripts/TestUpload_WaferStack.xlsx');

        //await browser.sleep(5000);
        cp.execSync(exePath + ' ' + filePath1);
        await browser.sleep(6000);
        expect(await objNewDemoRequest.verifyDocBrowsedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");
        expect(await objNewDemoRequest.clickOnUploadButtonAgainstField("Wafer Stack")).toContain("Pass");
        expect(await objNewDemoRequest.verifyDocumentUploadedAgainstField("Wafer Stack", "TestUpload_WaferStack.xlsx")).toContain("Pass");

        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
        sAlertMessage = "Demo Request submitted Successfully.";
        expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");

        //Approve the Newly created Demo on All view Page
       expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
       expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
       let sDemoNumber = await objCommonPage.getTableCellValue("Demo Number",sDemoName);

       expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"New Request")).toContain('Pass');
       expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
       expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
       expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objData.demoOwner)).toContain('Pass');
       expect(await objAllViewPage.clickOnSave()).toContain('Pass');
       let sAlert="Approval Saved Successfully"
       expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
       expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

        //Login My Demo as a Requestor
       await browser.waitForAngularEnabled(false);
       await objHomePage.openApplication('/');  
       expect(await objLoginPage.setUserName(objLoginData.userNameEstimator)).toContain('Pass');
       expect(await objLoginPage.setPassword(objLoginData.passwordEstimator)).toContain('Pass');
       expect(await objLoginPage.clickLogin()).toContain("Pass");
       await browser.waitForAngularEnabled(true);
       expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
       //Go to My Draft Request and look for secondary Demo
       expect(await objHomePage.selectMenuOption('Requests', 'My Draft Request')).toContain('Pass');
       expect(await objCommonPage.setSearchText(sDemoName)).toContain('Pass');
       expect(await objCommonPage.getTableCellValue("Demo Number",sDemoName)).toContain(objData.demoNumBu);
        
       //Go back to opprtunity Info screen by clicking on the demo number and update Field
       expect(await objCommonPage.clickInTheTableCell("Demo Number",sDemoName)).toContain('Pass');
       expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
       expect(await objNewDemoRequest.clickOnDropDownOption("Application Segment", objData.appSeg)).toContain("Pass");
       expect(await objNewDemoRequest.clickOnDropDownOption("AMAT Node", objData.amatNode)).toContain("Pass");
       expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
       expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
       expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
       sAlertMessage = "Demo Request submitted Successfully.";
       expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");



       //Take Login as Global Admin and Approve the secondary Demo.
       await browser.waitForAngularEnabled(false);
       await objHomePage.openApplication('/');  
       expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
       expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
       expect(await objLoginPage.clickLogin()).toContain("Pass");
       browser.waitForAngularEnabled(true);

       expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
       expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
       expect(await objAllViewPage.clickInTheStatusIconField(sDemoName,"New Request")).toContain('Pass');
       expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
       expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
       expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",objData.demoOwner)).toContain('Pass');
       expect(await objAllViewPage.clickOnSave()).toContain('Pass');
       expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
       expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');


       //Login My Demo as a Requestor
       await browser.waitForAngularEnabled(false);
       await objHomePage.openApplication('/');  
       expect(await objLoginPage.setUserName(objLoginData.userNameEstimator)).toContain('Pass');
       expect(await objLoginPage.setPassword(objLoginData.passwordEstimator)).toContain('Pass');
       expect(await objLoginPage.clickLogin()).toContain("Pass");
       await browser.waitForAngularEnabled(true);

       // Navigate to demo details page and check fro multi BU demo details.
       expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
       expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
       expect(await objAllViewPage.clickOnHyperLinkInDemoNumber(sDemoName)).toContain('Pass');
       expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain("Pass");
       expect(await objDemoDetailsPage.verifyMultiDemoSectionDisplay()).toContain("Pass");
       expect(await objDemoDetailsPage.expandSection("Multi BU Demos")).toContain("Pass");
       expect(await objDemoDetailsPage.verifyDemoNumberInMultiDemoSection(sDemoNumber)).toContain("Pass");
       
        
        

       done();
});
it('TC_11 - Verify that Demo owner will get a email notification if a schedule milestone is missed (config change date, demo start date, demo completion date)', async(done)=>{
  let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_01");
  console.info(objData);

  //Login My Demo application
  expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
  expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
  expect(await objLoginPage.clickLogin()).toContain("Pass");

  await browser.waitForAngularEnabled(true);

  expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

  //select menu option
  expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
  expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

  expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
  expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");

  var iRandomNum = Math.floor(1000 + Math.random() * 9000);
  sDemoName = "TestDemo_MyDemoTask" + iRandomNum;

  expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
  expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");;
  expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
  expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).not.toContain("Pass");
  expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).not.toContain("Pass");

  expect(await objNewDemoRequest.verifyToggleForFieldIsPresent('TAMBA')).toContain("Pass");

  expect(await objNewDemoRequest.verifyToggleForFieldIsPresent('Internal Demo')).toContain("Pass");
  expect(await objNewDemoRequest.toggleField('TAMBA', false)).toContain("Pass");
  expect(await objNewDemoRequest.toggleField('Internal Demo', true)).toContain("Pass");
  expect(await objNewDemoRequest.verifyPrimaryBUIsMandatoryWhenInternalDemo()).toContain("Pass");
  expect(await objNewDemoRequest.toggleField('Internal Demo', false)).toContain("Pass");

  expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
  
  expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
  expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
  expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
  expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
  expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
  await objNewDemoRequest.verifyTambaDtlsOnNewDemoForm();
  expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
  expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

  await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
  expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
  expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
  expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
  expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
  expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
  expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
  expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
  
  //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
  expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
  expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
  expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
  expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");;
  expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
  sAlertMessage = "Demo Request submitted Successfully.";
  expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
  expect(await objHomePage.selectMenuOption("Requests", "My Demo Request")).toContain("Pass");
  expect(await objMyDemoRequest.verifyDemoPresentInTable(sDemoName)).toContain("Pass");
  expect(await objMyDemoRequest.verifyDemoApprovalStatus(sDemoName, objData.expDemoStatus)).toContain("Pass");
  sDemoNumber = await objCommonPage.getTableCellValue("Demo Number", sDemoName).then(function(sText){return sText;});

  //Search or the demo which is having status as new request and make it approved 
  expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
  browser.sleep(5000);
  expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass'); 
  browser.sleep(5000);
  // expect(await objAllViewPage.clickOnACLApprovalInTableCell(sDemoName)).toContain('Pass'); 
  expect(await objAllViewPage.clickOnACLApprovalInTableCell(sDemoName)); 
  expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
  expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
  expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",sLoggedInUser)).toContain('Pass');
  expect(await objAllViewPage.clickOnSave()).toContain('Pass');
  let sAlert="Approval Saved Successfully"
  expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
  expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');


  //Search for the demo Name
  expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');  
  //click on the hyperlink
  expect(await objCommonPage.clickOnDemoNumberHyperLink("Demo Number",sDemoName)).toContain('Pass');  
  expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain('Pass');
  
  expect(await objDemoDetailsPage.clickOnCalendarIcon("Lab Ready")).toContain("Pass");
  expect(await objDemoDetailsPage.clickOnCalendarIcon("Config Change Date")).toContain("Pass"); 
  expect(await objCommonPage.selectDateFromCalendar("Today"));
  expect(await objDemoDetailsPage.selectOptionFromFieldOnDemoDetails("Config Change Date Milestone Status", "At Risk"));
  expect(await objCommonPage.takeActionOnAlert("Submit"));

  // expect(await objCommonPage.selectDateWithMilestoneStatus("Today", "Config Change Date Milestone Status", "At Risk")); 
  
  
  expect(await objDemoDetailsPage.clickOnCalendarIcon("Demo Start")).toContain("Pass");
  expect(await objDemoDetailsPage.clickOnCalendarIcon("Schedule Start Date")).toContain("Pass"); 
  expect(await objCommonPage.selectDateFromCalendar("Today"));
  expect(await objDemoDetailsPage.selectOptionFromFieldOnDemoDetails("Schedule Start Date Milestone Status", "At Risk"));
  expect(await objCommonPage.takeActionOnAlert("Submit"));

  // expect(await objCommonPage.selectDateWithMilestoneStatus("Today", "Schedule Start Date Milestone Status", "At Risk"));
 
  expect(await objDemoDetailsPage.clickOnCalendarIcon("Demo Completion")).toContain("Pass"); 
  expect(await objDemoDetailsPage.clickOnCalendarIcon("Schedule Completion Date")).toContain("Pass");  
  expect(await objCommonPage.selectDateFromCalendar("Today"));
  expect(await objDemoDetailsPage.selectOptionFromFieldOnDemoDetails("Schedule Completion Date Milestone Status", "At Risk"));
  expect(await objCommonPage.takeActionOnAlert("Submit"));

    // expect(await objCommonPage.selectDateWithMilestoneStatus("Today", "Schedule Completion Date Milestone Status", "At Risk"));
  
  expect(await objAllViewPage.selectValueFromDDOnPopUp("Execution Risk","Medium")).toContain('Pass'); 
  
  expect(await objDemoDetailsPage.clickOnBtn("Submit")).toContain("Pass");
  sAlert="Demo Details Submitted Successfully."
  expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
  expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

    
    // Need to change header as per required header mail
    let sMailHeader= "Status change for Demo Request "+sDemoNumber
    await browser.waitForAngularEnabled(false);
    await browser.sleep(5000);
    await objHomePage.openWebmail(objLoginData.outlookUrl);
    expect(await objOutlookPage.verifyOutllookEmailExistsSecondTime(sMailHeader)).toContain("Pass");
    await browser.sleep(5000);
    expect(await objOutlookPage.verifyMailBodyWithDemoNumNmInBold(sDemoName, sDemoNumber)).toContain("Pass");


  done();

});
//TC12  :Prerequisit TC11 should run 1st
it('Verify that whenever any milestone is updated in the demo request then user shall get email notification regarding the same', async(done)=>{
     
  //Login My Demo application
  expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
  expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
  expect(await objLoginPage.clickLogin()).toContain("Pass");

  await browser.waitForAngularEnabled(true);

  expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
  //Search or the demo which is having status as new request and make it approved 
  expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
  browser.sleep(5000);
  expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass'); 
  browser.sleep(5000);
  
  //click on the hyperlink
  expect(await objCommonPage.clickOnDemoNumberHyperLink("Demo Number",sDemoName)).toContain('Pass');  
  expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain('Pass');
  
  expect(await objDemoDetailsPage.clickOnCalendarIcon("Lab Ready")).toContain("Pass");
  expect(await objDemoDetailsPage.clickOnCalendarIcon("New Config Change Date")).toContain("Pass"); 
  expect(await objCommonPage.selectDateFromCalendar("Tomorrow"));  
  expect(await objDemoDetailsPage.setFieldValInDemoDtlsPage("Justification", "Testing"));
  expect(await objCommonPage.takeActionOnAlert("Submit"));

  expect(await objDemoDetailsPage.clickOnCalendarIcon("Demo Start")).toContain("Pass");
  expect(await objDemoDetailsPage.clickOnCalendarIcon("New Schedule Start Date")).toContain("Pass"); 
  expect(await objCommonPage.selectDateFromCalendar("Tomorrow"));
  expect(await objDemoDetailsPage.setFieldValInDemoDtlsPage("Justification", "Testing"));
  expect(await objCommonPage.takeActionOnAlert("Submit"));

  expect(await objDemoDetailsPage.clickOnCalendarIcon("Demo Completion")).toContain("Pass"); 
  expect(await objDemoDetailsPage.clickOnCalendarIcon("New Schedule Completion Date")).toContain("Pass");  
  expect(await objCommonPage.selectDateFromCalendar("Tomorrow"));
  expect(await objDemoDetailsPage.setFieldValInDemoDtlsPage("Justification", "Testing"));
  expect(await objCommonPage.takeActionOnAlert("Submit"));

  expect(await objDemoDetailsPage.clickOnBtn("Submit")).toContain("Pass");
  let sAlert="Demo Details Submitted Successfully."
  expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
  expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

      // Need to change header as per required header mail
  let sMailHeader= "MileStone change for Demo Request "+sDemoNumber
  await browser.waitForAngularEnabled(false);
  await objHomePage.openWebmail(objLoginData.outlookUrl);
  // expect(await objOutlookPage.verifyOutllookEmailExists(objLoginData.outlookUserName, "", sMailHeader)).toContain("Pass");
  expect(await objOutlookPage.verifyOutllookEmailExists("", "", sMailHeader)).toContain("Pass");  
  await browser.sleep(5000);
  // expect(await objOutlookPage.verifyMailBodyWithDemoNumNmInBold(sDemoName, sDemoNumber)).toContain("Pass");


  done();

});
//TC05
it('TC_05-"Verify that whenever user missed to fill mandatory fields and clicks on submit button he/she shall get a pop up warning to fill mandatory fields', async(done)=>{
  let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_01");
  console.info(objData);

  //Login My Demo application
  expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
  expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
  expect(await objLoginPage.clickLogin()).toContain("Pass");

  await browser.waitForAngularEnabled(true);

  expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

  //select menu option
  expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
  expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

  expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
  expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");

  var iRandomNum = Math.floor(1000 + Math.random() * 9000);
  sDemoName = "TestDemo_MyDemoTask" + iRandomNum;

  expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
  expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");;
  expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
  expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).not.toContain("Pass");
  expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).not.toContain("Pass");

  expect(await objNewDemoRequest.verifyToggleForFieldIsPresent('TAMBA')).toContain("Pass");

  expect(await objNewDemoRequest.verifyToggleForFieldIsPresent('Internal Demo')).toContain("Pass");
  expect(await objNewDemoRequest.toggleField('TAMBA', false)).toContain("Pass");
  expect(await objNewDemoRequest.toggleField('Internal Demo', true)).toContain("Pass");
  expect(await objNewDemoRequest.verifyPrimaryBUIsMandatoryWhenInternalDemo()).toContain("Pass");
  expect(await objNewDemoRequest.toggleField('Internal Demo', false)).toContain("Pass");

  expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
  
  expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
  expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
  expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
  expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
  expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
  await objNewDemoRequest.verifyTambaDtlsOnNewDemoForm();
  expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
  expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

  await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
  expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
  expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
  expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
  expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
  expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");

  expect(await objNewDemoRequest.verifyBtnIsDisabled("Submit")).toContain("Pass");

  expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
  expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
  
  //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
  expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
  expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
  expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
  expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");;

  expect(await objNewDemoRequest.verifyBtnIsDisabled("Submit")).not.toContain("Pass");

  expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
  sAlertMessage = "Demo Request submitted Successfully.";
  expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
  expect(await objHomePage.selectMenuOption("Requests", "My Demo Request")).toContain("Pass");
  expect(await objMyDemoRequest.verifyDemoPresentInTable(sDemoName)).toContain("Pass");
  expect(await objMyDemoRequest.verifyDemoApprovalStatus(sDemoName, objData.expDemoStatus)).toContain("Pass");
  sDemoNumber = await objCommonPage.getTableCellValue("Demo Number", sDemoName).then(function(sText){return sText;});

  //Search or the demo which is having status as new request and make it approved 
  expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
  browser.sleep(5000);
  expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass'); 
  browser.sleep(5000);
    
  expect(await objNewDemoRequest.verifyBtnIsDisabled("Save")).toContain("Pass");

  expect(await objAllViewPage.clickOnACLApprovalInTableCell(sDemoName));
  expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
  expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
  expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",sLoggedInUser)).toContain('Pass');
 
  expect(await objNewDemoRequest.verifyAlertBtnIsDisabled("Save")).not.toContain("Pass");

  expect(await objAllViewPage.clickOnSave()).toContain('Pass');
  let sAlert="Approval Saved Successfully"
  expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
  expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

  //Search for the demo Name
  expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');  
  //click on the hyperlink
  expect(await objCommonPage.clickOnDemoNumberHyperLink("Demo Number",sDemoName)).toContain('Pass');  
  expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain('Pass');
  
  expect(await objDemoDetailsPage.clickOnBtn("Submit")).toContain("Pass");
  sAlert="Risk is mandatory."
  expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
  expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
 

  done();

});
it('TC_16 - Verify that there will be a field added in Demo Details page to attach a hyper link to shipping requests in eSR database (fields called Shipping Information).Also verify the following related to the same.'+
'1.Field will become available always (non manditory)'+
'2.Need the ability to add multiple links in case of multi shipment'+
'3.Add to All the Views screen'+
'4.Field should be editable even if the demo is closed', async (done)=>
{
   
   //Login My Demo application as global admin user
   expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
   expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
   expect(await objLoginPage.clickLogin()).toContain("Pass");
   await browser.waitForAngularEnabled(true);
   expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");   
   expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
      
 
   //Search for the demo Name
   expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
   expect(await objMyDemoTasksPage.verifyDemoisDisplayed(sDemoName)).toContain('Pass');
   expect(await objCommonPage.clickOnDemoNumberHyperLink("Demo Number",sDemoName)).toContain('Pass');  
   expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain('Pass');  
   expect(await objDemoDetailsPage.verifySectionIsDisplayed("Shipment Tracking Info")).toContain('Pass');
   expect(await objDemoDetailsPage.expandSection("Shipment Tracking Info")).toContain('Pass');
   
   let linkURLwithoutHTTP = (browser.params.baseUrl).replace("https://",""); 
   let linkURL_withHttp = (browser.params.baseUrl);   
   
      
    expect(await objDemoDetailsPage.setlenghtyFieldValInDemoDtlsPage("Shipping Information", linkURLwithoutHTTP)).toContain("Pass");    
    expect(await objDemoDetailsPage.clickOnAddShippingInfo()).toContain("Pass"); 
    browser.sleep(5000);     
    expect(await objDemoDetailsPage.verifyNewlyAddedShippinglinkIsApendedorNot(linkURLwithoutHTTP)).toContain("Pass");      
    expect(await objDemoDetailsPage.clickOnNewlyAddedShippingLink()).toContain('Pass');
    await browser.sleep(3000);
    await objCommonPage.switchtoNewTab();
    await browser.sleep(3000);
    expect(await objHomePage.getCurrentUrl(linkURLwithoutHTTP)).toContain("Pass");
    await browser.sleep(5000);
    await objCommonPage.closeTab();
    await objCommonPage.switchtoParentTab();
    await browser.sleep(5000);
  
    expect(await objDemoDetailsPage.setlenghtyFieldValInDemoDtlsPage("Shipping Information", linkURL_withHttp)).toContain("Pass");    
    expect(await objDemoDetailsPage.clickOnAddShippingInfo()).toContain("Pass"); 
    browser.sleep(5000);
    expect(await objDemoDetailsPage.verifyNewlyAddedShippinglinkIsApendedorNot(linkURL_withHttp)).toContain("Pass");
    expect(await objDemoDetailsPage.clickOnNewlyAddedShippingLink()).toContain('Pass');
    await browser.sleep(3000);
    await objCommonPage.switchtoNewTab();
    await browser.sleep(3000);
    expect(await objHomePage.getCurrentUrl(linkURL_withHttp)).toContain("Pass");
    await browser.sleep(5000);
    await objCommonPage.closeTab();
    await objCommonPage.switchtoParentTab();
    await browser.sleep(5000); 

    done();


});
/*it('TC_25 - Verify that schedule assistant feature is integrated with MyLab application', async(done)=>{
  let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_01");
  console.info(objData);

  //Login My Demo application
  expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
  expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
  expect(await objLoginPage.clickLogin()).toContain("Pass");

  await browser.waitForAngularEnabled(true);

  expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

  //select menu option
  expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
  expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

  expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
  expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");

  var iRandomNum = Math.floor(1000 + Math.random() * 9000);
  sDemoName = "TestDemo_" + iRandomNum;

  expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
  expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");;
  expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
  expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).not.toContain("Pass");
  expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).not.toContain("Pass");

  expect(await objNewDemoRequest.verifyToggleForFieldIsPresent('TAMBA')).toContain("Pass");

  expect(await objNewDemoRequest.verifyToggleForFieldIsPresent('Internal Demo')).toContain("Pass");
  expect(await objNewDemoRequest.toggleField('TAMBA', false)).toContain("Pass");
  expect(await objNewDemoRequest.toggleField('Internal Demo', true)).toContain("Pass");
  expect(await objNewDemoRequest.verifyPrimaryBUIsMandatoryWhenInternalDemo()).toContain("Pass");
  expect(await objNewDemoRequest.toggleField('Internal Demo', false)).toContain("Pass");

  expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
  
  expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
  expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
  expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
  expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
  expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
  await objNewDemoRequest.verifyTambaDtlsOnNewDemoForm();
  expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
  expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

  await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
  expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
  expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
  expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
  expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
  expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
  expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
  expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
  
  //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
  expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
  expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
  expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
  expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");;
  expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
  sAlertMessage = "Demo Request submitted Successfully.";
  expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
  expect(await objHomePage.selectMenuOption("Requests", "My Demo Request")).toContain("Pass");
  expect(await objMyDemoRequest.verifyDemoPresentInTable(sDemoName)).toContain("Pass");
  expect(await objMyDemoRequest.verifyDemoApprovalStatus(sDemoName, objData.expDemoStatus)).toContain("Pass");
  sDemoNumber = await objCommonPage.getTableCellValue("Demo Number", sDemoName).then(function(sText){return sText;});

  //Search or the demo which is having status as new request and make it approved 
  expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
  browser.sleep(5000);
  expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass'); 
  browser.sleep(5000);
  // expect(await objAllViewPage.clickOnACLApprovalInTableCell(sDemoName)).toContain('Pass'); 
  expect(await objAllViewPage.clickOnACLApprovalInTableCell(sDemoName)); 
  expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
  expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
  expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",sLoggedInUser)).toContain('Pass');
  expect(await objAllViewPage.clickOnSave()).toContain('Pass');
  let sAlert="Approval Saved Successfully"
  expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
  expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');
  
  //Search for the demo Name
  expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');  
  //click on the hyperlink
  expect(await objCommonPage.clickOnDemoNumberHyperLink("Demo Number",sDemoName)).toContain('Pass');  
  expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain('Pass');
  

  objData = dataProvider.getJsonData("./data/myDemoTasks.json", "TC_25");
  console.log(objData);
  // //edit some fields    
  expect(await objDemoDetailsPage.clickOnFieldDropDown(objData.toolNameCol)).toContain("Pass");    
  expect(await objDemoDetailsPage.selectOptionFromDDList("Tool Name", objData.toolNameValue)).toContain("Pass");
  expect(await objDemoDetailsPage.getFieldValue("Tool ID"));

  expect(await objDemoDetailsPage.selectOptFromMultiSelectDDList("Chamber Position", "A~B~C")).toContain("Pass");
  expect(await objDemoDetailsPage.clickOnBtn("Schedule Assistant")).toContain("Pass");
  await browser.sleep(5000);
  // expect(await objDemoDetailsPage.clickOnScheduleAssistant()).toContain("Pass");
  
  await browser.sleep(60000);
  
  // await objCommonPage.switchtoNewTab();
  // await browser.sleep(5000);
  // expect(await objMyLabPage.clickOnCalendarIcon("Start Date")).toContain("Pass");
  // // await objCommonPage.closeTab();
  // // await objCommonPage.switchtoParentTab();
  // await browser.sleep(5000); 
  // expect(await objDemoDetailsPage.clickOnCalendarIcon("Start Date")).toContain("Pass");
  // expect(await objDemoDetailsPage.clickOnCalendarIcon("New Schedule Start Date")).toContain("Pass"); 
  // expect(await objCommonPage.selectDateFromCalendar("Tomorrow"));
  // expect(await objDemoDetailsPage.setFieldValInDemoDtlsPage("Justification", "Testing"));
  // expect(await objCommonPage.takeActionOnAlert("Submit"));

  done();

});
it('TC_26 - Verify that any demo that is marked as Live in MyDemo should be marked as Live demo on MyLab , the rest of the demos should be marked Demo in MyLab', async(done)=>{
  let objData = dataProvider.getJsonData("./data/createDemo.json", "TC_01");
  console.info(objData);

  //Login My Demo application
  expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
  expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
  expect(await objLoginPage.clickLogin()).toContain("Pass");

  await browser.waitForAngularEnabled(true);

  expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");

  //select menu option
  expect(await objHomePage.selectMenuOption("Requests", "Create New Demo Request")).toContain("Pass");
  expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");

  expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
  expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");

  var iRandomNum = Math.floor(1000 + Math.random() * 9000);
  sDemoName = "TestDemo_" + iRandomNum;

  expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
  expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");;
  expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
  expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).not.toContain("Pass");
  expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).not.toContain("Pass");

  expect(await objNewDemoRequest.verifyToggleForFieldIsPresent('TAMBA')).toContain("Pass");

  expect(await objNewDemoRequest.verifyToggleForFieldIsPresent('Internal Demo')).toContain("Pass");
  expect(await objNewDemoRequest.toggleField('TAMBA', false)).toContain("Pass");
  expect(await objNewDemoRequest.toggleField('Internal Demo', true)).toContain("Pass");
  expect(await objNewDemoRequest.verifyPrimaryBUIsMandatoryWhenInternalDemo()).toContain("Pass");
  expect(await objNewDemoRequest.toggleField('Internal Demo', false)).toContain("Pass");

  expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
  
  expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
  expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
  expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
  expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
  expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
  await objNewDemoRequest.verifyTambaDtlsOnNewDemoForm();
  expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
  expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

  await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
  expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
  expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
  expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
  expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
  expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
  expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
  expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
  
  //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
  expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
  expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
  expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
  expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
  expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");;
  expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
  sAlertMessage = "Demo Request submitted Successfully.";
  expect(await objCommonPage.verifyAlertAndTakeAction("", sAlertMessage, "OK")).toContain("Pass");
  expect(await objHomePage.selectMenuOption("Requests", "My Demo Request")).toContain("Pass");
  expect(await objMyDemoRequest.verifyDemoPresentInTable(sDemoName)).toContain("Pass");
  expect(await objMyDemoRequest.verifyDemoApprovalStatus(sDemoName, objData.expDemoStatus)).toContain("Pass");
  sDemoNumber = await objCommonPage.getTableCellValue("Demo Number", sDemoName).then(function(sText){return sText;});

  //Search or the demo which is having status as new request and make it approved 
  expect(await objHomePage.selectMenuOption("All Demo's", "All View")).toContain('Pass');
  browser.sleep(5000);
  expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass'); 
  browser.sleep(5000);
  // expect(await objAllViewPage.clickOnACLApprovalInTableCell(sDemoName)).toContain('Pass'); 
  expect(await objAllViewPage.clickOnACLApprovalInTableCell(sDemoName)); 
  expect(await objAllViewPage.selectValueFromDDOnPopUp("Demo Approval","ACL - Approved")).toContain('Pass');
  expect(await objAllViewPage.selectValueFromDDOnPopUp("Priority","Low")).toContain('Pass');
  expect(await objAllRequestPage.selectOwnerOnPopUp("Demo Owner",sLoggedInUser)).toContain('Pass');
  expect(await objAllViewPage.clickOnSave()).toContain('Pass');
  let sAlert="Approval Saved Successfully"
  expect(await objCommonPage.verifyAlertMessage(sAlert)).toContain('Pass');
  expect(await objCommonPage.takeActionOnAlert("OK")).toContain('Pass');

  //Search for the demo Name
  expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');  
  //click on the hyperlink
  expect(await objCommonPage.clickOnDemoNumberHyperLink("Demo Number",sDemoName)).toContain('Pass');  
  expect(await objDemoDetailsPage.verifyDemoDetailsPageIsDisplayed()).toContain('Pass');
  
  objData = dataProvider.getJsonData("./data/myDemoTasks.json", "TC_26");
  console.log(objData);
  // //edit some fields    
  expect(await objDemoDetailsPage.clickOnFieldDropDown(objData.toolNameCol)).toContain("Pass");    
  expect(await objDemoDetailsPage.selectOptionFromDDList("Tool Name", objData.toolNameValue)).toContain("Pass");
  expect(await objDemoDetailsPage.getFieldValue("Tool ID"));
  
  expect(await objDemoDetailsPage.selectOptFromMultiSelectDDList("Chamber Position", "A~B~C")).toContain("Pass");
  expect(await objDemoDetailsPage.clickOnBtn("Schedule Assistant")).toContain("Pass");
  await browser.sleep(5000);
  
  // await objCommonPage.switchtoNewTab();
  // await browser.sleep(5000);
  // expect(await objMyLabPage.clickOnCalendarIcon("Start Date")).toContain("Pass");
  // // await objCommonPage.closeTab();
  // // await objCommonPage.switchtoParentTab();
  // await browser.sleep(5000); 
  // expect(await objDemoDetailsPage.clickOnCalendarIcon("Start Date")).toContain("Pass");
  // expect(await objDemoDetailsPage.clickOnCalendarIcon("New Schedule Start Date")).toContain("Pass"); 
  // expect(await objCommonPage.selectDateFromCalendar("Tomorrow"));
  // expect(await objDemoDetailsPage.setFieldValInDemoDtlsPage("Justification", "Testing"));
  // expect(await objCommonPage.takeActionOnAlert("Submit"));


  done();

});*/
});