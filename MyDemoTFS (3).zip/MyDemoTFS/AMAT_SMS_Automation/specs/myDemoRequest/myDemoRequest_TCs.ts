import {browser, element, ExpectedConditions, by} from 'protractor';
import {homePage} from '../../pages/homePage.po';
import { commonPage } from '../../pages/commonPage.po';
import { newDemoRequest } from '../../pages/newDemoRequest.po';
import { myDraftRequestPage } from '../../pages/myDraftRequestPage.po';
import { myDemoRequestPage } from '../../pages/myDemoRequestPage.po';
import { dataProvider} from "../../data/dataProvider";
import { loginPage } from '../../pages/loginPage.po';


describe('My Demo Request Test cases', () => {
    
    let objHomePage:homePage;
    let objNewDemoRequest:newDemoRequest;
    let objMyDraftRequest:myDraftRequestPage;
    let objCommonPage: commonPage;
    let objMyDemoRequest: myDemoRequestPage;
    let objLoginPage:loginPage;
    let objLoginData = dataProvider.getJsonData("./data/login.json", "login");
    let sDemoName;
    let sAlertMessage = "";

    beforeEach(async () => {
        objHomePage = new homePage();
        objNewDemoRequest = new newDemoRequest();
        objMyDraftRequest = new myDraftRequestPage();
        objCommonPage = new commonPage();
        objMyDemoRequest = new myDemoRequestPage();
        objLoginPage = new loginPage();
        await browser.waitForAngularEnabled(false);
        //Open application Url
        await objHomePage.openApplication('/');        
    });

    afterEach(() => {
        
    });
    it('TC_Pre-Requisite.', async(done)=>{
        let objData = dataProvider.getJsonData("./data/myDemoRequest.json", "TC_Pre-Requisite");
        console.log(objData);
        //Login My Demo application
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain("Pass");
        expect(await objLoginPage.clickLogin()).toContain("Pass");
        await browser.waitForAngularEnabled(true);
        expect(await objHomePage.verifyHomePageDisplayed()).toContain("Pass");
        //select menu option
        expect(await objHomePage.selectMenuOption('Requests', 'Create New Demo Request')).toContain("Pass");
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyBtnIsDisabled("Save As Draft")).toContain("Pass");
       
        var iRandomNum = Math.floor(1000 + Math.random() * 9000);
        sDemoName = "TestDemo_MyDemoRequest" + iRandomNum;
        console.log(sDemoName);
 
        expect(await objNewDemoRequest.enterDemoName(sDemoName)).toContain("Pass");
        expect(await objNewDemoRequest.selectAccount(objData.account)).toContain("Pass");
       
        expect(await objNewDemoRequest.selectPrimaryBU(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.toggleField('TAMBA', true)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnTAMBASearch()).toContain("Pass");
        expect(await objNewDemoRequest.selectFromBUOnTAMBAsearchPopUp(objData.primaryBu)).toContain("Pass");
        expect(await objNewDemoRequest.selectFromAccountOnTambaSearchPopUp(objData.account)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnGoOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.selectTambaRowOnTambaSearchPopUp()).toContain("Pass");
        expect(await objNewDemoRequest.clickOnSubmit()).toContain("Pass");
        
        expect(await objNewDemoRequest.setTextInField("HVP", objData.hvp)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnRequestedCompletionDate()).toContain("Pass");
        expect(await objCommonPage.selectDateFromdd("1", "March", "2021")).toContain("Pass");

        let sLoggedInUser;
        await objHomePage.getLoggedInUser().then(function(sUser){sLoggedInUser = sUser.trim();});
        expect(await objNewDemoRequest.setAccountOwner(sLoggedInUser)).toContain("Pass");
        expect(await objNewDemoRequest.selectDemoType(objData.demoType)).toContain("Pass");
        expect(await objNewDemoRequest.setSuccessCriteria(objData.successCriteria)).toContain("Pass");
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Next")).toContain("Pass");
        expect(await objNewDemoRequest.verifyCustomerSpecSectionDisplayed()).toContain("Pass");
        expect(await objNewDemoRequest.selectSubstrateType(objData.substrateType)).toContain("Pass");
        expect(await objNewDemoRequest.clickCustomerSpecOption(objData.customerSpecOption)).toContain("Pass");
        
        //expect(await objNewDemoRequest.uploadCustSpec("Error_On_VM_IN_WS_78.txt")).toBeTruthy();
        expect(await objNewDemoRequest.setAttributeCategory(objData.attributeCategory)).toContain("Pass");
        expect(await objNewDemoRequest.setAttribute(objData.attribute)).toContain("Pass");
        expect(await objNewDemoRequest.setMarketSegmentReq(objData.marketSegReq)).toContain("Pass");
        expect(await objNewDemoRequest.selectWeighPriority(objData.weightProperty)).toContain("Pass");
        expect(await objNewDemoRequest.clickOnAttributeSave()).toContain("Pass");;
        expect(await objNewDemoRequest.clickBtnOnNewRequestForm("Submit")).toContain("Pass");
        expect(await objMyDraftRequest.clickOnOkBtnOnPopUp()).toContain('Pass');
        done();
}); 
    it('TC_01-Verify that My Demo Request page is loading fine and user shall be able to check whether recently submitted demo by current logged in user is displaying in the top of demos list.', async(done)=>{
        let objData = dataProvider.getJsonData("./data/myDemoRequest.json", "TC_01");
        console.log(objData);
        expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
        expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
        expect(await objLoginPage.clickLogin()).toContain('Pass')
        await browser.waitForAngularEnabled(true);
        expect(await objHomePage.verifyHomePageDisplayed()).toContain('Pass');
        expect(await objHomePage.selectMenuOption('Requests', 'My Demo Request')).toContain('Pass');
        //let sLoggedInUser;
        await objHomePage.getLoggedInUser();
        expect(await objCommonPage.getTableHeaders()).toEqual(objData.headerLabelList);
        await objCommonPage.getTheLatestDemoNm();  
        expect(await objCommonPage.verifyHyperLink('Demo Number', sDemoName)).toContain('Pass');
        expect(await objCommonPage.verifySorting('Demo Number')).not.toContain('Pass');
        expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass'); 
        expect(await objCommonPage.clickInTheTableCell('Demo Number',sDemoName)).toContain('Pass')
        expect(await objNewDemoRequest.verifyOpportunityInfoSectionDisplayed()).toContain('Pass');
        done();
});
it('TC_02-"Verify that Demo Request present in My demo request section should have one of the below status.', async(done)=>{
        /*
        1.Pending Review ( Replace New Demo Request , Pending Estimation)
        2.ACL / Approved
        3.BCL / On hold
        4.Rejected 
        5.Cancelled
        6.Closed / Completed
        Note : Since we don’t need to wait for estimation to be completed to do the review no need to Pending estimation status
       */
    let objData = dataProvider.getJsonData("./data/myDemoRequest.json", "TC_02");
    console.log(objData);
    expect(await objLoginPage.setUserName(objLoginData.userNameGlobalAdmin)).toContain('Pass');
    expect(await objLoginPage.setPassword(objLoginData.passwordGlobalAdmin)).toContain('Pass');
    expect(await objLoginPage.clickLogin()).toContain('Pass')
    await browser.waitForAngularEnabled(true);
    expect(await objHomePage.verifyHomePageDisplayed()).toContain('Pass');
    expect(await objHomePage.selectMenuOption('Requests', 'My Demo Request')).toContain('Pass');
    //let sLoggedInUser;
    await objHomePage.getLoggedInUser();
    expect(await objCommonPage.searchRequest(sDemoName)).toContain('Pass');
    expect(objData.demoStatus).toContain(objCommonPage.getTableCellValue('Demo Approval',sDemoName,));
    done();  
});
});